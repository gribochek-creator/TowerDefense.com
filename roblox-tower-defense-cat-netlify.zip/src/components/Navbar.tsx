const React = __vite__cjsImport0_react;const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=1e19e0c2";
import { CAT_IMAGE_URL } from "/src/data/constants.ts";
var _jsxFileName = "/app/applet/src/components/Navbar.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=1e19e0c2";
export const Navbar = ({ user, difficulty, onChangeDifficulty, inGameCash, unreadNotifsCount, onOpenModal, onResetGame, onOpenSecretHint, onTriggerSecretKekc, onOpenNetlifyDownload }) => {
	const [glassesClicks, setGlassesClicks] = React.useState(0);
	const handleGlassesClick = (e) => {
		e.stopPropagation();
		const next = glassesClicks + 1;
		setGlassesClicks(next);
		if (next >= 3) {
			setGlassesClicks(0);
			onTriggerSecretKekc();
		}
	};
	return /* @__PURE__ */ _jsxDEV("header", {
		className: "bg-slate-950/95 backdrop-blur-md border-b border-slate-800 text-white sticky top-0 z-40 select-none shadow-xl",
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: "max-w-7xl mx-auto px-4 py-2.5 flex flex-wrap items-center justify-between gap-3",
			children: [
				/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center space-x-3 cursor-pointer",
					onClick: onResetGame,
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "relative w-10 h-10 rounded-xl overflow-hidden border-2 border-cyan-400 bg-slate-900 shadow-md group hover:border-pink-400 transition-colors",
						onClick: handleGlassesClick,
						title: "Очки Кота (Нажми 3 раза для пасхалки!)",
						children: [
							/* @__PURE__ */ _jsxDEV("img", {
								src: CAT_IMAGE_URL,
								alt: "Cat Hero",
								className: "w-full h-full object-cover"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 54,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ _jsxDEV("span", {
								className: "absolute -bottom-1 -right-1 text-xs group-hover:scale-125 transition-transform",
								children: "🕶️"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 55,
								columnNumber: 13
							}, this),
							glassesClicks > 0 && /* @__PURE__ */ _jsxDEV("span", {
								className: "absolute top-0 right-0 bg-pink-500 text-[9px] px-1 font-bold text-white rounded-bl",
								children: [glassesClicks, "/3"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 59,
								columnNumber: 15
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 49,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center space-x-1.5",
						children: [/* @__PURE__ */ _jsxDEV("span", {
							className: "text-xs font-black uppercase tracking-wider bg-rose-600 text-white px-1.5 py-0.5 rounded",
							children: "ROBLOX"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 66,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("h1", {
							className: "font-black text-base tracking-tight text-white flex items-center",
							children: "CAT TOWER DEFENSE"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 69,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 65,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "text-[10px] text-cyan-400 font-mono flex items-center space-x-2",
						children: [
							/* @__PURE__ */ _jsxDEV("span", { children: "● Облако: Синхронизировано" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 74,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("span", {
								className: "text-slate-500",
								children: "|"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 75,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("span", {
								className: "text-slate-400",
								children: [
									"Клан: [",
									user.clanName || "Без клана",
									"]"
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 76,
								columnNumber: 15
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 73,
						columnNumber: 13
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 64,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 48,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center space-x-1 bg-slate-900 border border-slate-800 rounded-xl p-1 text-xs font-bold",
					children: [/* @__PURE__ */ _jsxDEV("span", {
						className: "text-slate-400 px-2 hidden lg:inline",
						children: "Сложность:"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 83,
						columnNumber: 11
					}, this), [
						{
							id: "easy",
							label: "Лёгкий",
							color: "text-emerald-400"
						},
						{
							id: "normal",
							label: "Обычный",
							color: "text-cyan-400"
						},
						{
							id: "hard",
							label: "Хардкор",
							color: "text-amber-400"
						},
						{
							id: "insane",
							label: "Кошмар",
							color: "text-rose-500"
						}
					].map((item) => /* @__PURE__ */ _jsxDEV("button", {
						onClick: () => onChangeDifficulty(item.id),
						className: `px-2.5 py-1 rounded-lg transition-all ${difficulty === item.id ? "bg-slate-800 text-white border border-slate-700 shadow-sm" : "text-slate-400 hover:text-white"}`,
						children: /* @__PURE__ */ _jsxDEV("span", {
							className: difficulty === item.id ? item.color : "",
							children: item.label
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 101,
							columnNumber: 15
						}, this)
					}, item.id, false, {
						fileName: _jsxFileName,
						lineNumber: 92,
						columnNumber: 13
					}, this))]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 82,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center space-x-2.5 text-xs font-black",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "bg-emerald-950/80 border border-emerald-600/50 px-2.5 py-1 rounded-xl flex items-center space-x-1.5 text-emerald-400 shadow-sm",
							children: [/* @__PURE__ */ _jsxDEV("span", { children: "💵" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 110,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "font-mono text-sm",
								children: ["$", inGameCash]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 111,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 109,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							onClick: () => onOpenModal("shop"),
							className: "bg-amber-950/60 border border-amber-600/40 px-2.5 py-1 rounded-xl flex items-center space-x-1.5 text-amber-300 cursor-pointer hover:border-amber-400 transition-colors",
							title: "Монеты аккаунта",
							children: [/* @__PURE__ */ _jsxDEV("span", { children: "🪙" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 120,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "font-mono",
								children: user.coins.toLocaleString()
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 121,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 115,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							onClick: () => onOpenModal("shop"),
							className: "bg-cyan-950/60 border border-cyan-600/40 px-2.5 py-1 rounded-xl flex items-center space-x-1.5 text-cyan-300 cursor-pointer hover:border-cyan-400 transition-colors",
							title: "Донат-кристаллы",
							children: [/* @__PURE__ */ _jsxDEV("span", { children: "💎" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 130,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "font-mono",
								children: user.gems.toLocaleString()
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 131,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 125,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							onClick: () => onOpenModal("shop"),
							className: "bg-emerald-950/60 border border-emerald-600/40 px-2 py-1 rounded-xl flex items-center space-x-1 text-emerald-300 cursor-pointer hover:border-emerald-400 hidden sm:flex",
							title: "Баланс Robux",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "font-bold",
								children: "R$"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 140,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "font-mono",
								children: user.robux
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 141,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 135,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 107,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center space-x-1.5",
					children: [
						/* @__PURE__ */ _jsxDEV("button", {
							onClick: onOpenSecretHint,
							className: "relative px-2 py-1.5 opacity-20 hover:opacity-100 bg-white/5 hover:bg-pink-500/10 text-slate-400 hover:text-pink-300 border border-white/10 hover:border-pink-500/40 rounded-xl text-xs font-medium flex items-center space-x-1 transition-all duration-300 cursor-pointer",
							title: "Секретка? (Пасхалка)",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "text-xs",
								children: "🤫"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 153,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "text-[10px] hidden xl:inline",
								children: "?"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 154,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 148,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("button", {
							onClick: () => onOpenModal("daily"),
							className: "relative px-2.5 py-1.5 bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 rounded-xl text-xs font-bold flex items-center space-x-1 transition-all",
							title: "Ежедневные награды за вход",
							children: [
								/* @__PURE__ */ _jsxDEV("span", { children: "🎁" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 163,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("span", {
									className: "hidden md:inline",
									children: "Бонусы"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 164,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ _jsxDEV("span", { className: "w-2 h-2 rounded-full bg-amber-400 animate-ping absolute -top-1 -right-1" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 165,
									columnNumber: 13
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 158,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("button", {
							onClick: () => onOpenModal("weekly"),
							className: "px-2.5 py-1.5 bg-purple-500/20 hover:bg-purple-500/30 text-purple-300 border border-purple-500/40 rounded-xl text-xs font-bold flex items-center space-x-1 transition-all",
							title: "Еженедельное испытание",
							children: [/* @__PURE__ */ _jsxDEV("span", { children: "⚔️" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 174,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "hidden md:inline",
								children: "Испытание"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 175,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 169,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("button", {
							onClick: () => onOpenModal("coop"),
							className: "px-2.5 py-1.5 bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-300 border border-cyan-500/40 rounded-xl text-xs font-bold flex items-center space-x-1 transition-all",
							title: "Кооператив с друзьями",
							children: [/* @__PURE__ */ _jsxDEV("span", { children: "🤝" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 184,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "hidden md:inline",
								children: "Кооп"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 185,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 179,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("button", {
							onClick: () => onOpenModal("clans"),
							className: "px-2.5 py-1.5 bg-indigo-500/20 hover:bg-indigo-500/30 text-indigo-300 border border-indigo-500/40 rounded-xl text-xs font-bold flex items-center space-x-1 transition-all",
							title: "Система кланов",
							children: [/* @__PURE__ */ _jsxDEV("span", { children: "🏰" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 194,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "hidden md:inline",
								children: "Кланы"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 195,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 189,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("button", {
							onClick: () => onOpenModal("shop"),
							className: "px-2.5 py-1.5 bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/40 rounded-xl text-xs font-bold flex items-center space-x-1 transition-all",
							title: "Магазин скинов и доната",
							children: [/* @__PURE__ */ _jsxDEV("span", { children: "🛍️" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 204,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "hidden md:inline",
								children: "Магазин"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 205,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 199,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("button", {
							onClick: () => onOpenModal("leaderboard"),
							className: "p-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-sm",
							title: "Таблица лидеров",
							children: "🏆"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 209,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("button", {
							onClick: () => onOpenModal("achievements"),
							className: "p-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-sm",
							title: "Достижения",
							children: "🎖️"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 218,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("button", {
							onClick: () => onOpenModal("notifications"),
							className: "relative p-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-sm",
							title: "Уведомления и акции",
							children: ["🔔", unreadNotifsCount > 0 && /* @__PURE__ */ _jsxDEV("span", {
								className: "absolute -top-1 -right-1 w-4 h-4 rounded-full bg-rose-500 text-white text-[9px] font-bold flex items-center justify-center",
								children: unreadNotifsCount
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 234,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 227,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("button", {
							onClick: onOpenNetlifyDownload,
							className: "px-2.5 py-1.5 bg-teal-500/20 hover:bg-teal-500/30 text-teal-300 border border-teal-500/40 rounded-xl text-xs font-bold flex items-center space-x-1.5 transition-all shadow-sm active:scale-95 cursor-pointer",
							title: "Скачать все файлы для Netlify (ZIP)",
							children: [/* @__PURE__ */ _jsxDEV("span", { children: "📥" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 246,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "hidden md:inline",
								children: "Netlify"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 247,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 241,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("button", {
							onClick: () => onOpenModal("profile"),
							className: "flex items-center space-x-1.5 pl-1.5 pr-2 py-1 bg-slate-900 hover:bg-slate-800 border border-slate-700 rounded-xl text-xs font-bold text-slate-200 transition-all",
							title: "Личный кабинет и профиль",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "w-6 h-6 rounded-lg overflow-hidden bg-slate-950 border border-cyan-400",
								children: /* @__PURE__ */ _jsxDEV("img", {
									src: user.avatarUrl,
									alt: "Avatar",
									className: "w-full h-full object-cover"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 257,
									columnNumber: 15
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 256,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "max-w-[70px] truncate hidden sm:inline",
								children: user.username
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 259,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 251,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 146,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 46,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 45,
		columnNumber: 5
	}, this);
};

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxXQUFXO0FBRWxCLFNBQVMscUJBQXFCOzs7QUFpQjlCLE9BQU8sTUFBTSxVQUFpQyxFQUM1QyxNQUNBLFlBQ0Esb0JBQ0EsWUFDQSxtQkFDQSxhQUNBLGFBQ0Esa0JBQ0EscUJBQ0EsNEJBQ0k7Q0FDSixNQUFNLENBQUMsZUFBZSxvQkFBb0IsTUFBTSxTQUFTLENBQUM7Q0FFMUQsTUFBTSxzQkFBc0IsTUFBd0I7RUFDbEQsRUFBRSxnQkFBZ0I7RUFDbEIsTUFBTSxPQUFPLGdCQUFnQjtFQUM3QixpQkFBaUIsSUFBSTtFQUNyQixJQUFJLFFBQVEsR0FBRztHQUNiLGlCQUFpQixDQUFDO0dBQ2xCLG9CQUFvQjtFQUN0QjtDQUNGO0NBRUEsT0FDRSx3QkFBQyxVQUFEO0VBQVEsV0FBVTtZQUNoQix3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFmO0lBRUUsd0JBQUMsT0FBRDtLQUFLLFdBQVU7S0FBNkMsU0FBUztlQUFyRSxDQUNFLHdCQUFDLE9BQUQ7TUFDRSxXQUFVO01BQ1YsU0FBUztNQUNULE9BQU07Z0JBSFI7T0FLRSx3QkFBQyxPQUFEO1FBQUssS0FBSztRQUFlLEtBQUk7UUFBVyxXQUFVO09BQThCOzs7OztPQUNoRix3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBaUY7T0FFM0Y7Ozs7O09BQ0wsZ0JBQWdCLEtBQ2Ysd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQWhCLENBQ0csZUFBYyxJQUNYOzs7Ozs7TUFFTDs7Ozs7ZUFDTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxRQUFEO09BQU0sV0FBVTtpQkFBMkY7TUFFckc7Ozs7Z0JBQ04sd0JBQUMsTUFBRDtPQUFJLFdBQVU7aUJBQW1FO01BRTdFOzs7O2NBQ0Q7Ozs7O2VBQ0wsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWY7T0FDRSx3QkFBQyxRQUFELFlBQU0sNkJBQWdDOzs7OztPQUN0Qyx3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBaUI7T0FBTzs7Ozs7T0FDeEMsd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQWhCO1NBQWlDO1NBQVEsS0FBSyxZQUFZO1NBQVk7UUFBTzs7Ozs7O01BQzFFOzs7OzthQUNGOzs7O2FBQ0Y7Ozs7OztJQUdMLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxRQUFEO01BQU0sV0FBVTtnQkFBdUM7S0FBZ0I7Ozs7ZUFFckU7TUFDRTtPQUFFLElBQUk7T0FBUSxPQUFPO09BQVUsT0FBTztNQUFtQjtNQUN6RDtPQUFFLElBQUk7T0FBVSxPQUFPO09BQVcsT0FBTztNQUFnQjtNQUN6RDtPQUFFLElBQUk7T0FBUSxPQUFPO09BQVcsT0FBTztNQUFpQjtNQUN4RDtPQUFFLElBQUk7T0FBVSxPQUFPO09BQVUsT0FBTztNQUFnQjtLQUMxRCxDQUFDLENBQ0QsS0FBSyxTQUNMLHdCQUFDLFVBQUQ7TUFFRSxlQUFlLG1CQUFtQixLQUFLLEVBQUU7TUFDekMsV0FBVyx5Q0FDVCxlQUFlLEtBQUssS0FDaEIsOERBQ0E7Z0JBR04sd0JBQUMsUUFBRDtPQUFNLFdBQVcsZUFBZSxLQUFLLEtBQUssS0FBSyxRQUFRO2lCQUFLLEtBQUs7TUFBWTs7Ozs7S0FDdkUsR0FURCxLQUFLOzs7O1lBU0osQ0FDVCxDQUNFOzs7Ozs7SUFHTCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmO01BRUUsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxRQUFELFlBQU0sS0FBUTs7OztpQkFDZCx3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBaEIsQ0FBb0MsS0FBRSxVQUFpQjs7Ozs7ZUFDcEQ7Ozs7OztNQUdMLHdCQUFDLE9BQUQ7T0FDRSxlQUFlLFlBQVksTUFBTTtPQUNqQyxXQUFVO09BQ1YsT0FBTTtpQkFIUixDQUtFLHdCQUFDLFFBQUQsWUFBTSxLQUFROzs7O2lCQUNkLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUFhLEtBQUssTUFBTSxlQUFlO09BQVE7Ozs7ZUFDNUQ7Ozs7OztNQUdMLHdCQUFDLE9BQUQ7T0FDRSxlQUFlLFlBQVksTUFBTTtPQUNqQyxXQUFVO09BQ1YsT0FBTTtpQkFIUixDQUtFLHdCQUFDLFFBQUQsWUFBTSxLQUFROzs7O2lCQUNkLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUFhLEtBQUssS0FBSyxlQUFlO09BQVE7Ozs7ZUFDM0Q7Ozs7OztNQUdMLHdCQUFDLE9BQUQ7T0FDRSxlQUFlLFlBQVksTUFBTTtPQUNqQyxXQUFVO09BQ1YsT0FBTTtpQkFIUixDQUtFLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUFZO09BQVE7Ozs7aUJBQ3BDLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUFhLEtBQUs7T0FBWTs7OztlQUMzQzs7Ozs7O0tBQ0Y7Ozs7OztJQUdMLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWY7TUFFRSx3QkFBQyxVQUFEO09BQ0UsU0FBUztPQUNULFdBQVU7T0FDVixPQUFNO2lCQUhSLENBS0Usd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQVU7T0FBUTs7OztpQkFDbEMsd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQStCO09BQU87Ozs7ZUFDaEQ7Ozs7OztNQUdSLHdCQUFDLFVBQUQ7T0FDRSxlQUFlLFlBQVksT0FBTztPQUNsQyxXQUFVO09BQ1YsT0FBTTtpQkFIUjtRQUtFLHdCQUFDLFFBQUQsWUFBTSxLQUFROzs7OztRQUNkLHdCQUFDLFFBQUQ7U0FBTSxXQUFVO21CQUFtQjtRQUFZOzs7OztRQUMvQyx3QkFBQyxRQUFELEVBQU0sV0FBVSwwRUFBMkU7Ozs7O09BQ3JGOzs7Ozs7TUFHUix3QkFBQyxVQUFEO09BQ0UsZUFBZSxZQUFZLFFBQVE7T0FDbkMsV0FBVTtPQUNWLE9BQU07aUJBSFIsQ0FLRSx3QkFBQyxRQUFELFlBQU0sS0FBUTs7OztpQkFDZCx3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBbUI7T0FBZTs7OztlQUM1Qzs7Ozs7O01BR1Isd0JBQUMsVUFBRDtPQUNFLGVBQWUsWUFBWSxNQUFNO09BQ2pDLFdBQVU7T0FDVixPQUFNO2lCQUhSLENBS0Usd0JBQUMsUUFBRCxZQUFNLEtBQVE7Ozs7aUJBQ2Qsd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQW1CO09BQVU7Ozs7ZUFDdkM7Ozs7OztNQUdSLHdCQUFDLFVBQUQ7T0FDRSxlQUFlLFlBQVksT0FBTztPQUNsQyxXQUFVO09BQ1YsT0FBTTtpQkFIUixDQUtFLHdCQUFDLFFBQUQsWUFBTSxLQUFROzs7O2lCQUNkLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUFtQjtPQUFXOzs7O2VBQ3hDOzs7Ozs7TUFHUix3QkFBQyxVQUFEO09BQ0UsZUFBZSxZQUFZLE1BQU07T0FDakMsV0FBVTtPQUNWLE9BQU07aUJBSFIsQ0FLRSx3QkFBQyxRQUFELFlBQU0sTUFBUzs7OztpQkFDZix3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBbUI7T0FBYTs7OztlQUMxQzs7Ozs7O01BR1Isd0JBQUMsVUFBRDtPQUNFLGVBQWUsWUFBWSxhQUFhO09BQ3hDLFdBQVU7T0FDVixPQUFNO2lCQUNQO01BRU87Ozs7O01BR1Isd0JBQUMsVUFBRDtPQUNFLGVBQWUsWUFBWSxjQUFjO09BQ3pDLFdBQVU7T0FDVixPQUFNO2lCQUNQO01BRU87Ozs7O01BR1Isd0JBQUMsVUFBRDtPQUNFLGVBQWUsWUFBWSxlQUFlO09BQzFDLFdBQVU7T0FDVixPQUFNO2lCQUhSLENBSUMsTUFFRSxvQkFBb0IsS0FDbkIsd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQ2I7T0FDRzs7OztlQUVGOzs7Ozs7TUFHUix3QkFBQyxVQUFEO09BQ0UsU0FBUztPQUNULFdBQVU7T0FDVixPQUFNO2lCQUhSLENBS0Usd0JBQUMsUUFBRCxZQUFNLEtBQVE7Ozs7aUJBQ2Qsd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQW1CO09BQWE7Ozs7ZUFDMUM7Ozs7OztNQUdSLHdCQUFDLFVBQUQ7T0FDRSxlQUFlLFlBQVksU0FBUztPQUNwQyxXQUFVO09BQ1YsT0FBTTtpQkFIUixDQUtFLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUNiLHdCQUFDLE9BQUQ7U0FBSyxLQUFLLEtBQUs7U0FBVyxLQUFJO1NBQVMsV0FBVTtRQUE4Qjs7Ozs7T0FDNUU7Ozs7aUJBQ0wsd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQTBDLEtBQUs7T0FBZTs7OztlQUN4RTs7Ozs7O0tBQ0w7Ozs7OztHQUNGOzs7Ozs7Q0FDQzs7Ozs7QUFFWiIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJOYXZiYXIudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBVc2VyUHJvZmlsZSwgRGlmZmljdWx0eSB9IGZyb20gJy4uL3R5cGVzL2dhbWUnO1xuaW1wb3J0IHsgQ0FUX0lNQUdFX1VSTCB9IGZyb20gJy4uL2RhdGEvY29uc3RhbnRzJztcblxuaW50ZXJmYWNlIE5hdmJhclByb3BzIHtcbiAgdXNlcjogVXNlclByb2ZpbGU7XG4gIGRpZmZpY3VsdHk6IERpZmZpY3VsdHk7XG4gIG9uQ2hhbmdlRGlmZmljdWx0eTogKGRpZmY6IERpZmZpY3VsdHkpID0+IHZvaWQ7XG4gIGluR2FtZUNhc2g6IG51bWJlcjtcbiAgdW5yZWFkTm90aWZzQ291bnQ6IG51bWJlcjtcbiAgb25PcGVuTW9kYWw6IChcbiAgICBtb2RhbDogJ2RhaWx5JyB8ICdzaG9wJyB8ICdjbGFucycgfCAnbGVhZGVyYm9hcmQnIHwgJ3dlZWtseScgfCAnY29vcCcgfCAnYWNoaWV2ZW1lbnRzJyB8ICdwcm9maWxlJyB8ICdub3RpZmljYXRpb25zJ1xuICApID0+IHZvaWQ7XG4gIG9uUmVzZXRHYW1lOiAoKSA9PiB2b2lkO1xuICBvbk9wZW5TZWNyZXRIaW50OiAoKSA9PiB2b2lkO1xuICBvblRyaWdnZXJTZWNyZXRLZWtjOiAoKSA9PiB2b2lkO1xuICBvbk9wZW5OZXRsaWZ5RG93bmxvYWQ6ICgpID0+IHZvaWQ7XG59XG5cbmV4cG9ydCBjb25zdCBOYXZiYXI6IFJlYWN0LkZDPE5hdmJhclByb3BzPiA9ICh7XG4gIHVzZXIsXG4gIGRpZmZpY3VsdHksXG4gIG9uQ2hhbmdlRGlmZmljdWx0eSxcbiAgaW5HYW1lQ2FzaCxcbiAgdW5yZWFkTm90aWZzQ291bnQsXG4gIG9uT3Blbk1vZGFsLFxuICBvblJlc2V0R2FtZSxcbiAgb25PcGVuU2VjcmV0SGludCxcbiAgb25UcmlnZ2VyU2VjcmV0S2VrYyxcbiAgb25PcGVuTmV0bGlmeURvd25sb2FkLFxufSkgPT4ge1xuICBjb25zdCBbZ2xhc3Nlc0NsaWNrcywgc2V0R2xhc3Nlc0NsaWNrc10gPSBSZWFjdC51c2VTdGF0ZSgwKTtcblxuICBjb25zdCBoYW5kbGVHbGFzc2VzQ2xpY2sgPSAoZTogUmVhY3QuTW91c2VFdmVudCkgPT4ge1xuICAgIGUuc3RvcFByb3BhZ2F0aW9uKCk7XG4gICAgY29uc3QgbmV4dCA9IGdsYXNzZXNDbGlja3MgKyAxO1xuICAgIHNldEdsYXNzZXNDbGlja3MobmV4dCk7XG4gICAgaWYgKG5leHQgPj0gMykge1xuICAgICAgc2V0R2xhc3Nlc0NsaWNrcygwKTtcbiAgICAgIG9uVHJpZ2dlclNlY3JldEtla2MoKTtcbiAgICB9XG4gIH07XG5cbiAgcmV0dXJuIChcbiAgICA8aGVhZGVyIGNsYXNzTmFtZT1cImJnLXNsYXRlLTk1MC85NSBiYWNrZHJvcC1ibHVyLW1kIGJvcmRlci1iIGJvcmRlci1zbGF0ZS04MDAgdGV4dC13aGl0ZSBzdGlja3kgdG9wLTAgei00MCBzZWxlY3Qtbm9uZSBzaGFkb3cteGxcIj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWF4LXctN3hsIG14LWF1dG8gcHgtNCBweS0yLjUgZmxleCBmbGV4LXdyYXAgaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtM1wiPlxuICAgICAgICB7LyogQnJhbmQgJiBSb2Jsb3ggQmxveCBMb2dvICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIHNwYWNlLXgtMyBjdXJzb3ItcG9pbnRlclwiIG9uQ2xpY2s9e29uUmVzZXRHYW1lfT5cbiAgICAgICAgICA8ZGl2XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJyZWxhdGl2ZSB3LTEwIGgtMTAgcm91bmRlZC14bCBvdmVyZmxvdy1oaWRkZW4gYm9yZGVyLTIgYm9yZGVyLWN5YW4tNDAwIGJnLXNsYXRlLTkwMCBzaGFkb3ctbWQgZ3JvdXAgaG92ZXI6Ym9yZGVyLXBpbmstNDAwIHRyYW5zaXRpb24tY29sb3JzXCJcbiAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZUdsYXNzZXNDbGlja31cbiAgICAgICAgICAgIHRpdGxlPVwi0J7Rh9C60Lgg0JrQvtGC0LAgKNCd0LDQttC80LggMyDRgNCw0LfQsCDQtNC70Y8g0L/QsNGB0YXQsNC70LrQuCEpXCJcbiAgICAgICAgICA+XG4gICAgICAgICAgICA8aW1nIHNyYz17Q0FUX0lNQUdFX1VSTH0gYWx0PVwiQ2F0IEhlcm9cIiBjbGFzc05hbWU9XCJ3LWZ1bGwgaC1mdWxsIG9iamVjdC1jb3ZlclwiIC8+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJhYnNvbHV0ZSAtYm90dG9tLTEgLXJpZ2h0LTEgdGV4dC14cyBncm91cC1ob3ZlcjpzY2FsZS0xMjUgdHJhbnNpdGlvbi10cmFuc2Zvcm1cIj5cbiAgICAgICAgICAgICAg8J+Vtu+4j1xuICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAge2dsYXNzZXNDbGlja3MgPiAwICYmIChcbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiYWJzb2x1dGUgdG9wLTAgcmlnaHQtMCBiZy1waW5rLTUwMCB0ZXh0LVs5cHhdIHB4LTEgZm9udC1ib2xkIHRleHQtd2hpdGUgcm91bmRlZC1ibFwiPlxuICAgICAgICAgICAgICAgIHtnbGFzc2VzQ2xpY2tzfS8zXG4gICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICl9XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgc3BhY2UteC0xLjVcIj5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJsYWNrIHVwcGVyY2FzZSB0cmFja2luZy13aWRlciBiZy1yb3NlLTYwMCB0ZXh0LXdoaXRlIHB4LTEuNSBweS0wLjUgcm91bmRlZFwiPlxuICAgICAgICAgICAgICAgIFJPQkxPWFxuICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJmb250LWJsYWNrIHRleHQtYmFzZSB0cmFja2luZy10aWdodCB0ZXh0LXdoaXRlIGZsZXggaXRlbXMtY2VudGVyXCI+XG4gICAgICAgICAgICAgICAgQ0FUIFRPV0VSIERFRkVOU0VcbiAgICAgICAgICAgICAgPC9oMT5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB0ZXh0LWN5YW4tNDAwIGZvbnQtbW9ubyBmbGV4IGl0ZW1zLWNlbnRlciBzcGFjZS14LTJcIj5cbiAgICAgICAgICAgICAgPHNwYW4+4pePINCe0LHQu9Cw0LrQvjog0KHQuNC90YXRgNC+0L3QuNC30LjRgNC+0LLQsNC90L48L3NwYW4+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNTAwXCI+fDwvc3Bhbj5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS00MDBcIj7QmtC70LDQvTogW3t1c2VyLmNsYW5OYW1lIHx8ICfQkdC10Lcg0LrQu9Cw0L3QsCd9XTwvc3Bhbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICB7LyogRGlmZmljdWx0eSBTZWxlY3Rpb24gKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgc3BhY2UteC0xIGJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLXhsIHAtMSB0ZXh0LXhzIGZvbnQtYm9sZFwiPlxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNDAwIHB4LTIgaGlkZGVuIGxnOmlubGluZVwiPtCh0LvQvtC20L3QvtGB0YLRjDo8L3NwYW4+XG4gICAgICAgICAgeyhcbiAgICAgICAgICAgIFtcbiAgICAgICAgICAgICAgeyBpZDogJ2Vhc3knLCBsYWJlbDogJ9Cb0ZHQs9C60LjQuScsIGNvbG9yOiAndGV4dC1lbWVyYWxkLTQwMCcgfSxcbiAgICAgICAgICAgICAgeyBpZDogJ25vcm1hbCcsIGxhYmVsOiAn0J7QsdGL0YfQvdGL0LknLCBjb2xvcjogJ3RleHQtY3lhbi00MDAnIH0sXG4gICAgICAgICAgICAgIHsgaWQ6ICdoYXJkJywgbGFiZWw6ICfQpdCw0YDQtNC60L7RgCcsIGNvbG9yOiAndGV4dC1hbWJlci00MDAnIH0sXG4gICAgICAgICAgICAgIHsgaWQ6ICdpbnNhbmUnLCBsYWJlbDogJ9Ca0L7RiNC80LDRgCcsIGNvbG9yOiAndGV4dC1yb3NlLTUwMCcgfSxcbiAgICAgICAgICAgIF0gYXMgY29uc3RcbiAgICAgICAgICApLm1hcCgoaXRlbSkgPT4gKFxuICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICBrZXk9e2l0ZW0uaWR9XG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG9uQ2hhbmdlRGlmZmljdWx0eShpdGVtLmlkKX1cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcHgtMi41IHB5LTEgcm91bmRlZC1sZyB0cmFuc2l0aW9uLWFsbCAke1xuICAgICAgICAgICAgICAgIGRpZmZpY3VsdHkgPT09IGl0ZW0uaWRcbiAgICAgICAgICAgICAgICAgID8gJ2JnLXNsYXRlLTgwMCB0ZXh0LXdoaXRlIGJvcmRlciBib3JkZXItc2xhdGUtNzAwIHNoYWRvdy1zbSdcbiAgICAgICAgICAgICAgICAgIDogJ3RleHQtc2xhdGUtNDAwIGhvdmVyOnRleHQtd2hpdGUnXG4gICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2RpZmZpY3VsdHkgPT09IGl0ZW0uaWQgPyBpdGVtLmNvbG9yIDogJyd9PntpdGVtLmxhYmVsfTwvc3Bhbj5cbiAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICkpfVxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICB7LyogSW4tR2FtZSBDdXJyZW5jaWVzICYgQ2FzaCAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBzcGFjZS14LTIuNSB0ZXh0LXhzIGZvbnQtYmxhY2tcIj5cbiAgICAgICAgICB7LyogQmF0dGxlIENhc2ggKi99XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1lbWVyYWxkLTk1MC84MCBib3JkZXIgYm9yZGVyLWVtZXJhbGQtNjAwLzUwIHB4LTIuNSBweS0xIHJvdW5kZWQteGwgZmxleCBpdGVtcy1jZW50ZXIgc3BhY2UteC0xLjUgdGV4dC1lbWVyYWxkLTQwMCBzaGFkb3ctc21cIj5cbiAgICAgICAgICAgIDxzcGFuPvCfkrU8L3NwYW4+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LW1vbm8gdGV4dC1zbVwiPiR7aW5HYW1lQ2FzaH08L3NwYW4+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICB7LyogQWNjb3VudCBDb2lucyAqL31cbiAgICAgICAgICA8ZGl2XG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBvbk9wZW5Nb2RhbCgnc2hvcCcpfVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctYW1iZXItOTUwLzYwIGJvcmRlciBib3JkZXItYW1iZXItNjAwLzQwIHB4LTIuNSBweS0xIHJvdW5kZWQteGwgZmxleCBpdGVtcy1jZW50ZXIgc3BhY2UteC0xLjUgdGV4dC1hbWJlci0zMDAgY3Vyc29yLXBvaW50ZXIgaG92ZXI6Ym9yZGVyLWFtYmVyLTQwMCB0cmFuc2l0aW9uLWNvbG9yc1wiXG4gICAgICAgICAgICB0aXRsZT1cItCc0L7QvdC10YLRiyDQsNC60LrQsNGD0L3RgtCwXCJcbiAgICAgICAgICA+XG4gICAgICAgICAgICA8c3Bhbj7wn6qZPC9zcGFuPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1tb25vXCI+e3VzZXIuY29pbnMudG9Mb2NhbGVTdHJpbmcoKX08L3NwYW4+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICB7LyogQWNjb3VudCBHZW1zICovfVxuICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG9uT3Blbk1vZGFsKCdzaG9wJyl9XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1jeWFuLTk1MC82MCBib3JkZXIgYm9yZGVyLWN5YW4tNjAwLzQwIHB4LTIuNSBweS0xIHJvdW5kZWQteGwgZmxleCBpdGVtcy1jZW50ZXIgc3BhY2UteC0xLjUgdGV4dC1jeWFuLTMwMCBjdXJzb3ItcG9pbnRlciBob3Zlcjpib3JkZXItY3lhbi00MDAgdHJhbnNpdGlvbi1jb2xvcnNcIlxuICAgICAgICAgICAgdGl0bGU9XCLQlNC+0L3QsNGCLdC60YDQuNGB0YLQsNC70LvRi1wiXG4gICAgICAgICAgPlxuICAgICAgICAgICAgPHNwYW4+8J+Sjjwvc3Bhbj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbW9ub1wiPnt1c2VyLmdlbXMudG9Mb2NhbGVTdHJpbmcoKX08L3NwYW4+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICB7LyogUm9idXggKi99XG4gICAgICAgICAgPGRpdlxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gb25PcGVuTW9kYWwoJ3Nob3AnKX1cbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLWVtZXJhbGQtOTUwLzYwIGJvcmRlciBib3JkZXItZW1lcmFsZC02MDAvNDAgcHgtMiBweS0xIHJvdW5kZWQteGwgZmxleCBpdGVtcy1jZW50ZXIgc3BhY2UteC0xIHRleHQtZW1lcmFsZC0zMDAgY3Vyc29yLXBvaW50ZXIgaG92ZXI6Ym9yZGVyLWVtZXJhbGQtNDAwIGhpZGRlbiBzbTpmbGV4XCJcbiAgICAgICAgICAgIHRpdGxlPVwi0JHQsNC70LDQvdGBIFJvYnV4XCJcbiAgICAgICAgICA+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LWJvbGRcIj5SJDwvc3Bhbj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbW9ub1wiPnt1c2VyLnJvYnV4fTwvc3Bhbj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgey8qIE1vZGFscyAmIFByb2ZpbGUgVHJpZ2dlciBIdWIgKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgc3BhY2UteC0xLjVcIj5cbiAgICAgICAgICB7LyogU2VjcmV0IEhpbnQgQnV0dG9uIChWZXJ5IHRyYW5zcGFyZW50IGVhc3RlciBlZ2cpICovfVxuICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgIG9uQ2xpY2s9e29uT3BlblNlY3JldEhpbnR9XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJyZWxhdGl2ZSBweC0yIHB5LTEuNSBvcGFjaXR5LTIwIGhvdmVyOm9wYWNpdHktMTAwIGJnLXdoaXRlLzUgaG92ZXI6YmctcGluay01MDAvMTAgdGV4dC1zbGF0ZS00MDAgaG92ZXI6dGV4dC1waW5rLTMwMCBib3JkZXIgYm9yZGVyLXdoaXRlLzEwIGhvdmVyOmJvcmRlci1waW5rLTUwMC80MCByb3VuZGVkLXhsIHRleHQteHMgZm9udC1tZWRpdW0gZmxleCBpdGVtcy1jZW50ZXIgc3BhY2UteC0xIHRyYW5zaXRpb24tYWxsIGR1cmF0aW9uLTMwMCBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICB0aXRsZT1cItCh0LXQutGA0LXRgtC60LA/ICjQn9Cw0YHRhdCw0LvQutCwKVwiXG4gICAgICAgICAgPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14c1wiPvCfpKs8L3NwYW4+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSBoaWRkZW4geGw6aW5saW5lXCI+Pzwvc3Bhbj5cbiAgICAgICAgICA8L2J1dHRvbj5cblxuICAgICAgICAgIHsvKiBEYWlseSBSZXdhcmRzIEJ1dHRvbiAqL31cbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBvbk9wZW5Nb2RhbCgnZGFpbHknKX1cbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInJlbGF0aXZlIHB4LTIuNSBweS0xLjUgYmctYW1iZXItNTAwLzIwIGhvdmVyOmJnLWFtYmVyLTUwMC8zMCB0ZXh0LWFtYmVyLTMwMCBib3JkZXIgYm9yZGVyLWFtYmVyLTUwMC80MCByb3VuZGVkLXhsIHRleHQteHMgZm9udC1ib2xkIGZsZXggaXRlbXMtY2VudGVyIHNwYWNlLXgtMSB0cmFuc2l0aW9uLWFsbFwiXG4gICAgICAgICAgICB0aXRsZT1cItCV0LbQtdC00L3QtdCy0L3Ri9C1INC90LDQs9GA0LDQtNGLINC30LAg0LLRhdC+0LRcIlxuICAgICAgICAgID5cbiAgICAgICAgICAgIDxzcGFuPvCfjoE8L3NwYW4+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJoaWRkZW4gbWQ6aW5saW5lXCI+0JHQvtC90YPRgdGLPC9zcGFuPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidy0yIGgtMiByb3VuZGVkLWZ1bGwgYmctYW1iZXItNDAwIGFuaW1hdGUtcGluZyBhYnNvbHV0ZSAtdG9wLTEgLXJpZ2h0LTFcIiAvPlxuICAgICAgICAgIDwvYnV0dG9uPlxuXG4gICAgICAgICAgey8qIFdlZWtseSBDaGFsbGVuZ2VzICovfVxuICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG9uT3Blbk1vZGFsKCd3ZWVrbHknKX1cbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTIuNSBweS0xLjUgYmctcHVycGxlLTUwMC8yMCBob3ZlcjpiZy1wdXJwbGUtNTAwLzMwIHRleHQtcHVycGxlLTMwMCBib3JkZXIgYm9yZGVyLXB1cnBsZS01MDAvNDAgcm91bmRlZC14bCB0ZXh0LXhzIGZvbnQtYm9sZCBmbGV4IGl0ZW1zLWNlbnRlciBzcGFjZS14LTEgdHJhbnNpdGlvbi1hbGxcIlxuICAgICAgICAgICAgdGl0bGU9XCLQldC20LXQvdC10LTQtdC70YzQvdC+0LUg0LjRgdC/0YvRgtCw0L3QuNC1XCJcbiAgICAgICAgICA+XG4gICAgICAgICAgICA8c3Bhbj7impTvuI88L3NwYW4+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJoaWRkZW4gbWQ6aW5saW5lXCI+0JjRgdC/0YvRgtCw0L3QuNC1PC9zcGFuPlxuICAgICAgICAgIDwvYnV0dG9uPlxuXG4gICAgICAgICAgey8qIENvLW9wIExvYmJ5ICovfVxuICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG9uT3Blbk1vZGFsKCdjb29wJyl9XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJweC0yLjUgcHktMS41IGJnLWN5YW4tNTAwLzIwIGhvdmVyOmJnLWN5YW4tNTAwLzMwIHRleHQtY3lhbi0zMDAgYm9yZGVyIGJvcmRlci1jeWFuLTUwMC80MCByb3VuZGVkLXhsIHRleHQteHMgZm9udC1ib2xkIGZsZXggaXRlbXMtY2VudGVyIHNwYWNlLXgtMSB0cmFuc2l0aW9uLWFsbFwiXG4gICAgICAgICAgICB0aXRsZT1cItCa0L7QvtC/0LXRgNCw0YLQuNCyINGBINC00YDRg9C30YzRj9C80LhcIlxuICAgICAgICAgID5cbiAgICAgICAgICAgIDxzcGFuPvCfpJ08L3NwYW4+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJoaWRkZW4gbWQ6aW5saW5lXCI+0JrQvtC+0L88L3NwYW4+XG4gICAgICAgICAgPC9idXR0b24+XG5cbiAgICAgICAgICB7LyogQ2xhbnMgKi99XG4gICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gb25PcGVuTW9kYWwoJ2NsYW5zJyl9XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJweC0yLjUgcHktMS41IGJnLWluZGlnby01MDAvMjAgaG92ZXI6YmctaW5kaWdvLTUwMC8zMCB0ZXh0LWluZGlnby0zMDAgYm9yZGVyIGJvcmRlci1pbmRpZ28tNTAwLzQwIHJvdW5kZWQteGwgdGV4dC14cyBmb250LWJvbGQgZmxleCBpdGVtcy1jZW50ZXIgc3BhY2UteC0xIHRyYW5zaXRpb24tYWxsXCJcbiAgICAgICAgICAgIHRpdGxlPVwi0KHQuNGB0YLQtdC80LAg0LrQu9Cw0L3QvtCyXCJcbiAgICAgICAgICA+XG4gICAgICAgICAgICA8c3Bhbj7wn4+wPC9zcGFuPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiaGlkZGVuIG1kOmlubGluZVwiPtCa0LvQsNC90Ys8L3NwYW4+XG4gICAgICAgICAgPC9idXR0b24+XG5cbiAgICAgICAgICB7LyogU2hvcCAqL31cbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBvbk9wZW5Nb2RhbCgnc2hvcCcpfVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtMi41IHB5LTEuNSBiZy1lbWVyYWxkLTUwMC8yMCBob3ZlcjpiZy1lbWVyYWxkLTUwMC8zMCB0ZXh0LWVtZXJhbGQtMzAwIGJvcmRlciBib3JkZXItZW1lcmFsZC01MDAvNDAgcm91bmRlZC14bCB0ZXh0LXhzIGZvbnQtYm9sZCBmbGV4IGl0ZW1zLWNlbnRlciBzcGFjZS14LTEgdHJhbnNpdGlvbi1hbGxcIlxuICAgICAgICAgICAgdGl0bGU9XCLQnNCw0LPQsNC30LjQvSDRgdC60LjQvdC+0LIg0Lgg0LTQvtC90LDRgtCwXCJcbiAgICAgICAgICA+XG4gICAgICAgICAgICA8c3Bhbj7wn5uN77iPPC9zcGFuPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiaGlkZGVuIG1kOmlubGluZVwiPtCc0LDQs9Cw0LfQuNC9PC9zcGFuPlxuICAgICAgICAgIDwvYnV0dG9uPlxuXG4gICAgICAgICAgey8qIExlYWRlcmJvYXJkICovfVxuICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG9uT3Blbk1vZGFsKCdsZWFkZXJib2FyZCcpfVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwicC0xLjUgYmctc2xhdGUtODAwIGhvdmVyOmJnLXNsYXRlLTcwMCB0ZXh0LXNsYXRlLTMwMCByb3VuZGVkLXhsIHRleHQtc21cIlxuICAgICAgICAgICAgdGl0bGU9XCLQotCw0LHQu9C40YbQsCDQu9C40LTQtdGA0L7QslwiXG4gICAgICAgICAgPlxuICAgICAgICAgICAg8J+PhlxuICAgICAgICAgIDwvYnV0dG9uPlxuXG4gICAgICAgICAgey8qIEFjaGlldmVtZW50cyAqL31cbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBvbk9wZW5Nb2RhbCgnYWNoaWV2ZW1lbnRzJyl9XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJwLTEuNSBiZy1zbGF0ZS04MDAgaG92ZXI6Ymctc2xhdGUtNzAwIHRleHQtc2xhdGUtMzAwIHJvdW5kZWQteGwgdGV4dC1zbVwiXG4gICAgICAgICAgICB0aXRsZT1cItCU0L7RgdGC0LjQttC10L3QuNGPXCJcbiAgICAgICAgICA+XG4gICAgICAgICAgICDwn46W77iPXG4gICAgICAgICAgPC9idXR0b24+XG5cbiAgICAgICAgICB7LyogTm90aWZpY2F0aW9ucyAqL31cbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBvbk9wZW5Nb2RhbCgnbm90aWZpY2F0aW9ucycpfVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwicmVsYXRpdmUgcC0xLjUgYmctc2xhdGUtODAwIGhvdmVyOmJnLXNsYXRlLTcwMCB0ZXh0LXNsYXRlLTMwMCByb3VuZGVkLXhsIHRleHQtc21cIlxuICAgICAgICAgICAgdGl0bGU9XCLQo9Cy0LXQtNC+0LzQu9C10L3QuNGPINC4INCw0LrRhtC40LhcIlxuICAgICAgICAgID5cbiAgICAgICAgICAgIPCflJRcbiAgICAgICAgICAgIHt1bnJlYWROb3RpZnNDb3VudCA+IDAgJiYgKFxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJhYnNvbHV0ZSAtdG9wLTEgLXJpZ2h0LTEgdy00IGgtNCByb3VuZGVkLWZ1bGwgYmctcm9zZS01MDAgdGV4dC13aGl0ZSB0ZXh0LVs5cHhdIGZvbnQtYm9sZCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlclwiPlxuICAgICAgICAgICAgICAgIHt1bnJlYWROb3RpZnNDb3VudH1cbiAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgKX1cbiAgICAgICAgICA8L2J1dHRvbj5cblxuICAgICAgICAgIHsvKiBOZXRsaWZ5IERvd25sb2FkIEJ1dHRvbiAqL31cbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICBvbkNsaWNrPXtvbk9wZW5OZXRsaWZ5RG93bmxvYWR9XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJweC0yLjUgcHktMS41IGJnLXRlYWwtNTAwLzIwIGhvdmVyOmJnLXRlYWwtNTAwLzMwIHRleHQtdGVhbC0zMDAgYm9yZGVyIGJvcmRlci10ZWFsLTUwMC80MCByb3VuZGVkLXhsIHRleHQteHMgZm9udC1ib2xkIGZsZXggaXRlbXMtY2VudGVyIHNwYWNlLXgtMS41IHRyYW5zaXRpb24tYWxsIHNoYWRvdy1zbSBhY3RpdmU6c2NhbGUtOTUgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgdGl0bGU9XCLQodC60LDRh9Cw0YLRjCDQstGB0LUg0YTQsNC50LvRiyDQtNC70Y8gTmV0bGlmeSAoWklQKVwiXG4gICAgICAgICAgPlxuICAgICAgICAgICAgPHNwYW4+8J+TpTwvc3Bhbj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImhpZGRlbiBtZDppbmxpbmVcIj5OZXRsaWZ5PC9zcGFuPlxuICAgICAgICAgIDwvYnV0dG9uPlxuXG4gICAgICAgICAgey8qIFVzZXIgUHJvZmlsZSBBdmF0YXIgKi99XG4gICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gb25PcGVuTW9kYWwoJ3Byb2ZpbGUnKX1cbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIHNwYWNlLXgtMS41IHBsLTEuNSBwci0yIHB5LTEgYmctc2xhdGUtOTAwIGhvdmVyOmJnLXNsYXRlLTgwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMCByb3VuZGVkLXhsIHRleHQteHMgZm9udC1ib2xkIHRleHQtc2xhdGUtMjAwIHRyYW5zaXRpb24tYWxsXCJcbiAgICAgICAgICAgIHRpdGxlPVwi0JvQuNGH0L3Ri9C5INC60LDQsdC40L3QtdGCINC4INC/0YDQvtGE0LjQu9GMXCJcbiAgICAgICAgICA+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctNiBoLTYgcm91bmRlZC1sZyBvdmVyZmxvdy1oaWRkZW4gYmctc2xhdGUtOTUwIGJvcmRlciBib3JkZXItY3lhbi00MDBcIj5cbiAgICAgICAgICAgICAgPGltZyBzcmM9e3VzZXIuYXZhdGFyVXJsfSBhbHQ9XCJBdmF0YXJcIiBjbGFzc05hbWU9XCJ3LWZ1bGwgaC1mdWxsIG9iamVjdC1jb3ZlclwiIC8+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1heC13LVs3MHB4XSB0cnVuY2F0ZSBoaWRkZW4gc206aW5saW5lXCI+e3VzZXIudXNlcm5hbWV9PC9zcGFuPlxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuICAgIDwvaGVhZGVyPlxuICApO1xufTtcbiJdfQ==