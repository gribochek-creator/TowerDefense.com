const React = __vite__cjsImport0_react; const useRef = __vite__cjsImport0_react["useRef"]; const useEffect = __vite__cjsImport0_react["useEffect"]; const useState = __vite__cjsImport0_react["useState"]; const useCallback = __vite__cjsImport0_react["useCallback"];const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=1e19e0c2";
import { TOWERS_DATA, CAT_IMAGE_URL } from "/src/data/constants.ts";
import { sounds } from "/src/utils/sound.ts";
var _jsxFileName = "/app/applet/src/components/GameCanvas.tsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=1e19e0c2";
// Map Waypoints (Canvas size: 840 x 500)
const WAYPOINTS = [
	{
		x: -30,
		y: 150
	},
	{
		x: 180,
		y: 150
	},
	{
		x: 180,
		y: 350
	},
	{
		x: 420,
		y: 350
	},
	{
		x: 420,
		y: 120
	},
	{
		x: 660,
		y: 120
	},
	{
		x: 660,
		y: 340
	},
	{
		x: 880,
		y: 340
	}
];
export const GameCanvas = ({ difficulty, isCoop, gameActive, onGameOver, selectedTowerToPlace, onSelectPlacedTower, selectedPlacedTowerId, cash, setCash, onTowerPlacedSuccess, wave, setWave, maxWaves, gameSpeed, setGameSpeed, isPaused, setIsPaused, coopMessages, onSendCoopPing, placedTowers, setPlacedTowers }) => {
	const canvasRef = useRef(null);
	// Base Castle Health
	const [baseHp, setBaseHp] = useState(100);
	const maxBaseHp = 100;
	// Wave status
	const [waveState, setWaveState] = useState("waiting");
	const [waveCountdown, setWaveCountdown] = useState(6);
	const [enemiesRemaining, setEnemiesRemaining] = useState(0);
	// Mouse / Pointer
	const [mousePos, setMousePos] = useState(null);
	// Active enemies, projectiles, particles
	const enemiesRef = useRef([]);
	const projectilesRef = useRef([]);
	const particlesRef = useRef([]);
	const catImgRef = useRef(null);
	// Co-op AI friend state
	const coopAllyTimerRef = useRef(0);
	// Load Cat Image
	useEffect(() => {
		const img = new Image();
		img.src = CAT_IMAGE_URL;
		img.onload = () => {
			catImgRef.current = img;
		};
	}, []);
	// Distance helper
	const dist = (x1, y1, x2, y2) => {
		return Math.sqrt((x2 - x1) ** 2 + (y2 - y1) ** 2);
	};
	// Check if position is on path
	const isPointOnPath = (px, py, tolerance = 38) => {
		for (let i = 0; i < WAYPOINTS.length - 1; i++) {
			const p1 = WAYPOINTS[i];
			const p2 = WAYPOINTS[i + 1];
			const l2 = (p2.x - p1.x) ** 2 + (p2.y - p1.y) ** 2;
			if (l2 === 0) continue;
			let t = ((px - p1.x) * (p2.x - p1.x) + (py - p1.y) * (p2.y - p1.y)) / l2;
			t = Math.max(0, Math.min(1, t));
			const projX = p1.x + t * (p2.x - p1.x);
			const projY = p1.y + t * (p2.y - p1.y);
			if (dist(px, py, projX, projY) < tolerance) {
				return true;
			}
		}
		return false;
	};
	// Add floating particle
	const addParticle = useCallback((x, y, text, color) => {
		particlesRef.current.push({
			id: Math.random().toString(),
			x,
			y,
			vx: (Math.random() - .5) * 1.5,
			vy: -1.8 - Math.random() * 1.2,
			color,
			size: 14,
			life: 1,
			maxLife: 1,
			text
		});
	}, []);
	// Start next wave
	const startNextWave = useCallback(() => {
		if (wave >= maxWaves) return;
		const nextWave = wave + 1;
		setWave(nextWave);
		setWaveState("spawning");
		sounds.playWaveStart();
		// Generate wave enemies
		const count = 6 + nextWave * 3 + (difficulty === "hard" ? 4 : difficulty === "insane" ? 8 : 0);
		setEnemiesRemaining(count);
		let spawnedCount = 0;
		const isBossWave = nextWave % 5 === 0;
		const spawnInterval = window.setInterval(() => {
			if (spawnedCount >= count) {
				clearInterval(spawnInterval);
				setWaveState("clearing");
				return;
			}
			spawnedCount++;
			const isBoss = isBossWave && spawnedCount === count;
			const isFast = !isBoss && Math.random() < .25;
			const isArmored = !isBoss && !isFast && Math.random() < .3 && nextWave > 3;
			let hp = (18 + nextWave * 14) * (difficulty === "easy" ? .8 : difficulty === "hard" ? 1.3 : difficulty === "insane" ? 1.7 : 1);
			let speed = 1.1 + Math.min(nextWave * .05, 1.2);
			let color = "#facc15";
			let size = 15;
			let name = "Нуб";
			let bounty = 15 + Math.floor(nextWave * 2.5);
			if (isBoss) {
				hp *= 8.5;
				speed = .65;
				color = "#ef4444";
				size = 28;
				name = nextWave === maxWaves ? "👑 ТИТАН РОБЛОКСА" : "👹 Мега-Босс Нуб";
				bounty = 250 + nextWave * 20;
			} else if (isFast) {
				hp *= .6;
				speed *= 1.75;
				color = "#38bdf8";
				size = 12;
				name = "Спидраннер";
			} else if (isArmored) {
				hp *= 2.2;
				speed *= .8;
				color = "#64748b";
				size = 19;
				name = "Бронированный";
			}
			const newEnemy = {
				id: "enemy_" + Math.random().toString(36).substr(2, 9),
				name,
				maxHp: Math.round(hp),
				hp: Math.round(hp),
				speed,
				currentSpeed: speed,
				bounty,
				x: WAYPOINTS[0].x,
				y: WAYPOINTS[0].y,
				pathIndex: 0,
				distanceTraveled: 0,
				color,
				size,
				isBoss
			};
			enemiesRef.current.push(newEnemy);
		}, 700 / gameSpeed);
	}, [
		wave,
		maxWaves,
		setWave,
		difficulty,
		gameSpeed
	]);
	// Early wave call
	const handleCallWaveEarly = () => {
		if (waveState === "waiting") {
			setCash((c) => c + 35);
			sounds.playCoin();
			addParticle(420, 250, "+$35 За ранний старт!", "#10b981");
			startNextWave();
		}
	};
	// Co-op Simulated Teammate placement
	useEffect(() => {
		if (!isCoop || !gameActive) return;
		const interval = window.setInterval(() => {
			coopAllyTimerRef.current++;
			// Ally occasionally places or upgrades a tower
			if (coopAllyTimerRef.current % 18 === 0) {
				const allySpots = [
					{
						x: 300,
						y: 220
					},
					{
						x: 530,
						y: 240
					},
					{
						x: 670,
						y: 220
					},
					{
						x: 260,
						y: 80
					}
				];
				const spot = allySpots[Math.floor(Math.random() * allySpots.length)];
				const spotTaken = placedTowers.some((t) => dist(t.x, t.y, spot.x, spot.y) < 45);
				if (!spotTaken && placedTowers.length < 14) {
					const allyTower = {
						instanceId: "ally_" + Math.random().toString(),
						towerId: Math.random() > .4 ? "cat" : "noob_knight",
						x: spot.x,
						y: spot.y,
						level: 0,
						totalInvested: 200,
						targetMode: "first",
						lastShotTime: 0,
						kills: 0,
						damageDealt: 0,
						ownerName: "Напарник ProBacon",
						isCoopAlly: true
					};
					setPlacedTowers((prev) => [...prev, allyTower]);
					onSendCoopPing("Напарник поставил защитную башню!");
					sounds.playPlaceTower();
				}
			}
		}, 1e3);
		return () => clearInterval(interval);
	}, [
		isCoop,
		gameActive,
		placedTowers,
		setPlacedTowers,
		onSendCoopPing
	]);
	// Main Game Loop (Canvas updates & logic)
	useEffect(() => {
		const canvas = canvasRef.current;
		if (!canvas) return;
		const ctx = canvas.getContext("2d");
		if (!ctx) return;
		let animFrame;
		let lastTime = performance.now();
		const loop = (time) => {
			const dt = Math.min((time - lastTime) / 1e3, .1) * (isPaused ? 0 : gameSpeed);
			lastTime = time;
			// Clear Canvas
			ctx.clearRect(0, 0, canvas.width, canvas.height);
			// 1. Draw Roblox Stud Baseplate Background
			ctx.fillStyle = "#1e293b";
			ctx.fillRect(0, 0, canvas.width, canvas.height);
			// Grid studs (Roblox block style)
			ctx.fillStyle = "#334155";
			const gridSize = 32;
			for (let x = 16; x < canvas.width; x += gridSize) {
				for (let y = 16; y < canvas.height; y += gridSize) {
					ctx.beginPath();
					ctx.arc(x, y, 2, 0, Math.PI * 2);
					ctx.fill();
				}
			}
			// 2. Draw Road / Path (Winding blocky stone path)
			ctx.strokeStyle = "#475569";
			ctx.lineWidth = 44;
			ctx.lineCap = "round";
			ctx.lineJoin = "round";
			ctx.beginPath();
			ctx.moveTo(WAYPOINTS[0].x, WAYPOINTS[0].y);
			for (let i = 1; i < WAYPOINTS.length; i++) {
				ctx.lineTo(WAYPOINTS[i].x, WAYPOINTS[i].y);
			}
			ctx.stroke();
			// Road Inner Dash Lines
			ctx.strokeStyle = "#64748b";
			ctx.lineWidth = 34;
			ctx.stroke();
			// Chevrons / directional arrows on path
			ctx.strokeStyle = "rgba(255, 255, 255, 0.15)";
			ctx.lineWidth = 3;
			for (let i = 0; i < WAYPOINTS.length - 1; i++) {
				const p1 = WAYPOINTS[i];
				const p2 = WAYPOINTS[i + 1];
				const mx = (p1.x + p2.x) / 2;
				const my = (p1.y + p2.y) / 2;
				ctx.beginPath();
				ctx.arc(mx, my, 4, 0, Math.PI * 2);
				ctx.stroke();
			}
			// 3. Draw Spawn Portal & Base Fortress
			// Spawn Portal (Left)
			const portalGlow = ctx.createRadialGradient(15, 150, 5, 15, 150, 40);
			portalGlow.addColorStop(0, "#a855f7");
			portalGlow.addColorStop(1, "transparent");
			ctx.fillStyle = portalGlow;
			ctx.fillRect(0, 110, 50, 80);
			ctx.fillStyle = "#c084fc";
			ctx.font = "bold 12px monospace";
			ctx.fillText("SPAWN", 2, 140);
			// Base Castle (Right)
			ctx.fillStyle = "#0284c7";
			ctx.fillRect(780, 290, 60, 90);
			ctx.fillStyle = "#38bdf8";
			ctx.fillRect(790, 300, 40, 70);
			ctx.fillStyle = "#ffffff";
			ctx.font = "bold 13px sans-serif";
			ctx.fillText("🏰 БАЗА", 785, 335);
			// Base HP bar above castle
			const hpWidth = 50;
			const hpPct = Math.max(0, baseHp / maxBaseHp);
			ctx.fillStyle = "rgba(0,0,0,0.6)";
			ctx.fillRect(785, 280, hpWidth, 7);
			ctx.fillStyle = hpPct > .4 ? "#22c55e" : "#ef4444";
			ctx.fillRect(785, 280, hpWidth * hpPct, 7);
			// 4. Update & Move Enemies
			if (!isPaused) {
				for (let i = enemiesRef.current.length - 1; i >= 0; i--) {
					const enemy = enemiesRef.current[i];
					// Handle slow effect decay
					if (enemy.slowEffect) {
						enemy.slowEffect.duration -= dt;
						if (enemy.slowEffect.duration <= 0) {
							enemy.slowEffect = undefined;
							enemy.currentSpeed = enemy.speed;
						} else {
							enemy.currentSpeed = enemy.speed * enemy.slowEffect.multiplier;
						}
					} else {
						enemy.currentSpeed = enemy.speed;
					}
					// Move along waypoints
					const targetWp = WAYPOINTS[enemy.pathIndex + 1];
					if (targetWp) {
						const dx = targetWp.x - enemy.x;
						const dy = targetWp.y - enemy.y;
						const d = Math.sqrt(dx * dx + dy * dy);
						const moveStep = enemy.currentSpeed * 65 * dt;
						if (d < moveStep) {
							enemy.x = targetWp.x;
							enemy.y = targetWp.y;
							enemy.pathIndex++;
							if (enemy.pathIndex >= WAYPOINTS.length - 1) {
								// Reached Base!
								const dmg = enemy.isBoss ? 25 : 8;
								setBaseHp((prev) => {
									const updated = Math.max(0, prev - dmg);
									if (updated <= 0) {
										addParticle(420, 250, "💀 го KEKC", "#ef4444");
										onGameOver(wave, 0, false);
									}
									return updated;
								});
								sounds.playExplosion();
								addParticle(enemy.x, enemy.y, `-${dmg} HP!`, "#ef4444");
								enemiesRef.current.splice(i, 1);
								continue;
							}
						} else {
							enemy.x += dx / d * moveStep;
							enemy.y += dy / d * moveStep;
							enemy.distanceTraveled += moveStep;
						}
					}
				}
			}
			// Draw Enemies
			enemiesRef.current.forEach((enemy) => {
				ctx.save();
				ctx.translate(enemy.x, enemy.y);
				// Slow effect frozen aura
				if (enemy.slowEffect) {
					ctx.beginPath();
					ctx.arc(0, 0, enemy.size + 8, 0, Math.PI * 2);
					ctx.strokeStyle = "rgba(56, 189, 248, 0.8)";
					ctx.lineWidth = 3;
					ctx.stroke();
					ctx.fillStyle = "rgba(56, 189, 248, 0.25)";
					ctx.fill();
					// Snowflake symbol
					ctx.fillStyle = "#bae6fd";
					ctx.font = "10px sans-serif";
					ctx.fillText("❄️", -6, -enemy.size - 12);
				}
				// Enemy Blocky Body
				ctx.fillStyle = enemy.color;
				ctx.shadowColor = enemy.color;
				ctx.shadowBlur = enemy.isBoss ? 14 : 4;
				ctx.fillRect(-enemy.size / 2, -enemy.size / 2, enemy.size, enemy.size);
				ctx.shadowBlur = 0;
				// Enemy Eyes (classic Roblox noob face)
				ctx.fillStyle = "#000000";
				const eyeSize = Math.max(2, enemy.size / 5);
				ctx.fillRect(-enemy.size / 4, -enemy.size / 4, eyeSize, eyeSize);
				ctx.fillRect(enemy.size / 6, -enemy.size / 4, eyeSize, eyeSize);
				// Smile
				ctx.fillRect(-enemy.size / 4, enemy.size / 6, enemy.size / 2, 2);
				// Health Bar above enemy
				const barW = Math.max(26, enemy.size * 1.4);
				const barH = 5;
				const hpRatio = Math.max(0, enemy.hp / enemy.maxHp);
				ctx.fillStyle = "rgba(0, 0, 0, 0.7)";
				ctx.fillRect(-barW / 2, -enemy.size - 8, barW, barH);
				ctx.fillStyle = enemy.isBoss ? "#f43f5e" : "#22c55e";
				ctx.fillRect(-barW / 2, -enemy.size - 8, barW * hpRatio, barH);
				// Boss Tag
				if (enemy.isBoss) {
					ctx.fillStyle = "#facc15";
					ctx.font = "bold 10px sans-serif";
					ctx.fillText("👑 BOSS", -18, -enemy.size - 14);
				}
				ctx.restore();
			});
			// 5. Update & Attack Towers
			const now = performance.now() / 1e3;
			placedTowers.forEach((tower) => {
				const def = TOWERS_DATA.find((t) => t.id === tower.towerId);
				if (!def) return;
				const lvlCfg = def.levels[Math.min(tower.level, def.levels.length - 1)];
				// Find enemies in range
				const inRangeEnemies = enemiesRef.current.filter((e) => {
					return dist(tower.x, tower.y, e.x, e.y) <= lvlCfg.range;
				});
				// Targeting strategy
				let target = null;
				if (inRangeEnemies.length > 0) {
					if (tower.targetMode === "first") {
						target = inRangeEnemies.reduce((prev, curr) => curr.distanceTraveled > prev.distanceTraveled ? curr : prev);
					} else if (tower.targetMode === "strongest") {
						target = inRangeEnemies.reduce((prev, curr) => curr.hp > prev.hp ? curr : prev);
					} else if (tower.targetMode === "weakest") {
						target = inRangeEnemies.reduce((prev, curr) => curr.hp < prev.hp ? curr : prev);
					} else {
						// closest
						target = inRangeEnemies.reduce((prev, curr) => dist(tower.x, tower.y, curr.x, curr.y) < dist(tower.x, tower.y, prev.x, prev.y) ? curr : prev);
					}
				}
				// Fire rate check
				if (!isPaused && target && now - tower.lastShotTime >= lvlCfg.fireRate) {
					tower.lastShotTime = now;
					// Sound triggers based on tower type
					if (tower.towerId === "cat") {
						if (tower.level === 3) {
							sounds.playFreeze();
						} else if (Math.random() < .25) {
							sounds.playMeow();
						} else {
							sounds.playLaser();
						}
					} else if (tower.towerId === "mecha_cat") {
						sounds.playRocketLaunch();
					} else if (tower.towerId === "tesla_wizard") {
						sounds.playZap();
					} else if (tower.towerId === "freeze_penguin") {
						sounds.playFreeze();
					} else {
						sounds.playLaser();
					}
					// Special logic for Cat Tower / Freeze Penguin / Mecha
					const isCatLvl3 = tower.towerId === "cat" && tower.level >= 3;
					const isPenguin = tower.towerId === "freeze_penguin";
					const isRocket = def.bulletType === "rocket";
					const isLightning = def.bulletType === "lightning";
					const isShuriken = def.bulletType === "shuriken";
					const slowMultiplier = isCatLvl3 ? .6 : isPenguin ? .5 : undefined;
					const slowDuration = isCatLvl3 ? 3 : isPenguin ? 2.8 : undefined;
					const splashRadius = isRocket ? 55 : undefined;
					// Shuriken crit calculation
					let finalDamage = lvlCfg.damage;
					if (isShuriken && Math.random() < .4) {
						finalDamage = Math.round(lvlCfg.damage * 1.6);
					}
					projectilesRef.current.push({
						id: "proj_" + Math.random().toString(),
						startX: tower.x,
						startY: tower.y,
						targetX: target.x,
						targetY: target.y,
						targetEnemyId: target.id,
						color: isCatLvl3 ? "#38bdf8" : def.bulletColor,
						type: isCatLvl3 ? "frost" : def.bulletType,
						progress: 0,
						speed: isRocket ? 4.5 : def.bulletType === "fire" ? 8.5 : 6.5,
						damage: finalDamage,
						splashRadius,
						slowMultiplier,
						slowDuration
					});
				}
			});
			// 6. Update Projectiles
			if (!isPaused) {
				for (let i = projectilesRef.current.length - 1; i >= 0; i--) {
					const p = projectilesRef.current[i];
					p.progress += p.speed * dt;
					const currX = p.startX + (p.targetX - p.startX) * Math.min(1, p.progress);
					const currY = p.startY + (p.targetY - p.startY) * Math.min(1, p.progress);
					// Draw Projectile
					ctx.beginPath();
					if (p.type === "rocket") {
						ctx.arc(currX, currY, 6, 0, Math.PI * 2);
					} else if (p.type === "fire") {
						ctx.arc(currX, currY, 5, 0, Math.PI * 2);
					} else if (p.type === "frost") {
						ctx.arc(currX, currY, 6, 0, Math.PI * 2);
					} else {
						ctx.arc(currX, currY, 4, 0, Math.PI * 2);
					}
					ctx.fillStyle = p.color;
					ctx.shadowColor = p.color;
					ctx.shadowBlur = 8;
					ctx.fill();
					ctx.shadowBlur = 0;
					// Trailing laser line
					ctx.strokeStyle = p.color;
					ctx.lineWidth = p.type === "frost" || p.type === "rocket" ? 3 : 2;
					ctx.beginPath();
					ctx.moveTo(p.startX, p.startY);
					ctx.lineTo(currX, currY);
					ctx.stroke();
					// Impact
					if (p.progress >= 1) {
						// Splash Damage for Rockets
						if (p.splashRadius && p.splashRadius > 0) {
							sounds.playExplosion();
							addParticle(p.targetX, p.targetY, "💥 ВЗРЫВ!", "#f43f5e");
							enemiesRef.current.forEach((en) => {
								if (dist(p.targetX, p.targetY, en.x, en.y) <= (p.splashRadius || 50)) {
									en.hp -= p.damage;
									addParticle(en.x, en.y - 6, `-${p.damage}`, "#fb7185");
									if (en.hp <= 0) {
										const idx = enemiesRef.current.indexOf(en);
										if (idx >= 0) {
											enemiesRef.current.splice(idx, 1);
											setCash((c) => c + en.bounty);
											addParticle(en.x, en.y, `+$${en.bounty}`, "#4ade80");
											sounds.playCoin();
										}
									}
								}
							});
						} else {
							// Direct Hit
							const hitEnemy = enemiesRef.current.find((e) => e.id === p.targetEnemyId) || enemiesRef.current.find((e) => dist(p.targetX, p.targetY, e.x, e.y) < 25);
							if (hitEnemy) {
								hitEnemy.hp -= p.damage;
								// Chain Lightning on impact
								if (p.type === "lightning") {
									const chainTargets = enemiesRef.current.filter((e) => e.id !== hitEnemy.id && dist(hitEnemy.x, hitEnemy.y, e.x, e.y) < 90).slice(0, 3);
									chainTargets.forEach((cEn) => {
										const chainDmg = Math.round(p.damage * .75);
										cEn.hp -= chainDmg;
										addParticle(cEn.x, cEn.y - 8, `⚡-${chainDmg}`, "#c084fc");
										if (cEn.hp <= 0) {
											const idx = enemiesRef.current.indexOf(cEn);
											if (idx >= 0) {
												enemiesRef.current.splice(idx, 1);
												setCash((c) => c + cEn.bounty);
												addParticle(cEn.x, cEn.y, `+$${cEn.bounty}`, "#4ade80");
											}
										}
									});
								}
								// Apply freeze/slow
								if (p.slowMultiplier && p.slowDuration) {
									hitEnemy.slowEffect = {
										multiplier: p.slowMultiplier,
										duration: p.slowDuration
									};
									addParticle(hitEnemy.x, hitEnemy.y - 10, "❄️ ЗАМЕДЛЕНИЕ!", "#38bdf8");
								}
								// Damage Particle
								const isCrit = p.type === "shuriken" && p.damage > 20;
								addParticle(hitEnemy.x + (Math.random() - .5) * 15, hitEnemy.y - 5, isCrit ? `💥-${p.damage} КРИТ!` : `-${p.damage}`, isCrit ? "#fbbf24" : p.type === "frost" ? "#7dd3fc" : p.type === "fire" ? "#fb923c" : "#f87171");
								// Check Enemy Death
								if (hitEnemy.hp <= 0) {
									const enemyIdx = enemiesRef.current.indexOf(hitEnemy);
									if (enemyIdx >= 0) {
										enemiesRef.current.splice(enemyIdx, 1);
										setCash((c) => c + hitEnemy.bounty);
										addParticle(hitEnemy.x, hitEnemy.y, `+$${hitEnemy.bounty}`, "#4ade80");
										sounds.playCoin();
									}
								}
							}
						}
						projectilesRef.current.splice(i, 1);
					}
				}
			}
			// 7. Draw Placed Towers
			placedTowers.forEach((tower) => {
				const def = TOWERS_DATA.find((t) => t.id === tower.towerId);
				if (!def) return;
				const isSelected = tower.instanceId === selectedPlacedTowerId;
				const lvlCfg = def.levels[Math.min(tower.level, def.levels.length - 1)];
				// Draw Range Circle if selected or hovering
				if (isSelected) {
					ctx.beginPath();
					ctx.arc(tower.x, tower.y, lvlCfg.range, 0, Math.PI * 2);
					ctx.fillStyle = "rgba(56, 189, 248, 0.12)";
					ctx.fill();
					ctx.strokeStyle = "#38bdf8";
					ctx.lineWidth = 1.5;
					ctx.setLineDash([6, 4]);
					ctx.stroke();
					ctx.setLineDash([]);
				}
				ctx.save();
				ctx.translate(tower.x, tower.y);
				// Tower Base Pedestal (Roblox block style)
				ctx.fillStyle = tower.isCoopAlly ? "#0284c7" : isSelected ? "#38bdf8" : "#334155";
				ctx.fillRect(-22, -22, 44, 44);
				ctx.fillStyle = isSelected ? "#60a5fa" : "#1e293b";
				ctx.fillRect(-18, -18, 36, 36);
				// Special render for CAT TOWER (uses uploaded thug life image)
				if (tower.towerId === "cat" && catImgRef.current) {
					// Circular clipped image
					ctx.save();
					ctx.beginPath();
					ctx.arc(0, 0, 16, 0, Math.PI * 2);
					ctx.clip();
					ctx.drawImage(catImgRef.current, -16, -16, 32, 32);
					ctx.restore();
					// Level 3 Frost Aura
					if (tower.level >= 3) {
						ctx.beginPath();
						ctx.arc(0, 0, 22, 0, Math.PI * 2);
						ctx.strokeStyle = "#38bdf8";
						ctx.lineWidth = 2.5;
						ctx.stroke();
						// Rotating snow star
						ctx.fillStyle = "#bae6fd";
						ctx.font = "10px sans-serif";
						ctx.fillText("❄️", 12, -12);
					}
				} else {
					// Emoji / Icon for other towers
					ctx.font = "20px sans-serif";
					ctx.textAlign = "center";
					ctx.textBaseline = "middle";
					ctx.fillText(def.icon, 0, 0);
				}
				// Level stars badge (★, ★★, ★★★)
				if (tower.level > 0) {
					ctx.fillStyle = "#facc15";
					ctx.font = "bold 11px monospace";
					ctx.textAlign = "center";
					ctx.fillText("★".repeat(tower.level), 0, -25);
				}
				// Ally marker if co-op
				if (tower.isCoopAlly) {
					ctx.fillStyle = "#06b6d4";
					ctx.font = "bold 9px sans-serif";
					ctx.textAlign = "center";
					ctx.fillText("[ДРУГ]", 0, 32);
				}
				ctx.restore();
			});
			// 8. Draw Placement Preview if selecting a tower to place
			if (selectedTowerToPlace && mousePos) {
				const def = TOWERS_DATA.find((t) => t.id === selectedTowerToPlace);
				if (def) {
					const onPath = isPointOnPath(mousePos.x, mousePos.y);
					const tooClose = placedTowers.some((t) => dist(t.x, t.y, mousePos.x, mousePos.y) < 42);
					const canPlace = !onPath && !tooClose && cash >= def.baseCost;
					// Range circle
					ctx.beginPath();
					ctx.arc(mousePos.x, mousePos.y, def.levels[0].range, 0, Math.PI * 2);
					ctx.fillStyle = canPlace ? "rgba(34, 197, 94, 0.15)" : "rgba(239, 68, 68, 0.2)";
					ctx.fill();
					ctx.strokeStyle = canPlace ? "#22c55e" : "#ef4444";
					ctx.lineWidth = 2;
					ctx.stroke();
					// Preview ghost
					ctx.save();
					ctx.translate(mousePos.x, mousePos.y);
					ctx.globalAlpha = .8;
					ctx.fillStyle = canPlace ? "#22c55e" : "#ef4444";
					ctx.fillRect(-18, -18, 36, 36);
					if (def.id === "cat" && catImgRef.current) {
						ctx.save();
						ctx.beginPath();
						ctx.arc(0, 0, 14, 0, Math.PI * 2);
						ctx.clip();
						ctx.drawImage(catImgRef.current, -14, -14, 28, 28);
						ctx.restore();
					} else {
						ctx.font = "18px sans-serif";
						ctx.textAlign = "center";
						ctx.textBaseline = "middle";
						ctx.fillText(def.icon, 0, 0);
					}
					ctx.restore();
				}
			}
			// 9. Update & Draw Particles (floating damage, texts)
			for (let i = particlesRef.current.length - 1; i >= 0; i--) {
				const p = particlesRef.current[i];
				p.x += p.vx;
				p.y += p.vy;
				p.life -= dt * 1.3;
				if (p.life <= 0) {
					particlesRef.current.splice(i, 1);
					continue;
				}
				ctx.save();
				ctx.globalAlpha = Math.max(0, p.life);
				ctx.fillStyle = p.color;
				ctx.font = "bold 12px monospace";
				ctx.fillText(p.text || "", p.x, p.y);
				ctx.restore();
			}
			// 10. Check Wave Completion
			if (waveState === "clearing" && enemiesRef.current.length === 0) {
				setWaveState("waiting");
				setWaveCountdown(6);
				sounds.playWaveStart();
				// End of wave economy bonuses
				const waveCashBonus = 160 + wave * 35;
				setCash((c) => c + waveCashBonus);
				addParticle(420, 250, `Волна ${wave} Завершена! +$${waveCashBonus}`, "#facc15");
				// Banker Cat bonus
				placedTowers.forEach((t) => {
					if (t.towerId === "banker_cat") {
						const bonus = [
							120,
							300,
							750,
							1600
						][Math.min(t.level, 3)];
						setCash((c) => c + bonus);
						addParticle(t.x, t.y - 20, `+$${bonus} Банк`, "#10b981");
					}
				});
				// Check if final wave cleared
				if (wave >= maxWaves) {
					sounds.playVictory();
					onGameOver(wave, wave * 2500, true);
				}
			}
			animFrame = requestAnimationFrame(loop);
		};
		animFrame = requestAnimationFrame(loop);
		return () => cancelAnimationFrame(animFrame);
	}, [
		baseHp,
		cash,
		gameSpeed,
		isPaused,
		maxWaves,
		mousePos,
		onGameOver,
		placedTowers,
		selectedPlacedTowerId,
		selectedTowerToPlace,
		setCash,
		wave,
		waveState,
		addParticle
	]);
	// Handle Canvas Click (place tower or select tower)
	const handleCanvasClick = (e) => {
		const canvas = canvasRef.current;
		if (!canvas) return;
		const rect = canvas.getBoundingClientRect();
		const scaleX = canvas.width / rect.width;
		const scaleY = canvas.height / rect.height;
		const x = (e.clientX - rect.left) * scaleX;
		const y = (e.clientY - rect.top) * scaleY;
		// Check if clicked an existing tower
		const clickedTower = placedTowers.find((t) => dist(t.x, t.y, x, y) < 24);
		if (clickedTower) {
			onSelectPlacedTower(clickedTower);
			return;
		}
		// Otherwise, place new tower if one is chosen
		if (selectedTowerToPlace) {
			const def = TOWERS_DATA.find((t) => t.id === selectedTowerToPlace);
			if (!def) return;
			const onPath = isPointOnPath(x, y);
			const tooClose = placedTowers.some((t) => dist(t.x, t.y, x, y) < 42);
			if (!onPath && !tooClose && cash >= def.baseCost) {
				const newTower = {
					instanceId: "tower_" + Math.random().toString(36).substr(2, 9),
					towerId: def.id,
					x,
					y,
					level: 0,
					totalInvested: def.baseCost,
					targetMode: "first",
					lastShotTime: 0,
					kills: 0,
					damageDealt: 0
				};
				setCash((c) => c - def.baseCost);
				setPlacedTowers((prev) => [...prev, newTower]);
				onTowerPlacedSuccess(def.id);
				sounds.playPlaceTower();
				addParticle(x, y, `-${def.baseCost}$`, "#ef4444");
			}
		} else {
			// Deselect
			onSelectPlacedTower(null);
		}
	};
	const handleMouseMove = (e) => {
		const canvas = canvasRef.current;
		if (!canvas) return;
		const rect = canvas.getBoundingClientRect();
		const scaleX = canvas.width / rect.width;
		const scaleY = canvas.height / rect.height;
		setMousePos({
			x: (e.clientX - rect.left) * scaleX,
			y: (e.clientY - rect.top) * scaleY
		});
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "relative w-full rounded-2xl overflow-hidden border-2 border-slate-700 bg-slate-900 shadow-2xl select-none",
		children: [/* @__PURE__ */ _jsxDEV("div", {
			className: "flex flex-wrap items-center justify-between px-4 py-2.5 bg-slate-950/80 backdrop-blur-md border-b border-slate-800 text-sm",
			children: [
				/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center space-x-2",
					children: [/* @__PURE__ */ _jsxDEV("span", {
						className: "text-xl",
						children: "🏰"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 941,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center space-x-1 font-bold text-xs text-slate-300",
						children: [/* @__PURE__ */ _jsxDEV("span", { children: "Здоровье Базы:" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 944,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("span", {
							className: baseHp > 30 ? "text-green-400" : "text-red-400",
							children: [baseHp, "%"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 945,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 943,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "w-28 h-2 bg-slate-800 rounded-full overflow-hidden mt-0.5",
						children: /* @__PURE__ */ _jsxDEV("div", {
							className: `h-full transition-all duration-300 ${baseHp > 30 ? "bg-green-500" : "bg-red-500"}`,
							style: { width: `${baseHp}%` }
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 948,
							columnNumber: 15
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 947,
						columnNumber: 13
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 942,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 940,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center space-x-3",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "text-center",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "text-xs text-slate-400",
								children: "Волна"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 959,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "font-extrabold text-base text-cyan-400",
								children: [
									wave,
									" ",
									/* @__PURE__ */ _jsxDEV("span", {
										className: "text-xs text-slate-500",
										children: ["/ ", maxWaves]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 961,
										columnNumber: 22
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 960,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 958,
							columnNumber: 11
						}, this),
						waveState === "waiting" && wave < maxWaves && /* @__PURE__ */ _jsxDEV("button", {
							onClick: handleCallWaveEarly,
							className: "px-3 py-1 text-xs font-bold bg-amber-500 hover:bg-amber-400 text-slate-950 rounded-lg shadow-lg transition-transform active:scale-95 animate-pulse flex items-center space-x-1",
							children: /* @__PURE__ */ _jsxDEV("span", { children: "⚡ Старт Волны (+$35)" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 970,
								columnNumber: 15
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 966,
							columnNumber: 13
						}, this),
						waveState === "spawning" && /* @__PURE__ */ _jsxDEV("span", {
							className: "px-2.5 py-1 text-xs bg-red-950/70 text-red-300 border border-red-700/50 rounded-md font-mono",
							children: [
								"⚠️ Атака (",
								enemiesRemaining,
								")"
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 975,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 957,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center space-x-2",
					children: [/* @__PURE__ */ _jsxDEV("button", {
						onClick: () => setIsPaused(!isPaused),
						className: "px-2.5 py-1 text-xs font-bold bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-md border border-slate-700",
						children: isPaused ? "▶️ Продолжить" : "⏸️ Пауза"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 983,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "flex rounded-md overflow-hidden border border-slate-700 text-xs font-bold",
						children: [
							1,
							2,
							3
						].map((spd) => /* @__PURE__ */ _jsxDEV("button", {
							onClick: () => setGameSpeed(spd),
							className: `px-2 py-1 ${gameSpeed === spd ? "bg-cyan-600 text-white" : "bg-slate-800 text-slate-400 hover:bg-slate-700"}`,
							children: [spd, "x"]
						}, spd, true, {
							fileName: _jsxFileName,
							lineNumber: 991,
							columnNumber: 15
						}, this))
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 989,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 982,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 938,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			className: "relative aspect-[840/500] w-full bg-slate-900",
			children: [
				/* @__PURE__ */ _jsxDEV("canvas", {
					ref: canvasRef,
					width: 840,
					height: 500,
					onClick: handleCanvasClick,
					onMouseMove: handleMouseMove,
					onMouseLeave: () => setMousePos(null),
					className: "w-full h-full cursor-crosshair block"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 1007,
					columnNumber: 9
				}, this),
				isCoop && /* @__PURE__ */ _jsxDEV("div", {
					className: "absolute bottom-3 left-3 bg-slate-950/85 backdrop-blur-md border border-cyan-800/60 rounded-xl p-2.5 max-w-xs text-xs shadow-xl pointer-events-none",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center space-x-1.5 font-bold text-cyan-400 mb-1",
						children: [/* @__PURE__ */ _jsxDEV("span", { className: "w-2 h-2 rounded-full bg-green-400 animate-ping" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 1021,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Кооператив с Напарником" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 1022,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 1020,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "space-y-0.5 text-slate-300 font-mono text-[11px]",
						children: coopMessages.slice(-3).map((msg, idx) => /* @__PURE__ */ _jsxDEV("div", {
							className: "truncate",
							children: ["💬 ", msg]
						}, idx, true, {
							fileName: _jsxFileName,
							lineNumber: 1026,
							columnNumber: 17
						}, this))
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 1024,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 1019,
					columnNumber: 11
				}, this),
				selectedTowerToPlace && /* @__PURE__ */ _jsxDEV("div", {
					className: "absolute top-3 left-1/2 -translate-x-1/2 bg-slate-950/90 text-cyan-300 border border-cyan-500/50 px-3 py-1 rounded-full text-xs font-bold shadow-lg pointer-events-none",
					children: "Кликните на свободное зеленое место на поле для установки"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 1036,
					columnNumber: 11
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 1006,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 936,
		columnNumber: 5
	}, this);
};

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLFFBQVEsV0FBVyxVQUFVLG1CQUFtQjtBQUVoRSxTQUFTLGFBQWEscUJBQXFCO0FBQzNDLFNBQVMsY0FBYzs7OztBQTZCdkIsTUFBTSxZQUFZO0NBQ2hCO0VBQUUsR0FBRyxDQUFDO0VBQUksR0FBRztDQUFJO0NBQ2pCO0VBQUUsR0FBRztFQUFLLEdBQUc7Q0FBSTtDQUNqQjtFQUFFLEdBQUc7RUFBSyxHQUFHO0NBQUk7Q0FDakI7RUFBRSxHQUFHO0VBQUssR0FBRztDQUFJO0NBQ2pCO0VBQUUsR0FBRztFQUFLLEdBQUc7Q0FBSTtDQUNqQjtFQUFFLEdBQUc7RUFBSyxHQUFHO0NBQUk7Q0FDakI7RUFBRSxHQUFHO0VBQUssR0FBRztDQUFJO0NBQ2pCO0VBQUUsR0FBRztFQUFLLEdBQUc7Q0FBSTtBQUNuQjtBQUVBLE9BQU8sTUFBTSxjQUF5QyxFQUNwRCxZQUNBLFFBQ0EsWUFDQSxZQUNBLHNCQUNBLHFCQUNBLHVCQUNBLE1BQ0EsU0FDQSxzQkFDQSxNQUNBLFNBQ0EsVUFDQSxXQUNBLGNBQ0EsVUFDQSxhQUNBLGNBQ0EsZ0JBQ0EsY0FDQSxzQkFDSTtDQUNKLE1BQU0sWUFBWSxPQUFpQyxJQUFJOztDQUd2RCxNQUFNLENBQUMsUUFBUSxhQUFhLFNBQVMsR0FBRztDQUN4QyxNQUFNLFlBQVk7O0NBR2xCLE1BQU0sQ0FBQyxXQUFXLGdCQUFnQixTQUE4QyxTQUFTO0NBQ3pGLE1BQU0sQ0FBQyxlQUFlLG9CQUFvQixTQUFTLENBQUM7Q0FDcEQsTUFBTSxDQUFDLGtCQUFrQix1QkFBdUIsU0FBUyxDQUFDOztDQUcxRCxNQUFNLENBQUMsVUFBVSxlQUFlLFNBQTBDLElBQUk7O0NBRzlFLE1BQU0sYUFBYSxPQUFnQixDQUFDLENBQUM7Q0FDckMsTUFBTSxpQkFBaUIsT0FBcUIsQ0FBQyxDQUFDO0NBQzlDLE1BQU0sZUFBZSxPQUFtQixDQUFDLENBQUM7Q0FDMUMsTUFBTSxZQUFZLE9BQWdDLElBQUk7O0NBR3RELE1BQU0sbUJBQW1CLE9BQWUsQ0FBQzs7Q0FHekMsZ0JBQWdCO0VBQ2QsTUFBTSxNQUFNLElBQUksTUFBTTtFQUN0QixJQUFJLE1BQU07RUFDVixJQUFJLGVBQWU7R0FDakIsVUFBVSxVQUFVO0VBQ3RCO0NBQ0YsR0FBRyxDQUFDLENBQUM7O0NBR0wsTUFBTSxRQUFRLElBQVksSUFBWSxJQUFZLE9BQWU7RUFDL0QsT0FBTyxLQUFLLE1BQU0sS0FBSyxPQUFPLEtBQUssS0FBSyxPQUFPLENBQUM7Q0FDbEQ7O0NBR0EsTUFBTSxpQkFBaUIsSUFBWSxJQUFZLFlBQVksT0FBZ0I7RUFDekUsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLFVBQVUsU0FBUyxHQUFHLEtBQUs7R0FDN0MsTUFBTSxLQUFLLFVBQVU7R0FDckIsTUFBTSxLQUFLLFVBQVUsSUFBSTtHQUV6QixNQUFNLE1BQU0sR0FBRyxJQUFJLEdBQUcsTUFBTSxLQUFLLEdBQUcsSUFBSSxHQUFHLE1BQU07R0FDakQsSUFBSSxPQUFPLEdBQUc7R0FFZCxJQUFJLE1BQU0sS0FBSyxHQUFHLE1BQU0sR0FBRyxJQUFJLEdBQUcsTUFBTSxLQUFLLEdBQUcsTUFBTSxHQUFHLElBQUksR0FBRyxNQUFNO0dBQ3RFLElBQUksS0FBSyxJQUFJLEdBQUcsS0FBSyxJQUFJLEdBQUcsQ0FBQyxDQUFDO0dBRTlCLE1BQU0sUUFBUSxHQUFHLElBQUksS0FBSyxHQUFHLElBQUksR0FBRztHQUNwQyxNQUFNLFFBQVEsR0FBRyxJQUFJLEtBQUssR0FBRyxJQUFJLEdBQUc7R0FFcEMsSUFBSSxLQUFLLElBQUksSUFBSSxPQUFPLEtBQUssSUFBSSxXQUFXO0lBQzFDLE9BQU87R0FDVDtFQUNGO0VBQ0EsT0FBTztDQUNUOztDQUdBLE1BQU0sY0FBYyxhQUFhLEdBQVcsR0FBVyxNQUFjLFVBQWtCO0VBQ3JGLGFBQWEsUUFBUSxLQUFLO0dBQ3hCLElBQUksS0FBSyxPQUFPLENBQUMsQ0FBQyxTQUFTO0dBQzNCO0dBQ0E7R0FDQSxLQUFLLEtBQUssT0FBTyxJQUFJLE1BQU87R0FDNUIsSUFBSSxDQUFDLE1BQU0sS0FBSyxPQUFPLElBQUk7R0FDM0I7R0FDQSxNQUFNO0dBQ04sTUFBTTtHQUNOLFNBQVM7R0FDVDtFQUNGLENBQUM7Q0FDSCxHQUFHLENBQUMsQ0FBQzs7Q0FHTCxNQUFNLGdCQUFnQixrQkFBa0I7RUFDdEMsSUFBSSxRQUFRLFVBQVU7RUFDdEIsTUFBTSxXQUFXLE9BQU87RUFDeEIsUUFBUSxRQUFRO0VBQ2hCLGFBQWEsVUFBVTtFQUN2QixPQUFPLGNBQWM7O0VBR3JCLE1BQU0sUUFBUSxJQUFJLFdBQVcsS0FBSyxlQUFlLFNBQVMsSUFBSSxlQUFlLFdBQVcsSUFBSTtFQUM1RixvQkFBb0IsS0FBSztFQUV6QixJQUFJLGVBQWU7RUFDbkIsTUFBTSxhQUFhLFdBQVcsTUFBTTtFQUVwQyxNQUFNLGdCQUFnQixPQUFPLGtCQUFrQjtHQUM3QyxJQUFJLGdCQUFnQixPQUFPO0lBQ3pCLGNBQWMsYUFBYTtJQUMzQixhQUFhLFVBQVU7SUFDdkI7R0FDRjtHQUVBO0dBQ0EsTUFBTSxTQUFTLGNBQWMsaUJBQWlCO0dBQzlDLE1BQU0sU0FBUyxDQUFDLFVBQVUsS0FBSyxPQUFPLElBQUk7R0FDMUMsTUFBTSxZQUFZLENBQUMsVUFBVSxDQUFDLFVBQVUsS0FBSyxPQUFPLElBQUksTUFBTyxXQUFXO0dBRTFFLElBQUksTUFBTSxLQUFLLFdBQVcsT0FBTyxlQUFlLFNBQVMsS0FBTSxlQUFlLFNBQVMsTUFBTSxlQUFlLFdBQVcsTUFBTTtHQUM3SCxJQUFJLFFBQVEsTUFBTSxLQUFLLElBQUksV0FBVyxLQUFNLEdBQUc7R0FDL0MsSUFBSSxRQUFRO0dBQ1osSUFBSSxPQUFPO0dBQ1gsSUFBSSxPQUFPO0dBQ1gsSUFBSSxTQUFTLEtBQUssS0FBSyxNQUFNLFdBQVcsR0FBRztHQUUzQyxJQUFJLFFBQVE7SUFDVixNQUFNO0lBQ04sUUFBUTtJQUNSLFFBQVE7SUFDUixPQUFPO0lBQ1AsT0FBTyxhQUFhLFdBQVcsc0JBQXNCO0lBQ3JELFNBQVMsTUFBTSxXQUFXO0dBQzVCLE9BQU8sSUFBSSxRQUFRO0lBQ2pCLE1BQU07SUFDTixTQUFTO0lBQ1QsUUFBUTtJQUNSLE9BQU87SUFDUCxPQUFPO0dBQ1QsT0FBTyxJQUFJLFdBQVc7SUFDcEIsTUFBTTtJQUNOLFNBQVM7SUFDVCxRQUFRO0lBQ1IsT0FBTztJQUNQLE9BQU87R0FDVDtHQUVBLE1BQU0sV0FBa0I7SUFDdEIsSUFBSSxXQUFXLEtBQUssT0FBTyxDQUFDLENBQUMsU0FBUyxFQUFFLENBQUMsQ0FBQyxPQUFPLEdBQUcsQ0FBQztJQUNyRDtJQUNBLE9BQU8sS0FBSyxNQUFNLEVBQUU7SUFDcEIsSUFBSSxLQUFLLE1BQU0sRUFBRTtJQUNqQjtJQUNBLGNBQWM7SUFDZDtJQUNBLEdBQUcsVUFBVSxFQUFFLENBQUM7SUFDaEIsR0FBRyxVQUFVLEVBQUUsQ0FBQztJQUNoQixXQUFXO0lBQ1gsa0JBQWtCO0lBQ2xCO0lBQ0E7SUFDQTtHQUNGO0dBRUEsV0FBVyxRQUFRLEtBQUssUUFBUTtFQUNsQyxHQUFHLE1BQU0sU0FBUztDQUNwQixHQUFHO0VBQUM7RUFBTTtFQUFVO0VBQVM7RUFBWTtDQUFTLENBQUM7O0NBR25ELE1BQU0sNEJBQTRCO0VBQ2hDLElBQUksY0FBYyxXQUFXO0dBQzNCLFNBQVMsTUFBTSxJQUFJLEVBQUU7R0FDckIsT0FBTyxTQUFTO0dBQ2hCLFlBQVksS0FBSyxLQUFLLHlCQUF5QixTQUFTO0dBQ3hELGNBQWM7RUFDaEI7Q0FDRjs7Q0FHQSxnQkFBZ0I7RUFDZCxJQUFJLENBQUMsVUFBVSxDQUFDLFlBQVk7RUFFNUIsTUFBTSxXQUFXLE9BQU8sa0JBQWtCO0dBQ3hDLGlCQUFpQjs7R0FFakIsSUFBSSxpQkFBaUIsVUFBVSxPQUFPLEdBQUc7SUFDdkMsTUFBTSxZQUFZO0tBQ2hCO01BQUUsR0FBRztNQUFLLEdBQUc7S0FBSTtLQUNqQjtNQUFFLEdBQUc7TUFBSyxHQUFHO0tBQUk7S0FDakI7TUFBRSxHQUFHO01BQUssR0FBRztLQUFJO0tBQ2pCO01BQUUsR0FBRztNQUFLLEdBQUc7S0FBRztJQUNsQjtJQUNBLE1BQU0sT0FBTyxVQUFVLEtBQUssTUFBTSxLQUFLLE9BQU8sSUFBSSxVQUFVLE1BQU07SUFDbEUsTUFBTSxZQUFZLGFBQWEsTUFBTSxNQUFNLEtBQUssRUFBRSxHQUFHLEVBQUUsR0FBRyxLQUFLLEdBQUcsS0FBSyxDQUFDLElBQUksRUFBRTtJQUU5RSxJQUFJLENBQUMsYUFBYSxhQUFhLFNBQVMsSUFBSTtLQUMxQyxNQUFNLFlBQXlCO01BQzdCLFlBQVksVUFBVSxLQUFLLE9BQU8sQ0FBQyxDQUFDLFNBQVM7TUFDN0MsU0FBUyxLQUFLLE9BQU8sSUFBSSxLQUFNLFFBQVE7TUFDdkMsR0FBRyxLQUFLO01BQ1IsR0FBRyxLQUFLO01BQ1IsT0FBTztNQUNQLGVBQWU7TUFDZixZQUFZO01BQ1osY0FBYztNQUNkLE9BQU87TUFDUCxhQUFhO01BQ2IsV0FBVztNQUNYLFlBQVk7S0FDZDtLQUNBLGlCQUFpQixTQUFTLENBQUMsR0FBRyxNQUFNLFNBQVMsQ0FBQztLQUM5QyxlQUFlLG1DQUFtQztLQUNsRCxPQUFPLGVBQWU7SUFDeEI7R0FDRjtFQUNGLEdBQUcsR0FBSTtFQUVQLGFBQWEsY0FBYyxRQUFRO0NBQ3JDLEdBQUc7RUFBQztFQUFRO0VBQVk7RUFBYztFQUFpQjtDQUFjLENBQUM7O0NBR3RFLGdCQUFnQjtFQUNkLE1BQU0sU0FBUyxVQUFVO0VBQ3pCLElBQUksQ0FBQyxRQUFRO0VBQ2IsTUFBTSxNQUFNLE9BQU8sV0FBVyxJQUFJO0VBQ2xDLElBQUksQ0FBQyxLQUFLO0VBRVYsSUFBSTtFQUNKLElBQUksV0FBVyxZQUFZLElBQUk7RUFFL0IsTUFBTSxRQUFRLFNBQWlCO0dBQzdCLE1BQU0sS0FBSyxLQUFLLEtBQUssT0FBTyxZQUFZLEtBQU0sRUFBRyxLQUFLLFdBQVcsSUFBSTtHQUNyRSxXQUFXOztHQUdYLElBQUksVUFBVSxHQUFHLEdBQUcsT0FBTyxPQUFPLE9BQU8sTUFBTTs7R0FHL0MsSUFBSSxZQUFZO0dBQ2hCLElBQUksU0FBUyxHQUFHLEdBQUcsT0FBTyxPQUFPLE9BQU8sTUFBTTs7R0FHOUMsSUFBSSxZQUFZO0dBQ2hCLE1BQU0sV0FBVztHQUNqQixLQUFLLElBQUksSUFBSSxJQUFJLElBQUksT0FBTyxPQUFPLEtBQUssVUFBVTtJQUNoRCxLQUFLLElBQUksSUFBSSxJQUFJLElBQUksT0FBTyxRQUFRLEtBQUssVUFBVTtLQUNqRCxJQUFJLFVBQVU7S0FDZCxJQUFJLElBQUksR0FBRyxHQUFHLEdBQUcsR0FBRyxLQUFLLEtBQUssQ0FBQztLQUMvQixJQUFJLEtBQUs7SUFDWDtHQUNGOztHQUdBLElBQUksY0FBYztHQUNsQixJQUFJLFlBQVk7R0FDaEIsSUFBSSxVQUFVO0dBQ2QsSUFBSSxXQUFXO0dBQ2YsSUFBSSxVQUFVO0dBQ2QsSUFBSSxPQUFPLFVBQVUsRUFBRSxDQUFDLEdBQUcsVUFBVSxFQUFFLENBQUMsQ0FBQztHQUN6QyxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksVUFBVSxRQUFRLEtBQUs7SUFDekMsSUFBSSxPQUFPLFVBQVUsRUFBRSxDQUFDLEdBQUcsVUFBVSxFQUFFLENBQUMsQ0FBQztHQUMzQztHQUNBLElBQUksT0FBTzs7R0FHWCxJQUFJLGNBQWM7R0FDbEIsSUFBSSxZQUFZO0dBQ2hCLElBQUksT0FBTzs7R0FHWCxJQUFJLGNBQWM7R0FDbEIsSUFBSSxZQUFZO0dBQ2hCLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxVQUFVLFNBQVMsR0FBRyxLQUFLO0lBQzdDLE1BQU0sS0FBSyxVQUFVO0lBQ3JCLE1BQU0sS0FBSyxVQUFVLElBQUk7SUFDekIsTUFBTSxNQUFNLEdBQUcsSUFBSSxHQUFHLEtBQUs7SUFDM0IsTUFBTSxNQUFNLEdBQUcsSUFBSSxHQUFHLEtBQUs7SUFDM0IsSUFBSSxVQUFVO0lBQ2QsSUFBSSxJQUFJLElBQUksSUFBSSxHQUFHLEdBQUcsS0FBSyxLQUFLLENBQUM7SUFDakMsSUFBSSxPQUFPO0dBQ2I7OztHQUlBLE1BQU0sYUFBYSxJQUFJLHFCQUFxQixJQUFJLEtBQUssR0FBRyxJQUFJLEtBQUssRUFBRTtHQUNuRSxXQUFXLGFBQWEsR0FBRyxTQUFTO0dBQ3BDLFdBQVcsYUFBYSxHQUFHLGFBQWE7R0FDeEMsSUFBSSxZQUFZO0dBQ2hCLElBQUksU0FBUyxHQUFHLEtBQUssSUFBSSxFQUFFO0dBQzNCLElBQUksWUFBWTtHQUNoQixJQUFJLE9BQU87R0FDWCxJQUFJLFNBQVMsU0FBUyxHQUFHLEdBQUc7O0dBRzVCLElBQUksWUFBWTtHQUNoQixJQUFJLFNBQVMsS0FBSyxLQUFLLElBQUksRUFBRTtHQUM3QixJQUFJLFlBQVk7R0FDaEIsSUFBSSxTQUFTLEtBQUssS0FBSyxJQUFJLEVBQUU7R0FDN0IsSUFBSSxZQUFZO0dBQ2hCLElBQUksT0FBTztHQUNYLElBQUksU0FBUyxXQUFXLEtBQUssR0FBRzs7R0FHaEMsTUFBTSxVQUFVO0dBQ2hCLE1BQU0sUUFBUSxLQUFLLElBQUksR0FBRyxTQUFTLFNBQVM7R0FDNUMsSUFBSSxZQUFZO0dBQ2hCLElBQUksU0FBUyxLQUFLLEtBQUssU0FBUyxDQUFDO0dBQ2pDLElBQUksWUFBWSxRQUFRLEtBQU0sWUFBWTtHQUMxQyxJQUFJLFNBQVMsS0FBSyxLQUFLLFVBQVUsT0FBTyxDQUFDOztHQUd6QyxJQUFJLENBQUMsVUFBVTtJQUNiLEtBQUssSUFBSSxJQUFJLFdBQVcsUUFBUSxTQUFTLEdBQUcsS0FBSyxHQUFHLEtBQUs7S0FDdkQsTUFBTSxRQUFRLFdBQVcsUUFBUTs7S0FHakMsSUFBSSxNQUFNLFlBQVk7TUFDcEIsTUFBTSxXQUFXLFlBQVk7TUFDN0IsSUFBSSxNQUFNLFdBQVcsWUFBWSxHQUFHO09BQ2xDLE1BQU0sYUFBYTtPQUNuQixNQUFNLGVBQWUsTUFBTTtNQUM3QixPQUFPO09BQ0wsTUFBTSxlQUFlLE1BQU0sUUFBUSxNQUFNLFdBQVc7TUFDdEQ7S0FDRixPQUFPO01BQ0wsTUFBTSxlQUFlLE1BQU07S0FDN0I7O0tBR0EsTUFBTSxXQUFXLFVBQVUsTUFBTSxZQUFZO0tBQzdDLElBQUksVUFBVTtNQUNaLE1BQU0sS0FBSyxTQUFTLElBQUksTUFBTTtNQUM5QixNQUFNLEtBQUssU0FBUyxJQUFJLE1BQU07TUFDOUIsTUFBTSxJQUFJLEtBQUssS0FBSyxLQUFLLEtBQUssS0FBSyxFQUFFO01BQ3JDLE1BQU0sV0FBVyxNQUFNLGVBQWUsS0FBSztNQUUzQyxJQUFJLElBQUksVUFBVTtPQUNoQixNQUFNLElBQUksU0FBUztPQUNuQixNQUFNLElBQUksU0FBUztPQUNuQixNQUFNO09BQ04sSUFBSSxNQUFNLGFBQWEsVUFBVSxTQUFTLEdBQUc7O1FBRTNDLE1BQU0sTUFBTSxNQUFNLFNBQVMsS0FBSztRQUNoQyxXQUFXLFNBQVM7U0FDbEIsTUFBTSxVQUFVLEtBQUssSUFBSSxHQUFHLE9BQU8sR0FBRztTQUN0QyxJQUFJLFdBQVcsR0FBRztVQUNoQixZQUFZLEtBQUssS0FBSyxjQUFjLFNBQVM7VUFDN0MsV0FBVyxNQUFNLEdBQUcsS0FBSztTQUMzQjtTQUNBLE9BQU87UUFDVCxDQUFDO1FBQ0QsT0FBTyxjQUFjO1FBQ3JCLFlBQVksTUFBTSxHQUFHLE1BQU0sR0FBRyxJQUFJLElBQUksT0FBTyxTQUFTO1FBQ3RELFdBQVcsUUFBUSxPQUFPLEdBQUcsQ0FBQztRQUM5QjtPQUNGO01BQ0YsT0FBTztPQUNMLE1BQU0sS0FBTSxLQUFLLElBQUs7T0FDdEIsTUFBTSxLQUFNLEtBQUssSUFBSztPQUN0QixNQUFNLG9CQUFvQjtNQUM1QjtLQUNGO0lBQ0Y7R0FDRjs7R0FHQSxXQUFXLFFBQVEsU0FBUyxVQUFVO0lBQ3BDLElBQUksS0FBSztJQUNULElBQUksVUFBVSxNQUFNLEdBQUcsTUFBTSxDQUFDOztJQUc5QixJQUFJLE1BQU0sWUFBWTtLQUNwQixJQUFJLFVBQVU7S0FDZCxJQUFJLElBQUksR0FBRyxHQUFHLE1BQU0sT0FBTyxHQUFHLEdBQUcsS0FBSyxLQUFLLENBQUM7S0FDNUMsSUFBSSxjQUFjO0tBQ2xCLElBQUksWUFBWTtLQUNoQixJQUFJLE9BQU87S0FFWCxJQUFJLFlBQVk7S0FDaEIsSUFBSSxLQUFLOztLQUdULElBQUksWUFBWTtLQUNoQixJQUFJLE9BQU87S0FDWCxJQUFJLFNBQVMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxNQUFNLE9BQU8sRUFBRTtJQUN6Qzs7SUFHQSxJQUFJLFlBQVksTUFBTTtJQUN0QixJQUFJLGNBQWMsTUFBTTtJQUN4QixJQUFJLGFBQWEsTUFBTSxTQUFTLEtBQUs7SUFDckMsSUFBSSxTQUFTLENBQUMsTUFBTSxPQUFPLEdBQUcsQ0FBQyxNQUFNLE9BQU8sR0FBRyxNQUFNLE1BQU0sTUFBTSxJQUFJO0lBQ3JFLElBQUksYUFBYTs7SUFHakIsSUFBSSxZQUFZO0lBQ2hCLE1BQU0sVUFBVSxLQUFLLElBQUksR0FBRyxNQUFNLE9BQU8sQ0FBQztJQUMxQyxJQUFJLFNBQVMsQ0FBQyxNQUFNLE9BQU8sR0FBRyxDQUFDLE1BQU0sT0FBTyxHQUFHLFNBQVMsT0FBTztJQUMvRCxJQUFJLFNBQVMsTUFBTSxPQUFPLEdBQUcsQ0FBQyxNQUFNLE9BQU8sR0FBRyxTQUFTLE9BQU87O0lBRzlELElBQUksU0FBUyxDQUFDLE1BQU0sT0FBTyxHQUFHLE1BQU0sT0FBTyxHQUFHLE1BQU0sT0FBTyxHQUFHLENBQUM7O0lBRy9ELE1BQU0sT0FBTyxLQUFLLElBQUksSUFBSSxNQUFNLE9BQU8sR0FBRztJQUMxQyxNQUFNLE9BQU87SUFDYixNQUFNLFVBQVUsS0FBSyxJQUFJLEdBQUcsTUFBTSxLQUFLLE1BQU0sS0FBSztJQUVsRCxJQUFJLFlBQVk7SUFDaEIsSUFBSSxTQUFTLENBQUMsT0FBTyxHQUFHLENBQUMsTUFBTSxPQUFPLEdBQUcsTUFBTSxJQUFJO0lBQ25ELElBQUksWUFBWSxNQUFNLFNBQVMsWUFBWTtJQUMzQyxJQUFJLFNBQVMsQ0FBQyxPQUFPLEdBQUcsQ0FBQyxNQUFNLE9BQU8sR0FBRyxPQUFPLFNBQVMsSUFBSTs7SUFHN0QsSUFBSSxNQUFNLFFBQVE7S0FDaEIsSUFBSSxZQUFZO0tBQ2hCLElBQUksT0FBTztLQUNYLElBQUksU0FBUyxXQUFXLENBQUMsSUFBSSxDQUFDLE1BQU0sT0FBTyxFQUFFO0lBQy9DO0lBRUEsSUFBSSxRQUFRO0dBQ2QsQ0FBQzs7R0FHRCxNQUFNLE1BQU0sWUFBWSxJQUFJLElBQUk7R0FDaEMsYUFBYSxTQUFTLFVBQVU7SUFDOUIsTUFBTSxNQUFNLFlBQVksTUFBTSxNQUFNLEVBQUUsT0FBTyxNQUFNLE9BQU87SUFDMUQsSUFBSSxDQUFDLEtBQUs7SUFDVixNQUFNLFNBQVMsSUFBSSxPQUFPLEtBQUssSUFBSSxNQUFNLE9BQU8sSUFBSSxPQUFPLFNBQVMsQ0FBQzs7SUFHckUsTUFBTSxpQkFBaUIsV0FBVyxRQUFRLFFBQVEsTUFBTTtLQUN0RCxPQUFPLEtBQUssTUFBTSxHQUFHLE1BQU0sR0FBRyxFQUFFLEdBQUcsRUFBRSxDQUFDLEtBQUssT0FBTztJQUNwRCxDQUFDOztJQUdELElBQUksU0FBdUI7SUFDM0IsSUFBSSxlQUFlLFNBQVMsR0FBRztLQUM3QixJQUFJLE1BQU0sZUFBZSxTQUFTO01BQ2hDLFNBQVMsZUFBZSxRQUFRLE1BQU0sU0FBVSxLQUFLLG1CQUFtQixLQUFLLG1CQUFtQixPQUFPLElBQUs7S0FDOUcsT0FBTyxJQUFJLE1BQU0sZUFBZSxhQUFhO01BQzNDLFNBQVMsZUFBZSxRQUFRLE1BQU0sU0FBVSxLQUFLLEtBQUssS0FBSyxLQUFLLE9BQU8sSUFBSztLQUNsRixPQUFPLElBQUksTUFBTSxlQUFlLFdBQVc7TUFDekMsU0FBUyxlQUFlLFFBQVEsTUFBTSxTQUFVLEtBQUssS0FBSyxLQUFLLEtBQUssT0FBTyxJQUFLO0tBQ2xGLE9BQU87O01BRUwsU0FBUyxlQUFlLFFBQVEsTUFBTSxTQUNwQyxLQUFLLE1BQU0sR0FBRyxNQUFNLEdBQUcsS0FBSyxHQUFHLEtBQUssQ0FBQyxJQUFJLEtBQUssTUFBTSxHQUFHLE1BQU0sR0FBRyxLQUFLLEdBQUcsS0FBSyxDQUFDLElBQUksT0FBTyxJQUMzRjtLQUNGO0lBQ0Y7O0lBR0EsSUFBSSxDQUFDLFlBQVksVUFBVSxNQUFNLE1BQU0sZ0JBQWdCLE9BQU8sVUFBVTtLQUN0RSxNQUFNLGVBQWU7O0tBR3JCLElBQUksTUFBTSxZQUFZLE9BQU87TUFDM0IsSUFBSSxNQUFNLFVBQVUsR0FBRztPQUNyQixPQUFPLFdBQVc7TUFDcEIsT0FBTyxJQUFJLEtBQUssT0FBTyxJQUFJLEtBQU07T0FDL0IsT0FBTyxTQUFTO01BQ2xCLE9BQU87T0FDTCxPQUFPLFVBQVU7TUFDbkI7S0FDRixPQUFPLElBQUksTUFBTSxZQUFZLGFBQWE7TUFDeEMsT0FBTyxpQkFBaUI7S0FDMUIsT0FBTyxJQUFJLE1BQU0sWUFBWSxnQkFBZ0I7TUFDM0MsT0FBTyxRQUFRO0tBQ2pCLE9BQU8sSUFBSSxNQUFNLFlBQVksa0JBQWtCO01BQzdDLE9BQU8sV0FBVztLQUNwQixPQUFPO01BQ0wsT0FBTyxVQUFVO0tBQ25COztLQUdBLE1BQU0sWUFBWSxNQUFNLFlBQVksU0FBUyxNQUFNLFNBQVM7S0FDNUQsTUFBTSxZQUFZLE1BQU0sWUFBWTtLQUNwQyxNQUFNLFdBQVcsSUFBSSxlQUFlO0tBQ3BDLE1BQU0sY0FBYyxJQUFJLGVBQWU7S0FDdkMsTUFBTSxhQUFhLElBQUksZUFBZTtLQUV0QyxNQUFNLGlCQUFpQixZQUFZLEtBQU0sWUFBWSxLQUFNO0tBQzNELE1BQU0sZUFBZSxZQUFZLElBQU0sWUFBWSxNQUFNO0tBQ3pELE1BQU0sZUFBZSxXQUFXLEtBQUs7O0tBR3JDLElBQUksY0FBYyxPQUFPO0tBQ3pCLElBQUksY0FBYyxLQUFLLE9BQU8sSUFBSSxJQUFLO01BQ3JDLGNBQWMsS0FBSyxNQUFNLE9BQU8sU0FBUyxHQUFHO0tBQzlDO0tBRUEsZUFBZSxRQUFRLEtBQUs7TUFDMUIsSUFBSSxVQUFVLEtBQUssT0FBTyxDQUFDLENBQUMsU0FBUztNQUNyQyxRQUFRLE1BQU07TUFDZCxRQUFRLE1BQU07TUFDZCxTQUFTLE9BQU87TUFDaEIsU0FBUyxPQUFPO01BQ2hCLGVBQWUsT0FBTztNQUN0QixPQUFPLFlBQVksWUFBWSxJQUFJO01BQ25DLE1BQU0sWUFBWSxVQUFVLElBQUk7TUFDaEMsVUFBVTtNQUNWLE9BQU8sV0FBVyxNQUFNLElBQUksZUFBZSxTQUFTLE1BQU07TUFDMUQsUUFBUTtNQUNSO01BQ0E7TUFDQTtLQUNGLENBQUM7SUFDSDtHQUNGLENBQUM7O0dBR0QsSUFBSSxDQUFDLFVBQVU7SUFDYixLQUFLLElBQUksSUFBSSxlQUFlLFFBQVEsU0FBUyxHQUFHLEtBQUssR0FBRyxLQUFLO0tBQzNELE1BQU0sSUFBSSxlQUFlLFFBQVE7S0FDakMsRUFBRSxZQUFZLEVBQUUsUUFBUTtLQUV4QixNQUFNLFFBQVEsRUFBRSxVQUFVLEVBQUUsVUFBVSxFQUFFLFVBQVUsS0FBSyxJQUFJLEdBQUcsRUFBRSxRQUFRO0tBQ3hFLE1BQU0sUUFBUSxFQUFFLFVBQVUsRUFBRSxVQUFVLEVBQUUsVUFBVSxLQUFLLElBQUksR0FBRyxFQUFFLFFBQVE7O0tBR3hFLElBQUksVUFBVTtLQUNkLElBQUksRUFBRSxTQUFTLFVBQVU7TUFDdkIsSUFBSSxJQUFJLE9BQU8sT0FBTyxHQUFHLEdBQUcsS0FBSyxLQUFLLENBQUM7S0FDekMsT0FBTyxJQUFJLEVBQUUsU0FBUyxRQUFRO01BQzVCLElBQUksSUFBSSxPQUFPLE9BQU8sR0FBRyxHQUFHLEtBQUssS0FBSyxDQUFDO0tBQ3pDLE9BQU8sSUFBSSxFQUFFLFNBQVMsU0FBUztNQUM3QixJQUFJLElBQUksT0FBTyxPQUFPLEdBQUcsR0FBRyxLQUFLLEtBQUssQ0FBQztLQUN6QyxPQUFPO01BQ0wsSUFBSSxJQUFJLE9BQU8sT0FBTyxHQUFHLEdBQUcsS0FBSyxLQUFLLENBQUM7S0FDekM7S0FDQSxJQUFJLFlBQVksRUFBRTtLQUNsQixJQUFJLGNBQWMsRUFBRTtLQUNwQixJQUFJLGFBQWE7S0FDakIsSUFBSSxLQUFLO0tBQ1QsSUFBSSxhQUFhOztLQUdqQixJQUFJLGNBQWMsRUFBRTtLQUNwQixJQUFJLFlBQVksRUFBRSxTQUFTLFdBQVcsRUFBRSxTQUFTLFdBQVcsSUFBSTtLQUNoRSxJQUFJLFVBQVU7S0FDZCxJQUFJLE9BQU8sRUFBRSxRQUFRLEVBQUUsTUFBTTtLQUM3QixJQUFJLE9BQU8sT0FBTyxLQUFLO0tBQ3ZCLElBQUksT0FBTzs7S0FHWCxJQUFJLEVBQUUsWUFBWSxHQUFHOztNQUVuQixJQUFJLEVBQUUsZ0JBQWdCLEVBQUUsZUFBZSxHQUFHO09BQ3hDLE9BQU8sY0FBYztPQUNyQixZQUFZLEVBQUUsU0FBUyxFQUFFLFNBQVMsYUFBYSxTQUFTO09BRXhELFdBQVcsUUFBUSxTQUFTLE9BQU87UUFDakMsSUFBSSxLQUFLLEVBQUUsU0FBUyxFQUFFLFNBQVMsR0FBRyxHQUFHLEdBQUcsQ0FBQyxNQUFNLEVBQUUsZ0JBQWdCLEtBQUs7U0FDcEUsR0FBRyxNQUFNLEVBQUU7U0FDWCxZQUFZLEdBQUcsR0FBRyxHQUFHLElBQUksR0FBRyxJQUFJLEVBQUUsVUFBVSxTQUFTO1NBQ3JELElBQUksR0FBRyxNQUFNLEdBQUc7VUFDZCxNQUFNLE1BQU0sV0FBVyxRQUFRLFFBQVEsRUFBRTtVQUN6QyxJQUFJLE9BQU8sR0FBRztXQUNaLFdBQVcsUUFBUSxPQUFPLEtBQUssQ0FBQztXQUNoQyxTQUFTLE1BQU0sSUFBSSxHQUFHLE1BQU07V0FDNUIsWUFBWSxHQUFHLEdBQUcsR0FBRyxHQUFHLEtBQUssR0FBRyxVQUFVLFNBQVM7V0FDbkQsT0FBTyxTQUFTO1VBQ2xCO1NBQ0Y7UUFDRjtPQUNGLENBQUM7TUFDSCxPQUFPOztPQUVMLE1BQU0sV0FBVyxXQUFXLFFBQVEsTUFBTSxNQUFNLEVBQUUsT0FBTyxFQUFFLGFBQWEsS0FDdEUsV0FBVyxRQUFRLE1BQU0sTUFBTSxLQUFLLEVBQUUsU0FBUyxFQUFFLFNBQVMsRUFBRSxHQUFHLEVBQUUsQ0FBQyxJQUFJLEVBQUU7T0FFMUUsSUFBSSxVQUFVO1FBQ1osU0FBUyxNQUFNLEVBQUU7O1FBR2pCLElBQUksRUFBRSxTQUFTLGFBQWE7U0FDMUIsTUFBTSxlQUFlLFdBQVcsUUFDN0IsUUFBUSxNQUFNLEVBQUUsT0FBTyxTQUFTLE1BQU0sS0FBSyxTQUFTLEdBQUcsU0FBUyxHQUFHLEVBQUUsR0FBRyxFQUFFLENBQUMsSUFBSSxFQUFFLENBQUMsQ0FDbEYsTUFBTSxHQUFHLENBQUM7U0FFYixhQUFhLFNBQVMsUUFBUTtVQUM1QixNQUFNLFdBQVcsS0FBSyxNQUFNLEVBQUUsU0FBUyxHQUFJO1VBQzNDLElBQUksTUFBTTtVQUNWLFlBQVksSUFBSSxHQUFHLElBQUksSUFBSSxHQUFHLEtBQUssWUFBWSxTQUFTO1VBQ3hELElBQUksSUFBSSxNQUFNLEdBQUc7V0FDZixNQUFNLE1BQU0sV0FBVyxRQUFRLFFBQVEsR0FBRztXQUMxQyxJQUFJLE9BQU8sR0FBRztZQUNaLFdBQVcsUUFBUSxPQUFPLEtBQUssQ0FBQztZQUNoQyxTQUFTLE1BQU0sSUFBSSxJQUFJLE1BQU07WUFDN0IsWUFBWSxJQUFJLEdBQUcsSUFBSSxHQUFHLEtBQUssSUFBSSxVQUFVLFNBQVM7V0FDeEQ7VUFDRjtTQUNGLENBQUM7UUFDSDs7UUFHQSxJQUFJLEVBQUUsa0JBQWtCLEVBQUUsY0FBYztTQUN0QyxTQUFTLGFBQWE7VUFDcEIsWUFBWSxFQUFFO1VBQ2QsVUFBVSxFQUFFO1NBQ2Q7U0FDQSxZQUFZLFNBQVMsR0FBRyxTQUFTLElBQUksSUFBSSxrQkFBa0IsU0FBUztRQUN0RTs7UUFHQSxNQUFNLFNBQVMsRUFBRSxTQUFTLGNBQWMsRUFBRSxTQUFTO1FBQ25ELFlBQ0UsU0FBUyxLQUFLLEtBQUssT0FBTyxJQUFJLE1BQU8sSUFDckMsU0FBUyxJQUFJLEdBQ2IsU0FBUyxNQUFNLEVBQUUsT0FBTyxVQUFVLElBQUksRUFBRSxVQUN4QyxTQUFTLFlBQVksRUFBRSxTQUFTLFVBQVUsWUFBWSxFQUFFLFNBQVMsU0FBUyxZQUFZLFNBQ3hGOztRQUdBLElBQUksU0FBUyxNQUFNLEdBQUc7U0FDcEIsTUFBTSxXQUFXLFdBQVcsUUFBUSxRQUFRLFFBQVE7U0FDcEQsSUFBSSxZQUFZLEdBQUc7VUFDakIsV0FBVyxRQUFRLE9BQU8sVUFBVSxDQUFDO1VBQ3JDLFNBQVMsTUFBTSxJQUFJLFNBQVMsTUFBTTtVQUNsQyxZQUFZLFNBQVMsR0FBRyxTQUFTLEdBQUcsS0FBSyxTQUFTLFVBQVUsU0FBUztVQUNyRSxPQUFPLFNBQVM7U0FDbEI7UUFDRjtPQUNGO01BQ0Y7TUFFQSxlQUFlLFFBQVEsT0FBTyxHQUFHLENBQUM7S0FDcEM7SUFDRjtHQUNGOztHQUdBLGFBQWEsU0FBUyxVQUFVO0lBQzlCLE1BQU0sTUFBTSxZQUFZLE1BQU0sTUFBTSxFQUFFLE9BQU8sTUFBTSxPQUFPO0lBQzFELElBQUksQ0FBQyxLQUFLO0lBQ1YsTUFBTSxhQUFhLE1BQU0sZUFBZTtJQUN4QyxNQUFNLFNBQVMsSUFBSSxPQUFPLEtBQUssSUFBSSxNQUFNLE9BQU8sSUFBSSxPQUFPLFNBQVMsQ0FBQzs7SUFHckUsSUFBSSxZQUFZO0tBQ2QsSUFBSSxVQUFVO0tBQ2QsSUFBSSxJQUFJLE1BQU0sR0FBRyxNQUFNLEdBQUcsT0FBTyxPQUFPLEdBQUcsS0FBSyxLQUFLLENBQUM7S0FDdEQsSUFBSSxZQUFZO0tBQ2hCLElBQUksS0FBSztLQUNULElBQUksY0FBYztLQUNsQixJQUFJLFlBQVk7S0FDaEIsSUFBSSxZQUFZLENBQUMsR0FBRyxDQUFDLENBQUM7S0FDdEIsSUFBSSxPQUFPO0tBQ1gsSUFBSSxZQUFZLENBQUMsQ0FBQztJQUNwQjtJQUVBLElBQUksS0FBSztJQUNULElBQUksVUFBVSxNQUFNLEdBQUcsTUFBTSxDQUFDOztJQUc5QixJQUFJLFlBQVksTUFBTSxhQUFhLFlBQVksYUFBYSxZQUFZO0lBQ3hFLElBQUksU0FBUyxDQUFDLElBQUksQ0FBQyxJQUFJLElBQUksRUFBRTtJQUU3QixJQUFJLFlBQVksYUFBYSxZQUFZO0lBQ3pDLElBQUksU0FBUyxDQUFDLElBQUksQ0FBQyxJQUFJLElBQUksRUFBRTs7SUFHN0IsSUFBSSxNQUFNLFlBQVksU0FBUyxVQUFVLFNBQVM7O0tBRWhELElBQUksS0FBSztLQUNULElBQUksVUFBVTtLQUNkLElBQUksSUFBSSxHQUFHLEdBQUcsSUFBSSxHQUFHLEtBQUssS0FBSyxDQUFDO0tBQ2hDLElBQUksS0FBSztLQUNULElBQUksVUFBVSxVQUFVLFNBQVMsQ0FBQyxJQUFJLENBQUMsSUFBSSxJQUFJLEVBQUU7S0FDakQsSUFBSSxRQUFROztLQUdaLElBQUksTUFBTSxTQUFTLEdBQUc7TUFDcEIsSUFBSSxVQUFVO01BQ2QsSUFBSSxJQUFJLEdBQUcsR0FBRyxJQUFJLEdBQUcsS0FBSyxLQUFLLENBQUM7TUFDaEMsSUFBSSxjQUFjO01BQ2xCLElBQUksWUFBWTtNQUNoQixJQUFJLE9BQU87O01BR1gsSUFBSSxZQUFZO01BQ2hCLElBQUksT0FBTztNQUNYLElBQUksU0FBUyxNQUFNLElBQUksQ0FBQyxFQUFFO0tBQzVCO0lBQ0YsT0FBTzs7S0FFTCxJQUFJLE9BQU87S0FDWCxJQUFJLFlBQVk7S0FDaEIsSUFBSSxlQUFlO0tBQ25CLElBQUksU0FBUyxJQUFJLE1BQU0sR0FBRyxDQUFDO0lBQzdCOztJQUdBLElBQUksTUFBTSxRQUFRLEdBQUc7S0FDbkIsSUFBSSxZQUFZO0tBQ2hCLElBQUksT0FBTztLQUNYLElBQUksWUFBWTtLQUNoQixJQUFJLFNBQVMsSUFBSSxPQUFPLE1BQU0sS0FBSyxHQUFHLEdBQUcsQ0FBQyxFQUFFO0lBQzlDOztJQUdBLElBQUksTUFBTSxZQUFZO0tBQ3BCLElBQUksWUFBWTtLQUNoQixJQUFJLE9BQU87S0FDWCxJQUFJLFlBQVk7S0FDaEIsSUFBSSxTQUFTLFVBQVUsR0FBRyxFQUFFO0lBQzlCO0lBRUEsSUFBSSxRQUFRO0dBQ2QsQ0FBQzs7R0FHRCxJQUFJLHdCQUF3QixVQUFVO0lBQ3BDLE1BQU0sTUFBTSxZQUFZLE1BQU0sTUFBTSxFQUFFLE9BQU8sb0JBQW9CO0lBQ2pFLElBQUksS0FBSztLQUNQLE1BQU0sU0FBUyxjQUFjLFNBQVMsR0FBRyxTQUFTLENBQUM7S0FDbkQsTUFBTSxXQUFXLGFBQWEsTUFBTSxNQUFNLEtBQUssRUFBRSxHQUFHLEVBQUUsR0FBRyxTQUFTLEdBQUcsU0FBUyxDQUFDLElBQUksRUFBRTtLQUNyRixNQUFNLFdBQVcsQ0FBQyxVQUFVLENBQUMsWUFBWSxRQUFRLElBQUk7O0tBR3JELElBQUksVUFBVTtLQUNkLElBQUksSUFBSSxTQUFTLEdBQUcsU0FBUyxHQUFHLElBQUksT0FBTyxFQUFFLENBQUMsT0FBTyxHQUFHLEtBQUssS0FBSyxDQUFDO0tBQ25FLElBQUksWUFBWSxXQUFXLDRCQUE0QjtLQUN2RCxJQUFJLEtBQUs7S0FDVCxJQUFJLGNBQWMsV0FBVyxZQUFZO0tBQ3pDLElBQUksWUFBWTtLQUNoQixJQUFJLE9BQU87O0tBR1gsSUFBSSxLQUFLO0tBQ1QsSUFBSSxVQUFVLFNBQVMsR0FBRyxTQUFTLENBQUM7S0FDcEMsSUFBSSxjQUFjO0tBQ2xCLElBQUksWUFBWSxXQUFXLFlBQVk7S0FDdkMsSUFBSSxTQUFTLENBQUMsSUFBSSxDQUFDLElBQUksSUFBSSxFQUFFO0tBRTdCLElBQUksSUFBSSxPQUFPLFNBQVMsVUFBVSxTQUFTO01BQ3pDLElBQUksS0FBSztNQUNULElBQUksVUFBVTtNQUNkLElBQUksSUFBSSxHQUFHLEdBQUcsSUFBSSxHQUFHLEtBQUssS0FBSyxDQUFDO01BQ2hDLElBQUksS0FBSztNQUNULElBQUksVUFBVSxVQUFVLFNBQVMsQ0FBQyxJQUFJLENBQUMsSUFBSSxJQUFJLEVBQUU7TUFDakQsSUFBSSxRQUFRO0tBQ2QsT0FBTztNQUNMLElBQUksT0FBTztNQUNYLElBQUksWUFBWTtNQUNoQixJQUFJLGVBQWU7TUFDbkIsSUFBSSxTQUFTLElBQUksTUFBTSxHQUFHLENBQUM7S0FDN0I7S0FDQSxJQUFJLFFBQVE7SUFDZDtHQUNGOztHQUdBLEtBQUssSUFBSSxJQUFJLGFBQWEsUUFBUSxTQUFTLEdBQUcsS0FBSyxHQUFHLEtBQUs7SUFDekQsTUFBTSxJQUFJLGFBQWEsUUFBUTtJQUMvQixFQUFFLEtBQUssRUFBRTtJQUNULEVBQUUsS0FBSyxFQUFFO0lBQ1QsRUFBRSxRQUFRLEtBQUs7SUFFZixJQUFJLEVBQUUsUUFBUSxHQUFHO0tBQ2YsYUFBYSxRQUFRLE9BQU8sR0FBRyxDQUFDO0tBQ2hDO0lBQ0Y7SUFFQSxJQUFJLEtBQUs7SUFDVCxJQUFJLGNBQWMsS0FBSyxJQUFJLEdBQUcsRUFBRSxJQUFJO0lBQ3BDLElBQUksWUFBWSxFQUFFO0lBQ2xCLElBQUksT0FBTztJQUNYLElBQUksU0FBUyxFQUFFLFFBQVEsSUFBSSxFQUFFLEdBQUcsRUFBRSxDQUFDO0lBQ25DLElBQUksUUFBUTtHQUNkOztHQUdBLElBQUksY0FBYyxjQUFjLFdBQVcsUUFBUSxXQUFXLEdBQUc7SUFDL0QsYUFBYSxTQUFTO0lBQ3RCLGlCQUFpQixDQUFDO0lBQ2xCLE9BQU8sY0FBYzs7SUFHckIsTUFBTSxnQkFBZ0IsTUFBTSxPQUFPO0lBQ25DLFNBQVMsTUFBTSxJQUFJLGFBQWE7SUFDaEMsWUFBWSxLQUFLLEtBQUssU0FBUyxLQUFLLGdCQUFnQixpQkFBaUIsU0FBUzs7SUFHOUUsYUFBYSxTQUFTLE1BQU07S0FDMUIsSUFBSSxFQUFFLFlBQVksY0FBYztNQUM5QixNQUFNLFFBQVE7T0FBQztPQUFLO09BQUs7T0FBSztNQUFJLENBQUMsQ0FBQyxLQUFLLElBQUksRUFBRSxPQUFPLENBQUM7TUFDdkQsU0FBUyxNQUFNLElBQUksS0FBSztNQUN4QixZQUFZLEVBQUUsR0FBRyxFQUFFLElBQUksSUFBSSxLQUFLLE1BQU0sUUFBUSxTQUFTO0tBQ3pEO0lBQ0YsQ0FBQzs7SUFHRCxJQUFJLFFBQVEsVUFBVTtLQUNwQixPQUFPLFlBQVk7S0FDbkIsV0FBVyxNQUFNLE9BQU8sTUFBTSxJQUFJO0lBQ3BDO0dBQ0Y7R0FFQSxZQUFZLHNCQUFzQixJQUFJO0VBQ3hDO0VBRUEsWUFBWSxzQkFBc0IsSUFBSTtFQUN0QyxhQUFhLHFCQUFxQixTQUFTO0NBQzdDLEdBQUc7RUFDRDtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0NBQ0YsQ0FBQzs7Q0FHRCxNQUFNLHFCQUFxQixNQUEyQztFQUNwRSxNQUFNLFNBQVMsVUFBVTtFQUN6QixJQUFJLENBQUMsUUFBUTtFQUNiLE1BQU0sT0FBTyxPQUFPLHNCQUFzQjtFQUMxQyxNQUFNLFNBQVMsT0FBTyxRQUFRLEtBQUs7RUFDbkMsTUFBTSxTQUFTLE9BQU8sU0FBUyxLQUFLO0VBQ3BDLE1BQU0sS0FBSyxFQUFFLFVBQVUsS0FBSyxRQUFRO0VBQ3BDLE1BQU0sS0FBSyxFQUFFLFVBQVUsS0FBSyxPQUFPOztFQUduQyxNQUFNLGVBQWUsYUFBYSxNQUFNLE1BQU0sS0FBSyxFQUFFLEdBQUcsRUFBRSxHQUFHLEdBQUcsQ0FBQyxJQUFJLEVBQUU7RUFDdkUsSUFBSSxjQUFjO0dBQ2hCLG9CQUFvQixZQUFZO0dBQ2hDO0VBQ0Y7O0VBR0EsSUFBSSxzQkFBc0I7R0FDeEIsTUFBTSxNQUFNLFlBQVksTUFBTSxNQUFNLEVBQUUsT0FBTyxvQkFBb0I7R0FDakUsSUFBSSxDQUFDLEtBQUs7R0FFVixNQUFNLFNBQVMsY0FBYyxHQUFHLENBQUM7R0FDakMsTUFBTSxXQUFXLGFBQWEsTUFBTSxNQUFNLEtBQUssRUFBRSxHQUFHLEVBQUUsR0FBRyxHQUFHLENBQUMsSUFBSSxFQUFFO0dBRW5FLElBQUksQ0FBQyxVQUFVLENBQUMsWUFBWSxRQUFRLElBQUksVUFBVTtJQUNoRCxNQUFNLFdBQXdCO0tBQzVCLFlBQVksV0FBVyxLQUFLLE9BQU8sQ0FBQyxDQUFDLFNBQVMsRUFBRSxDQUFDLENBQUMsT0FBTyxHQUFHLENBQUM7S0FDN0QsU0FBUyxJQUFJO0tBQ2I7S0FDQTtLQUNBLE9BQU87S0FDUCxlQUFlLElBQUk7S0FDbkIsWUFBWTtLQUNaLGNBQWM7S0FDZCxPQUFPO0tBQ1AsYUFBYTtJQUNmO0lBRUEsU0FBUyxNQUFNLElBQUksSUFBSSxRQUFRO0lBQy9CLGlCQUFpQixTQUFTLENBQUMsR0FBRyxNQUFNLFFBQVEsQ0FBQztJQUM3QyxxQkFBcUIsSUFBSSxFQUFFO0lBQzNCLE9BQU8sZUFBZTtJQUN0QixZQUFZLEdBQUcsR0FBRyxJQUFJLElBQUksU0FBUyxJQUFJLFNBQVM7R0FDbEQ7RUFDRixPQUFPOztHQUVMLG9CQUFvQixJQUFJO0VBQzFCO0NBQ0Y7Q0FFQSxNQUFNLG1CQUFtQixNQUEyQztFQUNsRSxNQUFNLFNBQVMsVUFBVTtFQUN6QixJQUFJLENBQUMsUUFBUTtFQUNiLE1BQU0sT0FBTyxPQUFPLHNCQUFzQjtFQUMxQyxNQUFNLFNBQVMsT0FBTyxRQUFRLEtBQUs7RUFDbkMsTUFBTSxTQUFTLE9BQU8sU0FBUyxLQUFLO0VBQ3BDLFlBQVk7R0FDVixJQUFJLEVBQUUsVUFBVSxLQUFLLFFBQVE7R0FDN0IsSUFBSSxFQUFFLFVBQVUsS0FBSyxPQUFPO0VBQzlCLENBQUM7Q0FDSDtDQUVBLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFBZixDQUVFLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQWY7SUFFRSx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsUUFBRDtNQUFNLFdBQVU7Z0JBQVU7S0FBUTs7OztlQUNsQyx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxRQUFELFlBQU0saUJBQW9COzs7O2dCQUMxQix3QkFBQyxRQUFEO09BQU0sV0FBVyxTQUFTLEtBQUssbUJBQW1CO2lCQUFsRCxDQUFtRSxRQUFPLEdBQU87Ozs7O2NBQzlFOzs7OztlQUNMLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUNiLHdCQUFDLE9BQUQ7T0FDRSxXQUFXLHNDQUFzQyxTQUFTLEtBQUssaUJBQWlCO09BQ2hGLE9BQU8sRUFBRSxPQUFPLEdBQUcsT0FBTyxHQUFHO01BQzlCOzs7OztLQUNFOzs7O2FBQ0Y7Ozs7YUFDRjs7Ozs7O0lBR0wsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZjtNQUNFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQXlCO09BQVc7Ozs7aUJBQ3BELHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmO1NBQ0c7U0FBSztTQUFDLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUFoQixDQUF5QyxNQUFHLFFBQWU7Ozs7OztRQUMvRDs7Ozs7ZUFDRjs7Ozs7O01BRUosY0FBYyxhQUFhLE9BQU8sWUFDakMsd0JBQUMsVUFBRDtPQUNFLFNBQVM7T0FDVCxXQUFVO2lCQUVWLHdCQUFDLFFBQUQsWUFBTSx1QkFBMEI7Ozs7O01BQzFCOzs7OztNQUdULGNBQWMsY0FDYix3QkFBQyxRQUFEO09BQU0sV0FBVTtpQkFBaEI7UUFBK0c7UUFDbEc7UUFBaUI7T0FDeEI7Ozs7OztLQUVMOzs7Ozs7SUFHTCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsVUFBRDtNQUNFLGVBQWUsWUFBWSxDQUFDLFFBQVE7TUFDcEMsV0FBVTtnQkFFVCxXQUFXLGtCQUFrQjtLQUN4Qjs7OztlQUNSLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUNaO09BQUM7T0FBRztPQUFHO01BQUMsQ0FBQyxDQUFDLEtBQUssUUFDZCx3QkFBQyxVQUFEO09BRUUsZUFBZSxhQUFhLEdBQUc7T0FDL0IsV0FBVyxhQUNULGNBQWMsTUFBTSwyQkFBMkI7aUJBSm5ELENBT0csS0FBSSxHQUNDO1NBUEQ7Ozs7YUFPQyxDQUNUO0tBQ0U7Ozs7YUFDRjs7Ozs7O0dBQ0Y7Ozs7O1lBR0wsd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFBZjtJQUNFLHdCQUFDLFVBQUQ7S0FDRSxLQUFLO0tBQ0wsT0FBTztLQUNQLFFBQVE7S0FDUixTQUFTO0tBQ1QsYUFBYTtLQUNiLG9CQUFvQixZQUFZLElBQUk7S0FDcEMsV0FBVTtJQUNYOzs7OztJQUdBLFVBQ0Msd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsUUFBRCxFQUFNLFdBQVUsaURBQWtEOzs7O2dCQUNsRSx3QkFBQyxRQUFELFlBQU0sMEJBQTZCOzs7O2NBQ2hDOzs7OztlQUNMLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUNaLGFBQWEsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssS0FBSyxRQUNoQyx3QkFBQyxPQUFEO09BQWUsV0FBVTtpQkFBekIsQ0FBb0MsT0FDOUIsR0FDRDtTQUZLOzs7O2FBRUwsQ0FDTjtLQUNFOzs7O2FBQ0Y7Ozs7OztJQUlOLHdCQUNDLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQTBLO0lBRXBMOzs7OztHQUVKOzs7OztVQUNGOzs7Ozs7QUFFVCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJHYW1lQ2FudmFzLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlUmVmLCB1c2VFZmZlY3QsIHVzZVN0YXRlLCB1c2VDYWxsYmFjayB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IFBsYWNlZFRvd2VyLCBFbmVteSwgUHJvamVjdGlsZSwgUGFydGljbGUsIERpZmZpY3VsdHkgfSBmcm9tICcuLi90eXBlcy9nYW1lJztcbmltcG9ydCB7IFRPV0VSU19EQVRBLCBDQVRfSU1BR0VfVVJMIH0gZnJvbSAnLi4vZGF0YS9jb25zdGFudHMnO1xuaW1wb3J0IHsgc291bmRzIH0gZnJvbSAnLi4vdXRpbHMvc291bmQnO1xuXG5pbnRlcmZhY2UgR2FtZUNhbnZhc1Byb3BzIHtcbiAgZGlmZmljdWx0eTogRGlmZmljdWx0eTtcbiAgaXNDb29wOiBib29sZWFuO1xuICBnYW1lQWN0aXZlOiBib29sZWFuO1xuICBvbkdhbWVPdmVyOiAod2F2ZXNDb21wbGV0ZWQ6IG51bWJlciwgc2NvcmU6IG51bWJlciwgdmljdG9yeTogYm9vbGVhbikgPT4gdm9pZDtcbiAgc2VsZWN0ZWRUb3dlclRvUGxhY2U6IHN0cmluZyB8IG51bGw7XG4gIG9uU2VsZWN0UGxhY2VkVG93ZXI6ICh0b3dlcjogUGxhY2VkVG93ZXIgfCBudWxsKSA9PiB2b2lkO1xuICBzZWxlY3RlZFBsYWNlZFRvd2VySWQ6IHN0cmluZyB8IG51bGw7XG4gIGNhc2g6IG51bWJlcjtcbiAgc2V0Q2FzaDogUmVhY3QuRGlzcGF0Y2g8UmVhY3QuU2V0U3RhdGVBY3Rpb248bnVtYmVyPj47XG4gIG9uVG93ZXJQbGFjZWRTdWNjZXNzOiAodG93ZXJJZDogc3RyaW5nKSA9PiB2b2lkO1xuICBvblRvd2VyVXBncmFkZWRTdWNjZXNzOiAodG93ZXJJZDogc3RyaW5nLCBsZXZlbDogbnVtYmVyKSA9PiB2b2lkO1xuICB3YXZlOiBudW1iZXI7XG4gIHNldFdhdmU6IFJlYWN0LkRpc3BhdGNoPFJlYWN0LlNldFN0YXRlQWN0aW9uPG51bWJlcj4+O1xuICBtYXhXYXZlczogbnVtYmVyO1xuICBnYW1lU3BlZWQ6IG51bWJlcjtcbiAgc2V0R2FtZVNwZWVkOiAoc3BlZWQ6IG51bWJlcikgPT4gdm9pZDtcbiAgaXNQYXVzZWQ6IGJvb2xlYW47XG4gIHNldElzUGF1c2VkOiAocGF1c2VkOiBib29sZWFuKSA9PiB2b2lkO1xuICB1cGdyYWRlVHJpZ2dlcjogbnVtYmVyOyAvLyBpbmNyZW1lbnRlZCBleHRlcm5hbGx5IHRvIHJlZnJlc2ggdG93ZXIgdXBncmFkZXNcbiAgY29vcE1lc3NhZ2VzOiBzdHJpbmdbXTtcbiAgb25TZW5kQ29vcFBpbmc6IChtc2c6IHN0cmluZykgPT4gdm9pZDtcbiAgcGxhY2VkVG93ZXJzOiBQbGFjZWRUb3dlcltdO1xuICBzZXRQbGFjZWRUb3dlcnM6IFJlYWN0LkRpc3BhdGNoPFJlYWN0LlNldFN0YXRlQWN0aW9uPFBsYWNlZFRvd2VyW10+Pjtcbn1cblxuLy8gTWFwIFdheXBvaW50cyAoQ2FudmFzIHNpemU6IDg0MCB4IDUwMClcbmNvbnN0IFdBWVBPSU5UUyA9IFtcbiAgeyB4OiAtMzAsIHk6IDE1MCB9LFxuICB7IHg6IDE4MCwgeTogMTUwIH0sXG4gIHsgeDogMTgwLCB5OiAzNTAgfSxcbiAgeyB4OiA0MjAsIHk6IDM1MCB9LFxuICB7IHg6IDQyMCwgeTogMTIwIH0sXG4gIHsgeDogNjYwLCB5OiAxMjAgfSxcbiAgeyB4OiA2NjAsIHk6IDM0MCB9LFxuICB7IHg6IDg4MCwgeTogMzQwIH0sXG5dO1xuXG5leHBvcnQgY29uc3QgR2FtZUNhbnZhczogUmVhY3QuRkM8R2FtZUNhbnZhc1Byb3BzPiA9ICh7XG4gIGRpZmZpY3VsdHksXG4gIGlzQ29vcCxcbiAgZ2FtZUFjdGl2ZSxcbiAgb25HYW1lT3ZlcixcbiAgc2VsZWN0ZWRUb3dlclRvUGxhY2UsXG4gIG9uU2VsZWN0UGxhY2VkVG93ZXIsXG4gIHNlbGVjdGVkUGxhY2VkVG93ZXJJZCxcbiAgY2FzaCxcbiAgc2V0Q2FzaCxcbiAgb25Ub3dlclBsYWNlZFN1Y2Nlc3MsXG4gIHdhdmUsXG4gIHNldFdhdmUsXG4gIG1heFdhdmVzLFxuICBnYW1lU3BlZWQsXG4gIHNldEdhbWVTcGVlZCxcbiAgaXNQYXVzZWQsXG4gIHNldElzUGF1c2VkLFxuICBjb29wTWVzc2FnZXMsXG4gIG9uU2VuZENvb3BQaW5nLFxuICBwbGFjZWRUb3dlcnMsXG4gIHNldFBsYWNlZFRvd2Vycyxcbn0pID0+IHtcbiAgY29uc3QgY2FudmFzUmVmID0gdXNlUmVmPEhUTUxDYW52YXNFbGVtZW50IHwgbnVsbD4obnVsbCk7XG5cbiAgLy8gQmFzZSBDYXN0bGUgSGVhbHRoXG4gIGNvbnN0IFtiYXNlSHAsIHNldEJhc2VIcF0gPSB1c2VTdGF0ZSgxMDApO1xuICBjb25zdCBtYXhCYXNlSHAgPSAxMDA7XG5cbiAgLy8gV2F2ZSBzdGF0dXNcbiAgY29uc3QgW3dhdmVTdGF0ZSwgc2V0V2F2ZVN0YXRlXSA9IHVzZVN0YXRlPCd3YWl0aW5nJyB8ICdzcGF3bmluZycgfCAnY2xlYXJpbmcnPignd2FpdGluZycpO1xuICBjb25zdCBbd2F2ZUNvdW50ZG93biwgc2V0V2F2ZUNvdW50ZG93bl0gPSB1c2VTdGF0ZSg2KTtcbiAgY29uc3QgW2VuZW1pZXNSZW1haW5pbmcsIHNldEVuZW1pZXNSZW1haW5pbmddID0gdXNlU3RhdGUoMCk7XG5cbiAgLy8gTW91c2UgLyBQb2ludGVyXG4gIGNvbnN0IFttb3VzZVBvcywgc2V0TW91c2VQb3NdID0gdXNlU3RhdGU8eyB4OiBudW1iZXI7IHk6IG51bWJlciB9IHwgbnVsbD4obnVsbCk7XG5cbiAgLy8gQWN0aXZlIGVuZW1pZXMsIHByb2plY3RpbGVzLCBwYXJ0aWNsZXNcbiAgY29uc3QgZW5lbWllc1JlZiA9IHVzZVJlZjxFbmVteVtdPihbXSk7XG4gIGNvbnN0IHByb2plY3RpbGVzUmVmID0gdXNlUmVmPFByb2plY3RpbGVbXT4oW10pO1xuICBjb25zdCBwYXJ0aWNsZXNSZWYgPSB1c2VSZWY8UGFydGljbGVbXT4oW10pO1xuICBjb25zdCBjYXRJbWdSZWYgPSB1c2VSZWY8SFRNTEltYWdlRWxlbWVudCB8IG51bGw+KG51bGwpO1xuXG4gIC8vIENvLW9wIEFJIGZyaWVuZCBzdGF0ZVxuICBjb25zdCBjb29wQWxseVRpbWVyUmVmID0gdXNlUmVmPG51bWJlcj4oMCk7XG5cbiAgLy8gTG9hZCBDYXQgSW1hZ2VcbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBjb25zdCBpbWcgPSBuZXcgSW1hZ2UoKTtcbiAgICBpbWcuc3JjID0gQ0FUX0lNQUdFX1VSTDtcbiAgICBpbWcub25sb2FkID0gKCkgPT4ge1xuICAgICAgY2F0SW1nUmVmLmN1cnJlbnQgPSBpbWc7XG4gICAgfTtcbiAgfSwgW10pO1xuXG4gIC8vIERpc3RhbmNlIGhlbHBlclxuICBjb25zdCBkaXN0ID0gKHgxOiBudW1iZXIsIHkxOiBudW1iZXIsIHgyOiBudW1iZXIsIHkyOiBudW1iZXIpID0+IHtcbiAgICByZXR1cm4gTWF0aC5zcXJ0KCh4MiAtIHgxKSAqKiAyICsgKHkyIC0geTEpICoqIDIpO1xuICB9O1xuXG4gIC8vIENoZWNrIGlmIHBvc2l0aW9uIGlzIG9uIHBhdGhcbiAgY29uc3QgaXNQb2ludE9uUGF0aCA9IChweDogbnVtYmVyLCBweTogbnVtYmVyLCB0b2xlcmFuY2UgPSAzOCk6IGJvb2xlYW4gPT4ge1xuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgV0FZUE9JTlRTLmxlbmd0aCAtIDE7IGkrKykge1xuICAgICAgY29uc3QgcDEgPSBXQVlQT0lOVFNbaV07XG4gICAgICBjb25zdCBwMiA9IFdBWVBPSU5UU1tpICsgMV07XG5cbiAgICAgIGNvbnN0IGwyID0gKHAyLnggLSBwMS54KSAqKiAyICsgKHAyLnkgLSBwMS55KSAqKiAyO1xuICAgICAgaWYgKGwyID09PSAwKSBjb250aW51ZTtcblxuICAgICAgbGV0IHQgPSAoKHB4IC0gcDEueCkgKiAocDIueCAtIHAxLngpICsgKHB5IC0gcDEueSkgKiAocDIueSAtIHAxLnkpKSAvIGwyO1xuICAgICAgdCA9IE1hdGgubWF4KDAsIE1hdGgubWluKDEsIHQpKTtcblxuICAgICAgY29uc3QgcHJvalggPSBwMS54ICsgdCAqIChwMi54IC0gcDEueCk7XG4gICAgICBjb25zdCBwcm9qWSA9IHAxLnkgKyB0ICogKHAyLnkgLSBwMS55KTtcblxuICAgICAgaWYgKGRpc3QocHgsIHB5LCBwcm9qWCwgcHJvalkpIDwgdG9sZXJhbmNlKSB7XG4gICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gZmFsc2U7XG4gIH07XG5cbiAgLy8gQWRkIGZsb2F0aW5nIHBhcnRpY2xlXG4gIGNvbnN0IGFkZFBhcnRpY2xlID0gdXNlQ2FsbGJhY2soKHg6IG51bWJlciwgeTogbnVtYmVyLCB0ZXh0OiBzdHJpbmcsIGNvbG9yOiBzdHJpbmcpID0+IHtcbiAgICBwYXJ0aWNsZXNSZWYuY3VycmVudC5wdXNoKHtcbiAgICAgIGlkOiBNYXRoLnJhbmRvbSgpLnRvU3RyaW5nKCksXG4gICAgICB4LFxuICAgICAgeSxcbiAgICAgIHZ4OiAoTWF0aC5yYW5kb20oKSAtIDAuNSkgKiAxLjUsXG4gICAgICB2eTogLTEuOCAtIE1hdGgucmFuZG9tKCkgKiAxLjIsXG4gICAgICBjb2xvcixcbiAgICAgIHNpemU6IDE0LFxuICAgICAgbGlmZTogMS4wLFxuICAgICAgbWF4TGlmZTogMS4wLFxuICAgICAgdGV4dCxcbiAgICB9KTtcbiAgfSwgW10pO1xuXG4gIC8vIFN0YXJ0IG5leHQgd2F2ZVxuICBjb25zdCBzdGFydE5leHRXYXZlID0gdXNlQ2FsbGJhY2soKCkgPT4ge1xuICAgIGlmICh3YXZlID49IG1heFdhdmVzKSByZXR1cm47XG4gICAgY29uc3QgbmV4dFdhdmUgPSB3YXZlICsgMTtcbiAgICBzZXRXYXZlKG5leHRXYXZlKTtcbiAgICBzZXRXYXZlU3RhdGUoJ3NwYXduaW5nJyk7XG4gICAgc291bmRzLnBsYXlXYXZlU3RhcnQoKTtcblxuICAgIC8vIEdlbmVyYXRlIHdhdmUgZW5lbWllc1xuICAgIGNvbnN0IGNvdW50ID0gNiArIG5leHRXYXZlICogMyArIChkaWZmaWN1bHR5ID09PSAnaGFyZCcgPyA0IDogZGlmZmljdWx0eSA9PT0gJ2luc2FuZScgPyA4IDogMCk7XG4gICAgc2V0RW5lbWllc1JlbWFpbmluZyhjb3VudCk7XG5cbiAgICBsZXQgc3Bhd25lZENvdW50ID0gMDtcbiAgICBjb25zdCBpc0Jvc3NXYXZlID0gbmV4dFdhdmUgJSA1ID09PSAwO1xuXG4gICAgY29uc3Qgc3Bhd25JbnRlcnZhbCA9IHdpbmRvdy5zZXRJbnRlcnZhbCgoKSA9PiB7XG4gICAgICBpZiAoc3Bhd25lZENvdW50ID49IGNvdW50KSB7XG4gICAgICAgIGNsZWFySW50ZXJ2YWwoc3Bhd25JbnRlcnZhbCk7XG4gICAgICAgIHNldFdhdmVTdGF0ZSgnY2xlYXJpbmcnKTtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuXG4gICAgICBzcGF3bmVkQ291bnQrKztcbiAgICAgIGNvbnN0IGlzQm9zcyA9IGlzQm9zc1dhdmUgJiYgc3Bhd25lZENvdW50ID09PSBjb3VudDtcbiAgICAgIGNvbnN0IGlzRmFzdCA9ICFpc0Jvc3MgJiYgTWF0aC5yYW5kb20oKSA8IDAuMjU7XG4gICAgICBjb25zdCBpc0FybW9yZWQgPSAhaXNCb3NzICYmICFpc0Zhc3QgJiYgTWF0aC5yYW5kb20oKSA8IDAuMyAmJiBuZXh0V2F2ZSA+IDM7XG5cbiAgICAgIGxldCBocCA9ICgxOCArIG5leHRXYXZlICogMTQpICogKGRpZmZpY3VsdHkgPT09ICdlYXN5JyA/IDAuOCA6IGRpZmZpY3VsdHkgPT09ICdoYXJkJyA/IDEuMyA6IGRpZmZpY3VsdHkgPT09ICdpbnNhbmUnID8gMS43IDogMS4wKTtcbiAgICAgIGxldCBzcGVlZCA9IDEuMSArIE1hdGgubWluKG5leHRXYXZlICogMC4wNSwgMS4yKTtcbiAgICAgIGxldCBjb2xvciA9ICcjZmFjYzE1JzsgLy8geWVsbG93IG5vb2JcbiAgICAgIGxldCBzaXplID0gMTU7XG4gICAgICBsZXQgbmFtZSA9ICfQndGD0LEnO1xuICAgICAgbGV0IGJvdW50eSA9IDE1ICsgTWF0aC5mbG9vcihuZXh0V2F2ZSAqIDIuNSk7XG5cbiAgICAgIGlmIChpc0Jvc3MpIHtcbiAgICAgICAgaHAgKj0gOC41O1xuICAgICAgICBzcGVlZCA9IDAuNjU7XG4gICAgICAgIGNvbG9yID0gJyNlZjQ0NDQnO1xuICAgICAgICBzaXplID0gMjg7XG4gICAgICAgIG5hbWUgPSBuZXh0V2F2ZSA9PT0gbWF4V2F2ZXMgPyAn8J+RkSDQotCY0KLQkNCdINCg0J7QkdCb0J7QmtCh0JAnIDogJ/Cfkbkg0JzQtdCz0LAt0JHQvtGB0YEg0J3Rg9CxJztcbiAgICAgICAgYm91bnR5ID0gMjUwICsgbmV4dFdhdmUgKiAyMDtcbiAgICAgIH0gZWxzZSBpZiAoaXNGYXN0KSB7XG4gICAgICAgIGhwICo9IDAuNjtcbiAgICAgICAgc3BlZWQgKj0gMS43NTtcbiAgICAgICAgY29sb3IgPSAnIzM4YmRmOCc7XG4gICAgICAgIHNpemUgPSAxMjtcbiAgICAgICAgbmFtZSA9ICfQodC/0LjQtNGA0LDQvdC90LXRgCc7XG4gICAgICB9IGVsc2UgaWYgKGlzQXJtb3JlZCkge1xuICAgICAgICBocCAqPSAyLjI7XG4gICAgICAgIHNwZWVkICo9IDAuODtcbiAgICAgICAgY29sb3IgPSAnIzY0NzQ4Yic7XG4gICAgICAgIHNpemUgPSAxOTtcbiAgICAgICAgbmFtZSA9ICfQkdGA0L7QvdC40YDQvtCy0LDQvdC90YvQuSc7XG4gICAgICB9XG5cbiAgICAgIGNvbnN0IG5ld0VuZW15OiBFbmVteSA9IHtcbiAgICAgICAgaWQ6ICdlbmVteV8nICsgTWF0aC5yYW5kb20oKS50b1N0cmluZygzNikuc3Vic3RyKDIsIDkpLFxuICAgICAgICBuYW1lLFxuICAgICAgICBtYXhIcDogTWF0aC5yb3VuZChocCksXG4gICAgICAgIGhwOiBNYXRoLnJvdW5kKGhwKSxcbiAgICAgICAgc3BlZWQsXG4gICAgICAgIGN1cnJlbnRTcGVlZDogc3BlZWQsXG4gICAgICAgIGJvdW50eSxcbiAgICAgICAgeDogV0FZUE9JTlRTWzBdLngsXG4gICAgICAgIHk6IFdBWVBPSU5UU1swXS55LFxuICAgICAgICBwYXRoSW5kZXg6IDAsXG4gICAgICAgIGRpc3RhbmNlVHJhdmVsZWQ6IDAsXG4gICAgICAgIGNvbG9yLFxuICAgICAgICBzaXplLFxuICAgICAgICBpc0Jvc3MsXG4gICAgICB9O1xuXG4gICAgICBlbmVtaWVzUmVmLmN1cnJlbnQucHVzaChuZXdFbmVteSk7XG4gICAgfSwgNzAwIC8gZ2FtZVNwZWVkKTtcbiAgfSwgW3dhdmUsIG1heFdhdmVzLCBzZXRXYXZlLCBkaWZmaWN1bHR5LCBnYW1lU3BlZWRdKTtcblxuICAvLyBFYXJseSB3YXZlIGNhbGxcbiAgY29uc3QgaGFuZGxlQ2FsbFdhdmVFYXJseSA9ICgpID0+IHtcbiAgICBpZiAod2F2ZVN0YXRlID09PSAnd2FpdGluZycpIHtcbiAgICAgIHNldENhc2goKGMpID0+IGMgKyAzNSk7XG4gICAgICBzb3VuZHMucGxheUNvaW4oKTtcbiAgICAgIGFkZFBhcnRpY2xlKDQyMCwgMjUwLCAnKyQzNSDQl9CwINGA0LDQvdC90LjQuSDRgdGC0LDRgNGCIScsICcjMTBiOTgxJyk7XG4gICAgICBzdGFydE5leHRXYXZlKCk7XG4gICAgfVxuICB9O1xuXG4gIC8vIENvLW9wIFNpbXVsYXRlZCBUZWFtbWF0ZSBwbGFjZW1lbnRcbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBpZiAoIWlzQ29vcCB8fCAhZ2FtZUFjdGl2ZSkgcmV0dXJuO1xuXG4gICAgY29uc3QgaW50ZXJ2YWwgPSB3aW5kb3cuc2V0SW50ZXJ2YWwoKCkgPT4ge1xuICAgICAgY29vcEFsbHlUaW1lclJlZi5jdXJyZW50Kys7XG4gICAgICAvLyBBbGx5IG9jY2FzaW9uYWxseSBwbGFjZXMgb3IgdXBncmFkZXMgYSB0b3dlclxuICAgICAgaWYgKGNvb3BBbGx5VGltZXJSZWYuY3VycmVudCAlIDE4ID09PSAwKSB7XG4gICAgICAgIGNvbnN0IGFsbHlTcG90cyA9IFtcbiAgICAgICAgICB7IHg6IDMwMCwgeTogMjIwIH0sXG4gICAgICAgICAgeyB4OiA1MzAsIHk6IDI0MCB9LFxuICAgICAgICAgIHsgeDogNjcwLCB5OiAyMjAgfSxcbiAgICAgICAgICB7IHg6IDI2MCwgeTogODAgfSxcbiAgICAgICAgXTtcbiAgICAgICAgY29uc3Qgc3BvdCA9IGFsbHlTcG90c1tNYXRoLmZsb29yKE1hdGgucmFuZG9tKCkgKiBhbGx5U3BvdHMubGVuZ3RoKV07XG4gICAgICAgIGNvbnN0IHNwb3RUYWtlbiA9IHBsYWNlZFRvd2Vycy5zb21lKCh0KSA9PiBkaXN0KHQueCwgdC55LCBzcG90LngsIHNwb3QueSkgPCA0NSk7XG5cbiAgICAgICAgaWYgKCFzcG90VGFrZW4gJiYgcGxhY2VkVG93ZXJzLmxlbmd0aCA8IDE0KSB7XG4gICAgICAgICAgY29uc3QgYWxseVRvd2VyOiBQbGFjZWRUb3dlciA9IHtcbiAgICAgICAgICAgIGluc3RhbmNlSWQ6ICdhbGx5XycgKyBNYXRoLnJhbmRvbSgpLnRvU3RyaW5nKCksXG4gICAgICAgICAgICB0b3dlcklkOiBNYXRoLnJhbmRvbSgpID4gMC40ID8gJ2NhdCcgOiAnbm9vYl9rbmlnaHQnLFxuICAgICAgICAgICAgeDogc3BvdC54LFxuICAgICAgICAgICAgeTogc3BvdC55LFxuICAgICAgICAgICAgbGV2ZWw6IDAsXG4gICAgICAgICAgICB0b3RhbEludmVzdGVkOiAyMDAsXG4gICAgICAgICAgICB0YXJnZXRNb2RlOiAnZmlyc3QnLFxuICAgICAgICAgICAgbGFzdFNob3RUaW1lOiAwLFxuICAgICAgICAgICAga2lsbHM6IDAsXG4gICAgICAgICAgICBkYW1hZ2VEZWFsdDogMCxcbiAgICAgICAgICAgIG93bmVyTmFtZTogJ9Cd0LDQv9Cw0YDQvdC40LogUHJvQmFjb24nLFxuICAgICAgICAgICAgaXNDb29wQWxseTogdHJ1ZSxcbiAgICAgICAgICB9O1xuICAgICAgICAgIHNldFBsYWNlZFRvd2VycygocHJldikgPT4gWy4uLnByZXYsIGFsbHlUb3dlcl0pO1xuICAgICAgICAgIG9uU2VuZENvb3BQaW5nKCfQndCw0L/QsNGA0L3QuNC6INC/0L7RgdGC0LDQstC40Lsg0LfQsNGJ0LjRgtC90YPRjiDQsdCw0YjQvdGOIScpO1xuICAgICAgICAgIHNvdW5kcy5wbGF5UGxhY2VUb3dlcigpO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfSwgMTAwMCk7XG5cbiAgICByZXR1cm4gKCkgPT4gY2xlYXJJbnRlcnZhbChpbnRlcnZhbCk7XG4gIH0sIFtpc0Nvb3AsIGdhbWVBY3RpdmUsIHBsYWNlZFRvd2Vycywgc2V0UGxhY2VkVG93ZXJzLCBvblNlbmRDb29wUGluZ10pO1xuXG4gIC8vIE1haW4gR2FtZSBMb29wIChDYW52YXMgdXBkYXRlcyAmIGxvZ2ljKVxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGNvbnN0IGNhbnZhcyA9IGNhbnZhc1JlZi5jdXJyZW50O1xuICAgIGlmICghY2FudmFzKSByZXR1cm47XG4gICAgY29uc3QgY3R4ID0gY2FudmFzLmdldENvbnRleHQoJzJkJyk7XG4gICAgaWYgKCFjdHgpIHJldHVybjtcblxuICAgIGxldCBhbmltRnJhbWU6IG51bWJlcjtcbiAgICBsZXQgbGFzdFRpbWUgPSBwZXJmb3JtYW5jZS5ub3coKTtcblxuICAgIGNvbnN0IGxvb3AgPSAodGltZTogbnVtYmVyKSA9PiB7XG4gICAgICBjb25zdCBkdCA9IE1hdGgubWluKCh0aW1lIC0gbGFzdFRpbWUpIC8gMTAwMCwgMC4xKSAqIChpc1BhdXNlZCA/IDAgOiBnYW1lU3BlZWQpO1xuICAgICAgbGFzdFRpbWUgPSB0aW1lO1xuXG4gICAgICAvLyBDbGVhciBDYW52YXNcbiAgICAgIGN0eC5jbGVhclJlY3QoMCwgMCwgY2FudmFzLndpZHRoLCBjYW52YXMuaGVpZ2h0KTtcblxuICAgICAgLy8gMS4gRHJhdyBSb2Jsb3ggU3R1ZCBCYXNlcGxhdGUgQmFja2dyb3VuZFxuICAgICAgY3R4LmZpbGxTdHlsZSA9ICcjMWUyOTNiJzsgLy8gU2xhdGUgZGFyayBiYXNlXG4gICAgICBjdHguZmlsbFJlY3QoMCwgMCwgY2FudmFzLndpZHRoLCBjYW52YXMuaGVpZ2h0KTtcblxuICAgICAgLy8gR3JpZCBzdHVkcyAoUm9ibG94IGJsb2NrIHN0eWxlKVxuICAgICAgY3R4LmZpbGxTdHlsZSA9ICcjMzM0MTU1JztcbiAgICAgIGNvbnN0IGdyaWRTaXplID0gMzI7XG4gICAgICBmb3IgKGxldCB4ID0gMTY7IHggPCBjYW52YXMud2lkdGg7IHggKz0gZ3JpZFNpemUpIHtcbiAgICAgICAgZm9yIChsZXQgeSA9IDE2OyB5IDwgY2FudmFzLmhlaWdodDsgeSArPSBncmlkU2l6ZSkge1xuICAgICAgICAgIGN0eC5iZWdpblBhdGgoKTtcbiAgICAgICAgICBjdHguYXJjKHgsIHksIDIsIDAsIE1hdGguUEkgKiAyKTtcbiAgICAgICAgICBjdHguZmlsbCgpO1xuICAgICAgICB9XG4gICAgICB9XG5cbiAgICAgIC8vIDIuIERyYXcgUm9hZCAvIFBhdGggKFdpbmRpbmcgYmxvY2t5IHN0b25lIHBhdGgpXG4gICAgICBjdHguc3Ryb2tlU3R5bGUgPSAnIzQ3NTU2OSc7XG4gICAgICBjdHgubGluZVdpZHRoID0gNDQ7XG4gICAgICBjdHgubGluZUNhcCA9ICdyb3VuZCc7XG4gICAgICBjdHgubGluZUpvaW4gPSAncm91bmQnO1xuICAgICAgY3R4LmJlZ2luUGF0aCgpO1xuICAgICAgY3R4Lm1vdmVUbyhXQVlQT0lOVFNbMF0ueCwgV0FZUE9JTlRTWzBdLnkpO1xuICAgICAgZm9yIChsZXQgaSA9IDE7IGkgPCBXQVlQT0lOVFMubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgY3R4LmxpbmVUbyhXQVlQT0lOVFNbaV0ueCwgV0FZUE9JTlRTW2ldLnkpO1xuICAgICAgfVxuICAgICAgY3R4LnN0cm9rZSgpO1xuXG4gICAgICAvLyBSb2FkIElubmVyIERhc2ggTGluZXNcbiAgICAgIGN0eC5zdHJva2VTdHlsZSA9ICcjNjQ3NDhiJztcbiAgICAgIGN0eC5saW5lV2lkdGggPSAzNDtcbiAgICAgIGN0eC5zdHJva2UoKTtcblxuICAgICAgLy8gQ2hldnJvbnMgLyBkaXJlY3Rpb25hbCBhcnJvd3Mgb24gcGF0aFxuICAgICAgY3R4LnN0cm9rZVN0eWxlID0gJ3JnYmEoMjU1LCAyNTUsIDI1NSwgMC4xNSknO1xuICAgICAgY3R4LmxpbmVXaWR0aCA9IDM7XG4gICAgICBmb3IgKGxldCBpID0gMDsgaSA8IFdBWVBPSU5UUy5sZW5ndGggLSAxOyBpKyspIHtcbiAgICAgICAgY29uc3QgcDEgPSBXQVlQT0lOVFNbaV07XG4gICAgICAgIGNvbnN0IHAyID0gV0FZUE9JTlRTW2kgKyAxXTtcbiAgICAgICAgY29uc3QgbXggPSAocDEueCArIHAyLngpIC8gMjtcbiAgICAgICAgY29uc3QgbXkgPSAocDEueSArIHAyLnkpIC8gMjtcbiAgICAgICAgY3R4LmJlZ2luUGF0aCgpO1xuICAgICAgICBjdHguYXJjKG14LCBteSwgNCwgMCwgTWF0aC5QSSAqIDIpO1xuICAgICAgICBjdHguc3Ryb2tlKCk7XG4gICAgICB9XG5cbiAgICAgIC8vIDMuIERyYXcgU3Bhd24gUG9ydGFsICYgQmFzZSBGb3J0cmVzc1xuICAgICAgLy8gU3Bhd24gUG9ydGFsIChMZWZ0KVxuICAgICAgY29uc3QgcG9ydGFsR2xvdyA9IGN0eC5jcmVhdGVSYWRpYWxHcmFkaWVudCgxNSwgMTUwLCA1LCAxNSwgMTUwLCA0MCk7XG4gICAgICBwb3J0YWxHbG93LmFkZENvbG9yU3RvcCgwLCAnI2E4NTVmNycpO1xuICAgICAgcG9ydGFsR2xvdy5hZGRDb2xvclN0b3AoMSwgJ3RyYW5zcGFyZW50Jyk7XG4gICAgICBjdHguZmlsbFN0eWxlID0gcG9ydGFsR2xvdztcbiAgICAgIGN0eC5maWxsUmVjdCgwLCAxMTAsIDUwLCA4MCk7XG4gICAgICBjdHguZmlsbFN0eWxlID0gJyNjMDg0ZmMnO1xuICAgICAgY3R4LmZvbnQgPSAnYm9sZCAxMnB4IG1vbm9zcGFjZSc7XG4gICAgICBjdHguZmlsbFRleHQoJ1NQQVdOJywgMiwgMTQwKTtcblxuICAgICAgLy8gQmFzZSBDYXN0bGUgKFJpZ2h0KVxuICAgICAgY3R4LmZpbGxTdHlsZSA9ICcjMDI4NGM3JztcbiAgICAgIGN0eC5maWxsUmVjdCg3ODAsIDI5MCwgNjAsIDkwKTtcbiAgICAgIGN0eC5maWxsU3R5bGUgPSAnIzM4YmRmOCc7XG4gICAgICBjdHguZmlsbFJlY3QoNzkwLCAzMDAsIDQwLCA3MCk7XG4gICAgICBjdHguZmlsbFN0eWxlID0gJyNmZmZmZmYnO1xuICAgICAgY3R4LmZvbnQgPSAnYm9sZCAxM3B4IHNhbnMtc2VyaWYnO1xuICAgICAgY3R4LmZpbGxUZXh0KCfwn4+wINCR0JDQl9CQJywgNzg1LCAzMzUpO1xuXG4gICAgICAvLyBCYXNlIEhQIGJhciBhYm92ZSBjYXN0bGVcbiAgICAgIGNvbnN0IGhwV2lkdGggPSA1MDtcbiAgICAgIGNvbnN0IGhwUGN0ID0gTWF0aC5tYXgoMCwgYmFzZUhwIC8gbWF4QmFzZUhwKTtcbiAgICAgIGN0eC5maWxsU3R5bGUgPSAncmdiYSgwLDAsMCwwLjYpJztcbiAgICAgIGN0eC5maWxsUmVjdCg3ODUsIDI4MCwgaHBXaWR0aCwgNyk7XG4gICAgICBjdHguZmlsbFN0eWxlID0gaHBQY3QgPiAwLjQgPyAnIzIyYzU1ZScgOiAnI2VmNDQ0NCc7XG4gICAgICBjdHguZmlsbFJlY3QoNzg1LCAyODAsIGhwV2lkdGggKiBocFBjdCwgNyk7XG5cbiAgICAgIC8vIDQuIFVwZGF0ZSAmIE1vdmUgRW5lbWllc1xuICAgICAgaWYgKCFpc1BhdXNlZCkge1xuICAgICAgICBmb3IgKGxldCBpID0gZW5lbWllc1JlZi5jdXJyZW50Lmxlbmd0aCAtIDE7IGkgPj0gMDsgaS0tKSB7XG4gICAgICAgICAgY29uc3QgZW5lbXkgPSBlbmVtaWVzUmVmLmN1cnJlbnRbaV07XG5cbiAgICAgICAgICAvLyBIYW5kbGUgc2xvdyBlZmZlY3QgZGVjYXlcbiAgICAgICAgICBpZiAoZW5lbXkuc2xvd0VmZmVjdCkge1xuICAgICAgICAgICAgZW5lbXkuc2xvd0VmZmVjdC5kdXJhdGlvbiAtPSBkdDtcbiAgICAgICAgICAgIGlmIChlbmVteS5zbG93RWZmZWN0LmR1cmF0aW9uIDw9IDApIHtcbiAgICAgICAgICAgICAgZW5lbXkuc2xvd0VmZmVjdCA9IHVuZGVmaW5lZDtcbiAgICAgICAgICAgICAgZW5lbXkuY3VycmVudFNwZWVkID0gZW5lbXkuc3BlZWQ7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICBlbmVteS5jdXJyZW50U3BlZWQgPSBlbmVteS5zcGVlZCAqIGVuZW15LnNsb3dFZmZlY3QubXVsdGlwbGllcjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgZW5lbXkuY3VycmVudFNwZWVkID0gZW5lbXkuc3BlZWQ7XG4gICAgICAgICAgfVxuXG4gICAgICAgICAgLy8gTW92ZSBhbG9uZyB3YXlwb2ludHNcbiAgICAgICAgICBjb25zdCB0YXJnZXRXcCA9IFdBWVBPSU5UU1tlbmVteS5wYXRoSW5kZXggKyAxXTtcbiAgICAgICAgICBpZiAodGFyZ2V0V3ApIHtcbiAgICAgICAgICAgIGNvbnN0IGR4ID0gdGFyZ2V0V3AueCAtIGVuZW15Lng7XG4gICAgICAgICAgICBjb25zdCBkeSA9IHRhcmdldFdwLnkgLSBlbmVteS55O1xuICAgICAgICAgICAgY29uc3QgZCA9IE1hdGguc3FydChkeCAqIGR4ICsgZHkgKiBkeSk7XG4gICAgICAgICAgICBjb25zdCBtb3ZlU3RlcCA9IGVuZW15LmN1cnJlbnRTcGVlZCAqIDY1ICogZHQ7XG5cbiAgICAgICAgICAgIGlmIChkIDwgbW92ZVN0ZXApIHtcbiAgICAgICAgICAgICAgZW5lbXkueCA9IHRhcmdldFdwLng7XG4gICAgICAgICAgICAgIGVuZW15LnkgPSB0YXJnZXRXcC55O1xuICAgICAgICAgICAgICBlbmVteS5wYXRoSW5kZXgrKztcbiAgICAgICAgICAgICAgaWYgKGVuZW15LnBhdGhJbmRleCA+PSBXQVlQT0lOVFMubGVuZ3RoIC0gMSkge1xuICAgICAgICAgICAgICAgIC8vIFJlYWNoZWQgQmFzZSFcbiAgICAgICAgICAgICAgICBjb25zdCBkbWcgPSBlbmVteS5pc0Jvc3MgPyAyNSA6IDg7XG4gICAgICAgICAgICAgICAgc2V0QmFzZUhwKChwcmV2KSA9PiB7XG4gICAgICAgICAgICAgICAgICBjb25zdCB1cGRhdGVkID0gTWF0aC5tYXgoMCwgcHJldiAtIGRtZyk7XG4gICAgICAgICAgICAgICAgICBpZiAodXBkYXRlZCA8PSAwKSB7XG4gICAgICAgICAgICAgICAgICAgIGFkZFBhcnRpY2xlKDQyMCwgMjUwLCAn8J+SgCDQs9C+IEtFS0MnLCAnI2VmNDQ0NCcpO1xuICAgICAgICAgICAgICAgICAgICBvbkdhbWVPdmVyKHdhdmUsIDAsIGZhbHNlKTtcbiAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgIHJldHVybiB1cGRhdGVkO1xuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgIHNvdW5kcy5wbGF5RXhwbG9zaW9uKCk7XG4gICAgICAgICAgICAgICAgYWRkUGFydGljbGUoZW5lbXkueCwgZW5lbXkueSwgYC0ke2RtZ30gSFAhYCwgJyNlZjQ0NDQnKTtcbiAgICAgICAgICAgICAgICBlbmVtaWVzUmVmLmN1cnJlbnQuc3BsaWNlKGksIDEpO1xuICAgICAgICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICBlbmVteS54ICs9IChkeCAvIGQpICogbW92ZVN0ZXA7XG4gICAgICAgICAgICAgIGVuZW15LnkgKz0gKGR5IC8gZCkgKiBtb3ZlU3RlcDtcbiAgICAgICAgICAgICAgZW5lbXkuZGlzdGFuY2VUcmF2ZWxlZCArPSBtb3ZlU3RlcDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgLy8gRHJhdyBFbmVtaWVzXG4gICAgICBlbmVtaWVzUmVmLmN1cnJlbnQuZm9yRWFjaCgoZW5lbXkpID0+IHtcbiAgICAgICAgY3R4LnNhdmUoKTtcbiAgICAgICAgY3R4LnRyYW5zbGF0ZShlbmVteS54LCBlbmVteS55KTtcblxuICAgICAgICAvLyBTbG93IGVmZmVjdCBmcm96ZW4gYXVyYVxuICAgICAgICBpZiAoZW5lbXkuc2xvd0VmZmVjdCkge1xuICAgICAgICAgIGN0eC5iZWdpblBhdGgoKTtcbiAgICAgICAgICBjdHguYXJjKDAsIDAsIGVuZW15LnNpemUgKyA4LCAwLCBNYXRoLlBJICogMik7XG4gICAgICAgICAgY3R4LnN0cm9rZVN0eWxlID0gJ3JnYmEoNTYsIDE4OSwgMjQ4LCAwLjgpJztcbiAgICAgICAgICBjdHgubGluZVdpZHRoID0gMztcbiAgICAgICAgICBjdHguc3Ryb2tlKCk7XG5cbiAgICAgICAgICBjdHguZmlsbFN0eWxlID0gJ3JnYmEoNTYsIDE4OSwgMjQ4LCAwLjI1KSc7XG4gICAgICAgICAgY3R4LmZpbGwoKTtcblxuICAgICAgICAgIC8vIFNub3dmbGFrZSBzeW1ib2xcbiAgICAgICAgICBjdHguZmlsbFN0eWxlID0gJyNiYWU2ZmQnO1xuICAgICAgICAgIGN0eC5mb250ID0gJzEwcHggc2Fucy1zZXJpZic7XG4gICAgICAgICAgY3R4LmZpbGxUZXh0KCfinYTvuI8nLCAtNiwgLWVuZW15LnNpemUgLSAxMik7XG4gICAgICAgIH1cblxuICAgICAgICAvLyBFbmVteSBCbG9ja3kgQm9keVxuICAgICAgICBjdHguZmlsbFN0eWxlID0gZW5lbXkuY29sb3I7XG4gICAgICAgIGN0eC5zaGFkb3dDb2xvciA9IGVuZW15LmNvbG9yO1xuICAgICAgICBjdHguc2hhZG93Qmx1ciA9IGVuZW15LmlzQm9zcyA/IDE0IDogNDtcbiAgICAgICAgY3R4LmZpbGxSZWN0KC1lbmVteS5zaXplIC8gMiwgLWVuZW15LnNpemUgLyAyLCBlbmVteS5zaXplLCBlbmVteS5zaXplKTtcbiAgICAgICAgY3R4LnNoYWRvd0JsdXIgPSAwO1xuXG4gICAgICAgIC8vIEVuZW15IEV5ZXMgKGNsYXNzaWMgUm9ibG94IG5vb2IgZmFjZSlcbiAgICAgICAgY3R4LmZpbGxTdHlsZSA9ICcjMDAwMDAwJztcbiAgICAgICAgY29uc3QgZXllU2l6ZSA9IE1hdGgubWF4KDIsIGVuZW15LnNpemUgLyA1KTtcbiAgICAgICAgY3R4LmZpbGxSZWN0KC1lbmVteS5zaXplIC8gNCwgLWVuZW15LnNpemUgLyA0LCBleWVTaXplLCBleWVTaXplKTtcbiAgICAgICAgY3R4LmZpbGxSZWN0KGVuZW15LnNpemUgLyA2LCAtZW5lbXkuc2l6ZSAvIDQsIGV5ZVNpemUsIGV5ZVNpemUpO1xuXG4gICAgICAgIC8vIFNtaWxlXG4gICAgICAgIGN0eC5maWxsUmVjdCgtZW5lbXkuc2l6ZSAvIDQsIGVuZW15LnNpemUgLyA2LCBlbmVteS5zaXplIC8gMiwgMik7XG5cbiAgICAgICAgLy8gSGVhbHRoIEJhciBhYm92ZSBlbmVteVxuICAgICAgICBjb25zdCBiYXJXID0gTWF0aC5tYXgoMjYsIGVuZW15LnNpemUgKiAxLjQpO1xuICAgICAgICBjb25zdCBiYXJIID0gNTtcbiAgICAgICAgY29uc3QgaHBSYXRpbyA9IE1hdGgubWF4KDAsIGVuZW15LmhwIC8gZW5lbXkubWF4SHApO1xuXG4gICAgICAgIGN0eC5maWxsU3R5bGUgPSAncmdiYSgwLCAwLCAwLCAwLjcpJztcbiAgICAgICAgY3R4LmZpbGxSZWN0KC1iYXJXIC8gMiwgLWVuZW15LnNpemUgLSA4LCBiYXJXLCBiYXJIKTtcbiAgICAgICAgY3R4LmZpbGxTdHlsZSA9IGVuZW15LmlzQm9zcyA/ICcjZjQzZjVlJyA6ICcjMjJjNTVlJztcbiAgICAgICAgY3R4LmZpbGxSZWN0KC1iYXJXIC8gMiwgLWVuZW15LnNpemUgLSA4LCBiYXJXICogaHBSYXRpbywgYmFySCk7XG5cbiAgICAgICAgLy8gQm9zcyBUYWdcbiAgICAgICAgaWYgKGVuZW15LmlzQm9zcykge1xuICAgICAgICAgIGN0eC5maWxsU3R5bGUgPSAnI2ZhY2MxNSc7XG4gICAgICAgICAgY3R4LmZvbnQgPSAnYm9sZCAxMHB4IHNhbnMtc2VyaWYnO1xuICAgICAgICAgIGN0eC5maWxsVGV4dCgn8J+RkSBCT1NTJywgLTE4LCAtZW5lbXkuc2l6ZSAtIDE0KTtcbiAgICAgICAgfVxuXG4gICAgICAgIGN0eC5yZXN0b3JlKCk7XG4gICAgICB9KTtcblxuICAgICAgLy8gNS4gVXBkYXRlICYgQXR0YWNrIFRvd2Vyc1xuICAgICAgY29uc3Qgbm93ID0gcGVyZm9ybWFuY2Uubm93KCkgLyAxMDAwO1xuICAgICAgcGxhY2VkVG93ZXJzLmZvckVhY2goKHRvd2VyKSA9PiB7XG4gICAgICAgIGNvbnN0IGRlZiA9IFRPV0VSU19EQVRBLmZpbmQoKHQpID0+IHQuaWQgPT09IHRvd2VyLnRvd2VySWQpO1xuICAgICAgICBpZiAoIWRlZikgcmV0dXJuO1xuICAgICAgICBjb25zdCBsdmxDZmcgPSBkZWYubGV2ZWxzW01hdGgubWluKHRvd2VyLmxldmVsLCBkZWYubGV2ZWxzLmxlbmd0aCAtIDEpXTtcblxuICAgICAgICAvLyBGaW5kIGVuZW1pZXMgaW4gcmFuZ2VcbiAgICAgICAgY29uc3QgaW5SYW5nZUVuZW1pZXMgPSBlbmVtaWVzUmVmLmN1cnJlbnQuZmlsdGVyKChlKSA9PiB7XG4gICAgICAgICAgcmV0dXJuIGRpc3QodG93ZXIueCwgdG93ZXIueSwgZS54LCBlLnkpIDw9IGx2bENmZy5yYW5nZTtcbiAgICAgICAgfSk7XG5cbiAgICAgICAgLy8gVGFyZ2V0aW5nIHN0cmF0ZWd5XG4gICAgICAgIGxldCB0YXJnZXQ6IEVuZW15IHwgbnVsbCA9IG51bGw7XG4gICAgICAgIGlmIChpblJhbmdlRW5lbWllcy5sZW5ndGggPiAwKSB7XG4gICAgICAgICAgaWYgKHRvd2VyLnRhcmdldE1vZGUgPT09ICdmaXJzdCcpIHtcbiAgICAgICAgICAgIHRhcmdldCA9IGluUmFuZ2VFbmVtaWVzLnJlZHVjZSgocHJldiwgY3VycikgPT4gKGN1cnIuZGlzdGFuY2VUcmF2ZWxlZCA+IHByZXYuZGlzdGFuY2VUcmF2ZWxlZCA/IGN1cnIgOiBwcmV2KSk7XG4gICAgICAgICAgfSBlbHNlIGlmICh0b3dlci50YXJnZXRNb2RlID09PSAnc3Ryb25nZXN0Jykge1xuICAgICAgICAgICAgdGFyZ2V0ID0gaW5SYW5nZUVuZW1pZXMucmVkdWNlKChwcmV2LCBjdXJyKSA9PiAoY3Vyci5ocCA+IHByZXYuaHAgPyBjdXJyIDogcHJldikpO1xuICAgICAgICAgIH0gZWxzZSBpZiAodG93ZXIudGFyZ2V0TW9kZSA9PT0gJ3dlYWtlc3QnKSB7XG4gICAgICAgICAgICB0YXJnZXQgPSBpblJhbmdlRW5lbWllcy5yZWR1Y2UoKHByZXYsIGN1cnIpID0+IChjdXJyLmhwIDwgcHJldi5ocCA/IGN1cnIgOiBwcmV2KSk7XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIC8vIGNsb3Nlc3RcbiAgICAgICAgICAgIHRhcmdldCA9IGluUmFuZ2VFbmVtaWVzLnJlZHVjZSgocHJldiwgY3VycikgPT5cbiAgICAgICAgICAgICAgZGlzdCh0b3dlci54LCB0b3dlci55LCBjdXJyLngsIGN1cnIueSkgPCBkaXN0KHRvd2VyLngsIHRvd2VyLnksIHByZXYueCwgcHJldi55KSA/IGN1cnIgOiBwcmV2XG4gICAgICAgICAgICApO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIC8vIEZpcmUgcmF0ZSBjaGVja1xuICAgICAgICBpZiAoIWlzUGF1c2VkICYmIHRhcmdldCAmJiBub3cgLSB0b3dlci5sYXN0U2hvdFRpbWUgPj0gbHZsQ2ZnLmZpcmVSYXRlKSB7XG4gICAgICAgICAgdG93ZXIubGFzdFNob3RUaW1lID0gbm93O1xuXG4gICAgICAgICAgLy8gU291bmQgdHJpZ2dlcnMgYmFzZWQgb24gdG93ZXIgdHlwZVxuICAgICAgICAgIGlmICh0b3dlci50b3dlcklkID09PSAnY2F0Jykge1xuICAgICAgICAgICAgaWYgKHRvd2VyLmxldmVsID09PSAzKSB7XG4gICAgICAgICAgICAgIHNvdW5kcy5wbGF5RnJlZXplKCk7XG4gICAgICAgICAgICB9IGVsc2UgaWYgKE1hdGgucmFuZG9tKCkgPCAwLjI1KSB7XG4gICAgICAgICAgICAgIHNvdW5kcy5wbGF5TWVvdygpO1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgc291bmRzLnBsYXlMYXNlcigpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH0gZWxzZSBpZiAodG93ZXIudG93ZXJJZCA9PT0gJ21lY2hhX2NhdCcpIHtcbiAgICAgICAgICAgIHNvdW5kcy5wbGF5Um9ja2V0TGF1bmNoKCk7XG4gICAgICAgICAgfSBlbHNlIGlmICh0b3dlci50b3dlcklkID09PSAndGVzbGFfd2l6YXJkJykge1xuICAgICAgICAgICAgc291bmRzLnBsYXlaYXAoKTtcbiAgICAgICAgICB9IGVsc2UgaWYgKHRvd2VyLnRvd2VySWQgPT09ICdmcmVlemVfcGVuZ3VpbicpIHtcbiAgICAgICAgICAgIHNvdW5kcy5wbGF5RnJlZXplKCk7XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHNvdW5kcy5wbGF5TGFzZXIoKTtcbiAgICAgICAgICB9XG5cbiAgICAgICAgICAvLyBTcGVjaWFsIGxvZ2ljIGZvciBDYXQgVG93ZXIgLyBGcmVlemUgUGVuZ3VpbiAvIE1lY2hhXG4gICAgICAgICAgY29uc3QgaXNDYXRMdmwzID0gdG93ZXIudG93ZXJJZCA9PT0gJ2NhdCcgJiYgdG93ZXIubGV2ZWwgPj0gMztcbiAgICAgICAgICBjb25zdCBpc1Blbmd1aW4gPSB0b3dlci50b3dlcklkID09PSAnZnJlZXplX3Blbmd1aW4nO1xuICAgICAgICAgIGNvbnN0IGlzUm9ja2V0ID0gZGVmLmJ1bGxldFR5cGUgPT09ICdyb2NrZXQnO1xuICAgICAgICAgIGNvbnN0IGlzTGlnaHRuaW5nID0gZGVmLmJ1bGxldFR5cGUgPT09ICdsaWdodG5pbmcnO1xuICAgICAgICAgIGNvbnN0IGlzU2h1cmlrZW4gPSBkZWYuYnVsbGV0VHlwZSA9PT0gJ3NodXJpa2VuJztcblxuICAgICAgICAgIGNvbnN0IHNsb3dNdWx0aXBsaWVyID0gaXNDYXRMdmwzID8gMC42IDogaXNQZW5ndWluID8gMC41IDogdW5kZWZpbmVkO1xuICAgICAgICAgIGNvbnN0IHNsb3dEdXJhdGlvbiA9IGlzQ2F0THZsMyA/IDMuMCA6IGlzUGVuZ3VpbiA/IDIuOCA6IHVuZGVmaW5lZDtcbiAgICAgICAgICBjb25zdCBzcGxhc2hSYWRpdXMgPSBpc1JvY2tldCA/IDU1IDogdW5kZWZpbmVkO1xuXG4gICAgICAgICAgLy8gU2h1cmlrZW4gY3JpdCBjYWxjdWxhdGlvblxuICAgICAgICAgIGxldCBmaW5hbERhbWFnZSA9IGx2bENmZy5kYW1hZ2U7XG4gICAgICAgICAgaWYgKGlzU2h1cmlrZW4gJiYgTWF0aC5yYW5kb20oKSA8IDAuNCkge1xuICAgICAgICAgICAgZmluYWxEYW1hZ2UgPSBNYXRoLnJvdW5kKGx2bENmZy5kYW1hZ2UgKiAxLjYpO1xuICAgICAgICAgIH1cblxuICAgICAgICAgIHByb2plY3RpbGVzUmVmLmN1cnJlbnQucHVzaCh7XG4gICAgICAgICAgICBpZDogJ3Byb2pfJyArIE1hdGgucmFuZG9tKCkudG9TdHJpbmcoKSxcbiAgICAgICAgICAgIHN0YXJ0WDogdG93ZXIueCxcbiAgICAgICAgICAgIHN0YXJ0WTogdG93ZXIueSxcbiAgICAgICAgICAgIHRhcmdldFg6IHRhcmdldC54LFxuICAgICAgICAgICAgdGFyZ2V0WTogdGFyZ2V0LnksXG4gICAgICAgICAgICB0YXJnZXRFbmVteUlkOiB0YXJnZXQuaWQsXG4gICAgICAgICAgICBjb2xvcjogaXNDYXRMdmwzID8gJyMzOGJkZjgnIDogZGVmLmJ1bGxldENvbG9yLFxuICAgICAgICAgICAgdHlwZTogaXNDYXRMdmwzID8gJ2Zyb3N0JyA6IGRlZi5idWxsZXRUeXBlLFxuICAgICAgICAgICAgcHJvZ3Jlc3M6IDAsXG4gICAgICAgICAgICBzcGVlZDogaXNSb2NrZXQgPyA0LjUgOiBkZWYuYnVsbGV0VHlwZSA9PT0gJ2ZpcmUnID8gOC41IDogNi41LFxuICAgICAgICAgICAgZGFtYWdlOiBmaW5hbERhbWFnZSxcbiAgICAgICAgICAgIHNwbGFzaFJhZGl1cyxcbiAgICAgICAgICAgIHNsb3dNdWx0aXBsaWVyLFxuICAgICAgICAgICAgc2xvd0R1cmF0aW9uLFxuICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgICB9KTtcblxuICAgICAgLy8gNi4gVXBkYXRlIFByb2plY3RpbGVzXG4gICAgICBpZiAoIWlzUGF1c2VkKSB7XG4gICAgICAgIGZvciAobGV0IGkgPSBwcm9qZWN0aWxlc1JlZi5jdXJyZW50Lmxlbmd0aCAtIDE7IGkgPj0gMDsgaS0tKSB7XG4gICAgICAgICAgY29uc3QgcCA9IHByb2plY3RpbGVzUmVmLmN1cnJlbnRbaV07XG4gICAgICAgICAgcC5wcm9ncmVzcyArPSBwLnNwZWVkICogZHQ7XG5cbiAgICAgICAgICBjb25zdCBjdXJyWCA9IHAuc3RhcnRYICsgKHAudGFyZ2V0WCAtIHAuc3RhcnRYKSAqIE1hdGgubWluKDEsIHAucHJvZ3Jlc3MpO1xuICAgICAgICAgIGNvbnN0IGN1cnJZID0gcC5zdGFydFkgKyAocC50YXJnZXRZIC0gcC5zdGFydFkpICogTWF0aC5taW4oMSwgcC5wcm9ncmVzcyk7XG5cbiAgICAgICAgICAvLyBEcmF3IFByb2plY3RpbGVcbiAgICAgICAgICBjdHguYmVnaW5QYXRoKCk7XG4gICAgICAgICAgaWYgKHAudHlwZSA9PT0gJ3JvY2tldCcpIHtcbiAgICAgICAgICAgIGN0eC5hcmMoY3VyclgsIGN1cnJZLCA2LCAwLCBNYXRoLlBJICogMik7XG4gICAgICAgICAgfSBlbHNlIGlmIChwLnR5cGUgPT09ICdmaXJlJykge1xuICAgICAgICAgICAgY3R4LmFyYyhjdXJyWCwgY3VyclksIDUsIDAsIE1hdGguUEkgKiAyKTtcbiAgICAgICAgICB9IGVsc2UgaWYgKHAudHlwZSA9PT0gJ2Zyb3N0Jykge1xuICAgICAgICAgICAgY3R4LmFyYyhjdXJyWCwgY3VyclksIDYsIDAsIE1hdGguUEkgKiAyKTtcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgY3R4LmFyYyhjdXJyWCwgY3VyclksIDQsIDAsIE1hdGguUEkgKiAyKTtcbiAgICAgICAgICB9XG4gICAgICAgICAgY3R4LmZpbGxTdHlsZSA9IHAuY29sb3I7XG4gICAgICAgICAgY3R4LnNoYWRvd0NvbG9yID0gcC5jb2xvcjtcbiAgICAgICAgICBjdHguc2hhZG93Qmx1ciA9IDg7XG4gICAgICAgICAgY3R4LmZpbGwoKTtcbiAgICAgICAgICBjdHguc2hhZG93Qmx1ciA9IDA7XG5cbiAgICAgICAgICAvLyBUcmFpbGluZyBsYXNlciBsaW5lXG4gICAgICAgICAgY3R4LnN0cm9rZVN0eWxlID0gcC5jb2xvcjtcbiAgICAgICAgICBjdHgubGluZVdpZHRoID0gcC50eXBlID09PSAnZnJvc3QnIHx8IHAudHlwZSA9PT0gJ3JvY2tldCcgPyAzIDogMjtcbiAgICAgICAgICBjdHguYmVnaW5QYXRoKCk7XG4gICAgICAgICAgY3R4Lm1vdmVUbyhwLnN0YXJ0WCwgcC5zdGFydFkpO1xuICAgICAgICAgIGN0eC5saW5lVG8oY3VyclgsIGN1cnJZKTtcbiAgICAgICAgICBjdHguc3Ryb2tlKCk7XG5cbiAgICAgICAgICAvLyBJbXBhY3RcbiAgICAgICAgICBpZiAocC5wcm9ncmVzcyA+PSAxKSB7XG4gICAgICAgICAgICAvLyBTcGxhc2ggRGFtYWdlIGZvciBSb2NrZXRzXG4gICAgICAgICAgICBpZiAocC5zcGxhc2hSYWRpdXMgJiYgcC5zcGxhc2hSYWRpdXMgPiAwKSB7XG4gICAgICAgICAgICAgIHNvdW5kcy5wbGF5RXhwbG9zaW9uKCk7XG4gICAgICAgICAgICAgIGFkZFBhcnRpY2xlKHAudGFyZ2V0WCwgcC50YXJnZXRZLCAn8J+SpSDQktCX0KDQq9CSIScsICcjZjQzZjVlJyk7XG5cbiAgICAgICAgICAgICAgZW5lbWllc1JlZi5jdXJyZW50LmZvckVhY2goKGVuKSA9PiB7XG4gICAgICAgICAgICAgICAgaWYgKGRpc3QocC50YXJnZXRYLCBwLnRhcmdldFksIGVuLngsIGVuLnkpIDw9IChwLnNwbGFzaFJhZGl1cyB8fCA1MCkpIHtcbiAgICAgICAgICAgICAgICAgIGVuLmhwIC09IHAuZGFtYWdlO1xuICAgICAgICAgICAgICAgICAgYWRkUGFydGljbGUoZW4ueCwgZW4ueSAtIDYsIGAtJHtwLmRhbWFnZX1gLCAnI2ZiNzE4NScpO1xuICAgICAgICAgICAgICAgICAgaWYgKGVuLmhwIDw9IDApIHtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgaWR4ID0gZW5lbWllc1JlZi5jdXJyZW50LmluZGV4T2YoZW4pO1xuICAgICAgICAgICAgICAgICAgICBpZiAoaWR4ID49IDApIHtcbiAgICAgICAgICAgICAgICAgICAgICBlbmVtaWVzUmVmLmN1cnJlbnQuc3BsaWNlKGlkeCwgMSk7XG4gICAgICAgICAgICAgICAgICAgICAgc2V0Q2FzaCgoYykgPT4gYyArIGVuLmJvdW50eSk7XG4gICAgICAgICAgICAgICAgICAgICAgYWRkUGFydGljbGUoZW4ueCwgZW4ueSwgYCskJHtlbi5ib3VudHl9YCwgJyM0YWRlODAnKTtcbiAgICAgICAgICAgICAgICAgICAgICBzb3VuZHMucGxheUNvaW4oKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAvLyBEaXJlY3QgSGl0XG4gICAgICAgICAgICAgIGNvbnN0IGhpdEVuZW15ID0gZW5lbWllc1JlZi5jdXJyZW50LmZpbmQoKGUpID0+IGUuaWQgPT09IHAudGFyZ2V0RW5lbXlJZCkgfHxcbiAgICAgICAgICAgICAgICBlbmVtaWVzUmVmLmN1cnJlbnQuZmluZCgoZSkgPT4gZGlzdChwLnRhcmdldFgsIHAudGFyZ2V0WSwgZS54LCBlLnkpIDwgMjUpO1xuXG4gICAgICAgICAgICAgIGlmIChoaXRFbmVteSkge1xuICAgICAgICAgICAgICAgIGhpdEVuZW15LmhwIC09IHAuZGFtYWdlO1xuXG4gICAgICAgICAgICAgICAgLy8gQ2hhaW4gTGlnaHRuaW5nIG9uIGltcGFjdFxuICAgICAgICAgICAgICAgIGlmIChwLnR5cGUgPT09ICdsaWdodG5pbmcnKSB7XG4gICAgICAgICAgICAgICAgICBjb25zdCBjaGFpblRhcmdldHMgPSBlbmVtaWVzUmVmLmN1cnJlbnRcbiAgICAgICAgICAgICAgICAgICAgLmZpbHRlcigoZSkgPT4gZS5pZCAhPT0gaGl0RW5lbXkuaWQgJiYgZGlzdChoaXRFbmVteS54LCBoaXRFbmVteS55LCBlLngsIGUueSkgPCA5MClcbiAgICAgICAgICAgICAgICAgICAgLnNsaWNlKDAsIDMpO1xuXG4gICAgICAgICAgICAgICAgICBjaGFpblRhcmdldHMuZm9yRWFjaCgoY0VuKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGNoYWluRG1nID0gTWF0aC5yb3VuZChwLmRhbWFnZSAqIDAuNzUpO1xuICAgICAgICAgICAgICAgICAgICBjRW4uaHAgLT0gY2hhaW5EbWc7XG4gICAgICAgICAgICAgICAgICAgIGFkZFBhcnRpY2xlKGNFbi54LCBjRW4ueSAtIDgsIGDimqEtJHtjaGFpbkRtZ31gLCAnI2MwODRmYycpO1xuICAgICAgICAgICAgICAgICAgICBpZiAoY0VuLmhwIDw9IDApIHtcbiAgICAgICAgICAgICAgICAgICAgICBjb25zdCBpZHggPSBlbmVtaWVzUmVmLmN1cnJlbnQuaW5kZXhPZihjRW4pO1xuICAgICAgICAgICAgICAgICAgICAgIGlmIChpZHggPj0gMCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgZW5lbWllc1JlZi5jdXJyZW50LnNwbGljZShpZHgsIDEpO1xuICAgICAgICAgICAgICAgICAgICAgICAgc2V0Q2FzaCgoYykgPT4gYyArIGNFbi5ib3VudHkpO1xuICAgICAgICAgICAgICAgICAgICAgICAgYWRkUGFydGljbGUoY0VuLngsIGNFbi55LCBgKyQke2NFbi5ib3VudHl9YCwgJyM0YWRlODAnKTtcbiAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgIC8vIEFwcGx5IGZyZWV6ZS9zbG93XG4gICAgICAgICAgICAgICAgaWYgKHAuc2xvd011bHRpcGxpZXIgJiYgcC5zbG93RHVyYXRpb24pIHtcbiAgICAgICAgICAgICAgICAgIGhpdEVuZW15LnNsb3dFZmZlY3QgPSB7XG4gICAgICAgICAgICAgICAgICAgIG11bHRpcGxpZXI6IHAuc2xvd011bHRpcGxpZXIsXG4gICAgICAgICAgICAgICAgICAgIGR1cmF0aW9uOiBwLnNsb3dEdXJhdGlvbixcbiAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICBhZGRQYXJ0aWNsZShoaXRFbmVteS54LCBoaXRFbmVteS55IC0gMTAsICfinYTvuI8g0JfQkNCc0JXQlNCb0JXQndCY0JUhJywgJyMzOGJkZjgnKTtcbiAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICAvLyBEYW1hZ2UgUGFydGljbGVcbiAgICAgICAgICAgICAgICBjb25zdCBpc0NyaXQgPSBwLnR5cGUgPT09ICdzaHVyaWtlbicgJiYgcC5kYW1hZ2UgPiAyMDtcbiAgICAgICAgICAgICAgICBhZGRQYXJ0aWNsZShcbiAgICAgICAgICAgICAgICAgIGhpdEVuZW15LnggKyAoTWF0aC5yYW5kb20oKSAtIDAuNSkgKiAxNSxcbiAgICAgICAgICAgICAgICAgIGhpdEVuZW15LnkgLSA1LFxuICAgICAgICAgICAgICAgICAgaXNDcml0ID8gYPCfkqUtJHtwLmRhbWFnZX0g0JrQoNCY0KIhYCA6IGAtJHtwLmRhbWFnZX1gLFxuICAgICAgICAgICAgICAgICAgaXNDcml0ID8gJyNmYmJmMjQnIDogcC50eXBlID09PSAnZnJvc3QnID8gJyM3ZGQzZmMnIDogcC50eXBlID09PSAnZmlyZScgPyAnI2ZiOTIzYycgOiAnI2Y4NzE3MSdcbiAgICAgICAgICAgICAgICApO1xuXG4gICAgICAgICAgICAgICAgLy8gQ2hlY2sgRW5lbXkgRGVhdGhcbiAgICAgICAgICAgICAgICBpZiAoaGl0RW5lbXkuaHAgPD0gMCkge1xuICAgICAgICAgICAgICAgICAgY29uc3QgZW5lbXlJZHggPSBlbmVtaWVzUmVmLmN1cnJlbnQuaW5kZXhPZihoaXRFbmVteSk7XG4gICAgICAgICAgICAgICAgICBpZiAoZW5lbXlJZHggPj0gMCkge1xuICAgICAgICAgICAgICAgICAgICBlbmVtaWVzUmVmLmN1cnJlbnQuc3BsaWNlKGVuZW15SWR4LCAxKTtcbiAgICAgICAgICAgICAgICAgICAgc2V0Q2FzaCgoYykgPT4gYyArIGhpdEVuZW15LmJvdW50eSk7XG4gICAgICAgICAgICAgICAgICAgIGFkZFBhcnRpY2xlKGhpdEVuZW15LngsIGhpdEVuZW15LnksIGArJCR7aGl0RW5lbXkuYm91bnR5fWAsICcjNGFkZTgwJyk7XG4gICAgICAgICAgICAgICAgICAgIHNvdW5kcy5wbGF5Q29pbigpO1xuICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBwcm9qZWN0aWxlc1JlZi5jdXJyZW50LnNwbGljZShpLCAxKTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgLy8gNy4gRHJhdyBQbGFjZWQgVG93ZXJzXG4gICAgICBwbGFjZWRUb3dlcnMuZm9yRWFjaCgodG93ZXIpID0+IHtcbiAgICAgICAgY29uc3QgZGVmID0gVE9XRVJTX0RBVEEuZmluZCgodCkgPT4gdC5pZCA9PT0gdG93ZXIudG93ZXJJZCk7XG4gICAgICAgIGlmICghZGVmKSByZXR1cm47XG4gICAgICAgIGNvbnN0IGlzU2VsZWN0ZWQgPSB0b3dlci5pbnN0YW5jZUlkID09PSBzZWxlY3RlZFBsYWNlZFRvd2VySWQ7XG4gICAgICAgIGNvbnN0IGx2bENmZyA9IGRlZi5sZXZlbHNbTWF0aC5taW4odG93ZXIubGV2ZWwsIGRlZi5sZXZlbHMubGVuZ3RoIC0gMSldO1xuXG4gICAgICAgIC8vIERyYXcgUmFuZ2UgQ2lyY2xlIGlmIHNlbGVjdGVkIG9yIGhvdmVyaW5nXG4gICAgICAgIGlmIChpc1NlbGVjdGVkKSB7XG4gICAgICAgICAgY3R4LmJlZ2luUGF0aCgpO1xuICAgICAgICAgIGN0eC5hcmModG93ZXIueCwgdG93ZXIueSwgbHZsQ2ZnLnJhbmdlLCAwLCBNYXRoLlBJICogMik7XG4gICAgICAgICAgY3R4LmZpbGxTdHlsZSA9ICdyZ2JhKDU2LCAxODksIDI0OCwgMC4xMiknO1xuICAgICAgICAgIGN0eC5maWxsKCk7XG4gICAgICAgICAgY3R4LnN0cm9rZVN0eWxlID0gJyMzOGJkZjgnO1xuICAgICAgICAgIGN0eC5saW5lV2lkdGggPSAxLjU7XG4gICAgICAgICAgY3R4LnNldExpbmVEYXNoKFs2LCA0XSk7XG4gICAgICAgICAgY3R4LnN0cm9rZSgpO1xuICAgICAgICAgIGN0eC5zZXRMaW5lRGFzaChbXSk7XG4gICAgICAgIH1cblxuICAgICAgICBjdHguc2F2ZSgpO1xuICAgICAgICBjdHgudHJhbnNsYXRlKHRvd2VyLngsIHRvd2VyLnkpO1xuXG4gICAgICAgIC8vIFRvd2VyIEJhc2UgUGVkZXN0YWwgKFJvYmxveCBibG9jayBzdHlsZSlcbiAgICAgICAgY3R4LmZpbGxTdHlsZSA9IHRvd2VyLmlzQ29vcEFsbHkgPyAnIzAyODRjNycgOiBpc1NlbGVjdGVkID8gJyMzOGJkZjgnIDogJyMzMzQxNTUnO1xuICAgICAgICBjdHguZmlsbFJlY3QoLTIyLCAtMjIsIDQ0LCA0NCk7XG5cbiAgICAgICAgY3R4LmZpbGxTdHlsZSA9IGlzU2VsZWN0ZWQgPyAnIzYwYTVmYScgOiAnIzFlMjkzYic7XG4gICAgICAgIGN0eC5maWxsUmVjdCgtMTgsIC0xOCwgMzYsIDM2KTtcblxuICAgICAgICAvLyBTcGVjaWFsIHJlbmRlciBmb3IgQ0FUIFRPV0VSICh1c2VzIHVwbG9hZGVkIHRodWcgbGlmZSBpbWFnZSlcbiAgICAgICAgaWYgKHRvd2VyLnRvd2VySWQgPT09ICdjYXQnICYmIGNhdEltZ1JlZi5jdXJyZW50KSB7XG4gICAgICAgICAgLy8gQ2lyY3VsYXIgY2xpcHBlZCBpbWFnZVxuICAgICAgICAgIGN0eC5zYXZlKCk7XG4gICAgICAgICAgY3R4LmJlZ2luUGF0aCgpO1xuICAgICAgICAgIGN0eC5hcmMoMCwgMCwgMTYsIDAsIE1hdGguUEkgKiAyKTtcbiAgICAgICAgICBjdHguY2xpcCgpO1xuICAgICAgICAgIGN0eC5kcmF3SW1hZ2UoY2F0SW1nUmVmLmN1cnJlbnQsIC0xNiwgLTE2LCAzMiwgMzIpO1xuICAgICAgICAgIGN0eC5yZXN0b3JlKCk7XG5cbiAgICAgICAgICAvLyBMZXZlbCAzIEZyb3N0IEF1cmFcbiAgICAgICAgICBpZiAodG93ZXIubGV2ZWwgPj0gMykge1xuICAgICAgICAgICAgY3R4LmJlZ2luUGF0aCgpO1xuICAgICAgICAgICAgY3R4LmFyYygwLCAwLCAyMiwgMCwgTWF0aC5QSSAqIDIpO1xuICAgICAgICAgICAgY3R4LnN0cm9rZVN0eWxlID0gJyMzOGJkZjgnO1xuICAgICAgICAgICAgY3R4LmxpbmVXaWR0aCA9IDIuNTtcbiAgICAgICAgICAgIGN0eC5zdHJva2UoKTtcblxuICAgICAgICAgICAgLy8gUm90YXRpbmcgc25vdyBzdGFyXG4gICAgICAgICAgICBjdHguZmlsbFN0eWxlID0gJyNiYWU2ZmQnO1xuICAgICAgICAgICAgY3R4LmZvbnQgPSAnMTBweCBzYW5zLXNlcmlmJztcbiAgICAgICAgICAgIGN0eC5maWxsVGV4dCgn4p2E77iPJywgMTIsIC0xMik7XG4gICAgICAgICAgfVxuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIC8vIEVtb2ppIC8gSWNvbiBmb3Igb3RoZXIgdG93ZXJzXG4gICAgICAgICAgY3R4LmZvbnQgPSAnMjBweCBzYW5zLXNlcmlmJztcbiAgICAgICAgICBjdHgudGV4dEFsaWduID0gJ2NlbnRlcic7XG4gICAgICAgICAgY3R4LnRleHRCYXNlbGluZSA9ICdtaWRkbGUnO1xuICAgICAgICAgIGN0eC5maWxsVGV4dChkZWYuaWNvbiwgMCwgMCk7XG4gICAgICAgIH1cblxuICAgICAgICAvLyBMZXZlbCBzdGFycyBiYWRnZSAo4piFLCDimIXimIUsIOKYheKYheKYhSlcbiAgICAgICAgaWYgKHRvd2VyLmxldmVsID4gMCkge1xuICAgICAgICAgIGN0eC5maWxsU3R5bGUgPSAnI2ZhY2MxNSc7XG4gICAgICAgICAgY3R4LmZvbnQgPSAnYm9sZCAxMXB4IG1vbm9zcGFjZSc7XG4gICAgICAgICAgY3R4LnRleHRBbGlnbiA9ICdjZW50ZXInO1xuICAgICAgICAgIGN0eC5maWxsVGV4dCgn4piFJy5yZXBlYXQodG93ZXIubGV2ZWwpLCAwLCAtMjUpO1xuICAgICAgICB9XG5cbiAgICAgICAgLy8gQWxseSBtYXJrZXIgaWYgY28tb3BcbiAgICAgICAgaWYgKHRvd2VyLmlzQ29vcEFsbHkpIHtcbiAgICAgICAgICBjdHguZmlsbFN0eWxlID0gJyMwNmI2ZDQnO1xuICAgICAgICAgIGN0eC5mb250ID0gJ2JvbGQgOXB4IHNhbnMtc2VyaWYnO1xuICAgICAgICAgIGN0eC50ZXh0QWxpZ24gPSAnY2VudGVyJztcbiAgICAgICAgICBjdHguZmlsbFRleHQoJ1vQlNCg0KPQk10nLCAwLCAzMik7XG4gICAgICAgIH1cblxuICAgICAgICBjdHgucmVzdG9yZSgpO1xuICAgICAgfSk7XG5cbiAgICAgIC8vIDguIERyYXcgUGxhY2VtZW50IFByZXZpZXcgaWYgc2VsZWN0aW5nIGEgdG93ZXIgdG8gcGxhY2VcbiAgICAgIGlmIChzZWxlY3RlZFRvd2VyVG9QbGFjZSAmJiBtb3VzZVBvcykge1xuICAgICAgICBjb25zdCBkZWYgPSBUT1dFUlNfREFUQS5maW5kKCh0KSA9PiB0LmlkID09PSBzZWxlY3RlZFRvd2VyVG9QbGFjZSk7XG4gICAgICAgIGlmIChkZWYpIHtcbiAgICAgICAgICBjb25zdCBvblBhdGggPSBpc1BvaW50T25QYXRoKG1vdXNlUG9zLngsIG1vdXNlUG9zLnkpO1xuICAgICAgICAgIGNvbnN0IHRvb0Nsb3NlID0gcGxhY2VkVG93ZXJzLnNvbWUoKHQpID0+IGRpc3QodC54LCB0LnksIG1vdXNlUG9zLngsIG1vdXNlUG9zLnkpIDwgNDIpO1xuICAgICAgICAgIGNvbnN0IGNhblBsYWNlID0gIW9uUGF0aCAmJiAhdG9vQ2xvc2UgJiYgY2FzaCA+PSBkZWYuYmFzZUNvc3Q7XG5cbiAgICAgICAgICAvLyBSYW5nZSBjaXJjbGVcbiAgICAgICAgICBjdHguYmVnaW5QYXRoKCk7XG4gICAgICAgICAgY3R4LmFyYyhtb3VzZVBvcy54LCBtb3VzZVBvcy55LCBkZWYubGV2ZWxzWzBdLnJhbmdlLCAwLCBNYXRoLlBJICogMik7XG4gICAgICAgICAgY3R4LmZpbGxTdHlsZSA9IGNhblBsYWNlID8gJ3JnYmEoMzQsIDE5NywgOTQsIDAuMTUpJyA6ICdyZ2JhKDIzOSwgNjgsIDY4LCAwLjIpJztcbiAgICAgICAgICBjdHguZmlsbCgpO1xuICAgICAgICAgIGN0eC5zdHJva2VTdHlsZSA9IGNhblBsYWNlID8gJyMyMmM1NWUnIDogJyNlZjQ0NDQnO1xuICAgICAgICAgIGN0eC5saW5lV2lkdGggPSAyO1xuICAgICAgICAgIGN0eC5zdHJva2UoKTtcblxuICAgICAgICAgIC8vIFByZXZpZXcgZ2hvc3RcbiAgICAgICAgICBjdHguc2F2ZSgpO1xuICAgICAgICAgIGN0eC50cmFuc2xhdGUobW91c2VQb3MueCwgbW91c2VQb3MueSk7XG4gICAgICAgICAgY3R4Lmdsb2JhbEFscGhhID0gMC44O1xuICAgICAgICAgIGN0eC5maWxsU3R5bGUgPSBjYW5QbGFjZSA/ICcjMjJjNTVlJyA6ICcjZWY0NDQ0JztcbiAgICAgICAgICBjdHguZmlsbFJlY3QoLTE4LCAtMTgsIDM2LCAzNik7XG5cbiAgICAgICAgICBpZiAoZGVmLmlkID09PSAnY2F0JyAmJiBjYXRJbWdSZWYuY3VycmVudCkge1xuICAgICAgICAgICAgY3R4LnNhdmUoKTtcbiAgICAgICAgICAgIGN0eC5iZWdpblBhdGgoKTtcbiAgICAgICAgICAgIGN0eC5hcmMoMCwgMCwgMTQsIDAsIE1hdGguUEkgKiAyKTtcbiAgICAgICAgICAgIGN0eC5jbGlwKCk7XG4gICAgICAgICAgICBjdHguZHJhd0ltYWdlKGNhdEltZ1JlZi5jdXJyZW50LCAtMTQsIC0xNCwgMjgsIDI4KTtcbiAgICAgICAgICAgIGN0eC5yZXN0b3JlKCk7XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIGN0eC5mb250ID0gJzE4cHggc2Fucy1zZXJpZic7XG4gICAgICAgICAgICBjdHgudGV4dEFsaWduID0gJ2NlbnRlcic7XG4gICAgICAgICAgICBjdHgudGV4dEJhc2VsaW5lID0gJ21pZGRsZSc7XG4gICAgICAgICAgICBjdHguZmlsbFRleHQoZGVmLmljb24sIDAsIDApO1xuICAgICAgICAgIH1cbiAgICAgICAgICBjdHgucmVzdG9yZSgpO1xuICAgICAgICB9XG4gICAgICB9XG5cbiAgICAgIC8vIDkuIFVwZGF0ZSAmIERyYXcgUGFydGljbGVzIChmbG9hdGluZyBkYW1hZ2UsIHRleHRzKVxuICAgICAgZm9yIChsZXQgaSA9IHBhcnRpY2xlc1JlZi5jdXJyZW50Lmxlbmd0aCAtIDE7IGkgPj0gMDsgaS0tKSB7XG4gICAgICAgIGNvbnN0IHAgPSBwYXJ0aWNsZXNSZWYuY3VycmVudFtpXTtcbiAgICAgICAgcC54ICs9IHAudng7XG4gICAgICAgIHAueSArPSBwLnZ5O1xuICAgICAgICBwLmxpZmUgLT0gZHQgKiAxLjM7XG5cbiAgICAgICAgaWYgKHAubGlmZSA8PSAwKSB7XG4gICAgICAgICAgcGFydGljbGVzUmVmLmN1cnJlbnQuc3BsaWNlKGksIDEpO1xuICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICB9XG5cbiAgICAgICAgY3R4LnNhdmUoKTtcbiAgICAgICAgY3R4Lmdsb2JhbEFscGhhID0gTWF0aC5tYXgoMCwgcC5saWZlKTtcbiAgICAgICAgY3R4LmZpbGxTdHlsZSA9IHAuY29sb3I7XG4gICAgICAgIGN0eC5mb250ID0gJ2JvbGQgMTJweCBtb25vc3BhY2UnO1xuICAgICAgICBjdHguZmlsbFRleHQocC50ZXh0IHx8ICcnLCBwLngsIHAueSk7XG4gICAgICAgIGN0eC5yZXN0b3JlKCk7XG4gICAgICB9XG5cbiAgICAgIC8vIDEwLiBDaGVjayBXYXZlIENvbXBsZXRpb25cbiAgICAgIGlmICh3YXZlU3RhdGUgPT09ICdjbGVhcmluZycgJiYgZW5lbWllc1JlZi5jdXJyZW50Lmxlbmd0aCA9PT0gMCkge1xuICAgICAgICBzZXRXYXZlU3RhdGUoJ3dhaXRpbmcnKTtcbiAgICAgICAgc2V0V2F2ZUNvdW50ZG93big2KTtcbiAgICAgICAgc291bmRzLnBsYXlXYXZlU3RhcnQoKTtcblxuICAgICAgICAvLyBFbmQgb2Ygd2F2ZSBlY29ub215IGJvbnVzZXNcbiAgICAgICAgY29uc3Qgd2F2ZUNhc2hCb251cyA9IDE2MCArIHdhdmUgKiAzNTtcbiAgICAgICAgc2V0Q2FzaCgoYykgPT4gYyArIHdhdmVDYXNoQm9udXMpO1xuICAgICAgICBhZGRQYXJ0aWNsZSg0MjAsIDI1MCwgYNCS0L7Qu9C90LAgJHt3YXZlfSDQl9Cw0LLQtdGA0YjQtdC90LAhICskJHt3YXZlQ2FzaEJvbnVzfWAsICcjZmFjYzE1Jyk7XG5cbiAgICAgICAgLy8gQmFua2VyIENhdCBib251c1xuICAgICAgICBwbGFjZWRUb3dlcnMuZm9yRWFjaCgodCkgPT4ge1xuICAgICAgICAgIGlmICh0LnRvd2VySWQgPT09ICdiYW5rZXJfY2F0Jykge1xuICAgICAgICAgICAgY29uc3QgYm9udXMgPSBbMTIwLCAzMDAsIDc1MCwgMTYwMF1bTWF0aC5taW4odC5sZXZlbCwgMyldO1xuICAgICAgICAgICAgc2V0Q2FzaCgoYykgPT4gYyArIGJvbnVzKTtcbiAgICAgICAgICAgIGFkZFBhcnRpY2xlKHQueCwgdC55IC0gMjAsIGArJCR7Ym9udXN9INCR0LDQvdC6YCwgJyMxMGI5ODEnKTtcbiAgICAgICAgICB9XG4gICAgICAgIH0pO1xuXG4gICAgICAgIC8vIENoZWNrIGlmIGZpbmFsIHdhdmUgY2xlYXJlZFxuICAgICAgICBpZiAod2F2ZSA+PSBtYXhXYXZlcykge1xuICAgICAgICAgIHNvdW5kcy5wbGF5VmljdG9yeSgpO1xuICAgICAgICAgIG9uR2FtZU92ZXIod2F2ZSwgd2F2ZSAqIDI1MDAsIHRydWUpO1xuICAgICAgICB9XG4gICAgICB9XG5cbiAgICAgIGFuaW1GcmFtZSA9IHJlcXVlc3RBbmltYXRpb25GcmFtZShsb29wKTtcbiAgICB9O1xuXG4gICAgYW5pbUZyYW1lID0gcmVxdWVzdEFuaW1hdGlvbkZyYW1lKGxvb3ApO1xuICAgIHJldHVybiAoKSA9PiBjYW5jZWxBbmltYXRpb25GcmFtZShhbmltRnJhbWUpO1xuICB9LCBbXG4gICAgYmFzZUhwLFxuICAgIGNhc2gsXG4gICAgZ2FtZVNwZWVkLFxuICAgIGlzUGF1c2VkLFxuICAgIG1heFdhdmVzLFxuICAgIG1vdXNlUG9zLFxuICAgIG9uR2FtZU92ZXIsXG4gICAgcGxhY2VkVG93ZXJzLFxuICAgIHNlbGVjdGVkUGxhY2VkVG93ZXJJZCxcbiAgICBzZWxlY3RlZFRvd2VyVG9QbGFjZSxcbiAgICBzZXRDYXNoLFxuICAgIHdhdmUsXG4gICAgd2F2ZVN0YXRlLFxuICAgIGFkZFBhcnRpY2xlLFxuICBdKTtcblxuICAvLyBIYW5kbGUgQ2FudmFzIENsaWNrIChwbGFjZSB0b3dlciBvciBzZWxlY3QgdG93ZXIpXG4gIGNvbnN0IGhhbmRsZUNhbnZhc0NsaWNrID0gKGU6IFJlYWN0Lk1vdXNlRXZlbnQ8SFRNTENhbnZhc0VsZW1lbnQ+KSA9PiB7XG4gICAgY29uc3QgY2FudmFzID0gY2FudmFzUmVmLmN1cnJlbnQ7XG4gICAgaWYgKCFjYW52YXMpIHJldHVybjtcbiAgICBjb25zdCByZWN0ID0gY2FudmFzLmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpO1xuICAgIGNvbnN0IHNjYWxlWCA9IGNhbnZhcy53aWR0aCAvIHJlY3Qud2lkdGg7XG4gICAgY29uc3Qgc2NhbGVZID0gY2FudmFzLmhlaWdodCAvIHJlY3QuaGVpZ2h0O1xuICAgIGNvbnN0IHggPSAoZS5jbGllbnRYIC0gcmVjdC5sZWZ0KSAqIHNjYWxlWDtcbiAgICBjb25zdCB5ID0gKGUuY2xpZW50WSAtIHJlY3QudG9wKSAqIHNjYWxlWTtcblxuICAgIC8vIENoZWNrIGlmIGNsaWNrZWQgYW4gZXhpc3RpbmcgdG93ZXJcbiAgICBjb25zdCBjbGlja2VkVG93ZXIgPSBwbGFjZWRUb3dlcnMuZmluZCgodCkgPT4gZGlzdCh0LngsIHQueSwgeCwgeSkgPCAyNCk7XG4gICAgaWYgKGNsaWNrZWRUb3dlcikge1xuICAgICAgb25TZWxlY3RQbGFjZWRUb3dlcihjbGlja2VkVG93ZXIpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIC8vIE90aGVyd2lzZSwgcGxhY2UgbmV3IHRvd2VyIGlmIG9uZSBpcyBjaG9zZW5cbiAgICBpZiAoc2VsZWN0ZWRUb3dlclRvUGxhY2UpIHtcbiAgICAgIGNvbnN0IGRlZiA9IFRPV0VSU19EQVRBLmZpbmQoKHQpID0+IHQuaWQgPT09IHNlbGVjdGVkVG93ZXJUb1BsYWNlKTtcbiAgICAgIGlmICghZGVmKSByZXR1cm47XG5cbiAgICAgIGNvbnN0IG9uUGF0aCA9IGlzUG9pbnRPblBhdGgoeCwgeSk7XG4gICAgICBjb25zdCB0b29DbG9zZSA9IHBsYWNlZFRvd2Vycy5zb21lKCh0KSA9PiBkaXN0KHQueCwgdC55LCB4LCB5KSA8IDQyKTtcblxuICAgICAgaWYgKCFvblBhdGggJiYgIXRvb0Nsb3NlICYmIGNhc2ggPj0gZGVmLmJhc2VDb3N0KSB7XG4gICAgICAgIGNvbnN0IG5ld1Rvd2VyOiBQbGFjZWRUb3dlciA9IHtcbiAgICAgICAgICBpbnN0YW5jZUlkOiAndG93ZXJfJyArIE1hdGgucmFuZG9tKCkudG9TdHJpbmcoMzYpLnN1YnN0cigyLCA5KSxcbiAgICAgICAgICB0b3dlcklkOiBkZWYuaWQsXG4gICAgICAgICAgeCxcbiAgICAgICAgICB5LFxuICAgICAgICAgIGxldmVsOiAwLFxuICAgICAgICAgIHRvdGFsSW52ZXN0ZWQ6IGRlZi5iYXNlQ29zdCxcbiAgICAgICAgICB0YXJnZXRNb2RlOiAnZmlyc3QnLFxuICAgICAgICAgIGxhc3RTaG90VGltZTogMCxcbiAgICAgICAgICBraWxsczogMCxcbiAgICAgICAgICBkYW1hZ2VEZWFsdDogMCxcbiAgICAgICAgfTtcblxuICAgICAgICBzZXRDYXNoKChjKSA9PiBjIC0gZGVmLmJhc2VDb3N0KTtcbiAgICAgICAgc2V0UGxhY2VkVG93ZXJzKChwcmV2KSA9PiBbLi4ucHJldiwgbmV3VG93ZXJdKTtcbiAgICAgICAgb25Ub3dlclBsYWNlZFN1Y2Nlc3MoZGVmLmlkKTtcbiAgICAgICAgc291bmRzLnBsYXlQbGFjZVRvd2VyKCk7XG4gICAgICAgIGFkZFBhcnRpY2xlKHgsIHksIGAtJHtkZWYuYmFzZUNvc3R9JGAsICcjZWY0NDQ0Jyk7XG4gICAgICB9XG4gICAgfSBlbHNlIHtcbiAgICAgIC8vIERlc2VsZWN0XG4gICAgICBvblNlbGVjdFBsYWNlZFRvd2VyKG51bGwpO1xuICAgIH1cbiAgfTtcblxuICBjb25zdCBoYW5kbGVNb3VzZU1vdmUgPSAoZTogUmVhY3QuTW91c2VFdmVudDxIVE1MQ2FudmFzRWxlbWVudD4pID0+IHtcbiAgICBjb25zdCBjYW52YXMgPSBjYW52YXNSZWYuY3VycmVudDtcbiAgICBpZiAoIWNhbnZhcykgcmV0dXJuO1xuICAgIGNvbnN0IHJlY3QgPSBjYW52YXMuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCk7XG4gICAgY29uc3Qgc2NhbGVYID0gY2FudmFzLndpZHRoIC8gcmVjdC53aWR0aDtcbiAgICBjb25zdCBzY2FsZVkgPSBjYW52YXMuaGVpZ2h0IC8gcmVjdC5oZWlnaHQ7XG4gICAgc2V0TW91c2VQb3Moe1xuICAgICAgeDogKGUuY2xpZW50WCAtIHJlY3QubGVmdCkgKiBzY2FsZVgsXG4gICAgICB5OiAoZS5jbGllbnRZIC0gcmVjdC50b3ApICogc2NhbGVZLFxuICAgIH0pO1xuICB9O1xuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSB3LWZ1bGwgcm91bmRlZC0yeGwgb3ZlcmZsb3ctaGlkZGVuIGJvcmRlci0yIGJvcmRlci1zbGF0ZS03MDAgYmctc2xhdGUtOTAwIHNoYWRvdy0yeGwgc2VsZWN0LW5vbmVcIj5cbiAgICAgIHsvKiBUb3AgR2FtZSBTdGF0dXMgQmFyICovfVxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHB4LTQgcHktMi41IGJnLXNsYXRlLTk1MC84MCBiYWNrZHJvcC1ibHVyLW1kIGJvcmRlci1iIGJvcmRlci1zbGF0ZS04MDAgdGV4dC1zbVwiPlxuICAgICAgICB7LyogQmFzZSBIZWFsdGggKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgc3BhY2UteC0yXCI+XG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14bFwiPvCfj7A8L3NwYW4+XG4gICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgc3BhY2UteC0xIGZvbnQtYm9sZCB0ZXh0LXhzIHRleHQtc2xhdGUtMzAwXCI+XG4gICAgICAgICAgICAgIDxzcGFuPtCX0LTQvtGA0L7QstGM0LUg0JHQsNC30Ys6PC9zcGFuPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2Jhc2VIcCA+IDMwID8gJ3RleHQtZ3JlZW4tNDAwJyA6ICd0ZXh0LXJlZC00MDAnfT57YmFzZUhwfSU8L3NwYW4+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0yOCBoLTIgYmctc2xhdGUtODAwIHJvdW5kZWQtZnVsbCBvdmVyZmxvdy1oaWRkZW4gbXQtMC41XCI+XG4gICAgICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BoLWZ1bGwgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMzAwICR7YmFzZUhwID4gMzAgPyAnYmctZ3JlZW4tNTAwJyA6ICdiZy1yZWQtNTAwJ31gfVxuICAgICAgICAgICAgICAgIHN0eWxlPXt7IHdpZHRoOiBgJHtiYXNlSHB9JWAgfX1cbiAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICB7LyogV2F2ZXMgSW5mbyAmIENhbGwgRWFybHkgKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgc3BhY2UteC0zXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlclwiPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTQwMFwiPtCS0L7Qu9C90LA8L3NwYW4+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvbnQtZXh0cmFib2xkIHRleHQtYmFzZSB0ZXh0LWN5YW4tNDAwXCI+XG4gICAgICAgICAgICAgIHt3YXZlfSA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNTAwXCI+LyB7bWF4V2F2ZXN9PC9zcGFuPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICB7d2F2ZVN0YXRlID09PSAnd2FpdGluZycgJiYgd2F2ZSA8IG1heFdhdmVzICYmIChcbiAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlQ2FsbFdhdmVFYXJseX1cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtMyBweS0xIHRleHQteHMgZm9udC1ib2xkIGJnLWFtYmVyLTUwMCBob3ZlcjpiZy1hbWJlci00MDAgdGV4dC1zbGF0ZS05NTAgcm91bmRlZC1sZyBzaGFkb3ctbGcgdHJhbnNpdGlvbi10cmFuc2Zvcm0gYWN0aXZlOnNjYWxlLTk1IGFuaW1hdGUtcHVsc2UgZmxleCBpdGVtcy1jZW50ZXIgc3BhY2UteC0xXCJcbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgPHNwYW4+4pqhINCh0YLQsNGA0YIg0JLQvtC70L3RiyAoKyQzNSk8L3NwYW4+XG4gICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICApfVxuXG4gICAgICAgICAge3dhdmVTdGF0ZSA9PT0gJ3NwYXduaW5nJyAmJiAoXG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJweC0yLjUgcHktMSB0ZXh0LXhzIGJnLXJlZC05NTAvNzAgdGV4dC1yZWQtMzAwIGJvcmRlciBib3JkZXItcmVkLTcwMC81MCByb3VuZGVkLW1kIGZvbnQtbW9ub1wiPlxuICAgICAgICAgICAgICDimqDvuI8g0JDRgtCw0LrQsCAoe2VuZW1pZXNSZW1haW5pbmd9KVxuICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICl9XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIHsvKiBTcGVlZCAmIENvbnRyb2xzICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIHNwYWNlLXgtMlwiPlxuICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldElzUGF1c2VkKCFpc1BhdXNlZCl9XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJweC0yLjUgcHktMSB0ZXh0LXhzIGZvbnQtYm9sZCBiZy1zbGF0ZS04MDAgaG92ZXI6Ymctc2xhdGUtNzAwIHRleHQtc2xhdGUtMjAwIHJvdW5kZWQtbWQgYm9yZGVyIGJvcmRlci1zbGF0ZS03MDBcIlxuICAgICAgICAgID5cbiAgICAgICAgICAgIHtpc1BhdXNlZCA/ICfilrbvuI8g0J/RgNC+0LTQvtC70LbQuNGC0YwnIDogJ+KPuO+4jyDQn9Cw0YPQt9CwJ31cbiAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggcm91bmRlZC1tZCBvdmVyZmxvdy1oaWRkZW4gYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAgdGV4dC14cyBmb250LWJvbGRcIj5cbiAgICAgICAgICAgIHtbMSwgMiwgM10ubWFwKChzcGQpID0+IChcbiAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgIGtleT17c3BkfVxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEdhbWVTcGVlZChzcGQpfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHB4LTIgcHktMSAke1xuICAgICAgICAgICAgICAgICAgZ2FtZVNwZWVkID09PSBzcGQgPyAnYmctY3lhbi02MDAgdGV4dC13aGl0ZScgOiAnYmctc2xhdGUtODAwIHRleHQtc2xhdGUtNDAwIGhvdmVyOmJnLXNsYXRlLTcwMCdcbiAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIHtzcGR9eFxuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICkpfVxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7LyogTWFpbiBDYW52YXMgKi99XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIGFzcGVjdC1bODQwLzUwMF0gdy1mdWxsIGJnLXNsYXRlLTkwMFwiPlxuICAgICAgICA8Y2FudmFzXG4gICAgICAgICAgcmVmPXtjYW52YXNSZWZ9XG4gICAgICAgICAgd2lkdGg9ezg0MH1cbiAgICAgICAgICBoZWlnaHQ9ezUwMH1cbiAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVDYW52YXNDbGlja31cbiAgICAgICAgICBvbk1vdXNlTW92ZT17aGFuZGxlTW91c2VNb3ZlfVxuICAgICAgICAgIG9uTW91c2VMZWF2ZT17KCkgPT4gc2V0TW91c2VQb3MobnVsbCl9XG4gICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGgtZnVsbCBjdXJzb3ItY3Jvc3NoYWlyIGJsb2NrXCJcbiAgICAgICAgLz5cblxuICAgICAgICB7LyogQ28tb3AgTGl2ZSBUZWFtbWF0ZSBBY3Rpdml0eSBPdmVybGF5ICovfVxuICAgICAgICB7aXNDb29wICYmIChcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIGJvdHRvbS0zIGxlZnQtMyBiZy1zbGF0ZS05NTAvODUgYmFja2Ryb3AtYmx1ci1tZCBib3JkZXIgYm9yZGVyLWN5YW4tODAwLzYwIHJvdW5kZWQteGwgcC0yLjUgbWF4LXcteHMgdGV4dC14cyBzaGFkb3cteGwgcG9pbnRlci1ldmVudHMtbm9uZVwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBzcGFjZS14LTEuNSBmb250LWJvbGQgdGV4dC1jeWFuLTQwMCBtYi0xXCI+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInctMiBoLTIgcm91bmRlZC1mdWxsIGJnLWdyZWVuLTQwMCBhbmltYXRlLXBpbmdcIiAvPlxuICAgICAgICAgICAgICA8c3Bhbj7QmtC+0L7Qv9C10YDQsNGC0LjQsiDRgSDQndCw0L/QsNGA0L3QuNC60L7QvDwvc3Bhbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTAuNSB0ZXh0LXNsYXRlLTMwMCBmb250LW1vbm8gdGV4dC1bMTFweF1cIj5cbiAgICAgICAgICAgICAge2Nvb3BNZXNzYWdlcy5zbGljZSgtMykubWFwKChtc2csIGlkeCkgPT4gKFxuICAgICAgICAgICAgICAgIDxkaXYga2V5PXtpZHh9IGNsYXNzTmFtZT1cInRydW5jYXRlXCI+XG4gICAgICAgICAgICAgICAgICDwn5KsIHttc2d9XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICl9XG5cbiAgICAgICAgey8qIFBsYWNlbWVudCBIaW50IFRvb2x0aXAgKi99XG4gICAgICAgIHtzZWxlY3RlZFRvd2VyVG9QbGFjZSAmJiAoXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSB0b3AtMyBsZWZ0LTEvMiAtdHJhbnNsYXRlLXgtMS8yIGJnLXNsYXRlLTk1MC85MCB0ZXh0LWN5YW4tMzAwIGJvcmRlciBib3JkZXItY3lhbi01MDAvNTAgcHgtMyBweS0xIHJvdW5kZWQtZnVsbCB0ZXh0LXhzIGZvbnQtYm9sZCBzaGFkb3ctbGcgcG9pbnRlci1ldmVudHMtbm9uZVwiPlxuICAgICAgICAgICAg0JrQu9C40LrQvdC40YLQtSDQvdCwINGB0LLQvtCx0L7QtNC90L7QtSDQt9C10LvQtdC90L7QtSDQvNC10YHRgtC+INC90LAg0L/QvtC70LUg0LTQu9GPINGD0YHRgtCw0L3QvtCy0LrQuFxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICApfVxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG4gICk7XG59O1xuIl19