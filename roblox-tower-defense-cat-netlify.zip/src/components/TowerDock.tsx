const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport2_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=1e19e0c2";
import { TOWERS_DATA } from "/src/data/constants.ts";
var _jsxFileName = "/app/applet/src/components/TowerDock.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=1e19e0c2";
export const TowerDock = ({ cash, selectedTowerToPlace, onSelectTowerToPlace, restrictedTowers }) => {
	const [filterCategory, setFilterCategory] = useState("all");
	const filteredTowers = TOWERS_DATA.filter((tower) => {
		if (filterCategory === "all") return true;
		if (filterCategory === "damage") return tower.type === "damage";
		if (filterCategory === "splash") return tower.type === "splash";
		if (filterCategory === "slow") return tower.type === "slow";
		if (filterCategory === "support_economy") return tower.type === "support" || tower.type === "economy";
		return true;
	});
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "bg-slate-900/95 backdrop-blur-md border border-slate-800 rounded-3xl p-3.5 shadow-2xl space-y-2.5",
		children: [/* @__PURE__ */ _jsxDEV("div", {
			className: "flex flex-wrap items-center justify-between gap-2 border-b border-slate-800/80 pb-2",
			children: [/* @__PURE__ */ _jsxDEV("div", {
				className: "flex items-center space-x-1.5 text-xs font-bold overflow-x-auto",
				children: [/* @__PURE__ */ _jsxDEV("span", {
					className: "text-slate-400 px-1 hidden md:inline text-[11px] uppercase tracking-wider",
					children: "Арсенал:"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 35,
					columnNumber: 11
				}, this), [
					{
						id: "all",
						label: `Все (${TOWERS_DATA.length})`
					},
					{
						id: "damage",
						label: "🎯 Урон"
					},
					{
						id: "splash",
						label: "💥 Сплеш"
					},
					{
						id: "slow",
						label: "❄️ Контроль"
					},
					{
						id: "support_economy",
						label: "💰 Саппорт / Банк"
					}
				].map((cat) => /* @__PURE__ */ _jsxDEV("button", {
					onClick: () => setFilterCategory(cat.id),
					className: `px-2.5 py-1 rounded-xl transition-all cursor-pointer text-xs ${filterCategory === cat.id ? "bg-cyan-500 text-slate-950 font-black shadow-md" : "bg-slate-800/80 text-slate-400 hover:text-white hover:bg-slate-700"}`,
					children: cat.label
				}, cat.id, false, {
					fileName: _jsxFileName,
					lineNumber: 45,
					columnNumber: 13
				}, this))]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 34,
				columnNumber: 9
			}, this), selectedTowerToPlace && /* @__PURE__ */ _jsxDEV("button", {
				onClick: () => onSelectTowerToPlace(null),
				className: "px-3 py-1 text-xs font-bold bg-rose-950/80 hover:bg-rose-900 border border-rose-800 text-rose-300 rounded-xl",
				children: "✕ Отменить выбор"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 60,
				columnNumber: 11
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 33,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			className: "flex items-center space-x-2.5 overflow-x-auto pb-1.5 pt-0.5 scrollbar-thin scrollbar-thumb-slate-700",
			children: filteredTowers.map((tower) => {
				const isRestricted = restrictedTowers && !restrictedTowers.includes(tower.id);
				const isSelected = selectedTowerToPlace === tower.id;
				const canAfford = cash >= tower.baseCost;
				if (isRestricted) {
					return /* @__PURE__ */ _jsxDEV("div", {
						className: "opacity-40 p-2.5 rounded-2xl bg-slate-950 border border-slate-800 flex items-center space-x-2 grayscale cursor-not-allowed text-xs shrink-0",
						title: "Запрещено в текущем испытании недели",
						children: [/* @__PURE__ */ _jsxDEV("span", { children: "🚫" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 83,
							columnNumber: 17
						}, this), /* @__PURE__ */ _jsxDEV("span", {
							className: "text-slate-500 font-bold",
							children: tower.name
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 84,
							columnNumber: 17
						}, this)]
					}, tower.id, true, {
						fileName: _jsxFileName,
						lineNumber: 78,
						columnNumber: 15
					}, this);
				}
				return /* @__PURE__ */ _jsxDEV("button", {
					onClick: () => {
						if (isSelected) {
							onSelectTowerToPlace(null);
						} else if (canAfford) {
							onSelectTowerToPlace(tower.id);
						}
					},
					disabled: !canAfford && !isSelected,
					className: `relative flex items-center space-x-2.5 px-3 py-2 rounded-2xl border-2 transition-all select-none text-left shrink-0 ${isSelected ? "bg-cyan-500/20 border-cyan-400 shadow-lg shadow-cyan-500/25 scale-105" : canAfford ? "bg-slate-800/80 border-slate-700 hover:border-cyan-500/50 hover:bg-slate-800 cursor-pointer active:scale-95" : "bg-slate-900/60 border-slate-800/50 opacity-45 cursor-not-allowed"}`,
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "relative w-11 h-11 rounded-xl bg-slate-950 border border-slate-700 flex items-center justify-center overflow-hidden shrink-0 shadow-inner",
							children: [tower.image ? /* @__PURE__ */ _jsxDEV("img", {
								src: tower.image,
								alt: tower.name,
								className: "w-full h-full object-cover"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 111,
								columnNumber: 19
							}, this) : /* @__PURE__ */ _jsxDEV("span", {
								className: "text-2xl",
								children: tower.icon
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 113,
								columnNumber: 19
							}, this), tower.id === "cat" && /* @__PURE__ */ _jsxDEV("span", {
								className: "absolute bottom-0 right-0 text-[10px]",
								children: "🕶️"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 116,
								columnNumber: 19
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 109,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "min-w-[105px]",
							children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center space-x-1",
									children: [
										/* @__PURE__ */ _jsxDEV("span", {
											className: "font-extrabold text-xs text-white truncate max-w-[110px]",
											children: tower.name
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 123,
											columnNumber: 19
										}, this),
										tower.id === "cat" && /* @__PURE__ */ _jsxDEV("span", {
											className: "px-1 py-0.2 text-[9px] font-bold bg-amber-500 text-slate-950 rounded",
											children: "ХИТ"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 127,
											columnNumber: 21
										}, this),
										tower.id === "mecha_cat" && /* @__PURE__ */ _jsxDEV("span", {
											className: "px-1 py-0.2 text-[9px] font-black bg-rose-600 text-white rounded",
											children: "NEW"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 132,
											columnNumber: 21
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 122,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center space-x-2 text-[11px] mt-0.5",
									children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "font-black text-emerald-400 font-mono",
										children: ["$", tower.baseCost]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 139,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("span", {
										className: "text-slate-400 text-[10px]",
										children: tower.type === "economy" ? /* @__PURE__ */ _jsxDEV("span", {
											className: "text-emerald-400 font-bold",
											children: "+$120/в"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 144,
											columnNumber: 23
										}, this) : /* @__PURE__ */ _jsxDEV(_Fragment, { children: ["Урон: ", /* @__PURE__ */ _jsxDEV("b", {
											className: "text-slate-200",
											children: tower.levels[0].damage
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 147,
											columnNumber: 31
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 146,
											columnNumber: 23
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 142,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 138,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "text-[10px] text-cyan-400/80 font-mono truncate max-w-[115px]",
									children: tower.levels[0].special || tower.tagline
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 154,
									columnNumber: 17
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 121,
							columnNumber: 15
						}, this),
						isSelected && /* @__PURE__ */ _jsxDEV("span", {
							className: "absolute -top-2 -right-1 px-1.5 py-0.5 rounded-full bg-cyan-400 text-slate-950 text-[9px] font-black uppercase shadow",
							children: "Выбран"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 160,
							columnNumber: 17
						}, this)
					]
				}, tower.id, true, {
					fileName: _jsxFileName,
					lineNumber: 90,
					columnNumber: 13
				}, this);
			})
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 70,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 31,
		columnNumber: 5
	}, this);
};

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLGdCQUFnQjtBQUNoQyxTQUFTLG1CQUFtQjs7O0FBVzVCLE9BQU8sTUFBTSxhQUF1QyxFQUNsRCxNQUNBLHNCQUNBLHNCQUNBLHVCQUNJO0NBQ0osTUFBTSxDQUFDLGdCQUFnQixxQkFBcUIsU0FBd0IsS0FBSztDQUV6RSxNQUFNLGlCQUFpQixZQUFZLFFBQVEsVUFBVTtFQUNuRCxJQUFJLG1CQUFtQixPQUFPLE9BQU87RUFDckMsSUFBSSxtQkFBbUIsVUFBVSxPQUFPLE1BQU0sU0FBUztFQUN2RCxJQUFJLG1CQUFtQixVQUFVLE9BQU8sTUFBTSxTQUFTO0VBQ3ZELElBQUksbUJBQW1CLFFBQVEsT0FBTyxNQUFNLFNBQVM7RUFDckQsSUFBSSxtQkFBbUIsbUJBQW1CLE9BQU8sTUFBTSxTQUFTLGFBQWEsTUFBTSxTQUFTO0VBQzVGLE9BQU87Q0FDVCxDQUFDO0NBRUQsT0FDRSx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUFmLENBRUUsd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFBZixDQUNFLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxRQUFEO0tBQU0sV0FBVTtlQUE0RTtJQUV0Rjs7OztjQUNMO0tBQ0M7TUFBRSxJQUFJO01BQU8sT0FBTyxRQUFRLFlBQVksT0FBTztLQUFHO0tBQ2xEO01BQUUsSUFBSTtNQUFVLE9BQU87S0FBVTtLQUNqQztNQUFFLElBQUk7TUFBVSxPQUFPO0tBQVc7S0FDbEM7TUFBRSxJQUFJO01BQVEsT0FBTztLQUFjO0tBQ25DO01BQUUsSUFBSTtNQUFtQixPQUFPO0tBQW9CO0lBQ3RELENBQUMsQ0FBQyxLQUFLLFFBQ0wsd0JBQUMsVUFBRDtLQUVFLGVBQWUsa0JBQWtCLElBQUksRUFBbUI7S0FDeEQsV0FBVyxnRUFDVCxtQkFBbUIsSUFBSSxLQUNuQixvREFDQTtlQUdMLElBQUk7SUFDQyxHQVRELElBQUk7Ozs7V0FTSCxDQUNULENBQ0U7Ozs7O2FBRUosd0JBQ0Msd0JBQUMsVUFBRDtJQUNFLGVBQWUscUJBQXFCLElBQUk7SUFDeEMsV0FBVTtjQUNYO0dBRU87Ozs7V0FFUDs7Ozs7WUFHTCx3QkFBQyxPQUFEO0dBQUssV0FBVTthQUNaLGVBQWUsS0FBSyxVQUFVO0lBQzdCLE1BQU0sZUFBZSxvQkFBb0IsQ0FBQyxpQkFBaUIsU0FBUyxNQUFNLEVBQUU7SUFDNUUsTUFBTSxhQUFhLHlCQUF5QixNQUFNO0lBQ2xELE1BQU0sWUFBWSxRQUFRLE1BQU07SUFFaEMsSUFBSSxjQUFjO0tBQ2hCLE9BQ0Usd0JBQUMsT0FBRDtNQUVFLFdBQVU7TUFDVixPQUFNO2dCQUhSLENBS0Usd0JBQUMsUUFBRCxZQUFNLEtBQVE7Ozs7Z0JBQ2Qsd0JBQUMsUUFBRDtPQUFNLFdBQVU7aUJBQTRCLE1BQU07TUFBVzs7OztjQUMxRDtRQU5FLE1BQU07Ozs7WUFNUjtJQUVUO0lBRUEsT0FDRSx3QkFBQyxVQUFEO0tBRUUsZUFBZTtNQUNiLElBQUksWUFBWTtPQUNkLHFCQUFxQixJQUFJO01BQzNCLE9BQU8sSUFBSSxXQUFXO09BQ3BCLHFCQUFxQixNQUFNLEVBQUU7TUFDL0I7S0FDRjtLQUNBLFVBQVUsQ0FBQyxhQUFhLENBQUM7S0FDekIsV0FBVyx1SEFDVCxhQUNJLDBFQUNBLFlBQ0EsZ0hBQ0E7ZUFmUjtNQW1CRSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNHLE1BQU0sUUFDTCx3QkFBQyxPQUFEO1FBQUssS0FBSyxNQUFNO1FBQU8sS0FBSyxNQUFNO1FBQU0sV0FBVTtPQUE4Qjs7OztrQkFFaEYsd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQVksTUFBTTtPQUFXOzs7O2lCQUU5QyxNQUFNLE9BQU8sU0FDWix3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBd0M7T0FBUzs7OztlQUVoRTs7Ozs7O01BR0wsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWY7UUFDRSx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZjtVQUNFLHdCQUFDLFFBQUQ7V0FBTSxXQUFVO3FCQUNiLE1BQU07VUFDSDs7Ozs7VUFDTCxNQUFNLE9BQU8sU0FDWix3QkFBQyxRQUFEO1dBQU0sV0FBVTtxQkFBdUU7VUFFakY7Ozs7O1VBRVAsTUFBTSxPQUFPLGVBQ1osd0JBQUMsUUFBRDtXQUFNLFdBQVU7cUJBQW1FO1VBRTdFOzs7OztTQUVMOzs7Ozs7UUFFTCx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNFLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUFoQixDQUF3RCxLQUNwRCxNQUFNLFFBQ0o7Ozs7O21CQUNOLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUNiLE1BQU0sU0FBUyxZQUNkLHdCQUFDLFFBQUQ7V0FBTSxXQUFVO3FCQUE2QjtVQUFhOzs7O3FCQUUxRCxnREFBRSxVQUNNLHdCQUFDLEtBQUQ7V0FBRyxXQUFVO3FCQUFrQixNQUFNLE9BQU8sRUFBRSxDQUFDO1VBQVU7Ozs7a0JBQy9EOzs7OztTQUVBOzs7O2lCQUNIOzs7Ozs7UUFHTCx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFDWixNQUFNLE9BQU8sRUFBRSxDQUFDLFdBQVcsTUFBTTtRQUMvQjs7Ozs7T0FDRjs7Ozs7O01BRUosY0FDQyx3QkFBQyxRQUFEO09BQU0sV0FBVTtpQkFBd0g7TUFFbEk7Ozs7O0tBRUY7T0F6RUQsTUFBTTs7OztXQXlFTDtHQUVaLENBQUM7RUFDRTs7OztVQUNGOzs7Ozs7QUFFVCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJUb3dlckRvY2sudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IFRPV0VSU19EQVRBIH0gZnJvbSAnLi4vZGF0YS9jb25zdGFudHMnO1xuXG5pbnRlcmZhY2UgVG93ZXJEb2NrUHJvcHMge1xuICBjYXNoOiBudW1iZXI7XG4gIHNlbGVjdGVkVG93ZXJUb1BsYWNlOiBzdHJpbmcgfCBudWxsO1xuICBvblNlbGVjdFRvd2VyVG9QbGFjZTogKHRvd2VySWQ6IHN0cmluZyB8IG51bGwpID0+IHZvaWQ7XG4gIHJlc3RyaWN0ZWRUb3dlcnM/OiBzdHJpbmdbXTsgLy8gZm9yIHdlZWtseSBjaGFsbGVuZ2UgbW9kaWZpZXJzXG59XG5cbnR5cGUgVG93ZXJDYXRlZ29yeSA9ICdhbGwnIHwgJ2RhbWFnZScgfCAnc3BsYXNoJyB8ICdzbG93JyB8ICdzdXBwb3J0X2Vjb25vbXknO1xuXG5leHBvcnQgY29uc3QgVG93ZXJEb2NrOiBSZWFjdC5GQzxUb3dlckRvY2tQcm9wcz4gPSAoe1xuICBjYXNoLFxuICBzZWxlY3RlZFRvd2VyVG9QbGFjZSxcbiAgb25TZWxlY3RUb3dlclRvUGxhY2UsXG4gIHJlc3RyaWN0ZWRUb3dlcnMsXG59KSA9PiB7XG4gIGNvbnN0IFtmaWx0ZXJDYXRlZ29yeSwgc2V0RmlsdGVyQ2F0ZWdvcnldID0gdXNlU3RhdGU8VG93ZXJDYXRlZ29yeT4oJ2FsbCcpO1xuXG4gIGNvbnN0IGZpbHRlcmVkVG93ZXJzID0gVE9XRVJTX0RBVEEuZmlsdGVyKCh0b3dlcikgPT4ge1xuICAgIGlmIChmaWx0ZXJDYXRlZ29yeSA9PT0gJ2FsbCcpIHJldHVybiB0cnVlO1xuICAgIGlmIChmaWx0ZXJDYXRlZ29yeSA9PT0gJ2RhbWFnZScpIHJldHVybiB0b3dlci50eXBlID09PSAnZGFtYWdlJztcbiAgICBpZiAoZmlsdGVyQ2F0ZWdvcnkgPT09ICdzcGxhc2gnKSByZXR1cm4gdG93ZXIudHlwZSA9PT0gJ3NwbGFzaCc7XG4gICAgaWYgKGZpbHRlckNhdGVnb3J5ID09PSAnc2xvdycpIHJldHVybiB0b3dlci50eXBlID09PSAnc2xvdyc7XG4gICAgaWYgKGZpbHRlckNhdGVnb3J5ID09PSAnc3VwcG9ydF9lY29ub215JykgcmV0dXJuIHRvd2VyLnR5cGUgPT09ICdzdXBwb3J0JyB8fCB0b3dlci50eXBlID09PSAnZWNvbm9teSc7XG4gICAgcmV0dXJuIHRydWU7XG4gIH0pO1xuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJiZy1zbGF0ZS05MDAvOTUgYmFja2Ryb3AtYmx1ci1tZCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLTN4bCBwLTMuNSBzaGFkb3ctMnhsIHNwYWNlLXktMi41XCI+XG4gICAgICB7LyogQ2F0ZWdvcnkgRmlsdGVyIENoaXBzICYgQ29udHJvbHMgKi99XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTIgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTgwMC84MCBwYi0yXCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgc3BhY2UteC0xLjUgdGV4dC14cyBmb250LWJvbGQgb3ZlcmZsb3cteC1hdXRvXCI+XG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS00MDAgcHgtMSBoaWRkZW4gbWQ6aW5saW5lIHRleHQtWzExcHhdIHVwcGVyY2FzZSB0cmFja2luZy13aWRlclwiPlxuICAgICAgICAgICAg0JDRgNGB0LXQvdCw0Ls6XG4gICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgIHtbXG4gICAgICAgICAgICB7IGlkOiAnYWxsJywgbGFiZWw6IGDQktGB0LUgKCR7VE9XRVJTX0RBVEEubGVuZ3RofSlgIH0sXG4gICAgICAgICAgICB7IGlkOiAnZGFtYWdlJywgbGFiZWw6ICfwn46vINCj0YDQvtC9JyB9LFxuICAgICAgICAgICAgeyBpZDogJ3NwbGFzaCcsIGxhYmVsOiAn8J+SpSDQodC/0LvQtdGIJyB9LFxuICAgICAgICAgICAgeyBpZDogJ3Nsb3cnLCBsYWJlbDogJ+KdhO+4jyDQmtC+0L3RgtGA0L7Qu9GMJyB9LFxuICAgICAgICAgICAgeyBpZDogJ3N1cHBvcnRfZWNvbm9teScsIGxhYmVsOiAn8J+SsCDQodCw0L/Qv9C+0YDRgiAvINCR0LDQvdC6JyB9LFxuICAgICAgICAgIF0ubWFwKChjYXQpID0+IChcbiAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAga2V5PXtjYXQuaWR9XG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEZpbHRlckNhdGVnb3J5KGNhdC5pZCBhcyBUb3dlckNhdGVnb3J5KX1cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcHgtMi41IHB5LTEgcm91bmRlZC14bCB0cmFuc2l0aW9uLWFsbCBjdXJzb3ItcG9pbnRlciB0ZXh0LXhzICR7XG4gICAgICAgICAgICAgICAgZmlsdGVyQ2F0ZWdvcnkgPT09IGNhdC5pZFxuICAgICAgICAgICAgICAgICAgPyAnYmctY3lhbi01MDAgdGV4dC1zbGF0ZS05NTAgZm9udC1ibGFjayBzaGFkb3ctbWQnXG4gICAgICAgICAgICAgICAgICA6ICdiZy1zbGF0ZS04MDAvODAgdGV4dC1zbGF0ZS00MDAgaG92ZXI6dGV4dC13aGl0ZSBob3ZlcjpiZy1zbGF0ZS03MDAnXG4gICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICB7Y2F0LmxhYmVsfVxuICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgKSl9XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIHtzZWxlY3RlZFRvd2VyVG9QbGFjZSAmJiAoXG4gICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gb25TZWxlY3RUb3dlclRvUGxhY2UobnVsbCl9XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJweC0zIHB5LTEgdGV4dC14cyBmb250LWJvbGQgYmctcm9zZS05NTAvODAgaG92ZXI6Ymctcm9zZS05MDAgYm9yZGVyIGJvcmRlci1yb3NlLTgwMCB0ZXh0LXJvc2UtMzAwIHJvdW5kZWQteGxcIlxuICAgICAgICAgID5cbiAgICAgICAgICAgIOKclSDQntGC0LzQtdC90LjRgtGMINCy0YvQsdC+0YBcbiAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgKX1cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7LyogVG93ZXJzIENhcmRzIFNsaWRlciAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgc3BhY2UteC0yLjUgb3ZlcmZsb3cteC1hdXRvIHBiLTEuNSBwdC0wLjUgc2Nyb2xsYmFyLXRoaW4gc2Nyb2xsYmFyLXRodW1iLXNsYXRlLTcwMFwiPlxuICAgICAgICB7ZmlsdGVyZWRUb3dlcnMubWFwKCh0b3dlcikgPT4ge1xuICAgICAgICAgIGNvbnN0IGlzUmVzdHJpY3RlZCA9IHJlc3RyaWN0ZWRUb3dlcnMgJiYgIXJlc3RyaWN0ZWRUb3dlcnMuaW5jbHVkZXModG93ZXIuaWQpO1xuICAgICAgICAgIGNvbnN0IGlzU2VsZWN0ZWQgPSBzZWxlY3RlZFRvd2VyVG9QbGFjZSA9PT0gdG93ZXIuaWQ7XG4gICAgICAgICAgY29uc3QgY2FuQWZmb3JkID0gY2FzaCA+PSB0b3dlci5iYXNlQ29zdDtcblxuICAgICAgICAgIGlmIChpc1Jlc3RyaWN0ZWQpIHtcbiAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgICAgICBrZXk9e3Rvd2VyLmlkfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm9wYWNpdHktNDAgcC0yLjUgcm91bmRlZC0yeGwgYmctc2xhdGUtOTUwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIGZsZXggaXRlbXMtY2VudGVyIHNwYWNlLXgtMiBncmF5c2NhbGUgY3Vyc29yLW5vdC1hbGxvd2VkIHRleHQteHMgc2hyaW5rLTBcIlxuICAgICAgICAgICAgICAgIHRpdGxlPVwi0JfQsNC/0YDQtdGJ0LXQvdC+INCyINGC0LXQutGD0YnQtdC8INC40YHQv9GL0YLQsNC90LjQuCDQvdC10LTQtdC70LhcIlxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgPHNwYW4+8J+aqzwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTUwMCBmb250LWJvbGRcIj57dG93ZXIubmFtZX08L3NwYW4+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKTtcbiAgICAgICAgICB9XG5cbiAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICBrZXk9e3Rvd2VyLmlkfVxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XG4gICAgICAgICAgICAgICAgaWYgKGlzU2VsZWN0ZWQpIHtcbiAgICAgICAgICAgICAgICAgIG9uU2VsZWN0VG93ZXJUb1BsYWNlKG51bGwpO1xuICAgICAgICAgICAgICAgIH0gZWxzZSBpZiAoY2FuQWZmb3JkKSB7XG4gICAgICAgICAgICAgICAgICBvblNlbGVjdFRvd2VyVG9QbGFjZSh0b3dlci5pZCk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICBkaXNhYmxlZD17IWNhbkFmZm9yZCAmJiAhaXNTZWxlY3RlZH1cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcmVsYXRpdmUgZmxleCBpdGVtcy1jZW50ZXIgc3BhY2UteC0yLjUgcHgtMyBweS0yIHJvdW5kZWQtMnhsIGJvcmRlci0yIHRyYW5zaXRpb24tYWxsIHNlbGVjdC1ub25lIHRleHQtbGVmdCBzaHJpbmstMCAke1xuICAgICAgICAgICAgICAgIGlzU2VsZWN0ZWRcbiAgICAgICAgICAgICAgICAgID8gJ2JnLWN5YW4tNTAwLzIwIGJvcmRlci1jeWFuLTQwMCBzaGFkb3ctbGcgc2hhZG93LWN5YW4tNTAwLzI1IHNjYWxlLTEwNSdcbiAgICAgICAgICAgICAgICAgIDogY2FuQWZmb3JkXG4gICAgICAgICAgICAgICAgICA/ICdiZy1zbGF0ZS04MDAvODAgYm9yZGVyLXNsYXRlLTcwMCBob3Zlcjpib3JkZXItY3lhbi01MDAvNTAgaG92ZXI6Ymctc2xhdGUtODAwIGN1cnNvci1wb2ludGVyIGFjdGl2ZTpzY2FsZS05NSdcbiAgICAgICAgICAgICAgICAgIDogJ2JnLXNsYXRlLTkwMC82MCBib3JkZXItc2xhdGUtODAwLzUwIG9wYWNpdHktNDUgY3Vyc29yLW5vdC1hbGxvd2VkJ1xuICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgey8qIEljb24gLyBJbWFnZSAqL31cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSB3LTExIGgtMTEgcm91bmRlZC14bCBiZy1zbGF0ZS05NTAgYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgb3ZlcmZsb3ctaGlkZGVuIHNocmluay0wIHNoYWRvdy1pbm5lclwiPlxuICAgICAgICAgICAgICAgIHt0b3dlci5pbWFnZSA/IChcbiAgICAgICAgICAgICAgICAgIDxpbWcgc3JjPXt0b3dlci5pbWFnZX0gYWx0PXt0b3dlci5uYW1lfSBjbGFzc05hbWU9XCJ3LWZ1bGwgaC1mdWxsIG9iamVjdC1jb3ZlclwiIC8+XG4gICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtMnhsXCI+e3Rvd2VyLmljb259PC9zcGFuPlxuICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAge3Rvd2VyLmlkID09PSAnY2F0JyAmJiAoXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJhYnNvbHV0ZSBib3R0b20tMCByaWdodC0wIHRleHQtWzEwcHhdXCI+8J+Vtu+4jzwvc3Bhbj5cbiAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICB7LyogSW5mbyAqL31cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtaW4tdy1bMTA1cHhdXCI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBzcGFjZS14LTFcIj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtZXh0cmFib2xkIHRleHQteHMgdGV4dC13aGl0ZSB0cnVuY2F0ZSBtYXgtdy1bMTEwcHhdXCI+XG4gICAgICAgICAgICAgICAgICAgIHt0b3dlci5uYW1lfVxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAge3Rvd2VyLmlkID09PSAnY2F0JyAmJiAoXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInB4LTEgcHktMC4yIHRleHQtWzlweF0gZm9udC1ib2xkIGJnLWFtYmVyLTUwMCB0ZXh0LXNsYXRlLTk1MCByb3VuZGVkXCI+XG4gICAgICAgICAgICAgICAgICAgICAg0KXQmNCiXG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICB7dG93ZXIuaWQgPT09ICdtZWNoYV9jYXQnICYmIChcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicHgtMSBweS0wLjIgdGV4dC1bOXB4XSBmb250LWJsYWNrIGJnLXJvc2UtNjAwIHRleHQtd2hpdGUgcm91bmRlZFwiPlxuICAgICAgICAgICAgICAgICAgICAgIE5FV1xuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBzcGFjZS14LTIgdGV4dC1bMTFweF0gbXQtMC41XCI+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LWJsYWNrIHRleHQtZW1lcmFsZC00MDAgZm9udC1tb25vXCI+XG4gICAgICAgICAgICAgICAgICAgICR7dG93ZXIuYmFzZUNvc3R9XG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQwMCB0ZXh0LVsxMHB4XVwiPlxuICAgICAgICAgICAgICAgICAgICB7dG93ZXIudHlwZSA9PT0gJ2Vjb25vbXknID8gKFxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtZW1lcmFsZC00MDAgZm9udC1ib2xkXCI+KyQxMjAv0LI8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgICAgPD5cbiAgICAgICAgICAgICAgICAgICAgICAgINCj0YDQvtC9OiA8YiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTIwMFwiPnt0b3dlci5sZXZlbHNbMF0uZGFtYWdlfTwvYj5cbiAgICAgICAgICAgICAgICAgICAgICA8Lz5cbiAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIHsvKiBTdWJ0YWcgKi99XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB0ZXh0LWN5YW4tNDAwLzgwIGZvbnQtbW9ubyB0cnVuY2F0ZSBtYXgtdy1bMTE1cHhdXCI+XG4gICAgICAgICAgICAgICAgICB7dG93ZXIubGV2ZWxzWzBdLnNwZWNpYWwgfHwgdG93ZXIudGFnbGluZX1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAge2lzU2VsZWN0ZWQgJiYgKFxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImFic29sdXRlIC10b3AtMiAtcmlnaHQtMSBweC0xLjUgcHktMC41IHJvdW5kZWQtZnVsbCBiZy1jeWFuLTQwMCB0ZXh0LXNsYXRlLTk1MCB0ZXh0LVs5cHhdIGZvbnQtYmxhY2sgdXBwZXJjYXNlIHNoYWRvd1wiPlxuICAgICAgICAgICAgICAgICAg0JLRi9Cx0YDQsNC9XG4gICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgKTtcbiAgICAgICAgfSl9XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgKTtcbn07XG4iXX0=