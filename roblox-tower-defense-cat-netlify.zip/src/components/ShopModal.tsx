const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=1e19e0c2";
import confetti from "/node_modules/.vite/deps/canvas-confetti.js?v=601c4ae1";
import { SKINS_DATA } from "/src/data/constants.ts";
import { sounds } from "/src/utils/sound.ts";
var _jsxFileName = "/app/applet/src/components/ShopModal.tsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=1e19e0c2";
export const ShopModal = ({ user, setUser, orders, setOrders, notifications, setNotifications, onClose }) => {
	const [activeTab, setActiveTab] = useState("skins");
	const [selectedPack, setSelectedPack] = useState(null);
	const [paymentMethod, setPaymentMethod] = useState("СБП");
	const [isProcessingPayment, setIsProcessingPayment] = useState(false);
	const [paymentSuccessReceipt, setPaymentSuccessReceipt] = useState(null);
	// Buy Skin with In-Game Currency
	const handleBuySkin = (skin) => {
		const isOwned = user.inventorySkins.includes(skin.id);
		if (isOwned) {
			// Equip Skin
			setUser((prev) => ({
				...prev,
				equippedSkins: {
					...prev.equippedSkins,
					[skin.towerId]: skin.id
				}
			}));
			sounds.playCoin();
			return;
		}
		const costCoins = skin.costCoins || 0;
		const costGems = skin.costGems || 0;
		if (user.coins >= costCoins && user.gems >= costGems) {
			setUser((prev) => ({
				...prev,
				coins: prev.coins - costCoins,
				gems: prev.gems - costGems,
				inventorySkins: [...prev.inventorySkins, skin.id],
				equippedSkins: {
					...prev.equippedSkins,
					[skin.towerId]: skin.id
				}
			}));
			sounds.playVictory();
			confetti({
				particleCount: 50,
				spread: 60
			});
		}
	};
	// Payment Packs for Real Donation / Currency
	const DONATION_PACKS = [
		{
			title: "Горсть Алмазов",
			rub: 99,
			gems: 120,
			robux: 50,
			bonus: "+10% Кешбэк"
		},
		{
			title: "Мешок Кристаллов + Robux",
			rub: 299,
			gems: 450,
			robux: 200,
			bonus: "Популярный"
		},
		{
			title: "Сундук Магната",
			rub: 699,
			gems: 1200,
			robux: 600,
			bonus: "Выгода +35%"
		},
		{
			title: "Королевская Казна",
			rub: 1499,
			gems: 3e3,
			robux: 1500,
			bonus: "VIP Статус"
		}
	];
	// Process Mock Real-World Payment
	const handleExecutePayment = () => {
		if (!selectedPack) return;
		setIsProcessingPayment(true);
		setTimeout(() => {
			setIsProcessingPayment(false);
			const cashback = Math.round(selectedPack.rub * .1);
			const orderNumber = `RBX-${Math.floor(1e3 + Math.random() * 9e3)}-TD`;
			const newOrder = {
				id: "ord_" + Math.random().toString(36).substr(2, 9),
				orderNumber,
				title: selectedPack.title,
				amountRub: selectedPack.rub,
				gemReward: selectedPack.gems,
				robuxReward: selectedPack.robux,
				cashbackEarned: cashback,
				date: "Только что",
				status: "Доставлен",
				paymentMethod
			};
			// Add push notification about order delivery & cashback
			const newNotif = {
				id: "notif_" + Math.random().toString(),
				title: `✅ Заказ ${orderNumber} успешно доставлен!`,
				message: `На ваш баланс зачислено +${selectedPack.gems} 💎, +${selectedPack.robux} R$ и начислен кешбэк +${cashback} баллов!`,
				type: "order",
				timestamp: "Только что",
				read: false,
				badge: "DELIVERED"
			};
			setOrders((prev) => [newOrder, ...prev]);
			setNotifications((prev) => [newNotif, ...prev]);
			setUser((prev) => ({
				...prev,
				gems: prev.gems + selectedPack.gems,
				robux: prev.robux + selectedPack.robux,
				coins: prev.coins + cashback * 5,
				cashbackPoints: prev.cashbackPoints + cashback
			}));
			sounds.playVictory();
			confetti({
				particleCount: 70,
				spread: 80
			});
			setPaymentSuccessReceipt(newOrder);
			setSelectedPack(null);
		}, 1200);
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "fixed inset-0 z-50 flex items-center justify-center bg-slate-950/85 backdrop-blur-md p-4",
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: "bg-slate-900 border-2 border-emerald-500/40 rounded-3xl p-6 max-w-3xl w-full shadow-2xl text-slate-100 max-h-[90vh] flex flex-col",
			children: [
				/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center justify-between pb-4 border-b border-slate-800",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center space-x-3",
						children: [/* @__PURE__ */ _jsxDEV("span", {
							className: "text-3xl",
							children: "🛍️"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 140,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h2", {
							className: "text-xl font-black text-emerald-400",
							children: "Магазин Скинов и Доната"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 142,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("p", {
							className: "text-xs text-slate-400",
							children: "Кастомизация героев, валюта, кешбэк 10% и официальные платежные шлюзы"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 145,
							columnNumber: 15
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 141,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 139,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("button", {
						onClick: onClose,
						className: "w-8 h-8 rounded-full bg-slate-800 hover:bg-slate-700 flex items-center justify-center text-slate-400 hover:text-white",
						children: "✕"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 150,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 138,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center space-x-2 my-4 border-b border-slate-800 pb-2",
					children: [
						/* @__PURE__ */ _jsxDEV("button", {
							onClick: () => setActiveTab("skins"),
							className: `px-4 py-2 rounded-xl text-xs font-bold transition-all ${activeTab === "skins" ? "bg-emerald-500 text-slate-950 shadow-md" : "text-slate-400 hover:text-white hover:bg-slate-800"}`,
							children: "🎭 Магазин Скинов"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 160,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("button", {
							onClick: () => setActiveTab("currency"),
							className: `px-4 py-2 rounded-xl text-xs font-bold transition-all ${activeTab === "currency" ? "bg-emerald-500 text-slate-950 shadow-md" : "text-slate-400 hover:text-white hover:bg-slate-800"}`,
							children: "💎 Покупка Валюты & Robux (+10% Кешбэк)"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 170,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("button", {
							onClick: () => setActiveTab("orders"),
							className: `px-4 py-2 rounded-xl text-xs font-bold transition-all ${activeTab === "orders" ? "bg-emerald-500 text-slate-950 shadow-md" : "text-slate-400 hover:text-white hover:bg-slate-800"}`,
							children: [
								"📜 Личный Кабинет & Чеки (",
								orders.length,
								")"
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 180,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 159,
					columnNumber: 9
				}, this),
				activeTab === "skins" && /* @__PURE__ */ _jsxDEV("div", {
					className: "overflow-y-auto flex-1 pr-1 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3",
					children: SKINS_DATA.map((skin) => {
						const isOwned = user.inventorySkins.includes(skin.id);
						const isEquipped = user.equippedSkins[skin.towerId] === skin.id;
						const canAfford = user.coins >= (skin.costCoins || 0) && user.gems >= (skin.costGems || 0);
						return /* @__PURE__ */ _jsxDEV("div", {
							className: "bg-slate-950/80 border border-slate-800 rounded-2xl p-3 flex flex-col justify-between hover:border-slate-700 transition-all",
							children: [/* @__PURE__ */ _jsxDEV("div", { children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: "relative w-full h-28 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-center overflow-hidden mb-2",
									children: [skin.image ? /* @__PURE__ */ _jsxDEV("img", {
										src: skin.image,
										alt: skin.name,
										className: "w-full h-full object-cover"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 210,
										columnNumber: 25
									}, this) : /* @__PURE__ */ _jsxDEV("span", {
										className: "text-4xl",
										children: "🐱"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 216,
										columnNumber: 25
									}, this), /* @__PURE__ */ _jsxDEV("span", {
										className: "absolute top-2 right-2 text-[10px] font-black px-2 py-0.5 rounded-full uppercase",
										style: {
											backgroundColor: skin.badgeColor,
											color: "#000000"
										},
										children: skin.rarity
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 218,
										columnNumber: 23
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 208,
									columnNumber: 21
								}, this),
								/* @__PURE__ */ _jsxDEV("h4", {
									className: "font-extrabold text-sm text-white",
									children: skin.name
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 226,
									columnNumber: 21
								}, this),
								/* @__PURE__ */ _jsxDEV("p", {
									className: "text-[11px] text-slate-400 mt-0.5 leading-snug",
									children: skin.description
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 227,
									columnNumber: 21
								}, this)
							] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 206,
								columnNumber: 19
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "mt-3 pt-2 border-t border-slate-800/80 flex items-center justify-between",
								children: [/* @__PURE__ */ _jsxDEV("div", { children: !isOwned ? /* @__PURE__ */ _jsxDEV("div", {
									className: "text-xs font-bold space-x-1.5",
									children: [skin.costCoins ? /* @__PURE__ */ _jsxDEV("span", {
										className: "text-amber-400 font-mono",
										children: [skin.costCoins, " 🪙"]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 237,
										columnNumber: 29
									}, this) : null, skin.costGems ? /* @__PURE__ */ _jsxDEV("span", {
										className: "text-cyan-400 font-mono",
										children: [skin.costGems, " 💎"]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 240,
										columnNumber: 29
									}, this) : null]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 235,
									columnNumber: 25
								}, this) : /* @__PURE__ */ _jsxDEV("span", {
									className: "text-xs font-bold text-emerald-400",
									children: "В инвентаре"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 244,
									columnNumber: 25
								}, this) }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 233,
									columnNumber: 21
								}, this), /* @__PURE__ */ _jsxDEV("button", {
									onClick: () => handleBuySkin(skin),
									disabled: !isOwned && !canAfford,
									className: `px-3 py-1.5 rounded-xl text-xs font-black transition-all ${isEquipped ? "bg-slate-800 text-slate-400 border border-slate-700 cursor-default" : isOwned ? "bg-cyan-500 hover:bg-cyan-400 text-slate-950 cursor-pointer" : canAfford ? "bg-emerald-500 hover:bg-emerald-400 text-slate-950 cursor-pointer active:scale-95" : "bg-slate-800 text-slate-500 cursor-not-allowed"}`,
									children: isEquipped ? "Надето ✓" : isOwned ? "Надеть" : "Купить"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 248,
									columnNumber: 21
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 232,
								columnNumber: 19
							}, this)]
						}, skin.id, true, {
							fileName: _jsxFileName,
							lineNumber: 202,
							columnNumber: 17
						}, this);
					})
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 194,
					columnNumber: 11
				}, this),
				activeTab === "currency" && /* @__PURE__ */ _jsxDEV("div", {
					className: "overflow-y-auto flex-1 pr-1 space-y-4",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "p-3.5 bg-gradient-to-r from-emerald-950/60 to-cyan-950/60 border border-emerald-500/40 rounded-2xl flex items-center justify-between",
							children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "text-xs font-black uppercase text-emerald-400",
								children: "🎁 Программа Кешбэка 10%"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 276,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("p", {
								className: "text-xs text-slate-300",
								children: "Возврат 10% от каждой суммы покупки на ваш бонусный счет в виде дополнительных монет!"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 279,
								columnNumber: 17
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 275,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "text-right",
								children: [/* @__PURE__ */ _jsxDEV("span", {
									className: "text-xs text-slate-400",
									children: "Ваш Кешбэк:"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 284,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "text-base font-black text-amber-300 font-mono",
									children: [user.cashbackPoints, " баллов"]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 285,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 283,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 274,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "grid grid-cols-1 sm:grid-cols-2 gap-3",
							children: DONATION_PACKS.map((pack, idx) => /* @__PURE__ */ _jsxDEV("div", {
								className: "bg-slate-950/70 border border-slate-800 hover:border-emerald-500/50 rounded-2xl p-4 flex flex-col justify-between",
								children: [
									/* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-start justify-between",
										children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
											className: "text-[10px] font-bold uppercase px-2 py-0.5 rounded-full bg-emerald-950 text-emerald-400 border border-emerald-700/50",
											children: pack.bonus
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 300,
											columnNumber: 23
										}, this), /* @__PURE__ */ _jsxDEV("h4", {
											className: "font-extrabold text-sm text-white mt-1.5",
											children: pack.title
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 303,
											columnNumber: 23
										}, this)] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 299,
											columnNumber: 21
										}, this), /* @__PURE__ */ _jsxDEV("span", {
											className: "text-2xl",
											children: "💎"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 305,
											columnNumber: 21
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 298,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "my-3 space-y-1 font-mono text-xs",
										children: [
											/* @__PURE__ */ _jsxDEV("div", {
												className: "text-cyan-400 font-bold",
												children: [
													"+",
													pack.gems,
													" Кристаллов"
												]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 309,
												columnNumber: 21
											}, this),
											/* @__PURE__ */ _jsxDEV("div", {
												className: "text-emerald-400 font-bold",
												children: [
													"+",
													pack.robux,
													" Robux (R$)"
												]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 310,
												columnNumber: 21
											}, this),
											/* @__PURE__ */ _jsxDEV("div", {
												className: "text-amber-400 text-[11px]",
												children: [
													"Кешбэк: +",
													Math.round(pack.rub * .1),
													" баллов"
												]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 311,
												columnNumber: 21
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 308,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("button", {
										onClick: () => setSelectedPack(pack),
										className: "w-full py-2 bg-emerald-500 hover:bg-emerald-400 text-slate-950 rounded-xl font-black text-xs transition-transform active:scale-95 shadow-md flex items-center justify-center space-x-1",
										children: /* @__PURE__ */ _jsxDEV("span", { children: [
											"Купить за ",
											pack.rub,
											" ₽"
										] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 320,
											columnNumber: 21
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 316,
										columnNumber: 19
									}, this)
								]
							}, idx, true, {
								fileName: _jsxFileName,
								lineNumber: 294,
								columnNumber: 17
							}, this))
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 292,
							columnNumber: 13
						}, this),
						selectedPack && /* @__PURE__ */ _jsxDEV("div", {
							className: "p-4 bg-slate-950 border-2 border-emerald-400 rounded-2xl space-y-3",
							children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center justify-between border-b border-slate-800 pb-2",
									children: [/* @__PURE__ */ _jsxDEV("h4", {
										className: "font-black text-sm text-white",
										children: [
											"Оформление заказа: ",
											selectedPack.title,
											" (",
											selectedPack.rub,
											" ₽)"
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 330,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("button", {
										onClick: () => setSelectedPack(null),
										className: "text-xs text-slate-400 hover:text-white",
										children: "Отмена"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 333,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 329,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "space-y-1.5",
									children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "text-xs font-bold text-slate-400",
										children: "Выберите платежную систему:"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 342,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "grid grid-cols-2 sm:grid-cols-4 gap-2",
										children: [
											{
												id: "СБП",
												label: "СБП (QR-код)",
												icon: "⚡"
											},
											{
												id: "Карта МИР",
												label: "Банк. Карта",
												icon: "💳"
											},
											{
												id: "ЮMoney",
												label: "ЮMoney",
												icon: "🟣"
											},
											{
												id: "Crypto",
												label: "Crypto (TON)",
												icon: "🪙"
											}
										].map((method) => /* @__PURE__ */ _jsxDEV("button", {
											onClick: () => setPaymentMethod(method.id),
											className: `p-2 rounded-xl border text-xs font-bold flex items-center space-x-1.5 ${paymentMethod === method.id ? "bg-emerald-950/80 border-emerald-400 text-emerald-300" : "bg-slate-900 border-slate-800 text-slate-400 hover:text-white"}`,
											children: [/* @__PURE__ */ _jsxDEV("span", { children: method.icon }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 363,
												columnNumber: 25
											}, this), /* @__PURE__ */ _jsxDEV("span", { children: method.label }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 364,
												columnNumber: 25
											}, this)]
										}, method.id, true, {
											fileName: _jsxFileName,
											lineNumber: 354,
											columnNumber: 23
										}, this))
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 345,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 341,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "pt-2 flex items-center justify-between",
									children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "text-xs text-slate-400",
										children: "Безопасный эквайринг с SSL-шифрованием"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 371,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("button", {
										onClick: handleExecutePayment,
										disabled: isProcessingPayment,
										className: "px-5 py-2 bg-gradient-to-r from-emerald-500 to-green-600 hover:from-emerald-400 hover:to-green-500 text-slate-950 font-black rounded-xl text-xs transition-transform active:scale-95 shadow-lg flex items-center space-x-2",
										children: isProcessingPayment ? /* @__PURE__ */ _jsxDEV("span", { children: "Обработка платежа..." }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 380,
											columnNumber: 23
										}, this) : /* @__PURE__ */ _jsxDEV("span", { children: [
											"Оплатить ",
											selectedPack.rub,
											" ₽"
										] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 382,
											columnNumber: 23
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 374,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 370,
									columnNumber: 17
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 328,
							columnNumber: 15
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 272,
					columnNumber: 11
				}, this),
				activeTab === "orders" && /* @__PURE__ */ _jsxDEV("div", {
					className: "overflow-y-auto flex-1 pr-1 space-y-3",
					children: orders.length === 0 ? /* @__PURE__ */ _jsxDEV("div", {
						className: "p-8 text-center text-slate-500 text-xs",
						children: "У вас пока нет оформленных заказов"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 395,
						columnNumber: 15
					}, this) : orders.map((ord) => /* @__PURE__ */ _jsxDEV("div", {
						className: "p-3.5 bg-slate-950/80 border border-slate-800 rounded-2xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3",
						children: [/* @__PURE__ */ _jsxDEV("div", { children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center space-x-2",
								children: [/* @__PURE__ */ _jsxDEV("span", {
									className: "font-mono text-xs font-bold text-slate-400",
									children: ["#", ord.orderNumber]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 406,
									columnNumber: 23
								}, this), /* @__PURE__ */ _jsxDEV("span", {
									className: "px-2 py-0.5 rounded-full text-[10px] font-black bg-emerald-950 text-emerald-400 border border-emerald-700/50",
									children: ord.status
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 409,
									columnNumber: 23
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 405,
								columnNumber: 21
							}, this),
							/* @__PURE__ */ _jsxDEV("h4", {
								className: "font-extrabold text-sm text-white mt-1",
								children: ord.title
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 413,
								columnNumber: 21
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "text-[11px] text-slate-400 mt-0.5 font-mono",
								children: [
									"Оплата: ",
									ord.paymentMethod,
									" • ",
									ord.date
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 414,
								columnNumber: 21
							}, this)
						] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 404,
							columnNumber: 19
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "text-right sm:border-l sm:border-slate-800 sm:pl-4",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "font-black text-sm text-white font-mono",
								children: [ord.amountRub, " ₽"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 420,
								columnNumber: 21
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "text-xs text-amber-400 font-bold font-mono",
								children: [
									"+",
									ord.cashbackEarned,
									" кешбэк"
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 421,
								columnNumber: 21
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 419,
							columnNumber: 19
						}, this)]
					}, ord.id, true, {
						fileName: _jsxFileName,
						lineNumber: 400,
						columnNumber: 17
					}, this))
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 393,
					columnNumber: 11
				}, this),
				paymentSuccessReceipt && /* @__PURE__ */ _jsxDEV("div", {
					className: "mt-3 p-3 bg-emerald-950/80 border border-emerald-500 rounded-2xl flex items-center justify-between text-xs text-emerald-300",
					children: [/* @__PURE__ */ _jsxDEV("span", { children: [
						"🎉 Чек #",
						paymentSuccessReceipt.orderNumber,
						" оплачен! Начислено: +",
						paymentSuccessReceipt.gemReward,
						" 💎, +",
						paymentSuccessReceipt.robuxReward,
						" R$"
					] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 434,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("button", {
						onClick: () => setPaymentSuccessReceipt(null),
						className: "text-white font-bold ml-2 underline cursor-pointer",
						children: "OK"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 438,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 433,
					columnNumber: 11
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 136,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 135,
		columnNumber: 5
	}, this);
};

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLGdCQUFnQjtBQUNoQyxPQUFPLGNBQWM7QUFFckIsU0FBUyxrQkFBaUM7QUFDMUMsU0FBUyxjQUFjOzs7QUFZdkIsT0FBTyxNQUFNLGFBQXVDLEVBQ2xELE1BQ0EsU0FDQSxRQUNBLFdBQ0EsZUFDQSxrQkFDQSxjQUNJO0NBQ0osTUFBTSxDQUFDLFdBQVcsZ0JBQWdCLFNBQTBDLE9BQU87Q0FDbkYsTUFBTSxDQUFDLGNBQWMsbUJBQW1CLFNBSzlCLElBQUk7Q0FFZCxNQUFNLENBQUMsZUFBZSxvQkFBb0IsU0FBa0UsS0FBSztDQUNqSCxNQUFNLENBQUMscUJBQXFCLDBCQUEwQixTQUFTLEtBQUs7Q0FDcEUsTUFBTSxDQUFDLHVCQUF1Qiw0QkFBNEIsU0FBMkIsSUFBSTs7Q0FHekYsTUFBTSxpQkFBaUIsU0FBZTtFQUNwQyxNQUFNLFVBQVUsS0FBSyxlQUFlLFNBQVMsS0FBSyxFQUFFO0VBQ3BELElBQUksU0FBUzs7R0FFWCxTQUFTLFVBQVU7SUFDakIsR0FBRztJQUNILGVBQWU7S0FDYixHQUFHLEtBQUs7TUFDUCxLQUFLLFVBQVUsS0FBSztJQUN2QjtHQUNGLEVBQUU7R0FDRixPQUFPLFNBQVM7R0FDaEI7RUFDRjtFQUVBLE1BQU0sWUFBWSxLQUFLLGFBQWE7RUFDcEMsTUFBTSxXQUFXLEtBQUssWUFBWTtFQUVsQyxJQUFJLEtBQUssU0FBUyxhQUFhLEtBQUssUUFBUSxVQUFVO0dBQ3BELFNBQVMsVUFBVTtJQUNqQixHQUFHO0lBQ0gsT0FBTyxLQUFLLFFBQVE7SUFDcEIsTUFBTSxLQUFLLE9BQU87SUFDbEIsZ0JBQWdCLENBQUMsR0FBRyxLQUFLLGdCQUFnQixLQUFLLEVBQUU7SUFDaEQsZUFBZTtLQUNiLEdBQUcsS0FBSztNQUNQLEtBQUssVUFBVSxLQUFLO0lBQ3ZCO0dBQ0YsRUFBRTtHQUNGLE9BQU8sWUFBWTtHQUNuQixTQUFTO0lBQUUsZUFBZTtJQUFJLFFBQVE7R0FBRyxDQUFDO0VBQzVDO0NBQ0Y7O0NBR0EsTUFBTSxpQkFBaUI7RUFDckI7R0FBRSxPQUFPO0dBQWtCLEtBQUs7R0FBSSxNQUFNO0dBQUssT0FBTztHQUFJLE9BQU87RUFBYztFQUMvRTtHQUFFLE9BQU87R0FBNEIsS0FBSztHQUFLLE1BQU07R0FBSyxPQUFPO0dBQUssT0FBTztFQUFhO0VBQzFGO0dBQUUsT0FBTztHQUFrQixLQUFLO0dBQUssTUFBTTtHQUFNLE9BQU87R0FBSyxPQUFPO0VBQWM7RUFDbEY7R0FBRSxPQUFPO0dBQXFCLEtBQUs7R0FBTSxNQUFNO0dBQU0sT0FBTztHQUFNLE9BQU87RUFBYTtDQUN4Rjs7Q0FHQSxNQUFNLDZCQUE2QjtFQUNqQyxJQUFJLENBQUMsY0FBYztFQUNuQix1QkFBdUIsSUFBSTtFQUUzQixpQkFBaUI7R0FDZix1QkFBdUIsS0FBSztHQUU1QixNQUFNLFdBQVcsS0FBSyxNQUFNLGFBQWEsTUFBTSxFQUFHO0dBQ2xELE1BQU0sY0FBYyxPQUFPLEtBQUssTUFBTSxNQUFPLEtBQUssT0FBTyxJQUFJLEdBQUksRUFBRTtHQUVuRSxNQUFNLFdBQXNCO0lBQzFCLElBQUksU0FBUyxLQUFLLE9BQU8sQ0FBQyxDQUFDLFNBQVMsRUFBRSxDQUFDLENBQUMsT0FBTyxHQUFHLENBQUM7SUFDbkQ7SUFDQSxPQUFPLGFBQWE7SUFDcEIsV0FBVyxhQUFhO0lBQ3hCLFdBQVcsYUFBYTtJQUN4QixhQUFhLGFBQWE7SUFDMUIsZ0JBQWdCO0lBQ2hCLE1BQU07SUFDTixRQUFRO0lBQ1I7R0FDRjs7R0FHQSxNQUFNLFdBQStCO0lBQ25DLElBQUksV0FBVyxLQUFLLE9BQU8sQ0FBQyxDQUFDLFNBQVM7SUFDdEMsT0FBTyxXQUFXLFlBQVk7SUFDOUIsU0FBUyw0QkFBNEIsYUFBYSxLQUFLLFFBQVEsYUFBYSxNQUFNLHlCQUF5QixTQUFTO0lBQ3BILE1BQU07SUFDTixXQUFXO0lBQ1gsTUFBTTtJQUNOLE9BQU87R0FDVDtHQUVBLFdBQVcsU0FBUyxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUM7R0FDdkMsa0JBQWtCLFNBQVMsQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDO0dBRTlDLFNBQVMsVUFBVTtJQUNqQixHQUFHO0lBQ0gsTUFBTSxLQUFLLE9BQU8sYUFBYTtJQUMvQixPQUFPLEtBQUssUUFBUSxhQUFhO0lBQ2pDLE9BQU8sS0FBSyxRQUFRLFdBQVc7SUFDL0IsZ0JBQWdCLEtBQUssaUJBQWlCO0dBQ3hDLEVBQUU7R0FFRixPQUFPLFlBQVk7R0FDbkIsU0FBUztJQUFFLGVBQWU7SUFBSSxRQUFRO0dBQUcsQ0FBQztHQUMxQyx5QkFBeUIsUUFBUTtHQUNqQyxnQkFBZ0IsSUFBSTtFQUN0QixHQUFHLElBQUk7Q0FDVDtDQUVBLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFDYix3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFmO0lBRUUsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsUUFBRDtPQUFNLFdBQVU7aUJBQVc7TUFBUzs7OztnQkFDcEMsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLE1BQUQ7T0FBSSxXQUFVO2lCQUFzQztNQUVoRDs7OztnQkFDSix3QkFBQyxLQUFEO09BQUcsV0FBVTtpQkFBeUI7TUFFbkM7Ozs7Y0FDQTs7OztjQUNGOzs7OztlQUNMLHdCQUFDLFVBQUQ7TUFDRSxTQUFTO01BQ1QsV0FBVTtnQkFDWDtLQUVPOzs7O2FBQ0w7Ozs7OztJQUdMLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWY7TUFDRSx3QkFBQyxVQUFEO09BQ0UsZUFBZSxhQUFhLE9BQU87T0FDbkMsV0FBVyx5REFDVCxjQUFjLFVBQ1YsNENBQ0E7aUJBRVA7TUFFTzs7Ozs7TUFDUix3QkFBQyxVQUFEO09BQ0UsZUFBZSxhQUFhLFVBQVU7T0FDdEMsV0FBVyx5REFDVCxjQUFjLGFBQ1YsNENBQ0E7aUJBRVA7TUFFTzs7Ozs7TUFDUix3QkFBQyxVQUFEO09BQ0UsZUFBZSxhQUFhLFFBQVE7T0FDcEMsV0FBVyx5REFDVCxjQUFjLFdBQ1YsNENBQ0E7aUJBTFI7UUFPQztRQUM0QixPQUFPO1FBQU87T0FDbkM7Ozs7OztLQUNMOzs7Ozs7SUFHSixjQUFjLFdBQ2Isd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFDWixXQUFXLEtBQUssU0FBUztNQUN4QixNQUFNLFVBQVUsS0FBSyxlQUFlLFNBQVMsS0FBSyxFQUFFO01BQ3BELE1BQU0sYUFBYSxLQUFLLGNBQWMsS0FBSyxhQUFhLEtBQUs7TUFDN0QsTUFBTSxZQUNKLEtBQUssVUFBVSxLQUFLLGFBQWEsTUFBTSxLQUFLLFNBQVMsS0FBSyxZQUFZO01BRXhFLE9BQ0Usd0JBQUMsT0FBRDtPQUVFLFdBQVU7aUJBRlosQ0FJRSx3QkFBQyxPQUFEO1FBRUUsd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FDRyxLQUFLLFFBQ0osd0JBQUMsT0FBRDtVQUNFLEtBQUssS0FBSztVQUNWLEtBQUssS0FBSztVQUNWLFdBQVU7U0FDWDs7OztvQkFFRCx3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBVztTQUFROzs7O21CQUVyQyx3QkFBQyxRQUFEO1VBQ0UsV0FBVTtVQUNWLE9BQU87V0FBRSxpQkFBaUIsS0FBSztXQUFZLE9BQU87VUFBVTtvQkFFM0QsS0FBSztTQUNGOzs7O2lCQUNIOzs7Ozs7UUFFTCx3QkFBQyxNQUFEO1NBQUksV0FBVTttQkFBcUMsS0FBSztRQUFTOzs7OztRQUNqRSx3QkFBQyxLQUFEO1NBQUcsV0FBVTttQkFDVixLQUFLO1FBQ0w7Ozs7O09BQ0E7Ozs7aUJBRUwsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxPQUFELFlBQ0csQ0FBQyxVQUNBLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0csS0FBSyxZQUNKLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUFoQixDQUE0QyxLQUFLLFdBQVUsS0FBUzs7Ozs7b0JBQ2xFLE1BQ0gsS0FBSyxXQUNKLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUFoQixDQUEyQyxLQUFLLFVBQVMsS0FBUzs7Ozs7b0JBQ2hFLElBQ0Q7Ozs7O21CQUVMLHdCQUFDLFFBQUQ7U0FBTSxXQUFVO21CQUFxQztRQUFpQjs7OztpQkFFckU7Ozs7a0JBRUwsd0JBQUMsVUFBRDtTQUNFLGVBQWUsY0FBYyxJQUFJO1NBQ2pDLFVBQVUsQ0FBQyxXQUFXLENBQUM7U0FDdkIsV0FBVyw0REFDVCxhQUNJLHVFQUNBLFVBQ0EsZ0VBQ0EsWUFDQSxzRkFDQTttQkFHTCxhQUFhLGFBQWEsVUFBVSxXQUFXO1FBQzFDOzs7O2dCQUNMOzs7OztlQUNGO1NBN0RFLEtBQUs7Ozs7YUE2RFA7S0FFVCxDQUFDO0lBQ0U7Ozs7O0lBSU4sY0FBYyxjQUNiLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWY7TUFFRSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBZ0Q7T0FFMUQ7Ozs7aUJBQ04sd0JBQUMsS0FBRDtRQUFHLFdBQVU7a0JBQXlCO09BRW5DOzs7O2VBQ0E7Ozs7aUJBQ0wsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxRQUFEO1NBQU0sV0FBVTttQkFBeUI7UUFBaUI7Ozs7a0JBQzFELHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0csS0FBSyxnQkFBZSxTQUNsQjs7Ozs7Z0JBQ0Y7Ozs7O2VBQ0Y7Ozs7OztNQUdMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUNaLGVBQWUsS0FBSyxNQUFNLFFBQ3pCLHdCQUFDLE9BQUQ7UUFFRSxXQUFVO2tCQUZaO1NBSUUsd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWYsQ0FDRSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsUUFBRDtXQUFNLFdBQVU7cUJBQ2IsS0FBSztVQUNGOzs7O29CQUNOLHdCQUFDLE1BQUQ7V0FBSSxXQUFVO3FCQUE0QyxLQUFLO1VBQVU7Ozs7a0JBQ3RFOzs7O29CQUNMLHdCQUFDLFFBQUQ7V0FBTSxXQUFVO3FCQUFXO1VBQVE7Ozs7a0JBQ2hDOzs7Ozs7U0FFTCx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZjtXQUNFLHdCQUFDLE9BQUQ7WUFBSyxXQUFVO3NCQUFmO2FBQXlDO2FBQUUsS0FBSzthQUFLO1lBQWdCOzs7Ozs7V0FDckUsd0JBQUMsT0FBRDtZQUFLLFdBQVU7c0JBQWY7YUFBNEM7YUFBRSxLQUFLO2FBQU07WUFBZ0I7Ozs7OztXQUN6RSx3QkFBQyxPQUFEO1lBQUssV0FBVTtzQkFBZjthQUE0QzthQUNoQyxLQUFLLE1BQU0sS0FBSyxNQUFNLEVBQUc7YUFBRTtZQUNsQzs7Ozs7O1VBQ0Y7Ozs7OztTQUVMLHdCQUFDLFVBQUQ7VUFDRSxlQUFlLGdCQUFnQixJQUFJO1VBQ25DLFdBQVU7b0JBRVYsd0JBQUMsUUFBRDtXQUFNO1dBQVcsS0FBSztXQUFJO1VBQVE7Ozs7O1NBQzVCOzs7OztRQUNMO1VBM0JFOzs7O2NBMkJGLENBQ047TUFDRTs7Ozs7TUFHSixnQkFDQyx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZjtRQUNFLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0Usd0JBQUMsTUFBRDtVQUFJLFdBQVU7b0JBQWQ7V0FBOEM7V0FDeEIsYUFBYTtXQUFNO1dBQUcsYUFBYTtXQUFJO1VBQ3pEOzs7OzttQkFDSix3QkFBQyxVQUFEO1VBQ0UsZUFBZSxnQkFBZ0IsSUFBSTtVQUNuQyxXQUFVO29CQUNYO1NBRU87Ozs7aUJBQ0w7Ozs7OztRQUVMLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0Usd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQW1DO1NBRTdDOzs7O21CQUNOLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUVYO1dBQ0U7WUFBRSxJQUFJO1lBQU8sT0FBTztZQUFnQixNQUFNO1dBQUk7V0FDOUM7WUFBRSxJQUFJO1lBQWEsT0FBTztZQUFlLE1BQU07V0FBSztXQUNwRDtZQUFFLElBQUk7WUFBVSxPQUFPO1lBQVUsTUFBTTtXQUFLO1dBQzVDO1lBQUUsSUFBSTtZQUFVLE9BQU87WUFBZ0IsTUFBTTtXQUFLO1VBQ3BELENBQUMsQ0FDRCxLQUFLLFdBQ0wsd0JBQUMsVUFBRDtXQUVFLGVBQWUsaUJBQWlCLE9BQU8sRUFBRTtXQUN6QyxXQUFXLHlFQUNULGtCQUFrQixPQUFPLEtBQ3JCLDBEQUNBO3FCQU5SLENBU0Usd0JBQUMsUUFBRCxZQUFPLE9BQU8sS0FBVzs7OztxQkFDekIsd0JBQUMsUUFBRCxZQUFPLE9BQU8sTUFBWTs7OzttQkFDcEI7YUFWRCxPQUFPOzs7O2lCQVVOLENBQ1Q7U0FDRTs7OztpQkFDRjs7Ozs7O1FBRUwsd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FDRSx3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBeUI7U0FFbkM7Ozs7bUJBQ04sd0JBQUMsVUFBRDtVQUNFLFNBQVM7VUFDVCxVQUFVO1VBQ1YsV0FBVTtvQkFFVCxzQkFDQyx3QkFBQyxRQUFELFlBQU0sdUJBQTBCOzs7O3FCQUVoQyx3QkFBQyxRQUFEO1dBQU07V0FBVSxhQUFhO1dBQUk7VUFBUTs7Ozs7U0FFckM7Ozs7aUJBQ0w7Ozs7OztPQUNGOzs7Ozs7S0FFSjs7Ozs7O0lBSU4sY0FBYyxZQUNiLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQ1osT0FBTyxXQUFXLElBQ2pCLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUF5QztLQUVuRDs7OztnQkFFTCxPQUFPLEtBQUssUUFDVix3QkFBQyxPQUFEO01BRUUsV0FBVTtnQkFGWixDQUlFLHdCQUFDLE9BQUQ7T0FDRSx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLFFBQUQ7U0FBTSxXQUFVO21CQUFoQixDQUE2RCxLQUN6RCxJQUFJLFdBQ0Y7Ozs7O2tCQUNOLHdCQUFDLFFBQUQ7U0FBTSxXQUFVO21CQUNiLElBQUk7UUFDRDs7OztnQkFDSDs7Ozs7O09BQ0wsd0JBQUMsTUFBRDtRQUFJLFdBQVU7a0JBQTBDLElBQUk7T0FBVTs7Ozs7T0FDdEUsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWY7U0FBNkQ7U0FDbEQsSUFBSTtTQUFjO1NBQVMsSUFBSTtRQUNyQzs7Ozs7O01BQ0Y7Ozs7Z0JBRUwsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUEwRCxJQUFJLFdBQVUsSUFBTzs7Ozs7aUJBQy9FLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmO1NBQTREO1NBQ3hELElBQUk7U0FBZTtRQUNsQjs7Ozs7ZUFDRjs7Ozs7Y0FDRjtRQXhCRSxJQUFJOzs7O1lBd0JOLENBQ047SUFFQTs7Ozs7SUFJTix5QkFDQyx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsUUFBRDtNQUFNO01BQ0ssc0JBQXNCO01BQVk7TUFDMUMsc0JBQXNCO01BQVU7TUFBTyxzQkFBc0I7TUFBWTtLQUN0RTs7OztlQUNOLHdCQUFDLFVBQUQ7TUFDRSxlQUFlLHlCQUF5QixJQUFJO01BQzVDLFdBQVU7Z0JBQ1g7S0FFTzs7OzthQUNMOzs7Ozs7R0FFSjs7Ozs7O0NBQ0Y7Ozs7O0FBRVQiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiU2hvcE1vZGFsLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgY29uZmV0dGkgZnJvbSAnY2FudmFzLWNvbmZldHRpJztcbmltcG9ydCB7IFVzZXJQcm9maWxlLCBPcmRlckl0ZW0sIFNraW4sIEluR2FtZU5vdGlmaWNhdGlvbiB9IGZyb20gJy4uL3R5cGVzL2dhbWUnO1xuaW1wb3J0IHsgU0tJTlNfREFUQSwgQ0FUX0lNQUdFX1VSTCB9IGZyb20gJy4uL2RhdGEvY29uc3RhbnRzJztcbmltcG9ydCB7IHNvdW5kcyB9IGZyb20gJy4uL3V0aWxzL3NvdW5kJztcblxuaW50ZXJmYWNlIFNob3BNb2RhbFByb3BzIHtcbiAgdXNlcjogVXNlclByb2ZpbGU7XG4gIHNldFVzZXI6IFJlYWN0LkRpc3BhdGNoPFJlYWN0LlNldFN0YXRlQWN0aW9uPFVzZXJQcm9maWxlPj47XG4gIG9yZGVyczogT3JkZXJJdGVtW107XG4gIHNldE9yZGVyczogUmVhY3QuRGlzcGF0Y2g8UmVhY3QuU2V0U3RhdGVBY3Rpb248T3JkZXJJdGVtW10+PjtcbiAgbm90aWZpY2F0aW9uczogSW5HYW1lTm90aWZpY2F0aW9uW107XG4gIHNldE5vdGlmaWNhdGlvbnM6IFJlYWN0LkRpc3BhdGNoPFJlYWN0LlNldFN0YXRlQWN0aW9uPEluR2FtZU5vdGlmaWNhdGlvbltdPj47XG4gIG9uQ2xvc2U6ICgpID0+IHZvaWQ7XG59XG5cbmV4cG9ydCBjb25zdCBTaG9wTW9kYWw6IFJlYWN0LkZDPFNob3BNb2RhbFByb3BzPiA9ICh7XG4gIHVzZXIsXG4gIHNldFVzZXIsXG4gIG9yZGVycyxcbiAgc2V0T3JkZXJzLFxuICBub3RpZmljYXRpb25zLFxuICBzZXROb3RpZmljYXRpb25zLFxuICBvbkNsb3NlLFxufSkgPT4ge1xuICBjb25zdCBbYWN0aXZlVGFiLCBzZXRBY3RpdmVUYWJdID0gdXNlU3RhdGU8J3NraW5zJyB8ICdjdXJyZW5jeScgfCAnb3JkZXJzJz4oJ3NraW5zJyk7XG4gIGNvbnN0IFtzZWxlY3RlZFBhY2ssIHNldFNlbGVjdGVkUGFja10gPSB1c2VTdGF0ZTx7XG4gICAgdGl0bGU6IHN0cmluZztcbiAgICBydWI6IG51bWJlcjtcbiAgICBnZW1zOiBudW1iZXI7XG4gICAgcm9idXg6IG51bWJlcjtcbiAgfSB8IG51bGw+KG51bGwpO1xuXG4gIGNvbnN0IFtwYXltZW50TWV0aG9kLCBzZXRQYXltZW50TWV0aG9kXSA9IHVzZVN0YXRlPCfQodCR0J8nIHwgJ9Ca0LDRgNGC0LAg0JzQmNCgJyB8ICfQrk1vbmV5JyB8ICdSb2J1eCBQYXknIHwgJ0NyeXB0byc+KCfQodCR0J8nKTtcbiAgY29uc3QgW2lzUHJvY2Vzc2luZ1BheW1lbnQsIHNldElzUHJvY2Vzc2luZ1BheW1lbnRdID0gdXNlU3RhdGUoZmFsc2UpO1xuICBjb25zdCBbcGF5bWVudFN1Y2Nlc3NSZWNlaXB0LCBzZXRQYXltZW50U3VjY2Vzc1JlY2VpcHRdID0gdXNlU3RhdGU8T3JkZXJJdGVtIHwgbnVsbD4obnVsbCk7XG5cbiAgLy8gQnV5IFNraW4gd2l0aCBJbi1HYW1lIEN1cnJlbmN5XG4gIGNvbnN0IGhhbmRsZUJ1eVNraW4gPSAoc2tpbjogU2tpbikgPT4ge1xuICAgIGNvbnN0IGlzT3duZWQgPSB1c2VyLmludmVudG9yeVNraW5zLmluY2x1ZGVzKHNraW4uaWQpO1xuICAgIGlmIChpc093bmVkKSB7XG4gICAgICAvLyBFcXVpcCBTa2luXG4gICAgICBzZXRVc2VyKChwcmV2KSA9PiAoe1xuICAgICAgICAuLi5wcmV2LFxuICAgICAgICBlcXVpcHBlZFNraW5zOiB7XG4gICAgICAgICAgLi4ucHJldi5lcXVpcHBlZFNraW5zLFxuICAgICAgICAgIFtza2luLnRvd2VySWRdOiBza2luLmlkLFxuICAgICAgICB9LFxuICAgICAgfSkpO1xuICAgICAgc291bmRzLnBsYXlDb2luKCk7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgY29uc3QgY29zdENvaW5zID0gc2tpbi5jb3N0Q29pbnMgfHwgMDtcbiAgICBjb25zdCBjb3N0R2VtcyA9IHNraW4uY29zdEdlbXMgfHwgMDtcblxuICAgIGlmICh1c2VyLmNvaW5zID49IGNvc3RDb2lucyAmJiB1c2VyLmdlbXMgPj0gY29zdEdlbXMpIHtcbiAgICAgIHNldFVzZXIoKHByZXYpID0+ICh7XG4gICAgICAgIC4uLnByZXYsXG4gICAgICAgIGNvaW5zOiBwcmV2LmNvaW5zIC0gY29zdENvaW5zLFxuICAgICAgICBnZW1zOiBwcmV2LmdlbXMgLSBjb3N0R2VtcyxcbiAgICAgICAgaW52ZW50b3J5U2tpbnM6IFsuLi5wcmV2LmludmVudG9yeVNraW5zLCBza2luLmlkXSxcbiAgICAgICAgZXF1aXBwZWRTa2luczoge1xuICAgICAgICAgIC4uLnByZXYuZXF1aXBwZWRTa2lucyxcbiAgICAgICAgICBbc2tpbi50b3dlcklkXTogc2tpbi5pZCxcbiAgICAgICAgfSxcbiAgICAgIH0pKTtcbiAgICAgIHNvdW5kcy5wbGF5VmljdG9yeSgpO1xuICAgICAgY29uZmV0dGkoeyBwYXJ0aWNsZUNvdW50OiA1MCwgc3ByZWFkOiA2MCB9KTtcbiAgICB9XG4gIH07XG5cbiAgLy8gUGF5bWVudCBQYWNrcyBmb3IgUmVhbCBEb25hdGlvbiAvIEN1cnJlbmN5XG4gIGNvbnN0IERPTkFUSU9OX1BBQ0tTID0gW1xuICAgIHsgdGl0bGU6ICfQk9C+0YDRgdGC0Ywg0JDQu9C80LDQt9C+0LInLCBydWI6IDk5LCBnZW1zOiAxMjAsIHJvYnV4OiA1MCwgYm9udXM6ICcrMTAlINCa0LXRiNCx0Y3QuicgfSxcbiAgICB7IHRpdGxlOiAn0JzQtdGI0L7QuiDQmtGA0LjRgdGC0LDQu9C70L7QsiArIFJvYnV4JywgcnViOiAyOTksIGdlbXM6IDQ1MCwgcm9idXg6IDIwMCwgYm9udXM6ICfQn9C+0L/Rg9C70Y/RgNC90YvQuScgfSxcbiAgICB7IHRpdGxlOiAn0KHRg9C90LTRg9C6INCc0LDQs9C90LDRgtCwJywgcnViOiA2OTksIGdlbXM6IDEyMDAsIHJvYnV4OiA2MDAsIGJvbnVzOiAn0JLRi9Cz0L7QtNCwICszNSUnIH0sXG4gICAgeyB0aXRsZTogJ9Ca0L7RgNC+0LvQtdCy0YHQutCw0Y8g0JrQsNC30L3QsCcsIHJ1YjogMTQ5OSwgZ2VtczogMzAwMCwgcm9idXg6IDE1MDAsIGJvbnVzOiAnVklQINCh0YLQsNGC0YPRgScgfSxcbiAgXTtcblxuICAvLyBQcm9jZXNzIE1vY2sgUmVhbC1Xb3JsZCBQYXltZW50XG4gIGNvbnN0IGhhbmRsZUV4ZWN1dGVQYXltZW50ID0gKCkgPT4ge1xuICAgIGlmICghc2VsZWN0ZWRQYWNrKSByZXR1cm47XG4gICAgc2V0SXNQcm9jZXNzaW5nUGF5bWVudCh0cnVlKTtcblxuICAgIHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgc2V0SXNQcm9jZXNzaW5nUGF5bWVudChmYWxzZSk7XG5cbiAgICAgIGNvbnN0IGNhc2hiYWNrID0gTWF0aC5yb3VuZChzZWxlY3RlZFBhY2sucnViICogMC4xKTsgLy8gMTAlIGNhc2hiYWNrXG4gICAgICBjb25zdCBvcmRlck51bWJlciA9IGBSQlgtJHtNYXRoLmZsb29yKDEwMDAgKyBNYXRoLnJhbmRvbSgpICogOTAwMCl9LVREYDtcblxuICAgICAgY29uc3QgbmV3T3JkZXI6IE9yZGVySXRlbSA9IHtcbiAgICAgICAgaWQ6ICdvcmRfJyArIE1hdGgucmFuZG9tKCkudG9TdHJpbmcoMzYpLnN1YnN0cigyLCA5KSxcbiAgICAgICAgb3JkZXJOdW1iZXIsXG4gICAgICAgIHRpdGxlOiBzZWxlY3RlZFBhY2sudGl0bGUsXG4gICAgICAgIGFtb3VudFJ1Yjogc2VsZWN0ZWRQYWNrLnJ1YixcbiAgICAgICAgZ2VtUmV3YXJkOiBzZWxlY3RlZFBhY2suZ2VtcyxcbiAgICAgICAgcm9idXhSZXdhcmQ6IHNlbGVjdGVkUGFjay5yb2J1eCxcbiAgICAgICAgY2FzaGJhY2tFYXJuZWQ6IGNhc2hiYWNrLFxuICAgICAgICBkYXRlOiAn0KLQvtC70YzQutC+INGH0YLQvicsXG4gICAgICAgIHN0YXR1czogJ9CU0L7RgdGC0LDQstC70LXQvScsXG4gICAgICAgIHBheW1lbnRNZXRob2QsXG4gICAgICB9O1xuXG4gICAgICAvLyBBZGQgcHVzaCBub3RpZmljYXRpb24gYWJvdXQgb3JkZXIgZGVsaXZlcnkgJiBjYXNoYmFja1xuICAgICAgY29uc3QgbmV3Tm90aWY6IEluR2FtZU5vdGlmaWNhdGlvbiA9IHtcbiAgICAgICAgaWQ6ICdub3RpZl8nICsgTWF0aC5yYW5kb20oKS50b1N0cmluZygpLFxuICAgICAgICB0aXRsZTogYOKchSDQl9Cw0LrQsNC3ICR7b3JkZXJOdW1iZXJ9INGD0YHQv9C10YjQvdC+INC00L7RgdGC0LDQstC70LXQvSFgLFxuICAgICAgICBtZXNzYWdlOiBg0J3QsCDQstCw0Ygg0LHQsNC70LDQvdGBINC30LDRh9C40YHQu9C10L3QviArJHtzZWxlY3RlZFBhY2suZ2Vtc30g8J+SjiwgKyR7c2VsZWN0ZWRQYWNrLnJvYnV4fSBSJCDQuCDQvdCw0YfQuNGB0LvQtdC9INC60LXRiNCx0Y3QuiArJHtjYXNoYmFja30g0LHQsNC70LvQvtCyIWAsXG4gICAgICAgIHR5cGU6ICdvcmRlcicsXG4gICAgICAgIHRpbWVzdGFtcDogJ9Ci0L7Qu9GM0LrQviDRh9GC0L4nLFxuICAgICAgICByZWFkOiBmYWxzZSxcbiAgICAgICAgYmFkZ2U6ICdERUxJVkVSRUQnLFxuICAgICAgfTtcblxuICAgICAgc2V0T3JkZXJzKChwcmV2KSA9PiBbbmV3T3JkZXIsIC4uLnByZXZdKTtcbiAgICAgIHNldE5vdGlmaWNhdGlvbnMoKHByZXYpID0+IFtuZXdOb3RpZiwgLi4ucHJldl0pO1xuXG4gICAgICBzZXRVc2VyKChwcmV2KSA9PiAoe1xuICAgICAgICAuLi5wcmV2LFxuICAgICAgICBnZW1zOiBwcmV2LmdlbXMgKyBzZWxlY3RlZFBhY2suZ2VtcyxcbiAgICAgICAgcm9idXg6IHByZXYucm9idXggKyBzZWxlY3RlZFBhY2sucm9idXgsXG4gICAgICAgIGNvaW5zOiBwcmV2LmNvaW5zICsgY2FzaGJhY2sgKiA1LCAvLyBjYXNoYmFjayBpbiBjb2luc1xuICAgICAgICBjYXNoYmFja1BvaW50czogcHJldi5jYXNoYmFja1BvaW50cyArIGNhc2hiYWNrLFxuICAgICAgfSkpO1xuXG4gICAgICBzb3VuZHMucGxheVZpY3RvcnkoKTtcbiAgICAgIGNvbmZldHRpKHsgcGFydGljbGVDb3VudDogNzAsIHNwcmVhZDogODAgfSk7XG4gICAgICBzZXRQYXltZW50U3VjY2Vzc1JlY2VpcHQobmV3T3JkZXIpO1xuICAgICAgc2V0U2VsZWN0ZWRQYWNrKG51bGwpO1xuICAgIH0sIDEyMDApO1xuICB9O1xuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJmaXhlZCBpbnNldC0wIHotNTAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgYmctc2xhdGUtOTUwLzg1IGJhY2tkcm9wLWJsdXItbWQgcC00XCI+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXNsYXRlLTkwMCBib3JkZXItMiBib3JkZXItZW1lcmFsZC01MDAvNDAgcm91bmRlZC0zeGwgcC02IG1heC13LTN4bCB3LWZ1bGwgc2hhZG93LTJ4bCB0ZXh0LXNsYXRlLTEwMCBtYXgtaC1bOTB2aF0gZmxleCBmbGV4LWNvbFwiPlxuICAgICAgICB7LyogSGVhZGVyICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBwYi00IGJvcmRlci1iIGJvcmRlci1zbGF0ZS04MDBcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIHNwYWNlLXgtM1wiPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC0zeGxcIj7wn5uN77iPPC9zcGFuPlxuICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1ibGFjayB0ZXh0LWVtZXJhbGQtNDAwXCI+XG4gICAgICAgICAgICAgICAg0JzQsNCz0LDQt9C40L0g0KHQutC40L3QvtCyINC4INCU0L7QvdCw0YLQsFxuICAgICAgICAgICAgICA8L2gyPlxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNDAwXCI+XG4gICAgICAgICAgICAgICAg0JrQsNGB0YLQvtC80LjQt9Cw0YbQuNGPINCz0LXRgNC+0LXQsiwg0LLQsNC70Y7RgtCwLCDQutC10YjQsdGN0LogMTAlINC4INC+0YTQuNGG0LjQsNC70YzQvdGL0LUg0L/Qu9Cw0YLQtdC20L3Ri9C1INGI0LvRjtC30YtcbiAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgb25DbGljaz17b25DbG9zZX1cbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInctOCBoLTggcm91bmRlZC1mdWxsIGJnLXNsYXRlLTgwMCBob3ZlcjpiZy1zbGF0ZS03MDAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgdGV4dC1zbGF0ZS00MDAgaG92ZXI6dGV4dC13aGl0ZVwiXG4gICAgICAgICAgPlxuICAgICAgICAgICAg4pyVXG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIHsvKiBOYXZpZ2F0aW9uIFRhYnMgKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgc3BhY2UteC0yIG15LTQgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTgwMCBwYi0yXCI+XG4gICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0QWN0aXZlVGFiKCdza2lucycpfVxuICAgICAgICAgICAgY2xhc3NOYW1lPXtgcHgtNCBweS0yIHJvdW5kZWQteGwgdGV4dC14cyBmb250LWJvbGQgdHJhbnNpdGlvbi1hbGwgJHtcbiAgICAgICAgICAgICAgYWN0aXZlVGFiID09PSAnc2tpbnMnXG4gICAgICAgICAgICAgICAgPyAnYmctZW1lcmFsZC01MDAgdGV4dC1zbGF0ZS05NTAgc2hhZG93LW1kJ1xuICAgICAgICAgICAgICAgIDogJ3RleHQtc2xhdGUtNDAwIGhvdmVyOnRleHQtd2hpdGUgaG92ZXI6Ymctc2xhdGUtODAwJ1xuICAgICAgICAgICAgfWB9XG4gICAgICAgICAgPlxuICAgICAgICAgICAg8J+OrSDQnNCw0LPQsNC30LjQvSDQodC60LjQvdC+0LJcbiAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRBY3RpdmVUYWIoJ2N1cnJlbmN5Jyl9XG4gICAgICAgICAgICBjbGFzc05hbWU9e2BweC00IHB5LTIgcm91bmRlZC14bCB0ZXh0LXhzIGZvbnQtYm9sZCB0cmFuc2l0aW9uLWFsbCAke1xuICAgICAgICAgICAgICBhY3RpdmVUYWIgPT09ICdjdXJyZW5jeSdcbiAgICAgICAgICAgICAgICA/ICdiZy1lbWVyYWxkLTUwMCB0ZXh0LXNsYXRlLTk1MCBzaGFkb3ctbWQnXG4gICAgICAgICAgICAgICAgOiAndGV4dC1zbGF0ZS00MDAgaG92ZXI6dGV4dC13aGl0ZSBob3ZlcjpiZy1zbGF0ZS04MDAnXG4gICAgICAgICAgICB9YH1cbiAgICAgICAgICA+XG4gICAgICAgICAgICDwn5KOINCf0L7QutGD0L/QutCwINCS0LDQu9GO0YLRiyAmIFJvYnV4ICgrMTAlINCa0LXRiNCx0Y3QuilcbiAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRBY3RpdmVUYWIoJ29yZGVycycpfVxuICAgICAgICAgICAgY2xhc3NOYW1lPXtgcHgtNCBweS0yIHJvdW5kZWQteGwgdGV4dC14cyBmb250LWJvbGQgdHJhbnNpdGlvbi1hbGwgJHtcbiAgICAgICAgICAgICAgYWN0aXZlVGFiID09PSAnb3JkZXJzJ1xuICAgICAgICAgICAgICAgID8gJ2JnLWVtZXJhbGQtNTAwIHRleHQtc2xhdGUtOTUwIHNoYWRvdy1tZCdcbiAgICAgICAgICAgICAgICA6ICd0ZXh0LXNsYXRlLTQwMCBob3Zlcjp0ZXh0LXdoaXRlIGhvdmVyOmJnLXNsYXRlLTgwMCdcbiAgICAgICAgICAgIH1gfVxuICAgICAgICAgID5cbiAgICAgICAgICAgIPCfk5wg0JvQuNGH0L3Ri9C5INCa0LDQsdC40L3QtdGCICYg0KfQtdC60LggKHtvcmRlcnMubGVuZ3RofSlcbiAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgey8qIFRhYiAxOiBTa2lucyBDYXRhbG9nICovfVxuICAgICAgICB7YWN0aXZlVGFiID09PSAnc2tpbnMnICYmIChcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm92ZXJmbG93LXktYXV0byBmbGV4LTEgcHItMSBncmlkIGdyaWQtY29scy0xIHNtOmdyaWQtY29scy0yIG1kOmdyaWQtY29scy0zIGdhcC0zXCI+XG4gICAgICAgICAgICB7U0tJTlNfREFUQS5tYXAoKHNraW4pID0+IHtcbiAgICAgICAgICAgICAgY29uc3QgaXNPd25lZCA9IHVzZXIuaW52ZW50b3J5U2tpbnMuaW5jbHVkZXMoc2tpbi5pZCk7XG4gICAgICAgICAgICAgIGNvbnN0IGlzRXF1aXBwZWQgPSB1c2VyLmVxdWlwcGVkU2tpbnNbc2tpbi50b3dlcklkXSA9PT0gc2tpbi5pZDtcbiAgICAgICAgICAgICAgY29uc3QgY2FuQWZmb3JkID1cbiAgICAgICAgICAgICAgICB1c2VyLmNvaW5zID49IChza2luLmNvc3RDb2lucyB8fCAwKSAmJiB1c2VyLmdlbXMgPj0gKHNraW4uY29zdEdlbXMgfHwgMCk7XG5cbiAgICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgICA8ZGl2XG4gICAgICAgICAgICAgICAgICBrZXk9e3NraW4uaWR9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy1zbGF0ZS05NTAvODAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC0yeGwgcC0zIGZsZXggZmxleC1jb2wganVzdGlmeS1iZXR3ZWVuIGhvdmVyOmJvcmRlci1zbGF0ZS03MDAgdHJhbnNpdGlvbi1hbGxcIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgIHsvKiBTa2luIFByZXZpZXcgQmFkZ2UgKi99XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgdy1mdWxsIGgtMjggcm91bmRlZC14bCBiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgb3ZlcmZsb3ctaGlkZGVuIG1iLTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICB7c2tpbi5pbWFnZSA/IChcbiAgICAgICAgICAgICAgICAgICAgICAgIDxpbWdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgc3JjPXtza2luLmltYWdlfVxuICAgICAgICAgICAgICAgICAgICAgICAgICBhbHQ9e3NraW4ubmFtZX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGgtZnVsbCBvYmplY3QtY292ZXJcIlxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC00eGxcIj7wn5CxPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW5cbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImFic29sdXRlIHRvcC0yIHJpZ2h0LTIgdGV4dC1bMTBweF0gZm9udC1ibGFjayBweC0yIHB5LTAuNSByb3VuZGVkLWZ1bGwgdXBwZXJjYXNlXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIHN0eWxlPXt7IGJhY2tncm91bmRDb2xvcjogc2tpbi5iYWRnZUNvbG9yLCBjb2xvcjogJyMwMDAwMDAnIH19XG4gICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAge3NraW4ucmFyaXR5fVxuICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgPGg0IGNsYXNzTmFtZT1cImZvbnQtZXh0cmFib2xkIHRleHQtc20gdGV4dC13aGl0ZVwiPntza2luLm5hbWV9PC9oND5cbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1zbGF0ZS00MDAgbXQtMC41IGxlYWRpbmctc251Z1wiPlxuICAgICAgICAgICAgICAgICAgICAgIHtza2luLmRlc2NyaXB0aW9ufVxuICAgICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0zIHB0LTIgYm9yZGVyLXQgYm9yZGVyLXNsYXRlLTgwMC84MCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICB7IWlzT3duZWQgPyAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHNwYWNlLXgtMS41XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtza2luLmNvc3RDb2lucyA/IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWFtYmVyLTQwMCBmb250LW1vbm9cIj57c2tpbi5jb3N0Q29pbnN9IPCfqpk8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICkgOiBudWxsfVxuICAgICAgICAgICAgICAgICAgICAgICAgICB7c2tpbi5jb3N0R2VtcyA/IChcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWN5YW4tNDAwIGZvbnQtbW9ub1wiPntza2luLmNvc3RHZW1zfSDwn5KOPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICApIDogbnVsbH1cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LWVtZXJhbGQtNDAwXCI+0JIg0LjQvdCy0LXQvdGC0LDRgNC1PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVCdXlTa2luKHNraW4pfVxuICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXshaXNPd25lZCAmJiAhY2FuQWZmb3JkfVxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHB4LTMgcHktMS41IHJvdW5kZWQteGwgdGV4dC14cyBmb250LWJsYWNrIHRyYW5zaXRpb24tYWxsICR7XG4gICAgICAgICAgICAgICAgICAgICAgICBpc0VxdWlwcGVkXG4gICAgICAgICAgICAgICAgICAgICAgICAgID8gJ2JnLXNsYXRlLTgwMCB0ZXh0LXNsYXRlLTQwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMCBjdXJzb3ItZGVmYXVsdCdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgOiBpc093bmVkXG4gICAgICAgICAgICAgICAgICAgICAgICAgID8gJ2JnLWN5YW4tNTAwIGhvdmVyOmJnLWN5YW4tNDAwIHRleHQtc2xhdGUtOTUwIGN1cnNvci1wb2ludGVyJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICA6IGNhbkFmZm9yZFxuICAgICAgICAgICAgICAgICAgICAgICAgICA/ICdiZy1lbWVyYWxkLTUwMCBob3ZlcjpiZy1lbWVyYWxkLTQwMCB0ZXh0LXNsYXRlLTk1MCBjdXJzb3ItcG9pbnRlciBhY3RpdmU6c2NhbGUtOTUnXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDogJ2JnLXNsYXRlLTgwMCB0ZXh0LXNsYXRlLTUwMCBjdXJzb3Itbm90LWFsbG93ZWQnXG4gICAgICAgICAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICB7aXNFcXVpcHBlZCA/ICfQndCw0LTQtdGC0L4g4pyTJyA6IGlzT3duZWQgPyAn0J3QsNC00LXRgtGMJyA6ICfQmtGD0L/QuNGC0YwnfVxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgfSl9XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICl9XG5cbiAgICAgICAgey8qIFRhYiAyOiBDdXJyZW5jeSAmIFBheW1lbnQgR2F0ZXdheXMgKi99XG4gICAgICAgIHthY3RpdmVUYWIgPT09ICdjdXJyZW5jeScgJiYgKFxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwib3ZlcmZsb3cteS1hdXRvIGZsZXgtMSBwci0xIHNwYWNlLXktNFwiPlxuICAgICAgICAgICAgey8qIENhc2hiYWNrIEJhbm5lciAqL31cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0zLjUgYmctZ3JhZGllbnQtdG8tciBmcm9tLWVtZXJhbGQtOTUwLzYwIHRvLWN5YW4tOTUwLzYwIGJvcmRlciBib3JkZXItZW1lcmFsZC01MDAvNDAgcm91bmRlZC0yeGwgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XG4gICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJsYWNrIHVwcGVyY2FzZSB0ZXh0LWVtZXJhbGQtNDAwXCI+XG4gICAgICAgICAgICAgICAgICDwn46BINCf0YDQvtCz0YDQsNC80LzQsCDQmtC10YjQsdGN0LrQsCAxMCVcbiAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTMwMFwiPlxuICAgICAgICAgICAgICAgICAg0JLQvtC30LLRgNCw0YIgMTAlINC+0YIg0LrQsNC20LTQvtC5INGB0YPQvNC80Ysg0L/QvtC60YPQv9C60Lgg0L3QsCDQstCw0Ygg0LHQvtC90YPRgdC90YvQuSDRgdGH0LXRgiDQsiDQstC40LTQtSDQtNC+0L/QvtC70L3QuNGC0LXQu9GM0L3Ri9GFINC80L7QvdC10YIhXG4gICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXJpZ2h0XCI+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTQwMFwiPtCS0LDRiCDQmtC10YjQsdGN0Lo6PC9zcGFuPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1iYXNlIGZvbnQtYmxhY2sgdGV4dC1hbWJlci0zMDAgZm9udC1tb25vXCI+XG4gICAgICAgICAgICAgICAgICB7dXNlci5jYXNoYmFja1BvaW50c30g0LHQsNC70LvQvtCyXG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIHsvKiBEb25hdGlvbiBQYWNrcyBHcmlkICovfVxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIHNtOmdyaWQtY29scy0yIGdhcC0zXCI+XG4gICAgICAgICAgICAgIHtET05BVElPTl9QQUNLUy5tYXAoKHBhY2ssIGlkeCkgPT4gKFxuICAgICAgICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgICAgICAgIGtleT17aWR4fVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTUwLzcwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIGhvdmVyOmJvcmRlci1lbWVyYWxkLTUwMC81MCByb3VuZGVkLTJ4bCBwLTQgZmxleCBmbGV4LWNvbCBqdXN0aWZ5LWJldHdlZW5cIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1zdGFydCBqdXN0aWZ5LWJldHdlZW5cIj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSBmb250LWJvbGQgdXBwZXJjYXNlIHB4LTIgcHktMC41IHJvdW5kZWQtZnVsbCBiZy1lbWVyYWxkLTk1MCB0ZXh0LWVtZXJhbGQtNDAwIGJvcmRlciBib3JkZXItZW1lcmFsZC03MDAvNTBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIHtwYWNrLmJvbnVzfVxuICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwiZm9udC1leHRyYWJvbGQgdGV4dC1zbSB0ZXh0LXdoaXRlIG10LTEuNVwiPntwYWNrLnRpdGxlfTwvaDQ+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LTJ4bFwiPvCfko48L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJteS0zIHNwYWNlLXktMSBmb250LW1vbm8gdGV4dC14c1wiPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtY3lhbi00MDAgZm9udC1ib2xkXCI+K3twYWNrLmdlbXN9INCa0YDQuNGB0YLQsNC70LvQvtCyPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1lbWVyYWxkLTQwMCBmb250LWJvbGRcIj4re3BhY2sucm9idXh9IFJvYnV4IChSJCk8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWFtYmVyLTQwMCB0ZXh0LVsxMXB4XVwiPlxuICAgICAgICAgICAgICAgICAgICAgINCa0LXRiNCx0Y3QujogK3tNYXRoLnJvdW5kKHBhY2sucnViICogMC4xKX0g0LHQsNC70LvQvtCyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U2VsZWN0ZWRQYWNrKHBhY2spfVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHktMiBiZy1lbWVyYWxkLTUwMCBob3ZlcjpiZy1lbWVyYWxkLTQwMCB0ZXh0LXNsYXRlLTk1MCByb3VuZGVkLXhsIGZvbnQtYmxhY2sgdGV4dC14cyB0cmFuc2l0aW9uLXRyYW5zZm9ybSBhY3RpdmU6c2NhbGUtOTUgc2hhZG93LW1kIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHNwYWNlLXgtMVwiXG4gICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuPtCa0YPQv9C40YLRjCDQt9CwIHtwYWNrLnJ1Yn0g4oK9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIHsvKiBNb2RhbCBDaGVja291dCBGb3JtIGlmIFBhY2sgU2VsZWN0ZWQgKi99XG4gICAgICAgICAgICB7c2VsZWN0ZWRQYWNrICYmIChcbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTQgYmctc2xhdGUtOTUwIGJvcmRlci0yIGJvcmRlci1lbWVyYWxkLTQwMCByb3VuZGVkLTJ4bCBzcGFjZS15LTNcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBib3JkZXItYiBib3JkZXItc2xhdGUtODAwIHBiLTJcIj5cbiAgICAgICAgICAgICAgICAgIDxoNCBjbGFzc05hbWU9XCJmb250LWJsYWNrIHRleHQtc20gdGV4dC13aGl0ZVwiPlxuICAgICAgICAgICAgICAgICAgICDQntGE0L7RgNC80LvQtdC90LjQtSDQt9Cw0LrQsNC30LA6IHtzZWxlY3RlZFBhY2sudGl0bGV9ICh7c2VsZWN0ZWRQYWNrLnJ1Yn0g4oK9KVxuICAgICAgICAgICAgICAgICAgPC9oND5cbiAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U2VsZWN0ZWRQYWNrKG51bGwpfVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNDAwIGhvdmVyOnRleHQtd2hpdGVcIlxuICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICDQntGC0LzQtdC90LBcbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTEuNVwiPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdGV4dC1zbGF0ZS00MDBcIj5cbiAgICAgICAgICAgICAgICAgICAg0JLRi9Cx0LXRgNC40YLQtSDQv9C70LDRgtC10LbQvdGD0Y4g0YHQuNGB0YLQtdC80YM6XG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgc206Z3JpZC1jb2xzLTQgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICAgICAgeyhcbiAgICAgICAgICAgICAgICAgICAgICBbXG4gICAgICAgICAgICAgICAgICAgICAgICB7IGlkOiAn0KHQkdCfJywgbGFiZWw6ICfQodCR0J8gKFFSLdC60L7QtCknLCBpY29uOiAn4pqhJyB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgeyBpZDogJ9Ca0LDRgNGC0LAg0JzQmNCgJywgbGFiZWw6ICfQkdCw0L3Qui4g0JrQsNGA0YLQsCcsIGljb246ICfwn5KzJyB9LFxuICAgICAgICAgICAgICAgICAgICAgICAgeyBpZDogJ9CuTW9uZXknLCBsYWJlbDogJ9CuTW9uZXknLCBpY29uOiAn8J+foycgfSxcbiAgICAgICAgICAgICAgICAgICAgICAgIHsgaWQ6ICdDcnlwdG8nLCBsYWJlbDogJ0NyeXB0byAoVE9OKScsIGljb246ICfwn6qZJyB9LFxuICAgICAgICAgICAgICAgICAgICAgIF0gYXMgY29uc3RcbiAgICAgICAgICAgICAgICAgICAgKS5tYXAoKG1ldGhvZCkgPT4gKFxuICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgIGtleT17bWV0aG9kLmlkfVxuICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0UGF5bWVudE1ldGhvZChtZXRob2QuaWQpfVxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcC0yIHJvdW5kZWQteGwgYm9yZGVyIHRleHQteHMgZm9udC1ib2xkIGZsZXggaXRlbXMtY2VudGVyIHNwYWNlLXgtMS41ICR7XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHBheW1lbnRNZXRob2QgPT09IG1ldGhvZC5pZFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gJ2JnLWVtZXJhbGQtOTUwLzgwIGJvcmRlci1lbWVyYWxkLTQwMCB0ZXh0LWVtZXJhbGQtMzAwJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogJ2JnLXNsYXRlLTkwMCBib3JkZXItc2xhdGUtODAwIHRleHQtc2xhdGUtNDAwIGhvdmVyOnRleHQtd2hpdGUnXG4gICAgICAgICAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj57bWV0aG9kLmljb259PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+e21ldGhvZC5sYWJlbH08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInB0LTIgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNDAwXCI+XG4gICAgICAgICAgICAgICAgICAgINCR0LXQt9C+0L/QsNGB0L3Ri9C5INGN0LrQstCw0LnRgNC40L3QsyDRgSBTU0wt0YjQuNGE0YDQvtCy0LDQvdC40LXQvFxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVFeGVjdXRlUGF5bWVudH1cbiAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2lzUHJvY2Vzc2luZ1BheW1lbnR9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTUgcHktMiBiZy1ncmFkaWVudC10by1yIGZyb20tZW1lcmFsZC01MDAgdG8tZ3JlZW4tNjAwIGhvdmVyOmZyb20tZW1lcmFsZC00MDAgaG92ZXI6dG8tZ3JlZW4tNTAwIHRleHQtc2xhdGUtOTUwIGZvbnQtYmxhY2sgcm91bmRlZC14bCB0ZXh0LXhzIHRyYW5zaXRpb24tdHJhbnNmb3JtIGFjdGl2ZTpzY2FsZS05NSBzaGFkb3ctbGcgZmxleCBpdGVtcy1jZW50ZXIgc3BhY2UteC0yXCJcbiAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAge2lzUHJvY2Vzc2luZ1BheW1lbnQgPyAoXG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4+0J7QsdGA0LDQsdC+0YLQutCwINC/0LvQsNGC0LXQttCwLi4uPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPtCe0L/Qu9Cw0YLQuNGC0Ywge3NlbGVjdGVkUGFjay5ydWJ9IOKCvTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICl9XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICl9XG5cbiAgICAgICAgey8qIFRhYiAzOiBPcmRlciBIaXN0b3J5ICYgQ2FzaGJhY2sgUmVjZWlwdCAqL31cbiAgICAgICAge2FjdGl2ZVRhYiA9PT0gJ29yZGVycycgJiYgKFxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwib3ZlcmZsb3cteS1hdXRvIGZsZXgtMSBwci0xIHNwYWNlLXktM1wiPlxuICAgICAgICAgICAge29yZGVycy5sZW5ndGggPT09IDAgPyAoXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC04IHRleHQtY2VudGVyIHRleHQtc2xhdGUtNTAwIHRleHQteHNcIj5cbiAgICAgICAgICAgICAgICDQoyDQstCw0YEg0L/QvtC60LAg0L3QtdGCINC+0YTQvtGA0LzQu9C10L3QvdGL0YUg0LfQsNC60LDQt9C+0LJcbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICBvcmRlcnMubWFwKChvcmQpID0+IChcbiAgICAgICAgICAgICAgICA8ZGl2XG4gICAgICAgICAgICAgICAgICBrZXk9e29yZC5pZH1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInAtMy41IGJnLXNsYXRlLTk1MC84MCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLTJ4bCBmbGV4IGZsZXgtY29sIHNtOmZsZXgtcm93IGl0ZW1zLXN0YXJ0IHNtOml0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTNcIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgc3BhY2UteC0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1tb25vIHRleHQteHMgZm9udC1ib2xkIHRleHQtc2xhdGUtNDAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAje29yZC5vcmRlck51bWJlcn1cbiAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicHgtMiBweS0wLjUgcm91bmRlZC1mdWxsIHRleHQtWzEwcHhdIGZvbnQtYmxhY2sgYmctZW1lcmFsZC05NTAgdGV4dC1lbWVyYWxkLTQwMCBib3JkZXIgYm9yZGVyLWVtZXJhbGQtNzAwLzUwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICB7b3JkLnN0YXR1c31cbiAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwiZm9udC1leHRyYWJvbGQgdGV4dC1zbSB0ZXh0LXdoaXRlIG10LTFcIj57b3JkLnRpdGxlfTwvaDQ+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1zbGF0ZS00MDAgbXQtMC41IGZvbnQtbW9ub1wiPlxuICAgICAgICAgICAgICAgICAgICAgINCe0L/Qu9Cw0YLQsDoge29yZC5wYXltZW50TWV0aG9kfSAmYnVsbDsge29yZC5kYXRlfVxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtcmlnaHQgc206Ym9yZGVyLWwgc206Ym9yZGVyLXNsYXRlLTgwMCBzbTpwbC00XCI+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9udC1ibGFjayB0ZXh0LXNtIHRleHQtd2hpdGUgZm9udC1tb25vXCI+e29yZC5hbW91bnRSdWJ9IOKCvTwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1hbWJlci00MDAgZm9udC1ib2xkIGZvbnQtbW9ub1wiPlxuICAgICAgICAgICAgICAgICAgICAgICt7b3JkLmNhc2hiYWNrRWFybmVkfSDQutC10YjQsdGN0LpcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgKSlcbiAgICAgICAgICAgICl9XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICl9XG5cbiAgICAgICAgey8qIEZvb3RlciBSZWNlaXB0IENvbmZpcm1hdGlvbiBCYW5uZXIgKi99XG4gICAgICAgIHtwYXltZW50U3VjY2Vzc1JlY2VpcHQgJiYgKFxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMyBwLTMgYmctZW1lcmFsZC05NTAvODAgYm9yZGVyIGJvcmRlci1lbWVyYWxkLTUwMCByb3VuZGVkLTJ4bCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gdGV4dC14cyB0ZXh0LWVtZXJhbGQtMzAwXCI+XG4gICAgICAgICAgICA8c3Bhbj5cbiAgICAgICAgICAgICAg8J+OiSDQp9C10LogI3twYXltZW50U3VjY2Vzc1JlY2VpcHQub3JkZXJOdW1iZXJ9INC+0L/Qu9Cw0YfQtdC9ISDQndCw0YfQuNGB0LvQtdC90L46ICtcbiAgICAgICAgICAgICAge3BheW1lbnRTdWNjZXNzUmVjZWlwdC5nZW1SZXdhcmR9IPCfko4sICt7cGF5bWVudFN1Y2Nlc3NSZWNlaXB0LnJvYnV4UmV3YXJkfSBSJFxuICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRQYXltZW50U3VjY2Vzc1JlY2VpcHQobnVsbCl9XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtd2hpdGUgZm9udC1ib2xkIG1sLTIgdW5kZXJsaW5lIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgT0tcbiAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICApfVxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG4gICk7XG59O1xuIl19