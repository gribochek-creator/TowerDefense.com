const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=1e19e0c2";
import { CAT_IMAGE_URL } from "/src/data/constants.ts";
import { sounds } from "/src/utils/sound.ts";
var _jsxFileName = "/app/applet/src/components/ProfileModal.tsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=1e19e0c2";
export const ProfileModal = ({ user, setUser, onClose, onOpenShopOrders, onOpenNetlifyDownload }) => {
	const [activeTab, setActiveTab] = useState("profile");
	const [newUsername, setNewUsername] = useState(user.username);
	const [newTitle, setNewTitle] = useState(user.title);
	const [syncCode, setSyncCode] = useState("");
	const [syncFeedback, setSyncFeedback] = useState(null);
	const AVAILABLE_AVATARS = [
		{
			url: CAT_IMAGE_URL,
			name: "Кот в очках"
		},
		{
			url: "https://api.dicebear.com/7.x/bottts/svg?seed=RobloxNoob",
			name: "Желтый Нуб"
		},
		{
			url: "https://api.dicebear.com/7.x/bottts/svg?seed=CyberKnight",
			name: "Кибер Рыцарь"
		},
		{
			url: "https://api.dicebear.com/7.x/bottts/svg?seed=NeonCat",
			name: "Неон Кот"
		}
	];
	const handleSaveProfile = (e) => {
		e.preventDefault();
		setUser((prev) => ({
			...prev,
			username: newUsername.trim() || prev.username,
			title: newTitle.trim() || prev.title
		}));
		sounds.playCoin();
		setSyncFeedback("Профиль успешно обновлен!");
		setTimeout(() => setSyncFeedback(null), 2500);
	};
	const handleSocialAuth = (provider, providerName) => {
		sounds.playUpgrade();
		setUser((prev) => ({
			...prev,
			authProvider: provider,
			username: `${providerName}_${Math.floor(100 + Math.random() * 900)}`
		}));
		setSyncFeedback(`Вы успешно авторизовались через ${providerName}! Профиль привязан.`);
		setTimeout(() => setSyncFeedback(null), 3e3);
	};
	// Export save code
	const handleExportCloudSave = () => {
		const raw = JSON.stringify(user);
		const encoded = btoa(unescape(encodeURIComponent(raw)));
		navigator.clipboard.writeText(encoded);
		setSyncFeedback("Код облачного сохранения скопирован в буфер обмена!");
		setTimeout(() => setSyncFeedback(null), 3e3);
	};
	// Import save code
	const handleImportCloudSave = () => {
		try {
			const decoded = decodeURIComponent(escape(atob(syncCode.trim())));
			const parsed = JSON.parse(decoded);
			if (parsed && parsed.username) {
				setUser(parsed);
				sounds.playVictory();
				setSyncFeedback("Данные успешно загружены из облачного кода!");
				setTimeout(() => setSyncFeedback(null), 3e3);
			}
		} catch {
			setSyncFeedback("Ошибка: неверный код сохранения!");
			setTimeout(() => setSyncFeedback(null), 3e3);
		}
	};
	const handleForceSync = () => {
		setUser((prev) => ({
			...prev,
			cloudSyncTimestamp: new Date().toISOString()
		}));
		sounds.playCoin();
		setSyncFeedback("Синхронизация с облачным сервером завершена!");
		setTimeout(() => setSyncFeedback(null), 2500);
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "fixed inset-0 z-50 flex items-center justify-center bg-slate-950/85 backdrop-blur-md p-4",
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: "bg-slate-900 border-2 border-slate-700 rounded-3xl p-6 max-w-xl w-full shadow-2xl text-slate-100 max-h-[90vh] flex flex-col",
			children: [
				/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center justify-between pb-4 border-b border-slate-800",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center space-x-3",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "w-12 h-12 rounded-xl bg-slate-800 border-2 border-cyan-400 overflow-hidden shrink-0",
							children: /* @__PURE__ */ _jsxDEV("img", {
								src: user.avatarUrl,
								alt: "Avatar",
								className: "w-full h-full object-cover"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 100,
								columnNumber: 15
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 99,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center space-x-2",
							children: [/* @__PURE__ */ _jsxDEV("h2", {
								className: "text-lg font-black text-white",
								children: user.username
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 104,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "px-2 py-0.5 rounded-full text-[10px] font-bold bg-cyan-950 text-cyan-400 border border-cyan-800 uppercase",
								children: user.authProvider
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 105,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 103,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("p", {
							className: "text-xs text-slate-400",
							children: user.title
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 109,
							columnNumber: 15
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 102,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 98,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("button", {
						onClick: onClose,
						className: "w-8 h-8 rounded-full bg-slate-800 hover:bg-slate-700 flex items-center justify-center text-slate-400 hover:text-white",
						children: "✕"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 112,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 97,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center space-x-2 my-4 border-b border-slate-800 pb-2 text-xs font-bold",
					children: [
						/* @__PURE__ */ _jsxDEV("button", {
							onClick: () => setActiveTab("profile"),
							className: `px-3 py-1.5 rounded-xl transition-all ${activeTab === "profile" ? "bg-cyan-500 text-slate-950 shadow-md" : "text-slate-400 hover:text-white"}`,
							children: "👤 Профиль"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 122,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("button", {
							onClick: () => setActiveTab("social"),
							className: `px-3 py-1.5 rounded-xl transition-all ${activeTab === "social" ? "bg-cyan-500 text-slate-950 shadow-md" : "text-slate-400 hover:text-white"}`,
							children: "🔑 Соцсети"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 132,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("button", {
							onClick: () => setActiveTab("cloud"),
							className: `px-3 py-1.5 rounded-xl transition-all ${activeTab === "cloud" ? "bg-cyan-500 text-slate-950 shadow-md" : "text-slate-400 hover:text-white"}`,
							children: "☁️ Облако & Синхронизация"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 142,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("button", {
							onClick: () => setActiveTab("settings"),
							className: `px-3 py-1.5 rounded-xl transition-all ${activeTab === "settings" ? "bg-cyan-500 text-slate-950 shadow-md" : "text-slate-400 hover:text-white"}`,
							children: "⚙️ Опции"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 152,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 121,
					columnNumber: 9
				}, this),
				syncFeedback && /* @__PURE__ */ _jsxDEV("div", {
					className: "mb-3 p-2.5 bg-cyan-950/80 border border-cyan-500 text-cyan-300 rounded-xl text-xs font-bold text-center animate-in fade-in",
					children: syncFeedback
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 166,
					columnNumber: 11
				}, this),
				activeTab === "profile" && /* @__PURE__ */ _jsxDEV("form", {
					onSubmit: handleSaveProfile,
					className: "flex-1 overflow-y-auto space-y-4 pr-1",
					children: [
						/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
							className: "block text-xs font-bold text-slate-400 mb-2",
							children: "Выберите аватар героя:"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 176,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center space-x-3",
							children: AVAILABLE_AVATARS.map((av, idx) => /* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								onClick: () => setUser((p) => ({
									...p,
									avatarUrl: av.url
								})),
								className: `w-14 h-14 rounded-2xl overflow-hidden border-2 transition-all p-0.5 bg-slate-950 ${user.avatarUrl === av.url ? "border-cyan-400 scale-105 shadow-md shadow-cyan-500/30" : "border-slate-800 opacity-60 hover:opacity-100"}`,
								children: /* @__PURE__ */ _jsxDEV("img", {
									src: av.url,
									alt: av.name,
									className: "w-full h-full object-cover rounded-xl"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 191,
									columnNumber: 21
								}, this)
							}, idx, false, {
								fileName: _jsxFileName,
								lineNumber: 181,
								columnNumber: 19
							}, this))
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 179,
							columnNumber: 15
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 175,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
							className: "block text-xs font-bold text-slate-400 mb-1",
							children: "Никнейм:"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 198,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("input", {
							type: "text",
							value: newUsername,
							onChange: (e) => setNewUsername(e.target.value),
							className: "w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-500 font-bold"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 199,
							columnNumber: 15
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 197,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
							className: "block text-xs font-bold text-slate-400 mb-1",
							children: "Почетное звание / Титул:"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 208,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("input", {
							type: "text",
							value: newTitle,
							onChange: (e) => setNewTitle(e.target.value),
							className: "w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-500"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 211,
							columnNumber: 15
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 207,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "p-3 bg-slate-950 rounded-2xl border border-slate-800 flex items-center justify-between",
							children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "text-xs font-bold text-slate-300",
								children: "История заказов и кешбэк:"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 221,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("p", {
								className: "text-[11px] text-slate-500",
								children: [user.cashbackPoints, " бонусных баллов кешбэка"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 222,
								columnNumber: 17
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 220,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								onClick: () => {
									onClose();
									onOpenShopOrders();
								},
								className: "px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold",
								children: "Открыть чеки"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 226,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 219,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("button", {
							type: "submit",
							className: "w-full py-2.5 bg-cyan-500 hover:bg-cyan-400 text-slate-950 rounded-xl font-black text-xs shadow-md",
							children: "Сохранить Изменения"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 238,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 173,
					columnNumber: 11
				}, this),
				activeTab === "social" && /* @__PURE__ */ _jsxDEV("div", {
					className: "flex-1 overflow-y-auto space-y-3 pr-1 text-xs",
					children: [/* @__PURE__ */ _jsxDEV("p", {
						className: "text-slate-400",
						children: "Привяжите социальную сеть для быстрого входа в один клик и синхронизации с другими устройствами:"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 250,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "space-y-2",
						children: [
							/* @__PURE__ */ _jsxDEV("button", {
								onClick: () => handleSocialAuth("roblox", "RobloxPlayer"),
								className: "w-full p-3 rounded-2xl bg-slate-950 border border-slate-700 hover:border-cyan-400 flex items-center justify-between transition-colors",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center space-x-3",
									children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "text-xl",
										children: "🟥"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 260,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "text-left",
										children: [/* @__PURE__ */ _jsxDEV("div", {
											className: "font-extrabold text-white",
											children: "Вход через Roblox OAuth"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 262,
											columnNumber: 21
										}, this), /* @__PURE__ */ _jsxDEV("div", {
											className: "text-[10px] text-slate-400",
											children: "Официальная синхронизация инвентаря"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 263,
											columnNumber: 21
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 261,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 259,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("span", {
									className: "px-2 py-1 rounded bg-slate-800 text-slate-300 font-bold text-[11px]",
									children: user.authProvider === "roblox" ? "Подключено ✓" : "Войти"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 266,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 255,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("button", {
								onClick: () => handleSocialAuth("discord", "DiscordMaster"),
								className: "w-full p-3 rounded-2xl bg-slate-950 border border-slate-700 hover:border-indigo-400 flex items-center justify-between transition-colors",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center space-x-3",
									children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "text-xl",
										children: "👾"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 276,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "text-left",
										children: [/* @__PURE__ */ _jsxDEV("div", {
											className: "font-extrabold text-white",
											children: "Вход через Discord"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 278,
											columnNumber: 21
										}, this), /* @__PURE__ */ _jsxDEV("div", {
											className: "text-[10px] text-slate-400",
											children: "Клановый войс и уведомления"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 279,
											columnNumber: 21
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 277,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 275,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("span", {
									className: "px-2 py-1 rounded bg-slate-800 text-slate-300 font-bold text-[11px]",
									children: user.authProvider === "discord" ? "Подключено ✓" : "Войти"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 282,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 271,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("button", {
								onClick: () => handleSocialAuth("google", "GoogleGamer"),
								className: "w-full p-3 rounded-2xl bg-slate-950 border border-slate-700 hover:border-rose-400 flex items-center justify-between transition-colors",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center space-x-3",
									children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "text-xl",
										children: "🌐"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 292,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "text-left",
										children: [/* @__PURE__ */ _jsxDEV("div", {
											className: "font-extrabold text-white",
											children: "Вход через Google"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 294,
											columnNumber: 21
										}, this), /* @__PURE__ */ _jsxDEV("div", {
											className: "text-[10px] text-slate-400",
											children: "Google Play Games сохранение"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 295,
											columnNumber: 21
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 293,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 291,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("span", {
									className: "px-2 py-1 rounded bg-slate-800 text-slate-300 font-bold text-[11px]",
									children: user.authProvider === "google" ? "Подключено ✓" : "Войти"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 298,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 287,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("button", {
								onClick: () => handleSocialAuth("steam", "SteamWarrior"),
								className: "w-full p-3 rounded-2xl bg-slate-950 border border-slate-700 hover:border-blue-400 flex items-center justify-between transition-colors",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center space-x-3",
									children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "text-xl",
										children: "🎮"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 308,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "text-left",
										children: [/* @__PURE__ */ _jsxDEV("div", {
											className: "font-extrabold text-white",
											children: "Вход через Steam"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 310,
											columnNumber: 21
										}, this), /* @__PURE__ */ _jsxDEV("div", {
											className: "text-[10px] text-slate-400",
											children: "Синхронизация достижений"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 311,
											columnNumber: 21
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 309,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 307,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("span", {
									className: "px-2 py-1 rounded bg-slate-800 text-slate-300 font-bold text-[11px]",
									children: user.authProvider === "steam" ? "Подключено ✓" : "Войти"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 314,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 303,
								columnNumber: 15
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 254,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 249,
					columnNumber: 11
				}, this),
				activeTab === "cloud" && /* @__PURE__ */ _jsxDEV("div", {
					className: "flex-1 overflow-y-auto space-y-4 pr-1 text-xs",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "p-3 bg-emerald-950/40 border border-emerald-500/40 rounded-2xl flex items-center justify-between",
							children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "font-bold text-emerald-400",
								children: "● Облако Подключено"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 327,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "text-[11px] text-slate-400 font-mono mt-0.5",
								children: ["Последний бэкап: ", new Date(user.cloudSyncTimestamp).toLocaleTimeString()]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 328,
								columnNumber: 17
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 326,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("button", {
								onClick: handleForceSync,
								className: "px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl font-bold",
								children: "Синхронизировать"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 332,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 325,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "p-3 bg-slate-950 rounded-2xl border border-slate-800 space-y-2",
							children: [
								/* @__PURE__ */ _jsxDEV("h4", {
									className: "font-bold text-white",
									children: "Кроссплатформенный код сохранения (PC / Mobile)"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 342,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("p", {
									className: "text-slate-400 text-[11px]",
									children: "Используйте этот код, чтобы мгновенно перенести свой прогресс на телефон или другой браузер:"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 343,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("button", {
									onClick: handleExportCloudSave,
									className: "w-full py-2 bg-slate-800 hover:bg-slate-700 text-cyan-300 rounded-xl font-bold",
									children: "📋 Скопировать Облачный Код"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 346,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 341,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "p-3 bg-slate-950 rounded-2xl border border-slate-800 space-y-2",
							children: [
								/* @__PURE__ */ _jsxDEV("h4", {
									className: "font-bold text-white",
									children: "Загрузить сохранение по коду:"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 356,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("input", {
									type: "text",
									placeholder: "Вставьте скопированный код сохранения...",
									value: syncCode,
									onChange: (e) => setSyncCode(e.target.value),
									className: "w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-1.5 text-xs text-white font-mono focus:outline-none focus:border-cyan-500"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 357,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("button", {
									onClick: handleImportCloudSave,
									className: "w-full py-2 bg-cyan-600 hover:bg-cyan-500 text-white rounded-xl font-bold",
									children: "📥 Загрузить Данные"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 364,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 355,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "p-3 bg-teal-950/40 border border-teal-500/40 rounded-2xl space-y-2",
							children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center space-x-2",
									children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "text-base",
										children: "🌐"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 375,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("h4", {
										className: "font-bold text-teal-300",
										children: "Деплой проекта на Netlify"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 376,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 374,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("p", {
									className: "text-slate-400 text-[11px] leading-relaxed",
									children: [
										"Скачайте полный готовый архив со всеми файлами игры, ассетами и ",
										/* @__PURE__ */ _jsxDEV("code", {
											className: "text-teal-300",
											children: "netlify.toml"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 379,
											columnNumber: 81
										}, this),
										" для мгновенного развертывания на Netlify:"
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 378,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									onClick: () => {
										onClose();
										onOpenNetlifyDownload?.();
									},
									className: "w-full py-2.5 bg-gradient-to-r from-teal-500 to-emerald-600 hover:from-teal-400 hover:to-emerald-500 text-slate-950 rounded-xl font-black text-xs shadow-md transition-all flex items-center justify-center space-x-1.5 cursor-pointer active:scale-95",
									children: [/* @__PURE__ */ _jsxDEV("span", { children: "📦" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 389,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Скачать все файлы для Netlify (ZIP)" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 390,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 381,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 373,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 324,
					columnNumber: 11
				}, this),
				activeTab === "settings" && /* @__PURE__ */ _jsxDEV("div", {
					className: "flex-1 overflow-y-auto space-y-3 pr-1 text-xs",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "p-3 bg-slate-950 rounded-2xl border border-slate-800 flex items-center justify-between",
							children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "font-bold text-white",
								children: "Тема оформления:"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 402,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("p", {
								className: "text-[11px] text-slate-400",
								children: "Темный стиль Roblox с неоновыми акцентами"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 403,
								columnNumber: 17
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 401,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "flex space-x-1 font-bold",
								children: [/* @__PURE__ */ _jsxDEV("button", {
									onClick: () => setUser((p) => ({
										...p,
										theme: "dark"
									})),
									className: `px-2.5 py-1 rounded-lg ${user.theme === "dark" ? "bg-cyan-500 text-slate-950" : "bg-slate-800 text-slate-400"}`,
									children: "Dark"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 406,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("button", {
									onClick: () => setUser((p) => ({
										...p,
										theme: "cyber"
									})),
									className: `px-2.5 py-1 rounded-lg ${user.theme === "cyber" ? "bg-cyan-500 text-slate-950" : "bg-slate-800 text-slate-400"}`,
									children: "Cyber"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 414,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 405,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 400,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "p-3 bg-slate-950 rounded-2xl border border-slate-800 flex items-center justify-between",
							children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "font-bold text-white",
								children: "Звуковые эффекты башен и кота:"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 428,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("p", {
								className: "text-[11px] text-slate-400",
								children: "Синтезатор звуков лазеров, мяуканья и взрывов"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 429,
								columnNumber: 17
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 427,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("input", {
								type: "checkbox",
								checked: user.soundEnabled,
								onChange: (e) => {
									setUser((p) => ({
										...p,
										soundEnabled: e.target.checked
									}));
									sounds.setMuted(!e.target.checked);
								},
								className: "w-5 h-5 accent-cyan-500 cursor-pointer"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 431,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 426,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "p-3 bg-slate-950 rounded-2xl border border-slate-800 flex items-center justify-between",
							children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "font-bold text-white",
								children: "Push-уведомления:"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 445,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("p", {
								className: "text-[11px] text-slate-400",
								children: "Оповещения об акциях, статусах доставки заказов и еженедельных испытаниях"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 446,
								columnNumber: 17
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 444,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("input", {
								type: "checkbox",
								checked: user.pushNotifications,
								onChange: (e) => setUser((p) => ({
									...p,
									pushNotifications: e.target.checked
								})),
								className: "w-5 h-5 accent-cyan-500 cursor-pointer"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 450,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 443,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 398,
					columnNumber: 11
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 95,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 94,
		columnNumber: 5
	}, this);
};

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLGdCQUFnQjtBQUVoQyxTQUFTLHFCQUFxQjtBQUM5QixTQUFTLGNBQWM7OztBQVV2QixPQUFPLE1BQU0sZ0JBQTZDLEVBQ3hELE1BQ0EsU0FDQSxTQUNBLGtCQUNBLDRCQUNJO0NBQ0osTUFBTSxDQUFDLFdBQVcsZ0JBQWdCLFNBQXNELFNBQVM7Q0FDakcsTUFBTSxDQUFDLGFBQWEsa0JBQWtCLFNBQVMsS0FBSyxRQUFRO0NBQzVELE1BQU0sQ0FBQyxVQUFVLGVBQWUsU0FBUyxLQUFLLEtBQUs7Q0FDbkQsTUFBTSxDQUFDLFVBQVUsZUFBZSxTQUFTLEVBQUU7Q0FDM0MsTUFBTSxDQUFDLGNBQWMsbUJBQW1CLFNBQXdCLElBQUk7Q0FFcEUsTUFBTSxvQkFBb0I7RUFDeEI7R0FBRSxLQUFLO0dBQWUsTUFBTTtFQUFjO0VBQzFDO0dBQUUsS0FBSztHQUEyRCxNQUFNO0VBQWE7RUFDckY7R0FBRSxLQUFLO0dBQTRELE1BQU07RUFBZTtFQUN4RjtHQUFFLEtBQUs7R0FBd0QsTUFBTTtFQUFXO0NBQ2xGO0NBRUEsTUFBTSxxQkFBcUIsTUFBdUI7RUFDaEQsRUFBRSxlQUFlO0VBQ2pCLFNBQVMsVUFBVTtHQUNqQixHQUFHO0dBQ0gsVUFBVSxZQUFZLEtBQUssS0FBSyxLQUFLO0dBQ3JDLE9BQU8sU0FBUyxLQUFLLEtBQUssS0FBSztFQUNqQyxFQUFFO0VBQ0YsT0FBTyxTQUFTO0VBQ2hCLGdCQUFnQiwyQkFBMkI7RUFDM0MsaUJBQWlCLGdCQUFnQixJQUFJLEdBQUcsSUFBSTtDQUM5QztDQUVBLE1BQU0sb0JBQW9CLFVBQXVDLGlCQUF5QjtFQUN4RixPQUFPLFlBQVk7RUFDbkIsU0FBUyxVQUFVO0dBQ2pCLEdBQUc7R0FDSCxjQUFjO0dBQ2QsVUFBVSxHQUFHLGFBQWEsR0FBRyxLQUFLLE1BQU0sTUFBTSxLQUFLLE9BQU8sSUFBSSxHQUFHO0VBQ25FLEVBQUU7RUFDRixnQkFBZ0IsbUNBQW1DLGFBQWEsb0JBQW9CO0VBQ3BGLGlCQUFpQixnQkFBZ0IsSUFBSSxHQUFHLEdBQUk7Q0FDOUM7O0NBR0EsTUFBTSw4QkFBOEI7RUFDbEMsTUFBTSxNQUFNLEtBQUssVUFBVSxJQUFJO0VBQy9CLE1BQU0sVUFBVSxLQUFLLFNBQVMsbUJBQW1CLEdBQUcsQ0FBQyxDQUFDO0VBQ3RELFVBQVUsVUFBVSxVQUFVLE9BQU87RUFDckMsZ0JBQWdCLHFEQUFxRDtFQUNyRSxpQkFBaUIsZ0JBQWdCLElBQUksR0FBRyxHQUFJO0NBQzlDOztDQUdBLE1BQU0sOEJBQThCO0VBQ2xDLElBQUk7R0FDRixNQUFNLFVBQVUsbUJBQW1CLE9BQU8sS0FBSyxTQUFTLEtBQUssQ0FBQyxDQUFDLENBQUM7R0FDaEUsTUFBTSxTQUFTLEtBQUssTUFBTSxPQUFPO0dBQ2pDLElBQUksVUFBVSxPQUFPLFVBQVU7SUFDN0IsUUFBUSxNQUFNO0lBQ2QsT0FBTyxZQUFZO0lBQ25CLGdCQUFnQiw2Q0FBNkM7SUFDN0QsaUJBQWlCLGdCQUFnQixJQUFJLEdBQUcsR0FBSTtHQUM5QztFQUNGLFFBQVE7R0FDTixnQkFBZ0Isa0NBQWtDO0dBQ2xELGlCQUFpQixnQkFBZ0IsSUFBSSxHQUFHLEdBQUk7RUFDOUM7Q0FDRjtDQUVBLE1BQU0sd0JBQXdCO0VBQzVCLFNBQVMsVUFBVTtHQUNqQixHQUFHO0dBQ0gsb0JBQW9CLElBQUksS0FBSyxDQUFDLENBQUMsWUFBWTtFQUM3QyxFQUFFO0VBQ0YsT0FBTyxTQUFTO0VBQ2hCLGdCQUFnQiw4Q0FBOEM7RUFDOUQsaUJBQWlCLGdCQUFnQixJQUFJLEdBQUcsSUFBSTtDQUM5QztDQUVBLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFDYix3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFmO0lBRUUsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQ2Isd0JBQUMsT0FBRDtRQUFLLEtBQUssS0FBSztRQUFXLEtBQUk7UUFBUyxXQUFVO09BQThCOzs7OztNQUM1RTs7OztnQkFDTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxNQUFEO1FBQUksV0FBVTtrQkFBaUMsS0FBSztPQUFhOzs7O2lCQUNqRSx3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFDYixLQUFLO09BQ0Y7Ozs7ZUFDSDs7Ozs7Z0JBQ0wsd0JBQUMsS0FBRDtPQUFHLFdBQVU7aUJBQTBCLEtBQUs7TUFBUzs7OztjQUNsRDs7OztjQUNGOzs7OztlQUNMLHdCQUFDLFVBQUQ7TUFDRSxTQUFTO01BQ1QsV0FBVTtnQkFDWDtLQUVPOzs7O2FBQ0w7Ozs7OztJQUdMLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWY7TUFDRSx3QkFBQyxVQUFEO09BQ0UsZUFBZSxhQUFhLFNBQVM7T0FDckMsV0FBVyx5Q0FDVCxjQUFjLFlBQ1YseUNBQ0E7aUJBRVA7TUFFTzs7Ozs7TUFDUix3QkFBQyxVQUFEO09BQ0UsZUFBZSxhQUFhLFFBQVE7T0FDcEMsV0FBVyx5Q0FDVCxjQUFjLFdBQ1YseUNBQ0E7aUJBRVA7TUFFTzs7Ozs7TUFDUix3QkFBQyxVQUFEO09BQ0UsZUFBZSxhQUFhLE9BQU87T0FDbkMsV0FBVyx5Q0FDVCxjQUFjLFVBQ1YseUNBQ0E7aUJBRVA7TUFFTzs7Ozs7TUFDUix3QkFBQyxVQUFEO09BQ0UsZUFBZSxhQUFhLFVBQVU7T0FDdEMsV0FBVyx5Q0FDVCxjQUFjLGFBQ1YseUNBQ0E7aUJBRVA7TUFFTzs7Ozs7S0FDTDs7Ozs7O0lBR0osZ0JBQ0Msd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFDWjtJQUNFOzs7OztJQUlOLGNBQWMsYUFDYix3QkFBQyxRQUFEO0tBQU0sVUFBVTtLQUFtQixXQUFVO2VBQTdDO01BRUUsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7T0FBTyxXQUFVO2lCQUE4QztNQUV4RDs7OztnQkFDUCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFDWixrQkFBa0IsS0FBSyxJQUFJLFFBQzFCLHdCQUFDLFVBQUQ7UUFDRSxNQUFLO1FBRUwsZUFBZSxTQUFTLE9BQU87U0FBRSxHQUFHO1NBQUcsV0FBVyxHQUFHO1FBQUksRUFBRTtRQUMzRCxXQUFXLG9GQUNULEtBQUssY0FBYyxHQUFHLE1BQ2xCLDJEQUNBO2tCQUdOLHdCQUFDLE9BQUQ7U0FBSyxLQUFLLEdBQUc7U0FBSyxLQUFLLEdBQUc7U0FBTSxXQUFVO1FBQXlDOzs7OztPQUM3RSxHQVREOzs7O2NBU0MsQ0FDVDtNQUNFOzs7O2NBQ0Y7Ozs7O01BRUwsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7T0FBTyxXQUFVO2lCQUE4QztNQUFlOzs7O2dCQUM5RSx3QkFBQyxTQUFEO09BQ0UsTUFBSztPQUNMLE9BQU87T0FDUCxXQUFXLE1BQU0sZUFBZSxFQUFFLE9BQU8sS0FBSztPQUM5QyxXQUFVO01BQ1g7Ozs7Y0FDRTs7Ozs7TUFFTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDtPQUFPLFdBQVU7aUJBQThDO01BRXhEOzs7O2dCQUNQLHdCQUFDLFNBQUQ7T0FDRSxNQUFLO09BQ0wsT0FBTztPQUNQLFdBQVcsTUFBTSxZQUFZLEVBQUUsT0FBTyxLQUFLO09BQzNDLFdBQVU7TUFDWDs7OztjQUNFOzs7OztNQUVMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUFtQztPQUErQjs7OztpQkFDbEYsd0JBQUMsS0FBRDtRQUFHLFdBQVU7a0JBQWIsQ0FDRyxLQUFLLGdCQUFlLDBCQUNwQjs7Ozs7ZUFDQTs7OztpQkFDTCx3QkFBQyxVQUFEO1FBQ0UsTUFBSztRQUNMLGVBQWU7U0FDYixRQUFRO1NBQ1IsaUJBQWlCO1FBQ25CO1FBQ0EsV0FBVTtrQkFDWDtPQUVPOzs7O2VBQ0w7Ozs7OztNQUVMLHdCQUFDLFVBQUQ7T0FDRSxNQUFLO09BQ0wsV0FBVTtpQkFDWDtNQUVPOzs7OztLQUNKOzs7Ozs7SUFJUCxjQUFjLFlBQ2Isd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLEtBQUQ7TUFBRyxXQUFVO2dCQUFpQjtLQUUzQjs7OztlQUVILHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmO09BQ0Usd0JBQUMsVUFBRDtRQUNFLGVBQWUsaUJBQWlCLFVBQVUsY0FBYztRQUN4RCxXQUFVO2tCQUZaLENBSUUsd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FDRSx3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBVTtTQUFROzs7O21CQUNsQyx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUNFLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUE0QjtVQUE0Qjs7OztvQkFDdkUsd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQTZCO1VBQXdDOzs7O2tCQUNqRjs7Ozs7aUJBQ0Y7Ozs7O2tCQUNMLHdCQUFDLFFBQUQ7U0FBTSxXQUFVO21CQUNiLEtBQUssaUJBQWlCLFdBQVcsaUJBQWlCO1FBQy9DOzs7O2dCQUNBOzs7Ozs7T0FFUix3QkFBQyxVQUFEO1FBQ0UsZUFBZSxpQkFBaUIsV0FBVyxlQUFlO1FBQzFELFdBQVU7a0JBRlosQ0FJRSx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNFLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUFVO1NBQVE7Ozs7bUJBQ2xDLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmLENBQ0Usd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQTRCO1VBQXVCOzs7O29CQUNsRSx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFBNkI7VUFBZ0M7Ozs7a0JBQ3pFOzs7OztpQkFDRjs7Ozs7a0JBQ0wsd0JBQUMsUUFBRDtTQUFNLFdBQVU7bUJBQ2IsS0FBSyxpQkFBaUIsWUFBWSxpQkFBaUI7UUFDaEQ7Ozs7Z0JBQ0E7Ozs7OztPQUVSLHdCQUFDLFVBQUQ7UUFDRSxlQUFlLGlCQUFpQixVQUFVLGFBQWE7UUFDdkQsV0FBVTtrQkFGWixDQUlFLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0Usd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQVU7U0FBUTs7OzttQkFDbEMsd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWYsQ0FDRSx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFBNEI7VUFBc0I7Ozs7b0JBQ2pFLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUE2QjtVQUFpQzs7OztrQkFDMUU7Ozs7O2lCQUNGOzs7OztrQkFDTCx3QkFBQyxRQUFEO1NBQU0sV0FBVTttQkFDYixLQUFLLGlCQUFpQixXQUFXLGlCQUFpQjtRQUMvQzs7OztnQkFDQTs7Ozs7O09BRVIsd0JBQUMsVUFBRDtRQUNFLGVBQWUsaUJBQWlCLFNBQVMsY0FBYztRQUN2RCxXQUFVO2tCQUZaLENBSUUsd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FDRSx3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBVTtTQUFROzs7O21CQUNsQyx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZixDQUNFLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUE0QjtVQUFxQjs7OztvQkFDaEUsd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQTZCO1VBQTZCOzs7O2tCQUN0RTs7Ozs7aUJBQ0Y7Ozs7O2tCQUNMLHdCQUFDLFFBQUQ7U0FBTSxXQUFVO21CQUNiLEtBQUssaUJBQWlCLFVBQVUsaUJBQWlCO1FBQzlDOzs7O2dCQUNBOzs7Ozs7TUFDTDs7Ozs7YUFDRjs7Ozs7O0lBSU4sY0FBYyxXQUNiLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWY7TUFDRSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBNkI7T0FBeUI7Ozs7aUJBQ3RFLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQTZELHFCQUN6QyxJQUFJLEtBQUssS0FBSyxrQkFBa0IsQ0FBQyxDQUFDLG1CQUFtQixDQUNwRTs7Ozs7ZUFDRjs7OztpQkFDTCx3QkFBQyxVQUFEO1FBQ0UsU0FBUztRQUNULFdBQVU7a0JBQ1g7T0FFTzs7OztlQUNMOzs7Ozs7TUFHTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZjtRQUNFLHdCQUFDLE1BQUQ7U0FBSSxXQUFVO21CQUF1QjtRQUFtRDs7Ozs7UUFDeEYsd0JBQUMsS0FBRDtTQUFHLFdBQVU7bUJBQTZCO1FBRXZDOzs7OztRQUNILHdCQUFDLFVBQUQ7U0FDRSxTQUFTO1NBQ1QsV0FBVTttQkFDWDtRQUVPOzs7OztPQUNMOzs7Ozs7TUFHTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZjtRQUNFLHdCQUFDLE1BQUQ7U0FBSSxXQUFVO21CQUF1QjtRQUFpQzs7Ozs7UUFDdEUsd0JBQUMsU0FBRDtTQUNFLE1BQUs7U0FDTCxhQUFZO1NBQ1osT0FBTztTQUNQLFdBQVcsTUFBTSxZQUFZLEVBQUUsT0FBTyxLQUFLO1NBQzNDLFdBQVU7UUFDWDs7Ozs7UUFDRCx3QkFBQyxVQUFEO1NBQ0UsU0FBUztTQUNULFdBQVU7bUJBQ1g7UUFFTzs7Ozs7T0FDTDs7Ozs7O01BR0wsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWY7UUFDRSx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZixDQUNFLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUFZO1NBQVE7Ozs7bUJBQ3BDLHdCQUFDLE1BQUQ7VUFBSSxXQUFVO29CQUEwQjtTQUE2Qjs7OztpQkFDbEU7Ozs7OztRQUNMLHdCQUFDLEtBQUQ7U0FBRyxXQUFVO21CQUFiO1VBQTBEO1VBQ1Esd0JBQUMsUUFBRDtXQUFNLFdBQVU7cUJBQWdCO1VBQWtCOzs7OztVQUFDO1NBQ2xIOzs7Ozs7UUFDSCx3QkFBQyxVQUFEO1NBQ0UsTUFBSztTQUNMLGVBQWU7VUFDYixRQUFRO1VBQ1Isd0JBQXdCO1NBQzFCO1NBQ0EsV0FBVTttQkFOWixDQVFFLHdCQUFDLFFBQUQsWUFBTSxLQUFROzs7O21CQUNkLHdCQUFDLFFBQUQsWUFBTSxzQ0FBeUM7Ozs7aUJBQ3pDOzs7Ozs7T0FDTDs7Ozs7O0tBQ0Y7Ozs7OztJQUlOLGNBQWMsY0FDYix3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmO01BRUUsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQXVCO09BQXNCOzs7O2lCQUM3RCx3QkFBQyxLQUFEO1FBQUcsV0FBVTtrQkFBNkI7T0FBNEM7Ozs7ZUFDbkY7Ozs7aUJBQ0wsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxVQUFEO1NBQ0UsZUFBZSxTQUFTLE9BQU87VUFBRSxHQUFHO1VBQUcsT0FBTztTQUFPLEVBQUU7U0FDdkQsV0FBVywwQkFDVCxLQUFLLFVBQVUsU0FBUywrQkFBK0I7bUJBRTFEO1FBRU87Ozs7a0JBQ1Isd0JBQUMsVUFBRDtTQUNFLGVBQWUsU0FBUyxPQUFPO1VBQUUsR0FBRztVQUFHLE9BQU87U0FBUSxFQUFFO1NBQ3hELFdBQVcsMEJBQ1QsS0FBSyxVQUFVLFVBQVUsK0JBQStCO21CQUUzRDtRQUVPOzs7O2dCQUNMOzs7OztlQUNGOzs7Ozs7TUFHTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBdUI7T0FBb0M7Ozs7aUJBQzNFLHdCQUFDLEtBQUQ7UUFBRyxXQUFVO2tCQUE2QjtPQUFnRDs7OztlQUN2Rjs7OztpQkFDTCx3QkFBQyxTQUFEO1FBQ0UsTUFBSztRQUNMLFNBQVMsS0FBSztRQUNkLFdBQVcsTUFBTTtTQUNmLFNBQVMsT0FBTztVQUFFLEdBQUc7VUFBRyxjQUFjLEVBQUUsT0FBTztTQUFRLEVBQUU7U0FDekQsT0FBTyxTQUFTLENBQUMsRUFBRSxPQUFPLE9BQU87UUFDbkM7UUFDQSxXQUFVO09BQ1g7Ozs7ZUFDRTs7Ozs7O01BR0wsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQXVCO09BQXVCOzs7O2lCQUM5RCx3QkFBQyxLQUFEO1FBQUcsV0FBVTtrQkFBNkI7T0FFdkM7Ozs7ZUFDQTs7OztpQkFDTCx3QkFBQyxTQUFEO1FBQ0UsTUFBSztRQUNMLFNBQVMsS0FBSztRQUNkLFdBQVcsTUFBTSxTQUFTLE9BQU87U0FBRSxHQUFHO1NBQUcsbUJBQW1CLEVBQUUsT0FBTztRQUFRLEVBQUU7UUFDL0UsV0FBVTtPQUNYOzs7O2VBQ0U7Ozs7OztLQUNGOzs7Ozs7R0FFSjs7Ozs7O0NBQ0Y7Ozs7O0FBRVQiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiUHJvZmlsZU1vZGFsLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBVc2VyUHJvZmlsZSB9IGZyb20gJy4uL3R5cGVzL2dhbWUnO1xuaW1wb3J0IHsgQ0FUX0lNQUdFX1VSTCB9IGZyb20gJy4uL2RhdGEvY29uc3RhbnRzJztcbmltcG9ydCB7IHNvdW5kcyB9IGZyb20gJy4uL3V0aWxzL3NvdW5kJztcblxuaW50ZXJmYWNlIFByb2ZpbGVNb2RhbFByb3BzIHtcbiAgdXNlcjogVXNlclByb2ZpbGU7XG4gIHNldFVzZXI6IFJlYWN0LkRpc3BhdGNoPFJlYWN0LlNldFN0YXRlQWN0aW9uPFVzZXJQcm9maWxlPj47XG4gIG9uQ2xvc2U6ICgpID0+IHZvaWQ7XG4gIG9uT3BlblNob3BPcmRlcnM6ICgpID0+IHZvaWQ7XG4gIG9uT3Blbk5ldGxpZnlEb3dubG9hZD86ICgpID0+IHZvaWQ7XG59XG5cbmV4cG9ydCBjb25zdCBQcm9maWxlTW9kYWw6IFJlYWN0LkZDPFByb2ZpbGVNb2RhbFByb3BzPiA9ICh7XG4gIHVzZXIsXG4gIHNldFVzZXIsXG4gIG9uQ2xvc2UsXG4gIG9uT3BlblNob3BPcmRlcnMsXG4gIG9uT3Blbk5ldGxpZnlEb3dubG9hZCxcbn0pID0+IHtcbiAgY29uc3QgW2FjdGl2ZVRhYiwgc2V0QWN0aXZlVGFiXSA9IHVzZVN0YXRlPCdwcm9maWxlJyB8ICdzb2NpYWwnIHwgJ2Nsb3VkJyB8ICdzZXR0aW5ncyc+KCdwcm9maWxlJyk7XG4gIGNvbnN0IFtuZXdVc2VybmFtZSwgc2V0TmV3VXNlcm5hbWVdID0gdXNlU3RhdGUodXNlci51c2VybmFtZSk7XG4gIGNvbnN0IFtuZXdUaXRsZSwgc2V0TmV3VGl0bGVdID0gdXNlU3RhdGUodXNlci50aXRsZSk7XG4gIGNvbnN0IFtzeW5jQ29kZSwgc2V0U3luY0NvZGVdID0gdXNlU3RhdGUoJycpO1xuICBjb25zdCBbc3luY0ZlZWRiYWNrLCBzZXRTeW5jRmVlZGJhY2tdID0gdXNlU3RhdGU8c3RyaW5nIHwgbnVsbD4obnVsbCk7XG5cbiAgY29uc3QgQVZBSUxBQkxFX0FWQVRBUlMgPSBbXG4gICAgeyB1cmw6IENBVF9JTUFHRV9VUkwsIG5hbWU6ICfQmtC+0YIg0LIg0L7Rh9C60LDRhScgfSxcbiAgICB7IHVybDogJ2h0dHBzOi8vYXBpLmRpY2ViZWFyLmNvbS83LngvYm90dHRzL3N2Zz9zZWVkPVJvYmxveE5vb2InLCBuYW1lOiAn0JbQtdC70YLRi9C5INCd0YPQsScgfSxcbiAgICB7IHVybDogJ2h0dHBzOi8vYXBpLmRpY2ViZWFyLmNvbS83LngvYm90dHRzL3N2Zz9zZWVkPUN5YmVyS25pZ2h0JywgbmFtZTogJ9Ca0LjQsdC10YAg0KDRi9GG0LDRgNGMJyB9LFxuICAgIHsgdXJsOiAnaHR0cHM6Ly9hcGkuZGljZWJlYXIuY29tLzcueC9ib3R0dHMvc3ZnP3NlZWQ9TmVvbkNhdCcsIG5hbWU6ICfQndC10L7QvSDQmtC+0YInIH0sXG4gIF07XG5cbiAgY29uc3QgaGFuZGxlU2F2ZVByb2ZpbGUgPSAoZTogUmVhY3QuRm9ybUV2ZW50KSA9PiB7XG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgIHNldFVzZXIoKHByZXYpID0+ICh7XG4gICAgICAuLi5wcmV2LFxuICAgICAgdXNlcm5hbWU6IG5ld1VzZXJuYW1lLnRyaW0oKSB8fCBwcmV2LnVzZXJuYW1lLFxuICAgICAgdGl0bGU6IG5ld1RpdGxlLnRyaW0oKSB8fCBwcmV2LnRpdGxlLFxuICAgIH0pKTtcbiAgICBzb3VuZHMucGxheUNvaW4oKTtcbiAgICBzZXRTeW5jRmVlZGJhY2soJ9Cf0YDQvtGE0LjQu9GMINGD0YHQv9C10YjQvdC+INC+0LHQvdC+0LLQu9C10L0hJyk7XG4gICAgc2V0VGltZW91dCgoKSA9PiBzZXRTeW5jRmVlZGJhY2sobnVsbCksIDI1MDApO1xuICB9O1xuXG4gIGNvbnN0IGhhbmRsZVNvY2lhbEF1dGggPSAocHJvdmlkZXI6IFVzZXJQcm9maWxlWydhdXRoUHJvdmlkZXInXSwgcHJvdmlkZXJOYW1lOiBzdHJpbmcpID0+IHtcbiAgICBzb3VuZHMucGxheVVwZ3JhZGUoKTtcbiAgICBzZXRVc2VyKChwcmV2KSA9PiAoe1xuICAgICAgLi4ucHJldixcbiAgICAgIGF1dGhQcm92aWRlcjogcHJvdmlkZXIsXG4gICAgICB1c2VybmFtZTogYCR7cHJvdmlkZXJOYW1lfV8ke01hdGguZmxvb3IoMTAwICsgTWF0aC5yYW5kb20oKSAqIDkwMCl9YCxcbiAgICB9KSk7XG4gICAgc2V0U3luY0ZlZWRiYWNrKGDQktGLINGD0YHQv9C10YjQvdC+INCw0LLRgtC+0YDQuNC30L7QstCw0LvQuNGB0Ywg0YfQtdGA0LXQtyAke3Byb3ZpZGVyTmFtZX0hINCf0YDQvtGE0LjQu9GMINC/0YDQuNCy0Y/Qt9Cw0L0uYCk7XG4gICAgc2V0VGltZW91dCgoKSA9PiBzZXRTeW5jRmVlZGJhY2sobnVsbCksIDMwMDApO1xuICB9O1xuXG4gIC8vIEV4cG9ydCBzYXZlIGNvZGVcbiAgY29uc3QgaGFuZGxlRXhwb3J0Q2xvdWRTYXZlID0gKCkgPT4ge1xuICAgIGNvbnN0IHJhdyA9IEpTT04uc3RyaW5naWZ5KHVzZXIpO1xuICAgIGNvbnN0IGVuY29kZWQgPSBidG9hKHVuZXNjYXBlKGVuY29kZVVSSUNvbXBvbmVudChyYXcpKSk7XG4gICAgbmF2aWdhdG9yLmNsaXBib2FyZC53cml0ZVRleHQoZW5jb2RlZCk7XG4gICAgc2V0U3luY0ZlZWRiYWNrKCfQmtC+0LQg0L7QsdC70LDRh9C90L7Qs9C+INGB0L7RhdGA0LDQvdC10L3QuNGPINGB0LrQvtC/0LjRgNC+0LLQsNC9INCyINCx0YPRhNC10YAg0L7QsdC80LXQvdCwIScpO1xuICAgIHNldFRpbWVvdXQoKCkgPT4gc2V0U3luY0ZlZWRiYWNrKG51bGwpLCAzMDAwKTtcbiAgfTtcblxuICAvLyBJbXBvcnQgc2F2ZSBjb2RlXG4gIGNvbnN0IGhhbmRsZUltcG9ydENsb3VkU2F2ZSA9ICgpID0+IHtcbiAgICB0cnkge1xuICAgICAgY29uc3QgZGVjb2RlZCA9IGRlY29kZVVSSUNvbXBvbmVudChlc2NhcGUoYXRvYihzeW5jQ29kZS50cmltKCkpKSk7XG4gICAgICBjb25zdCBwYXJzZWQgPSBKU09OLnBhcnNlKGRlY29kZWQpO1xuICAgICAgaWYgKHBhcnNlZCAmJiBwYXJzZWQudXNlcm5hbWUpIHtcbiAgICAgICAgc2V0VXNlcihwYXJzZWQpO1xuICAgICAgICBzb3VuZHMucGxheVZpY3RvcnkoKTtcbiAgICAgICAgc2V0U3luY0ZlZWRiYWNrKCfQlNCw0L3QvdGL0LUg0YPRgdC/0LXRiNC90L4g0LfQsNCz0YDRg9C20LXQvdGLINC40Lcg0L7QsdC70LDRh9C90L7Qs9C+INC60L7QtNCwIScpO1xuICAgICAgICBzZXRUaW1lb3V0KCgpID0+IHNldFN5bmNGZWVkYmFjayhudWxsKSwgMzAwMCk7XG4gICAgICB9XG4gICAgfSBjYXRjaCB7XG4gICAgICBzZXRTeW5jRmVlZGJhY2soJ9Ce0YjQuNCx0LrQsDog0L3QtdCy0LXRgNC90YvQuSDQutC+0LQg0YHQvtGF0YDQsNC90LXQvdC40Y8hJyk7XG4gICAgICBzZXRUaW1lb3V0KCgpID0+IHNldFN5bmNGZWVkYmFjayhudWxsKSwgMzAwMCk7XG4gICAgfVxuICB9O1xuXG4gIGNvbnN0IGhhbmRsZUZvcmNlU3luYyA9ICgpID0+IHtcbiAgICBzZXRVc2VyKChwcmV2KSA9PiAoe1xuICAgICAgLi4ucHJldixcbiAgICAgIGNsb3VkU3luY1RpbWVzdGFtcDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxuICAgIH0pKTtcbiAgICBzb3VuZHMucGxheUNvaW4oKTtcbiAgICBzZXRTeW5jRmVlZGJhY2soJ9Ch0LjQvdGF0YDQvtC90LjQt9Cw0YbQuNGPINGBINC+0LHQu9Cw0YfQvdGL0Lwg0YHQtdGA0LLQtdGA0L7QvCDQt9Cw0LLQtdGA0YjQtdC90LAhJyk7XG4gICAgc2V0VGltZW91dCgoKSA9PiBzZXRTeW5jRmVlZGJhY2sobnVsbCksIDI1MDApO1xuICB9O1xuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJmaXhlZCBpbnNldC0wIHotNTAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgYmctc2xhdGUtOTUwLzg1IGJhY2tkcm9wLWJsdXItbWQgcC00XCI+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXNsYXRlLTkwMCBib3JkZXItMiBib3JkZXItc2xhdGUtNzAwIHJvdW5kZWQtM3hsIHAtNiBtYXgtdy14bCB3LWZ1bGwgc2hhZG93LTJ4bCB0ZXh0LXNsYXRlLTEwMCBtYXgtaC1bOTB2aF0gZmxleCBmbGV4LWNvbFwiPlxuICAgICAgICB7LyogSGVhZGVyICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBwYi00IGJvcmRlci1iIGJvcmRlci1zbGF0ZS04MDBcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIHNwYWNlLXgtM1wiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTEyIGgtMTIgcm91bmRlZC14bCBiZy1zbGF0ZS04MDAgYm9yZGVyLTIgYm9yZGVyLWN5YW4tNDAwIG92ZXJmbG93LWhpZGRlbiBzaHJpbmstMFwiPlxuICAgICAgICAgICAgICA8aW1nIHNyYz17dXNlci5hdmF0YXJVcmx9IGFsdD1cIkF2YXRhclwiIGNsYXNzTmFtZT1cInctZnVsbCBoLWZ1bGwgb2JqZWN0LWNvdmVyXCIgLz5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBzcGFjZS14LTJcIj5cbiAgICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LWJsYWNrIHRleHQtd2hpdGVcIj57dXNlci51c2VybmFtZX08L2gyPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInB4LTIgcHktMC41IHJvdW5kZWQtZnVsbCB0ZXh0LVsxMHB4XSBmb250LWJvbGQgYmctY3lhbi05NTAgdGV4dC1jeWFuLTQwMCBib3JkZXIgYm9yZGVyLWN5YW4tODAwIHVwcGVyY2FzZVwiPlxuICAgICAgICAgICAgICAgICAge3VzZXIuYXV0aFByb3ZpZGVyfVxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS00MDBcIj57dXNlci50aXRsZX08L3A+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICBvbkNsaWNrPXtvbkNsb3NlfVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwidy04IGgtOCByb3VuZGVkLWZ1bGwgYmctc2xhdGUtODAwIGhvdmVyOmJnLXNsYXRlLTcwMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciB0ZXh0LXNsYXRlLTQwMCBob3Zlcjp0ZXh0LXdoaXRlXCJcbiAgICAgICAgICA+XG4gICAgICAgICAgICDinJVcbiAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgey8qIFRhYnMgKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgc3BhY2UteC0yIG15LTQgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTgwMCBwYi0yIHRleHQteHMgZm9udC1ib2xkXCI+XG4gICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0QWN0aXZlVGFiKCdwcm9maWxlJyl9XG4gICAgICAgICAgICBjbGFzc05hbWU9e2BweC0zIHB5LTEuNSByb3VuZGVkLXhsIHRyYW5zaXRpb24tYWxsICR7XG4gICAgICAgICAgICAgIGFjdGl2ZVRhYiA9PT0gJ3Byb2ZpbGUnXG4gICAgICAgICAgICAgICAgPyAnYmctY3lhbi01MDAgdGV4dC1zbGF0ZS05NTAgc2hhZG93LW1kJ1xuICAgICAgICAgICAgICAgIDogJ3RleHQtc2xhdGUtNDAwIGhvdmVyOnRleHQtd2hpdGUnXG4gICAgICAgICAgICB9YH1cbiAgICAgICAgICA+XG4gICAgICAgICAgICDwn5GkINCf0YDQvtGE0LjQu9GMXG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0QWN0aXZlVGFiKCdzb2NpYWwnKX1cbiAgICAgICAgICAgIGNsYXNzTmFtZT17YHB4LTMgcHktMS41IHJvdW5kZWQteGwgdHJhbnNpdGlvbi1hbGwgJHtcbiAgICAgICAgICAgICAgYWN0aXZlVGFiID09PSAnc29jaWFsJ1xuICAgICAgICAgICAgICAgID8gJ2JnLWN5YW4tNTAwIHRleHQtc2xhdGUtOTUwIHNoYWRvdy1tZCdcbiAgICAgICAgICAgICAgICA6ICd0ZXh0LXNsYXRlLTQwMCBob3Zlcjp0ZXh0LXdoaXRlJ1xuICAgICAgICAgICAgfWB9XG4gICAgICAgICAgPlxuICAgICAgICAgICAg8J+UkSDQodC+0YbRgdC10YLQuFxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEFjdGl2ZVRhYignY2xvdWQnKX1cbiAgICAgICAgICAgIGNsYXNzTmFtZT17YHB4LTMgcHktMS41IHJvdW5kZWQteGwgdHJhbnNpdGlvbi1hbGwgJHtcbiAgICAgICAgICAgICAgYWN0aXZlVGFiID09PSAnY2xvdWQnXG4gICAgICAgICAgICAgICAgPyAnYmctY3lhbi01MDAgdGV4dC1zbGF0ZS05NTAgc2hhZG93LW1kJ1xuICAgICAgICAgICAgICAgIDogJ3RleHQtc2xhdGUtNDAwIGhvdmVyOnRleHQtd2hpdGUnXG4gICAgICAgICAgICB9YH1cbiAgICAgICAgICA+XG4gICAgICAgICAgICDimIHvuI8g0J7QsdC70LDQutC+ICYg0KHQuNC90YXRgNC+0L3QuNC30LDRhtC40Y9cbiAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRBY3RpdmVUYWIoJ3NldHRpbmdzJyl9XG4gICAgICAgICAgICBjbGFzc05hbWU9e2BweC0zIHB5LTEuNSByb3VuZGVkLXhsIHRyYW5zaXRpb24tYWxsICR7XG4gICAgICAgICAgICAgIGFjdGl2ZVRhYiA9PT0gJ3NldHRpbmdzJ1xuICAgICAgICAgICAgICAgID8gJ2JnLWN5YW4tNTAwIHRleHQtc2xhdGUtOTUwIHNoYWRvdy1tZCdcbiAgICAgICAgICAgICAgICA6ICd0ZXh0LXNsYXRlLTQwMCBob3Zlcjp0ZXh0LXdoaXRlJ1xuICAgICAgICAgICAgfWB9XG4gICAgICAgICAgPlxuICAgICAgICAgICAg4pqZ77iPINCe0L/RhtC40LhcbiAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgey8qIEZlZWRiYWNrIE1lc3NhZ2UgKi99XG4gICAgICAgIHtzeW5jRmVlZGJhY2sgJiYgKFxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItMyBwLTIuNSBiZy1jeWFuLTk1MC84MCBib3JkZXIgYm9yZGVyLWN5YW4tNTAwIHRleHQtY3lhbi0zMDAgcm91bmRlZC14bCB0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LWNlbnRlciBhbmltYXRlLWluIGZhZGUtaW5cIj5cbiAgICAgICAgICAgIHtzeW5jRmVlZGJhY2t9XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICl9XG5cbiAgICAgICAgey8qIFRhYiAxOiBQcm9maWxlIEN1c3RvbWl6YXRpb24gKi99XG4gICAgICAgIHthY3RpdmVUYWIgPT09ICdwcm9maWxlJyAmJiAoXG4gICAgICAgICAgPGZvcm0gb25TdWJtaXQ9e2hhbmRsZVNhdmVQcm9maWxlfSBjbGFzc05hbWU9XCJmbGV4LTEgb3ZlcmZsb3cteS1hdXRvIHNwYWNlLXktNCBwci0xXCI+XG4gICAgICAgICAgICB7LyogQXZhdGFyIFNlbGVjdG9yICovfVxuICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQteHMgZm9udC1ib2xkIHRleHQtc2xhdGUtNDAwIG1iLTJcIj5cbiAgICAgICAgICAgICAgICDQktGL0LHQtdGA0LjRgtC1INCw0LLQsNGC0LDRgCDQs9C10YDQvtGPOlxuICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIHNwYWNlLXgtM1wiPlxuICAgICAgICAgICAgICAgIHtBVkFJTEFCTEVfQVZBVEFSUy5tYXAoKGF2LCBpZHgpID0+IChcbiAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgIGtleT17aWR4fVxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRVc2VyKChwKSA9PiAoeyAuLi5wLCBhdmF0YXJVcmw6IGF2LnVybCB9KSl9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHctMTQgaC0xNCByb3VuZGVkLTJ4bCBvdmVyZmxvdy1oaWRkZW4gYm9yZGVyLTIgdHJhbnNpdGlvbi1hbGwgcC0wLjUgYmctc2xhdGUtOTUwICR7XG4gICAgICAgICAgICAgICAgICAgICAgdXNlci5hdmF0YXJVcmwgPT09IGF2LnVybFxuICAgICAgICAgICAgICAgICAgICAgICAgPyAnYm9yZGVyLWN5YW4tNDAwIHNjYWxlLTEwNSBzaGFkb3ctbWQgc2hhZG93LWN5YW4tNTAwLzMwJ1xuICAgICAgICAgICAgICAgICAgICAgICAgOiAnYm9yZGVyLXNsYXRlLTgwMCBvcGFjaXR5LTYwIGhvdmVyOm9wYWNpdHktMTAwJ1xuICAgICAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgPGltZyBzcmM9e2F2LnVybH0gYWx0PXthdi5uYW1lfSBjbGFzc05hbWU9XCJ3LWZ1bGwgaC1mdWxsIG9iamVjdC1jb3ZlciByb3VuZGVkLXhsXCIgLz5cbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC14cyBmb250LWJvbGQgdGV4dC1zbGF0ZS00MDAgbWItMVwiPtCd0LjQutC90LXQudC8OjwvbGFiZWw+XG4gICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICB2YWx1ZT17bmV3VXNlcm5hbWV9XG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXROZXdVc2VybmFtZShlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJnLXNsYXRlLTk1MCBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMCByb3VuZGVkLXhsIHB4LTMgcHktMiB0ZXh0LXhzIHRleHQtd2hpdGUgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOmJvcmRlci1jeWFuLTUwMCBmb250LWJvbGRcIlxuICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJibG9jayB0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTQwMCBtYi0xXCI+XG4gICAgICAgICAgICAgICAg0J/QvtGH0LXRgtC90L7QtSDQt9Cy0LDQvdC40LUgLyDQotC40YLRg9C7OlxuICAgICAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgdmFsdWU9e25ld1RpdGxlfVxuICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0TmV3VGl0bGUoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBiZy1zbGF0ZS05NTAgYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAgcm91bmRlZC14bCBweC0zIHB5LTIgdGV4dC14cyB0ZXh0LXdoaXRlIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpib3JkZXItY3lhbi01MDBcIlxuICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0zIGJnLXNsYXRlLTk1MCByb3VuZGVkLTJ4bCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cbiAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LXNsYXRlLTMwMFwiPtCY0YHRgtC+0YDQuNGPINC30LDQutCw0LfQvtCyINC4INC60LXRiNCx0Y3Qujo8L3NwYW4+XG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1zbGF0ZS01MDBcIj5cbiAgICAgICAgICAgICAgICAgIHt1c2VyLmNhc2hiYWNrUG9pbnRzfSDQsdC+0L3Rg9GB0L3Ri9GFINCx0LDQu9C70L7QsiDQutC10YjQsdGN0LrQsFxuICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XG4gICAgICAgICAgICAgICAgICBvbkNsb3NlKCk7XG4gICAgICAgICAgICAgICAgICBvbk9wZW5TaG9wT3JkZXJzKCk7XG4gICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC0zIHB5LTEuNSBiZy1lbWVyYWxkLTYwMCBob3ZlcjpiZy1lbWVyYWxkLTUwMCB0ZXh0LXdoaXRlIHJvdW5kZWQteGwgdGV4dC14cyBmb250LWJvbGRcIlxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAg0J7RgtC60YDRi9GC0Ywg0YfQtdC60LhcbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICB0eXBlPVwic3VibWl0XCJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB5LTIuNSBiZy1jeWFuLTUwMCBob3ZlcjpiZy1jeWFuLTQwMCB0ZXh0LXNsYXRlLTk1MCByb3VuZGVkLXhsIGZvbnQtYmxhY2sgdGV4dC14cyBzaGFkb3ctbWRcIlxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICDQodC+0YXRgNCw0L3QuNGC0Ywg0JjQt9C80LXQvdC10L3QuNGPXG4gICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICA8L2Zvcm0+XG4gICAgICAgICl9XG5cbiAgICAgICAgey8qIFRhYiAyOiBTb2NpYWwgQXV0aCAqL31cbiAgICAgICAge2FjdGl2ZVRhYiA9PT0gJ3NvY2lhbCcgJiYgKFxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xIG92ZXJmbG93LXktYXV0byBzcGFjZS15LTMgcHItMSB0ZXh0LXhzXCI+XG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQwMFwiPlxuICAgICAgICAgICAgICDQn9GA0LjQstGP0LbQuNGC0LUg0YHQvtGG0LjQsNC70YzQvdGD0Y4g0YHQtdGC0Ywg0LTQu9GPINCx0YvRgdGC0YDQvtCz0L4g0LLRhdC+0LTQsCDQsiDQvtC00LjQvSDQutC70LjQuiDQuCDRgdC40L3RhdGA0L7QvdC40LfQsNGG0LjQuCDRgSDQtNGA0YPQs9C40LzQuCDRg9GB0YLRgNC+0LnRgdGC0LLQsNC80Lg6XG4gICAgICAgICAgICA8L3A+XG5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS0yXCI+XG4gICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVTb2NpYWxBdXRoKCdyb2Jsb3gnLCAnUm9ibG94UGxheWVyJyl9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHAtMyByb3VuZGVkLTJ4bCBiZy1zbGF0ZS05NTAgYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAgaG92ZXI6Ym9yZGVyLWN5YW4tNDAwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiB0cmFuc2l0aW9uLWNvbG9yc1wiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIHNwYWNlLXgtM1wiPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14bFwiPvCfn6U8L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtbGVmdFwiPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvbnQtZXh0cmFib2xkIHRleHQtd2hpdGVcIj7QktGF0L7QtCDRh9C10YDQtdC3IFJvYmxveCBPQXV0aDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHRleHQtc2xhdGUtNDAwXCI+0J7RhNC40YbQuNCw0LvRjNC90LDRjyDRgdC40L3RhdGA0L7QvdC40LfQsNGG0LjRjyDQuNC90LLQtdC90YLQsNGA0Y88L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInB4LTIgcHktMSByb3VuZGVkIGJnLXNsYXRlLTgwMCB0ZXh0LXNsYXRlLTMwMCBmb250LWJvbGQgdGV4dC1bMTFweF1cIj5cbiAgICAgICAgICAgICAgICAgIHt1c2VyLmF1dGhQcm92aWRlciA9PT0gJ3JvYmxveCcgPyAn0J/QvtC00LrQu9GO0YfQtdC90L4g4pyTJyA6ICfQktC+0LnRgtC4J31cbiAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuXG4gICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVTb2NpYWxBdXRoKCdkaXNjb3JkJywgJ0Rpc2NvcmRNYXN0ZXInKX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcC0zIHJvdW5kZWQtMnhsIGJnLXNsYXRlLTk1MCBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMCBob3Zlcjpib3JkZXItaW5kaWdvLTQwMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gdHJhbnNpdGlvbi1jb2xvcnNcIlxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBzcGFjZS14LTNcIj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteGxcIj7wn5G+PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWxlZnRcIj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmb250LWV4dHJhYm9sZCB0ZXh0LXdoaXRlXCI+0JLRhdC+0LQg0YfQtdGA0LXQtyBEaXNjb3JkPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC1zbGF0ZS00MDBcIj7QmtC70LDQvdC+0LLRi9C5INCy0L7QudGBINC4INGD0LLQtdC00L7QvNC70LXQvdC40Y88L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInB4LTIgcHktMSByb3VuZGVkIGJnLXNsYXRlLTgwMCB0ZXh0LXNsYXRlLTMwMCBmb250LWJvbGQgdGV4dC1bMTFweF1cIj5cbiAgICAgICAgICAgICAgICAgIHt1c2VyLmF1dGhQcm92aWRlciA9PT0gJ2Rpc2NvcmQnID8gJ9Cf0L7QtNC60LvRjtGH0LXQvdC+IOKckycgOiAn0JLQvtC50YLQuCd9XG4gICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICA8L2J1dHRvbj5cblxuICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlU29jaWFsQXV0aCgnZ29vZ2xlJywgJ0dvb2dsZUdhbWVyJyl9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHAtMyByb3VuZGVkLTJ4bCBiZy1zbGF0ZS05NTAgYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAgaG92ZXI6Ym9yZGVyLXJvc2UtNDAwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiB0cmFuc2l0aW9uLWNvbG9yc1wiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIHNwYWNlLXgtM1wiPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14bFwiPvCfjJA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtbGVmdFwiPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZvbnQtZXh0cmFib2xkIHRleHQtd2hpdGVcIj7QktGF0L7QtCDRh9C10YDQtdC3IEdvb2dsZTwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHRleHQtc2xhdGUtNDAwXCI+R29vZ2xlIFBsYXkgR2FtZXMg0YHQvtGF0YDQsNC90LXQvdC40LU8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInB4LTIgcHktMSByb3VuZGVkIGJnLXNsYXRlLTgwMCB0ZXh0LXNsYXRlLTMwMCBmb250LWJvbGQgdGV4dC1bMTFweF1cIj5cbiAgICAgICAgICAgICAgICAgIHt1c2VyLmF1dGhQcm92aWRlciA9PT0gJ2dvb2dsZScgPyAn0J/QvtC00LrQu9GO0YfQtdC90L4g4pyTJyA6ICfQktC+0LnRgtC4J31cbiAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuXG4gICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVTb2NpYWxBdXRoKCdzdGVhbScsICdTdGVhbVdhcnJpb3InKX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcC0zIHJvdW5kZWQtMnhsIGJnLXNsYXRlLTk1MCBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMCBob3Zlcjpib3JkZXItYmx1ZS00MDAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHRyYW5zaXRpb24tY29sb3JzXCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgc3BhY2UteC0zXCI+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhsXCI+8J+Orjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1sZWZ0XCI+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9udC1leHRyYWJvbGQgdGV4dC13aGl0ZVwiPtCS0YXQvtC0INGH0LXRgNC10LcgU3RlYW08L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB0ZXh0LXNsYXRlLTQwMFwiPtCh0LjQvdGF0YDQvtC90LjQt9Cw0YbQuNGPINC00L7RgdGC0LjQttC10L3QuNC5PC9kaXY+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJweC0yIHB5LTEgcm91bmRlZCBiZy1zbGF0ZS04MDAgdGV4dC1zbGF0ZS0zMDAgZm9udC1ib2xkIHRleHQtWzExcHhdXCI+XG4gICAgICAgICAgICAgICAgICB7dXNlci5hdXRoUHJvdmlkZXIgPT09ICdzdGVhbScgPyAn0J/QvtC00LrQu9GO0YfQtdC90L4g4pyTJyA6ICfQktC+0LnRgtC4J31cbiAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICl9XG5cbiAgICAgICAgey8qIFRhYiAzOiBDbG91ZCBTYXZlICYgQ3Jvc3MtUGxhdGZvcm0gKi99XG4gICAgICAgIHthY3RpdmVUYWIgPT09ICdjbG91ZCcgJiYgKFxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xIG92ZXJmbG93LXktYXV0byBzcGFjZS15LTQgcHItMSB0ZXh0LXhzXCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMyBiZy1lbWVyYWxkLTk1MC80MCBib3JkZXIgYm9yZGVyLWVtZXJhbGQtNTAwLzQwIHJvdW5kZWQtMnhsIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxuICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LWVtZXJhbGQtNDAwXCI+4pePINCe0LHQu9Cw0LrQviDQn9C+0LTQutC70Y7Rh9C10L3Qvjwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtc2xhdGUtNDAwIGZvbnQtbW9ubyBtdC0wLjVcIj5cbiAgICAgICAgICAgICAgICAgINCf0L7RgdC70LXQtNC90LjQuSDQsdGN0LrQsNC/OiB7bmV3IERhdGUodXNlci5jbG91ZFN5bmNUaW1lc3RhbXApLnRvTG9jYWxlVGltZVN0cmluZygpfVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZUZvcmNlU3luY31cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC0zIHB5LTEuNSBiZy1lbWVyYWxkLTYwMCBob3ZlcjpiZy1lbWVyYWxkLTUwMCB0ZXh0LXdoaXRlIHJvdW5kZWQteGwgZm9udC1ib2xkXCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgINCh0LjQvdGF0YDQvtC90LjQt9C40YDQvtCy0LDRgtGMXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIHsvKiBFeHBvcnQgKi99XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMyBiZy1zbGF0ZS05NTAgcm91bmRlZC0yeGwgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgc3BhY2UteS0yXCI+XG4gICAgICAgICAgICAgIDxoNCBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC13aGl0ZVwiPtCa0YDQvtGB0YHQv9C70LDRgtGE0L7RgNC80LXQvdC90YvQuSDQutC+0LQg0YHQvtGF0YDQsNC90LXQvdC40Y8gKFBDIC8gTW9iaWxlKTwvaDQ+XG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNDAwIHRleHQtWzExcHhdXCI+XG4gICAgICAgICAgICAgICAg0JjRgdC/0L7Qu9GM0LfRg9C50YLQtSDRjdGC0L7RgiDQutC+0LQsINGH0YLQvtCx0Ysg0LzQs9C90L7QstC10L3QvdC+INC/0LXRgNC10L3QtdGB0YLQuCDRgdCy0L7QuSDQv9GA0L7Qs9GA0LXRgdGBINC90LAg0YLQtdC70LXRhNC+0L0g0LjQu9C4INC00YDRg9Cz0L7QuSDQsdGA0LDRg9C30LXRgDpcbiAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlRXhwb3J0Q2xvdWRTYXZlfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweS0yIGJnLXNsYXRlLTgwMCBob3ZlcjpiZy1zbGF0ZS03MDAgdGV4dC1jeWFuLTMwMCByb3VuZGVkLXhsIGZvbnQtYm9sZFwiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICDwn5OLINCh0LrQvtC/0LjRgNC+0LLQsNGC0Ywg0J7QsdC70LDRh9C90YvQuSDQmtC+0LRcbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgey8qIEltcG9ydCAqL31cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0zIGJnLXNsYXRlLTk1MCByb3VuZGVkLTJ4bCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCBzcGFjZS15LTJcIj5cbiAgICAgICAgICAgICAgPGg0IGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LXdoaXRlXCI+0JfQsNCz0YDRg9C30LjRgtGMINGB0L7RhdGA0LDQvdC10L3QuNC1INC/0L4g0LrQvtC00YM6PC9oND5cbiAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwi0JLRgdGC0LDQstGM0YLQtSDRgdC60L7Qv9C40YDQvtCy0LDQvdC90YvQuSDQutC+0LQg0YHQvtGF0YDQsNC90LXQvdC40Y8uLi5cIlxuICAgICAgICAgICAgICAgIHZhbHVlPXtzeW5jQ29kZX1cbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFN5bmNDb2RlKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctc2xhdGUtOTAwIGJvcmRlciBib3JkZXItc2xhdGUtNzAwIHJvdW5kZWQteGwgcHgtMyBweS0xLjUgdGV4dC14cyB0ZXh0LXdoaXRlIGZvbnQtbW9ubyBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6Ym9yZGVyLWN5YW4tNTAwXCJcbiAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZUltcG9ydENsb3VkU2F2ZX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHktMiBiZy1jeWFuLTYwMCBob3ZlcjpiZy1jeWFuLTUwMCB0ZXh0LXdoaXRlIHJvdW5kZWQteGwgZm9udC1ib2xkXCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIPCfk6Ug0JfQsNCz0YDRg9C30LjRgtGMINCU0LDQvdC90YvQtVxuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICB7LyogTmV0bGlmeSBFeHBvcnQgQ2FyZCAqL31cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0zIGJnLXRlYWwtOTUwLzQwIGJvcmRlciBib3JkZXItdGVhbC01MDAvNDAgcm91bmRlZC0yeGwgc3BhY2UteS0yXCI+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgc3BhY2UteC0yXCI+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1iYXNlXCI+8J+MkDwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtdGVhbC0zMDBcIj7QlNC10L/Qu9C+0Lkg0L/RgNC+0LXQutGC0LAg0L3QsCBOZXRsaWZ5PC9oND5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtNDAwIHRleHQtWzExcHhdIGxlYWRpbmctcmVsYXhlZFwiPlxuICAgICAgICAgICAgICAgINCh0LrQsNGH0LDQudGC0LUg0L/QvtC70L3Ri9C5INCz0L7RgtC+0LLRi9C5INCw0YDRhdC40LIg0YHQviDQstGB0LXQvNC4INGE0LDQudC70LDQvNC4INC40LPRgNGLLCDQsNGB0YHQtdGC0LDQvNC4INC4IDxjb2RlIGNsYXNzTmFtZT1cInRleHQtdGVhbC0zMDBcIj5uZXRsaWZ5LnRvbWw8L2NvZGU+INC00LvRjyDQvNCz0L3QvtCy0LXQvdC90L7Qs9C+INGA0LDQt9Cy0LXRgNGC0YvQstCw0L3QuNGPINC90LAgTmV0bGlmeTpcbiAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xuICAgICAgICAgICAgICAgICAgb25DbG9zZSgpO1xuICAgICAgICAgICAgICAgICAgb25PcGVuTmV0bGlmeURvd25sb2FkPy4oKTtcbiAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBweS0yLjUgYmctZ3JhZGllbnQtdG8tciBmcm9tLXRlYWwtNTAwIHRvLWVtZXJhbGQtNjAwIGhvdmVyOmZyb20tdGVhbC00MDAgaG92ZXI6dG8tZW1lcmFsZC01MDAgdGV4dC1zbGF0ZS05NTAgcm91bmRlZC14bCBmb250LWJsYWNrIHRleHQteHMgc2hhZG93LW1kIHRyYW5zaXRpb24tYWxsIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHNwYWNlLXgtMS41IGN1cnNvci1wb2ludGVyIGFjdGl2ZTpzY2FsZS05NVwiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICA8c3Bhbj7wn5OmPC9zcGFuPlxuICAgICAgICAgICAgICAgIDxzcGFuPtCh0LrQsNGH0LDRgtGMINCy0YHQtSDRhNCw0LnQu9GLINC00LvRjyBOZXRsaWZ5IChaSVApPC9zcGFuPlxuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICApfVxuXG4gICAgICAgIHsvKiBUYWIgNDogU2V0dGluZ3MgKi99XG4gICAgICAgIHthY3RpdmVUYWIgPT09ICdzZXR0aW5ncycgJiYgKFxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xIG92ZXJmbG93LXktYXV0byBzcGFjZS15LTMgcHItMSB0ZXh0LXhzXCI+XG4gICAgICAgICAgICB7LyogVGhlbWUgKi99XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMyBiZy1zbGF0ZS05NTAgcm91bmRlZC0yeGwgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuXCI+XG4gICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtd2hpdGVcIj7QotC10LzQsCDQvtGE0L7RgNC80LvQtdC90LjRjzo8L3NwYW4+XG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1zbGF0ZS00MDBcIj7QotC10LzQvdGL0Lkg0YHRgtC40LvRjCBSb2Jsb3gg0YEg0L3QtdC+0L3QvtCy0YvQvNC4INCw0LrRhtC10L3RgtCw0LzQuDwvcD5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBzcGFjZS14LTEgZm9udC1ib2xkXCI+XG4gICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0VXNlcigocCkgPT4gKHsgLi4ucCwgdGhlbWU6ICdkYXJrJyB9KSl9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BweC0yLjUgcHktMSByb3VuZGVkLWxnICR7XG4gICAgICAgICAgICAgICAgICAgIHVzZXIudGhlbWUgPT09ICdkYXJrJyA/ICdiZy1jeWFuLTUwMCB0ZXh0LXNsYXRlLTk1MCcgOiAnYmctc2xhdGUtODAwIHRleHQtc2xhdGUtNDAwJ1xuICAgICAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgRGFya1xuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFVzZXIoKHApID0+ICh7IC4uLnAsIHRoZW1lOiAnY3liZXInIH0pKX1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHB4LTIuNSBweS0xIHJvdW5kZWQtbGcgJHtcbiAgICAgICAgICAgICAgICAgICAgdXNlci50aGVtZSA9PT0gJ2N5YmVyJyA/ICdiZy1jeWFuLTUwMCB0ZXh0LXNsYXRlLTk1MCcgOiAnYmctc2xhdGUtODAwIHRleHQtc2xhdGUtNDAwJ1xuICAgICAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgQ3liZXJcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgey8qIFNvdW5kIEZYICovfVxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTMgYmctc2xhdGUtOTUwIHJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItc2xhdGUtODAwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxuICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LXdoaXRlXCI+0JfQstGD0LrQvtCy0YvQtSDRjdGE0YTQtdC60YLRiyDQsdCw0YjQtdC9INC4INC60L7RgtCwOjwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LXNsYXRlLTQwMFwiPtCh0LjQvdGC0LXQt9Cw0YLQvtGAINC30LLRg9C60L7QsiDQu9Cw0LfQtdGA0L7Qsiwg0LzRj9GD0LrQsNC90YzRjyDQuCDQstC30YDRi9Cy0L7QsjwvcD5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgIHR5cGU9XCJjaGVja2JveFwiXG4gICAgICAgICAgICAgICAgY2hlY2tlZD17dXNlci5zb3VuZEVuYWJsZWR9XG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiB7XG4gICAgICAgICAgICAgICAgICBzZXRVc2VyKChwKSA9PiAoeyAuLi5wLCBzb3VuZEVuYWJsZWQ6IGUudGFyZ2V0LmNoZWNrZWQgfSkpO1xuICAgICAgICAgICAgICAgICAgc291bmRzLnNldE11dGVkKCFlLnRhcmdldC5jaGVja2VkKTtcbiAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctNSBoLTUgYWNjZW50LWN5YW4tNTAwIGN1cnNvci1wb2ludGVyXCJcbiAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICB7LyogUHVzaCBub3RpZmljYXRpb25zICovfVxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTMgYmctc2xhdGUtOTUwIHJvdW5kZWQtMnhsIGJvcmRlciBib3JkZXItc2xhdGUtODAwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxuICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LXdoaXRlXCI+UHVzaC3Rg9Cy0LXQtNC+0LzQu9C10L3QuNGPOjwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSB0ZXh0LXNsYXRlLTQwMFwiPlxuICAgICAgICAgICAgICAgICAg0J7Qv9C+0LLQtdGJ0LXQvdC40Y8g0L7QsSDQsNC60YbQuNGP0YUsINGB0YLQsNGC0YPRgdCw0YUg0LTQvtGB0YLQsNCy0LrQuCDQt9Cw0LrQsNC30L7QsiDQuCDQtdC20LXQvdC10LTQtdC70YzQvdGL0YUg0LjRgdC/0YvRgtCw0L3QuNGP0YVcbiAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICB0eXBlPVwiY2hlY2tib3hcIlxuICAgICAgICAgICAgICAgIGNoZWNrZWQ9e3VzZXIucHVzaE5vdGlmaWNhdGlvbnN9XG4gICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRVc2VyKChwKSA9PiAoeyAuLi5wLCBwdXNoTm90aWZpY2F0aW9uczogZS50YXJnZXQuY2hlY2tlZCB9KSl9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy01IGgtNSBhY2NlbnQtY3lhbi01MDAgY3Vyc29yLXBvaW50ZXJcIlxuICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICl9XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgKTtcbn07XG4iXX0=