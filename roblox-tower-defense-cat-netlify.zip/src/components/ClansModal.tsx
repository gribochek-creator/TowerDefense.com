const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=1e19e0c2";
import { sounds } from "/src/utils/sound.ts";
var _jsxFileName = "/app/applet/src/components/ClansModal.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=1e19e0c2";
export const ClansModal = ({ user, setUser, clans, setClans, chat, setChat, onClose, onTriggerSecretKekc }) => {
	const [activeTab, setActiveTab] = useState("myclan");
	const [newClanName, setNewClanName] = useState("");
	const [newClanTag, setNewClanTag] = useState("");
	const [newClanDesc, setNewClanDesc] = useState("");
	const [chatInput, setChatInput] = useState("");
	const currentClan = clans.find((c) => c.id === user.clanId) || null;
	const handleJoinClan = (clan) => {
		setUser((prev) => ({
			...prev,
			clanId: clan.id,
			clanName: clan.name,
			clanRole: "member"
		}));
		setChat((prev) => [...prev, {
			id: "sys_" + Math.random(),
			sender: "Система",
			role: "Уведомление",
			message: `${user.username} вступил в ряды клана!`,
			timestamp: "Только что",
			isSystem: true
		}]);
		sounds.playUpgrade();
		setActiveTab("myclan");
	};
	const handleLeaveClan = () => {
		setUser((prev) => ({
			...prev,
			clanId: null,
			clanName: null,
			clanRole: null
		}));
		sounds.playCoin();
		setActiveTab("browse");
	};
	const handleCreateClan = (e) => {
		e.preventDefault();
		if (!newClanName.trim() || !newClanTag.trim()) return;
		if (user.coins < 1e3) {
			alert("Для основания клана требуется 1,000 монет!");
			return;
		}
		const newClan = {
			id: "clan_" + Math.random().toString(36).substr(2, 9),
			name: newClanName.trim(),
			tag: newClanTag.trim().toUpperCase(),
			badge: "👑⚔️",
			description: newClanDesc.trim() || "Новый клан защитников Роблокса",
			level: 1,
			xp: 0,
			membersCount: 1,
			maxMembers: 20,
			leaderName: user.username,
			ratingScore: 1e3,
			perks: {
				bonusGoldPercent: 5,
				bonusDamagePercent: 3
			},
			weeklyQuest: {
				title: "Уничтожить 500 врагов в коопе",
				progress: 0,
				goal: 500,
				rewardGems: 100
			}
		};
		setClans((prev) => [newClan, ...prev]);
		setUser((prev) => ({
			...prev,
			coins: prev.coins - 1e3,
			clanId: newClan.id,
			clanName: newClan.name,
			clanRole: "leader"
		}));
		sounds.playVictory();
		setActiveTab("myclan");
	};
	const handleSendChatMessage = (e) => {
		e.preventDefault();
		if (!chatInput.trim()) return;
		const lower = chatInput.trim().toLowerCase();
		if (lower === "го kekc" || lower === "го кекс" || lower === "kekc" || lower === "кекс") {
			if (onTriggerSecretKekc) {
				onTriggerSecretKekc();
			}
		}
		const newMsg = {
			id: "msg_" + Math.random().toString(),
			sender: user.username,
			role: user.clanRole === "leader" ? "Лидер" : user.clanRole === "officer" ? "Офицер" : "Боец",
			message: chatInput.trim(),
			timestamp: new Date().toLocaleTimeString([], {
				hour: "2-digit",
				minute: "2-digit"
			})
		};
		setChat((prev) => [...prev, newMsg]);
		setChatInput("");
		sounds.playCoin();
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "fixed inset-0 z-50 flex items-center justify-center bg-slate-950/85 backdrop-blur-md p-4",
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: "bg-slate-900 border-2 border-indigo-500/40 rounded-3xl p-6 max-w-3xl w-full shadow-2xl text-slate-100 max-h-[90vh] flex flex-col",
			children: [
				/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center justify-between pb-4 border-b border-slate-800",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center space-x-3",
						children: [/* @__PURE__ */ _jsxDEV("span", {
							className: "text-3xl",
							children: "🏰"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 145,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h2", {
							className: "text-xl font-black text-indigo-400",
							children: "Система Кланов"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 147,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("p", {
							className: "text-xs text-slate-400",
							children: "Общие бонусы к золоту и урону, клановые рейды и закрытый чат"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 148,
							columnNumber: 15
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 146,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 144,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("button", {
						onClick: onClose,
						className: "w-8 h-8 rounded-full bg-slate-800 hover:bg-slate-700 flex items-center justify-center text-slate-400 hover:text-white",
						children: "✕"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 153,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 143,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center space-x-2 my-4 border-b border-slate-800 pb-2",
					children: [
						/* @__PURE__ */ _jsxDEV("button", {
							onClick: () => setActiveTab("myclan"),
							className: `px-4 py-2 rounded-xl text-xs font-bold transition-all ${activeTab === "myclan" ? "bg-indigo-600 text-white shadow-md" : "text-slate-400 hover:text-white hover:bg-slate-800"}`,
							children: ["🛡️ Мой Клан ", currentClan ? `[${currentClan.tag}]` : ""]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 163,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("button", {
							onClick: () => setActiveTab("browse"),
							className: `px-4 py-2 rounded-xl text-xs font-bold transition-all ${activeTab === "browse" ? "bg-indigo-600 text-white shadow-md" : "text-slate-400 hover:text-white hover:bg-slate-800"}`,
							children: [
								"📜 Список Кланов (",
								clans.length,
								")"
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 173,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("button", {
							onClick: () => setActiveTab("create"),
							className: `px-4 py-2 rounded-xl text-xs font-bold transition-all ${activeTab === "create" ? "bg-indigo-600 text-white shadow-md" : "text-slate-400 hover:text-white hover:bg-slate-800"}`,
							children: "⚔️ Создать Свой Клан"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 183,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 162,
					columnNumber: 9
				}, this),
				activeTab === "myclan" && /* @__PURE__ */ _jsxDEV("div", {
					className: "flex-1 overflow-y-auto pr-1 space-y-4",
					children: currentClan ? /* @__PURE__ */ _jsxDEV("div", {
						className: "space-y-4",
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "p-4 bg-slate-950/80 border border-indigo-500/30 rounded-2xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3",
								children: [/* @__PURE__ */ _jsxDEV("div", { children: [
									/* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-center space-x-2",
										children: [
											/* @__PURE__ */ _jsxDEV("span", {
												className: "text-2xl",
												children: currentClan.badge
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 204,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("h3", {
												className: "text-lg font-black text-white",
												children: [
													currentClan.name,
													" ",
													/* @__PURE__ */ _jsxDEV("span", {
														className: "text-indigo-400 font-mono",
														children: [
															"[",
															currentClan.tag,
															"]"
														]
													}, void 0, true, {
														fileName: _jsxFileName,
														lineNumber: 207,
														columnNumber: 25
													}, this)
												]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 205,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ _jsxDEV("span", {
												className: "px-2 py-0.5 rounded-full text-[10px] font-bold bg-indigo-950 text-indigo-300 border border-indigo-700",
												children: ["Ур. ", currentClan.level]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 209,
												columnNumber: 23
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 203,
										columnNumber: 21
									}, this),
									/* @__PURE__ */ _jsxDEV("p", {
										className: "text-xs text-slate-400 mt-1",
										children: currentClan.description
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 213,
										columnNumber: 21
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "text-[11px] text-slate-500 mt-1",
										children: [
											"Лидер: ",
											/* @__PURE__ */ _jsxDEV("b", {
												className: "text-slate-300",
												children: currentClan.leaderName
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 215,
												columnNumber: 30
											}, this),
											" • Участники:",
											" ",
											/* @__PURE__ */ _jsxDEV("b", {
												className: "text-slate-300",
												children: [
													currentClan.membersCount,
													" / ",
													currentClan.maxMembers
												]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 216,
												columnNumber: 23
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 214,
										columnNumber: 21
									}, this)
								] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 202,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("button", {
									onClick: handleLeaveClan,
									className: "px-3 py-1.5 rounded-xl text-xs font-bold bg-rose-950/60 text-rose-300 border border-rose-800/40 hover:bg-rose-900",
									children: "Покинуть клан"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 222,
									columnNumber: 19
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 201,
								columnNumber: 17
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "grid grid-cols-1 sm:grid-cols-2 gap-3",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "p-3 bg-slate-950/70 border border-slate-800 rounded-2xl",
									children: [/* @__PURE__ */ _jsxDEV("span", {
										className: "text-xs font-bold text-amber-400 uppercase",
										children: "⚡ Активные пассивные бонусы:"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 234,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("ul", {
										className: "mt-2 space-y-1 text-xs text-slate-300",
										children: [/* @__PURE__ */ _jsxDEV("li", { children: [
											"• +",
											currentClan.perks.bonusGoldPercent,
											"% золота за прохождение волн"
										] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 238,
											columnNumber: 23
										}, this), /* @__PURE__ */ _jsxDEV("li", { children: [
											"• +",
											currentClan.perks.bonusDamagePercent,
											"% базового урона всех башен"
										] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 239,
											columnNumber: 23
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 237,
										columnNumber: 21
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 233,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "p-3 bg-slate-950/70 border border-slate-800 rounded-2xl",
									children: [
										/* @__PURE__ */ _jsxDEV("div", {
											className: "flex items-center justify-between",
											children: [/* @__PURE__ */ _jsxDEV("span", {
												className: "text-xs font-bold text-cyan-400 uppercase",
												children: "🎯 Еженедельный Квест:"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 246,
												columnNumber: 23
											}, this), /* @__PURE__ */ _jsxDEV("span", {
												className: "text-xs font-mono font-bold text-amber-400",
												children: [
													"+",
													currentClan.weeklyQuest.rewardGems,
													" 💎"
												]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 249,
												columnNumber: 23
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 245,
											columnNumber: 21
										}, this),
										/* @__PURE__ */ _jsxDEV("p", {
											className: "text-xs text-slate-200 mt-1 font-semibold",
											children: currentClan.weeklyQuest.title
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 253,
											columnNumber: 21
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "mt-2",
											children: [/* @__PURE__ */ _jsxDEV("div", {
												className: "flex justify-between text-[11px] font-mono text-slate-400",
												children: [/* @__PURE__ */ _jsxDEV("span", { children: "Прогресс" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 258,
													columnNumber: 25
												}, this), /* @__PURE__ */ _jsxDEV("span", { children: [
													currentClan.weeklyQuest.progress,
													" / ",
													currentClan.weeklyQuest.goal
												] }, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 259,
													columnNumber: 25
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 257,
												columnNumber: 23
											}, this), /* @__PURE__ */ _jsxDEV("div", {
												className: "w-full h-2 bg-slate-800 rounded-full overflow-hidden mt-1",
												children: /* @__PURE__ */ _jsxDEV("div", {
													className: "h-full bg-cyan-500 rounded-full",
													style: { width: `${Math.min(100, currentClan.weeklyQuest.progress / currentClan.weeklyQuest.goal * 100)}%` }
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 264,
													columnNumber: 25
												}, this)
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 263,
												columnNumber: 23
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 256,
											columnNumber: 21
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 244,
									columnNumber: 19
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 231,
								columnNumber: 17
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "p-3 bg-slate-950/80 border border-slate-800 rounded-2xl flex flex-col h-56",
								children: [
									/* @__PURE__ */ _jsxDEV("span", {
										className: "text-xs font-bold text-slate-400 mb-2",
										children: "💬 Чат Клана:"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 280,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "flex-1 overflow-y-auto space-y-1.5 pr-2 text-xs",
										children: chat.map((msg) => /* @__PURE__ */ _jsxDEV("div", {
											className: `p-1.5 rounded-lg ${msg.isSystem ? "bg-indigo-950/50 text-indigo-300 text-center font-semibold" : "bg-slate-900"}`,
											children: [!msg.isSystem && /* @__PURE__ */ _jsxDEV("div", {
												className: "flex items-center justify-between text-[10px] text-slate-400",
												children: [/* @__PURE__ */ _jsxDEV("span", {
													className: "font-bold text-cyan-400",
													children: [
														"[",
														msg.role,
														"] ",
														msg.sender
													]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 293,
													columnNumber: 29
												}, this), /* @__PURE__ */ _jsxDEV("span", {
													className: "font-mono",
													children: msg.timestamp
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 296,
													columnNumber: 29
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 292,
												columnNumber: 27
											}, this), /* @__PURE__ */ _jsxDEV("p", {
												className: "text-slate-200 mt-0.5",
												children: msg.message
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 299,
												columnNumber: 25
											}, this)]
										}, msg.id, true, {
											fileName: _jsxFileName,
											lineNumber: 283,
											columnNumber: 23
										}, this))
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 281,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("form", {
										onSubmit: handleSendChatMessage,
										className: "mt-2 flex space-x-2",
										children: [/* @__PURE__ */ _jsxDEV("input", {
											type: "text",
											value: chatInput,
											onChange: (e) => setChatInput(e.target.value),
											placeholder: "Написать сообщение соклановцам...",
											className: "flex-1 bg-slate-900 border border-slate-700 rounded-xl px-3 py-1.5 text-xs text-white focus:outline-none focus:border-indigo-500"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 305,
											columnNumber: 21
										}, this), /* @__PURE__ */ _jsxDEV("button", {
											type: "submit",
											className: "px-4 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-bold",
											children: "Отправить"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 312,
											columnNumber: 21
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 304,
										columnNumber: 19
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 279,
								columnNumber: 17
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 199,
						columnNumber: 15
					}, this) : /* @__PURE__ */ _jsxDEV("div", {
						className: "text-center p-8 bg-slate-950/50 rounded-2xl border border-slate-800",
						children: [
							/* @__PURE__ */ _jsxDEV("span", {
								className: "text-4xl mb-2 block",
								children: "🏰"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 323,
								columnNumber: 17
							}, this),
							/* @__PURE__ */ _jsxDEV("h3", {
								className: "font-black text-lg text-white",
								children: "Вы еще не состоите в клане"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 324,
								columnNumber: 17
							}, this),
							/* @__PURE__ */ _jsxDEV("p", {
								className: "text-xs text-slate-400 max-w-sm mx-auto mt-1 mb-4",
								children: "Вступайте в существующий клан из списка или создайте свой собственный, чтобы получать бонусы к золоту и прокачке!"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 325,
								columnNumber: 17
							}, this),
							/* @__PURE__ */ _jsxDEV("button", {
								onClick: () => setActiveTab("browse"),
								className: "px-5 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl font-bold text-xs",
								children: "Выбрать Клан"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 329,
								columnNumber: 17
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 322,
						columnNumber: 15
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 197,
					columnNumber: 11
				}, this),
				activeTab === "browse" && /* @__PURE__ */ _jsxDEV("div", {
					className: "flex-1 overflow-y-auto pr-1 space-y-2.5",
					children: clans.map((clan) => /* @__PURE__ */ _jsxDEV("div", {
						className: "p-3.5 bg-slate-950/70 border border-slate-800 hover:border-slate-700 rounded-2xl flex items-center justify-between",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center space-x-3",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "text-2xl",
								children: clan.badge
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 349,
								columnNumber: 19
							}, this), /* @__PURE__ */ _jsxDEV("div", { children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center space-x-2",
									children: [
										/* @__PURE__ */ _jsxDEV("h4", {
											className: "font-extrabold text-sm text-white",
											children: clan.name
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 352,
											columnNumber: 23
										}, this),
										/* @__PURE__ */ _jsxDEV("span", {
											className: "text-xs font-mono font-bold text-indigo-400",
											children: [
												"[",
												clan.tag,
												"]"
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 353,
											columnNumber: 23
										}, this),
										/* @__PURE__ */ _jsxDEV("span", {
											className: "text-[10px] px-1.5 py-0.2 bg-slate-800 text-slate-300 rounded",
											children: ["Ур. ", clan.level]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 354,
											columnNumber: 23
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 351,
									columnNumber: 21
								}, this),
								/* @__PURE__ */ _jsxDEV("p", {
									className: "text-xs text-slate-400 mt-0.5",
									children: clan.description
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 358,
									columnNumber: 21
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "text-[11px] text-slate-500 mt-0.5",
									children: [
										"Лидер: ",
										clan.leaderName,
										" • Участники: ",
										clan.membersCount,
										"/",
										clan.maxMembers
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 359,
									columnNumber: 21
								}, this)
							] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 350,
								columnNumber: 19
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 348,
							columnNumber: 17
						}, this), user.clanId === clan.id ? /* @__PURE__ */ _jsxDEV("span", {
							className: "text-xs font-bold text-indigo-400 px-3 py-1 bg-indigo-950 rounded-xl",
							children: "Ваш клан ✓"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 366,
							columnNumber: 19
						}, this) : /* @__PURE__ */ _jsxDEV("button", {
							onClick: () => handleJoinClan(clan),
							className: "px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-bold",
							children: "Вступить"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 370,
							columnNumber: 19
						}, this)]
					}, clan.id, true, {
						fileName: _jsxFileName,
						lineNumber: 344,
						columnNumber: 15
					}, this))
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 342,
					columnNumber: 11
				}, this),
				activeTab === "create" && /* @__PURE__ */ _jsxDEV("form", {
					onSubmit: handleCreateClan,
					className: "flex-1 overflow-y-auto pr-1 space-y-4",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "p-4 bg-indigo-950/40 border border-indigo-600/30 rounded-2xl text-xs text-indigo-200",
							children: [
								"💡 Создание клана стоит ",
								/* @__PURE__ */ _jsxDEV("b", {
									className: "text-amber-400 font-mono",
									children: "1,000 монет"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 386,
									columnNumber: 39
								}, this),
								". Лидер может приглашать игроков, настраивать герб и распределять награды за квесты."
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 385,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-3",
							children: [
								/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
									className: "block text-xs font-bold text-slate-400 mb-1",
									children: "Название клана:"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 392,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("input", {
									type: "text",
									required: true,
									placeholder: "Например: Легенды Мяу",
									value: newClanName,
									onChange: (e) => setNewClanName(e.target.value),
									className: "w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-indigo-500"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 395,
									columnNumber: 17
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 391,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
									className: "block text-xs font-bold text-slate-400 mb-1",
									children: "Клановый тег (до 5 символов):"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 406,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("input", {
									type: "text",
									maxLength: 5,
									required: true,
									placeholder: "MEOW",
									value: newClanTag,
									onChange: (e) => setNewClanTag(e.target.value),
									className: "w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white uppercase focus:outline-none focus:border-indigo-500 font-mono"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 409,
									columnNumber: 17
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 405,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
									className: "block text-xs font-bold text-slate-400 mb-1",
									children: "Девиз / Описание:"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 421,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("textarea", {
									rows: 3,
									placeholder: "Опишите цели вашего клана...",
									value: newClanDesc,
									onChange: (e) => setNewClanDesc(e.target.value),
									className: "w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-indigo-500"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 424,
									columnNumber: 17
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 420,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 390,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("button", {
							type: "submit",
							className: "w-full py-3 bg-gradient-to-r from-indigo-500 to-purple-600 hover:from-indigo-400 hover:to-purple-500 text-white rounded-xl font-black text-sm shadow-xl active:scale-95 transition-transform",
							children: "Основать Клан за 1,000 🪙"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 434,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 384,
					columnNumber: 11
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 141,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 140,
		columnNumber: 5
	}, this);
};

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLGdCQUFnQjtBQUVoQyxTQUFTLGNBQWM7OztBQWF2QixPQUFPLE1BQU0sY0FBeUMsRUFDcEQsTUFDQSxTQUNBLE9BQ0EsVUFDQSxNQUNBLFNBQ0EsU0FDQSwwQkFDSTtDQUNKLE1BQU0sQ0FBQyxXQUFXLGdCQUFnQixTQUF5QyxRQUFRO0NBQ25GLE1BQU0sQ0FBQyxhQUFhLGtCQUFrQixTQUFTLEVBQUU7Q0FDakQsTUFBTSxDQUFDLFlBQVksaUJBQWlCLFNBQVMsRUFBRTtDQUMvQyxNQUFNLENBQUMsYUFBYSxrQkFBa0IsU0FBUyxFQUFFO0NBQ2pELE1BQU0sQ0FBQyxXQUFXLGdCQUFnQixTQUFTLEVBQUU7Q0FFN0MsTUFBTSxjQUFjLE1BQU0sTUFBTSxNQUFNLEVBQUUsT0FBTyxLQUFLLE1BQU0sS0FBSztDQUUvRCxNQUFNLGtCQUFrQixTQUFlO0VBQ3JDLFNBQVMsVUFBVTtHQUNqQixHQUFHO0dBQ0gsUUFBUSxLQUFLO0dBQ2IsVUFBVSxLQUFLO0dBQ2YsVUFBVTtFQUNaLEVBQUU7RUFFRixTQUFTLFNBQVMsQ0FDaEIsR0FBRyxNQUNIO0dBQ0UsSUFBSSxTQUFTLEtBQUssT0FBTztHQUN6QixRQUFRO0dBQ1IsTUFBTTtHQUNOLFNBQVMsR0FBRyxLQUFLLFNBQVM7R0FDMUIsV0FBVztHQUNYLFVBQVU7RUFDWixDQUNGLENBQUM7RUFFRCxPQUFPLFlBQVk7RUFDbkIsYUFBYSxRQUFRO0NBQ3ZCO0NBRUEsTUFBTSx3QkFBd0I7RUFDNUIsU0FBUyxVQUFVO0dBQ2pCLEdBQUc7R0FDSCxRQUFRO0dBQ1IsVUFBVTtHQUNWLFVBQVU7RUFDWixFQUFFO0VBQ0YsT0FBTyxTQUFTO0VBQ2hCLGFBQWEsUUFBUTtDQUN2QjtDQUVBLE1BQU0sb0JBQW9CLE1BQXVCO0VBQy9DLEVBQUUsZUFBZTtFQUNqQixJQUFJLENBQUMsWUFBWSxLQUFLLEtBQUssQ0FBQyxXQUFXLEtBQUssR0FBRztFQUUvQyxJQUFJLEtBQUssUUFBUSxLQUFNO0dBQ3JCLE1BQU0sNENBQTRDO0dBQ2xEO0VBQ0Y7RUFFQSxNQUFNLFVBQWdCO0dBQ3BCLElBQUksVUFBVSxLQUFLLE9BQU8sQ0FBQyxDQUFDLFNBQVMsRUFBRSxDQUFDLENBQUMsT0FBTyxHQUFHLENBQUM7R0FDcEQsTUFBTSxZQUFZLEtBQUs7R0FDdkIsS0FBSyxXQUFXLEtBQUssQ0FBQyxDQUFDLFlBQVk7R0FDbkMsT0FBTztHQUNQLGFBQWEsWUFBWSxLQUFLLEtBQUs7R0FDbkMsT0FBTztHQUNQLElBQUk7R0FDSixjQUFjO0dBQ2QsWUFBWTtHQUNaLFlBQVksS0FBSztHQUNqQixhQUFhO0dBQ2IsT0FBTztJQUNMLGtCQUFrQjtJQUNsQixvQkFBb0I7R0FDdEI7R0FDQSxhQUFhO0lBQ1gsT0FBTztJQUNQLFVBQVU7SUFDVixNQUFNO0lBQ04sWUFBWTtHQUNkO0VBQ0Y7RUFFQSxVQUFVLFNBQVMsQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDO0VBQ3JDLFNBQVMsVUFBVTtHQUNqQixHQUFHO0dBQ0gsT0FBTyxLQUFLLFFBQVE7R0FDcEIsUUFBUSxRQUFRO0dBQ2hCLFVBQVUsUUFBUTtHQUNsQixVQUFVO0VBQ1osRUFBRTtFQUVGLE9BQU8sWUFBWTtFQUNuQixhQUFhLFFBQVE7Q0FDdkI7Q0FFQSxNQUFNLHlCQUF5QixNQUF1QjtFQUNwRCxFQUFFLGVBQWU7RUFDakIsSUFBSSxDQUFDLFVBQVUsS0FBSyxHQUFHO0VBRXZCLE1BQU0sUUFBUSxVQUFVLEtBQUssQ0FBQyxDQUFDLFlBQVk7RUFDM0MsSUFBSSxVQUFVLGFBQWEsVUFBVSxhQUFhLFVBQVUsVUFBVSxVQUFVLFFBQVE7R0FDdEYsSUFBSSxxQkFBcUI7SUFDdkIsb0JBQW9CO0dBQ3RCO0VBQ0Y7RUFFQSxNQUFNLFNBQTBCO0dBQzlCLElBQUksU0FBUyxLQUFLLE9BQU8sQ0FBQyxDQUFDLFNBQVM7R0FDcEMsUUFBUSxLQUFLO0dBQ2IsTUFBTSxLQUFLLGFBQWEsV0FBVyxVQUFVLEtBQUssYUFBYSxZQUFZLFdBQVc7R0FDdEYsU0FBUyxVQUFVLEtBQUs7R0FDeEIsV0FBVyxJQUFJLEtBQUssQ0FBQyxDQUFDLG1CQUFtQixDQUFDLEdBQUc7SUFBRSxNQUFNO0lBQVcsUUFBUTtHQUFVLENBQUM7RUFDckY7RUFFQSxTQUFTLFNBQVMsQ0FBQyxHQUFHLE1BQU0sTUFBTSxDQUFDO0VBQ25DLGFBQWEsRUFBRTtFQUNmLE9BQU8sU0FBUztDQUNsQjtDQUVBLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFDYix3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFmO0lBRUUsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsUUFBRDtPQUFNLFdBQVU7aUJBQVc7TUFBUTs7OztnQkFDbkMsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLE1BQUQ7T0FBSSxXQUFVO2lCQUFxQztNQUFrQjs7OztnQkFDckUsd0JBQUMsS0FBRDtPQUFHLFdBQVU7aUJBQXlCO01BRW5DOzs7O2NBQ0E7Ozs7Y0FDRjs7Ozs7ZUFDTCx3QkFBQyxVQUFEO01BQ0UsU0FBUztNQUNULFdBQVU7Z0JBQ1g7S0FFTzs7OzthQUNMOzs7Ozs7SUFHTCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmO01BQ0Usd0JBQUMsVUFBRDtPQUNFLGVBQWUsYUFBYSxRQUFRO09BQ3BDLFdBQVcseURBQ1QsY0FBYyxXQUNWLHVDQUNBO2lCQUxSLENBT0MsaUJBQ2UsY0FBYyxJQUFJLFlBQVksSUFBSSxLQUFLLEVBQy9DOzs7Ozs7TUFDUix3QkFBQyxVQUFEO09BQ0UsZUFBZSxhQUFhLFFBQVE7T0FDcEMsV0FBVyx5REFDVCxjQUFjLFdBQ1YsdUNBQ0E7aUJBTFI7UUFPQztRQUNvQixNQUFNO1FBQU87T0FDMUI7Ozs7OztNQUNSLHdCQUFDLFVBQUQ7T0FDRSxlQUFlLGFBQWEsUUFBUTtPQUNwQyxXQUFXLHlEQUNULGNBQWMsV0FDVix1Q0FDQTtpQkFFUDtNQUVPOzs7OztLQUNMOzs7Ozs7SUFHSixjQUFjLFlBQ2Isd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFDWixjQUNDLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmO09BRUUsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxPQUFEO1NBQ0Usd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWY7V0FDRSx3QkFBQyxRQUFEO1lBQU0sV0FBVTtzQkFBWSxZQUFZO1dBQVk7Ozs7O1dBQ3BELHdCQUFDLE1BQUQ7WUFBSSxXQUFVO3NCQUFkO2FBQ0csWUFBWTthQUFNO2FBQ25CLHdCQUFDLFFBQUQ7Y0FBTSxXQUFVO3dCQUFoQjtlQUE0QztlQUFFLFlBQVk7ZUFBSTtjQUFPOzs7Ozs7WUFDbkU7Ozs7OztXQUNKLHdCQUFDLFFBQUQ7WUFBTSxXQUFVO3NCQUFoQixDQUF3SCxRQUNqSCxZQUFZLEtBQ2I7Ozs7OztVQUNIOzs7Ozs7U0FDTCx3QkFBQyxLQUFEO1VBQUcsV0FBVTtvQkFBK0IsWUFBWTtTQUFlOzs7OztTQUN2RSx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFBZjtXQUFpRDtXQUN4Qyx3QkFBQyxLQUFEO1lBQUcsV0FBVTtzQkFBa0IsWUFBWTtXQUFjOzs7OztXQUFDO1dBQW1CO1dBQ3BGLHdCQUFDLEtBQUQ7WUFBRyxXQUFVO3NCQUFiO2FBQ0csWUFBWTthQUFhO2FBQUksWUFBWTtZQUN6Qzs7Ozs7O1VBQ0E7Ozs7OztRQUNGOzs7O2tCQUVMLHdCQUFDLFVBQUQ7U0FDRSxTQUFTO1NBQ1QsV0FBVTttQkFDWDtRQUVPOzs7O2dCQUNMOzs7Ozs7T0FHTCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUVFLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0Usd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQTZDO1NBRXZEOzs7O21CQUNOLHdCQUFDLE1BQUQ7VUFBSSxXQUFVO29CQUFkLENBQ0Usd0JBQUMsTUFBRDtXQUFJO1dBQUksWUFBWSxNQUFNO1dBQWlCO1VBQWdDOzs7O29CQUMzRSx3QkFBQyxNQUFEO1dBQUk7V0FBSSxZQUFZLE1BQU07V0FBbUI7VUFBK0I7Ozs7a0JBQzFFOzs7OztpQkFDRDs7Ozs7a0JBR0wsd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWY7VUFDRSx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFBZixDQUNFLHdCQUFDLFFBQUQ7WUFBTSxXQUFVO3NCQUE0QztXQUV0RDs7OztxQkFDTix3QkFBQyxRQUFEO1lBQU0sV0FBVTtzQkFBaEI7YUFBNkQ7YUFDekQsWUFBWSxZQUFZO2FBQVc7WUFDakM7Ozs7O21CQUNIOzs7Ozs7VUFDTCx3QkFBQyxLQUFEO1dBQUcsV0FBVTtxQkFDVixZQUFZLFlBQVk7VUFDeEI7Ozs7O1VBQ0gsd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQWYsQ0FDRSx3QkFBQyxPQUFEO1lBQUssV0FBVTtzQkFBZixDQUNFLHdCQUFDLFFBQUQsWUFBTSxXQUFjOzs7O3NCQUNwQix3QkFBQyxRQUFEO2FBQ0csWUFBWSxZQUFZO2FBQVM7YUFBSSxZQUFZLFlBQVk7WUFDMUQ7Ozs7b0JBQ0g7Ozs7O3FCQUNMLHdCQUFDLE9BQUQ7WUFBSyxXQUFVO3NCQUNiLHdCQUFDLE9BQUQ7YUFDRSxXQUFVO2FBQ1YsT0FBTyxFQUNMLE9BQU8sR0FBRyxLQUFLLElBQ2IsS0FDQyxZQUFZLFlBQVksV0FBVyxZQUFZLFlBQVksT0FBUSxHQUN0RSxFQUFFLEdBQ0o7WUFDRDs7Ozs7V0FDRTs7OzttQkFDRjs7Ozs7O1NBQ0Y7Ozs7O2dCQUNGOzs7Ozs7T0FHTCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZjtTQUNFLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUF3QztTQUFtQjs7Ozs7U0FDM0Usd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQ1osS0FBSyxLQUFLLFFBQ1Qsd0JBQUMsT0FBRDtXQUVFLFdBQVcsb0JBQ1QsSUFBSSxXQUNBLCtEQUNBO3FCQUxSLENBUUcsQ0FBQyxJQUFJLFlBQ0osd0JBQUMsT0FBRDtZQUFLLFdBQVU7c0JBQWYsQ0FDRSx3QkFBQyxRQUFEO2FBQU0sV0FBVTt1QkFBaEI7Y0FBMEM7Y0FDdEMsSUFBSTtjQUFLO2NBQUcsSUFBSTthQUNkOzs7OztzQkFDTix3QkFBQyxRQUFEO2FBQU0sV0FBVTt1QkFBYSxJQUFJO1lBQWdCOzs7O29CQUM5Qzs7Ozs7cUJBRVAsd0JBQUMsS0FBRDtZQUFHLFdBQVU7c0JBQXlCLElBQUk7V0FBVzs7OzttQkFDbEQ7YUFoQkUsSUFBSTs7OztpQkFnQk4sQ0FDTjtTQUNFOzs7OztTQUVMLHdCQUFDLFFBQUQ7VUFBTSxVQUFVO1VBQXVCLFdBQVU7b0JBQWpELENBQ0Usd0JBQUMsU0FBRDtXQUNFLE1BQUs7V0FDTCxPQUFPO1dBQ1AsV0FBVyxNQUFNLGFBQWEsRUFBRSxPQUFPLEtBQUs7V0FDNUMsYUFBWTtXQUNaLFdBQVU7VUFDWDs7OztvQkFDRCx3QkFBQyxVQUFEO1dBQ0UsTUFBSztXQUNMLFdBQVU7cUJBQ1g7VUFFTzs7OztrQkFDSjs7Ozs7O1FBQ0g7Ozs7OztNQUNGOzs7OztnQkFFTCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZjtPQUNFLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUFzQjtPQUFROzs7OztPQUM5Qyx3QkFBQyxNQUFEO1FBQUksV0FBVTtrQkFBZ0M7T0FBOEI7Ozs7O09BQzVFLHdCQUFDLEtBQUQ7UUFBRyxXQUFVO2tCQUFvRDtPQUc5RDs7Ozs7T0FDSCx3QkFBQyxVQUFEO1FBQ0UsZUFBZSxhQUFhLFFBQVE7UUFDcEMsV0FBVTtrQkFDWDtPQUVPOzs7OztNQUNMOzs7Ozs7SUFFSjs7Ozs7SUFJTixjQUFjLFlBQ2Isd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFDWixNQUFNLEtBQUssU0FDVix3QkFBQyxPQUFEO01BRUUsV0FBVTtnQkFGWixDQUlFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQVksS0FBSztPQUFZOzs7O2lCQUM3Qyx3QkFBQyxPQUFEO1FBQ0Usd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWY7VUFDRSx3QkFBQyxNQUFEO1dBQUksV0FBVTtxQkFBcUMsS0FBSztVQUFTOzs7OztVQUNqRSx3QkFBQyxRQUFEO1dBQU0sV0FBVTtxQkFBaEI7WUFBOEQ7WUFBRSxLQUFLO1lBQUk7V0FBTzs7Ozs7O1VBQ2hGLHdCQUFDLFFBQUQ7V0FBTSxXQUFVO3FCQUFoQixDQUFnRixRQUN6RSxLQUFLLEtBQ047Ozs7OztTQUNIOzs7Ozs7UUFDTCx3QkFBQyxLQUFEO1NBQUcsV0FBVTttQkFBaUMsS0FBSztRQUFlOzs7OztRQUNsRSx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZjtVQUFtRDtVQUN6QyxLQUFLO1VBQVc7VUFBb0IsS0FBSztVQUFhO1VBQUUsS0FBSztTQUNsRTs7Ozs7O09BQ0Y7Ozs7ZUFDRjs7Ozs7Z0JBRUosS0FBSyxXQUFXLEtBQUssS0FDcEIsd0JBQUMsUUFBRDtPQUFNLFdBQVU7aUJBQXVFO01BRWpGOzs7O2lCQUVOLHdCQUFDLFVBQUQ7T0FDRSxlQUFlLGVBQWUsSUFBSTtPQUNsQyxXQUFVO2lCQUNYO01BRU87Ozs7Y0FFUDtRQWhDRSxLQUFLOzs7O1lBZ0NQLENBQ047SUFDRTs7Ozs7SUFJTixjQUFjLFlBQ2Isd0JBQUMsUUFBRDtLQUFNLFVBQVU7S0FBa0IsV0FBVTtlQUE1QztNQUNFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmO1FBQXNHO1FBQzVFLHdCQUFDLEtBQUQ7U0FBRyxXQUFVO21CQUEyQjtRQUFjOzs7OztRQUFDO09BRTVFOzs7Ozs7TUFFTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZjtRQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO1NBQU8sV0FBVTttQkFBOEM7UUFFeEQ7Ozs7a0JBQ1Asd0JBQUMsU0FBRDtTQUNFLE1BQUs7U0FDTDtTQUNBLGFBQVk7U0FDWixPQUFPO1NBQ1AsV0FBVyxNQUFNLGVBQWUsRUFBRSxPQUFPLEtBQUs7U0FDOUMsV0FBVTtRQUNYOzs7O2dCQUNFOzs7OztRQUVMLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxTQUFEO1NBQU8sV0FBVTttQkFBOEM7UUFFeEQ7Ozs7a0JBQ1Asd0JBQUMsU0FBRDtTQUNFLE1BQUs7U0FDTCxXQUFXO1NBQ1g7U0FDQSxhQUFZO1NBQ1osT0FBTztTQUNQLFdBQVcsTUFBTSxjQUFjLEVBQUUsT0FBTyxLQUFLO1NBQzdDLFdBQVU7UUFDWDs7OztnQkFDRTs7Ozs7UUFFTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRDtTQUFPLFdBQVU7bUJBQThDO1FBRXhEOzs7O2tCQUNQLHdCQUFDLFlBQUQ7U0FDRSxNQUFNO1NBQ04sYUFBWTtTQUNaLE9BQU87U0FDUCxXQUFXLE1BQU0sZUFBZSxFQUFFLE9BQU8sS0FBSztTQUM5QyxXQUFVO1FBQ1g7Ozs7Z0JBQ0U7Ozs7O09BQ0Y7Ozs7OztNQUVMLHdCQUFDLFVBQUQ7T0FDRSxNQUFLO09BQ0wsV0FBVTtpQkFDWDtNQUVPOzs7OztLQUNKOzs7Ozs7R0FFTDs7Ozs7O0NBQ0Y7Ozs7O0FBRVQiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiQ2xhbnNNb2RhbC50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgQ2xhbiwgQ2xhbkNoYXRNZXNzYWdlLCBVc2VyUHJvZmlsZSB9IGZyb20gJy4uL3R5cGVzL2dhbWUnO1xuaW1wb3J0IHsgc291bmRzIH0gZnJvbSAnLi4vdXRpbHMvc291bmQnO1xuXG5pbnRlcmZhY2UgQ2xhbnNNb2RhbFByb3BzIHtcbiAgdXNlcjogVXNlclByb2ZpbGU7XG4gIHNldFVzZXI6IFJlYWN0LkRpc3BhdGNoPFJlYWN0LlNldFN0YXRlQWN0aW9uPFVzZXJQcm9maWxlPj47XG4gIGNsYW5zOiBDbGFuW107XG4gIHNldENsYW5zOiBSZWFjdC5EaXNwYXRjaDxSZWFjdC5TZXRTdGF0ZUFjdGlvbjxDbGFuW10+PjtcbiAgY2hhdDogQ2xhbkNoYXRNZXNzYWdlW107XG4gIHNldENoYXQ6IFJlYWN0LkRpc3BhdGNoPFJlYWN0LlNldFN0YXRlQWN0aW9uPENsYW5DaGF0TWVzc2FnZVtdPj47XG4gIG9uQ2xvc2U6ICgpID0+IHZvaWQ7XG4gIG9uVHJpZ2dlclNlY3JldEtla2M/OiAoKSA9PiB2b2lkO1xufVxuXG5leHBvcnQgY29uc3QgQ2xhbnNNb2RhbDogUmVhY3QuRkM8Q2xhbnNNb2RhbFByb3BzPiA9ICh7XG4gIHVzZXIsXG4gIHNldFVzZXIsXG4gIGNsYW5zLFxuICBzZXRDbGFucyxcbiAgY2hhdCxcbiAgc2V0Q2hhdCxcbiAgb25DbG9zZSxcbiAgb25UcmlnZ2VyU2VjcmV0S2VrYyxcbn0pID0+IHtcbiAgY29uc3QgW2FjdGl2ZVRhYiwgc2V0QWN0aXZlVGFiXSA9IHVzZVN0YXRlPCdicm93c2UnIHwgJ215Y2xhbicgfCAnY3JlYXRlJz4oJ215Y2xhbicpO1xuICBjb25zdCBbbmV3Q2xhbk5hbWUsIHNldE5ld0NsYW5OYW1lXSA9IHVzZVN0YXRlKCcnKTtcbiAgY29uc3QgW25ld0NsYW5UYWcsIHNldE5ld0NsYW5UYWddID0gdXNlU3RhdGUoJycpO1xuICBjb25zdCBbbmV3Q2xhbkRlc2MsIHNldE5ld0NsYW5EZXNjXSA9IHVzZVN0YXRlKCcnKTtcbiAgY29uc3QgW2NoYXRJbnB1dCwgc2V0Q2hhdElucHV0XSA9IHVzZVN0YXRlKCcnKTtcblxuICBjb25zdCBjdXJyZW50Q2xhbiA9IGNsYW5zLmZpbmQoKGMpID0+IGMuaWQgPT09IHVzZXIuY2xhbklkKSB8fCBudWxsO1xuXG4gIGNvbnN0IGhhbmRsZUpvaW5DbGFuID0gKGNsYW46IENsYW4pID0+IHtcbiAgICBzZXRVc2VyKChwcmV2KSA9PiAoe1xuICAgICAgLi4ucHJldixcbiAgICAgIGNsYW5JZDogY2xhbi5pZCxcbiAgICAgIGNsYW5OYW1lOiBjbGFuLm5hbWUsXG4gICAgICBjbGFuUm9sZTogJ21lbWJlcicsXG4gICAgfSkpO1xuXG4gICAgc2V0Q2hhdCgocHJldikgPT4gW1xuICAgICAgLi4ucHJldixcbiAgICAgIHtcbiAgICAgICAgaWQ6ICdzeXNfJyArIE1hdGgucmFuZG9tKCksXG4gICAgICAgIHNlbmRlcjogJ9Ch0LjRgdGC0LXQvNCwJyxcbiAgICAgICAgcm9sZTogJ9Cj0LLQtdC00L7QvNC70LXQvdC40LUnLFxuICAgICAgICBtZXNzYWdlOiBgJHt1c2VyLnVzZXJuYW1lfSDQstGB0YLRg9C/0LjQuyDQsiDRgNGP0LTRiyDQutC70LDQvdCwIWAsXG4gICAgICAgIHRpbWVzdGFtcDogJ9Ci0L7Qu9GM0LrQviDRh9GC0L4nLFxuICAgICAgICBpc1N5c3RlbTogdHJ1ZSxcbiAgICAgIH0sXG4gICAgXSk7XG5cbiAgICBzb3VuZHMucGxheVVwZ3JhZGUoKTtcbiAgICBzZXRBY3RpdmVUYWIoJ215Y2xhbicpO1xuICB9O1xuXG4gIGNvbnN0IGhhbmRsZUxlYXZlQ2xhbiA9ICgpID0+IHtcbiAgICBzZXRVc2VyKChwcmV2KSA9PiAoe1xuICAgICAgLi4ucHJldixcbiAgICAgIGNsYW5JZDogbnVsbCxcbiAgICAgIGNsYW5OYW1lOiBudWxsLFxuICAgICAgY2xhblJvbGU6IG51bGwsXG4gICAgfSkpO1xuICAgIHNvdW5kcy5wbGF5Q29pbigpO1xuICAgIHNldEFjdGl2ZVRhYignYnJvd3NlJyk7XG4gIH07XG5cbiAgY29uc3QgaGFuZGxlQ3JlYXRlQ2xhbiA9IChlOiBSZWFjdC5Gb3JtRXZlbnQpID0+IHtcbiAgICBlLnByZXZlbnREZWZhdWx0KCk7XG4gICAgaWYgKCFuZXdDbGFuTmFtZS50cmltKCkgfHwgIW5ld0NsYW5UYWcudHJpbSgpKSByZXR1cm47XG5cbiAgICBpZiAodXNlci5jb2lucyA8IDEwMDApIHtcbiAgICAgIGFsZXJ0KCfQlNC70Y8g0L7RgdC90L7QstCw0L3QuNGPINC60LvQsNC90LAg0YLRgNC10LHRg9C10YLRgdGPIDEsMDAwINC80L7QvdC10YIhJyk7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgY29uc3QgbmV3Q2xhbjogQ2xhbiA9IHtcbiAgICAgIGlkOiAnY2xhbl8nICsgTWF0aC5yYW5kb20oKS50b1N0cmluZygzNikuc3Vic3RyKDIsIDkpLFxuICAgICAgbmFtZTogbmV3Q2xhbk5hbWUudHJpbSgpLFxuICAgICAgdGFnOiBuZXdDbGFuVGFnLnRyaW0oKS50b1VwcGVyQ2FzZSgpLFxuICAgICAgYmFkZ2U6ICfwn5GR4pqU77iPJyxcbiAgICAgIGRlc2NyaXB0aW9uOiBuZXdDbGFuRGVzYy50cmltKCkgfHwgJ9Cd0L7QstGL0Lkg0LrQu9Cw0L0g0LfQsNGJ0LjRgtC90LjQutC+0LIg0KDQvtCx0LvQvtC60YHQsCcsXG4gICAgICBsZXZlbDogMSxcbiAgICAgIHhwOiAwLFxuICAgICAgbWVtYmVyc0NvdW50OiAxLFxuICAgICAgbWF4TWVtYmVyczogMjAsXG4gICAgICBsZWFkZXJOYW1lOiB1c2VyLnVzZXJuYW1lLFxuICAgICAgcmF0aW5nU2NvcmU6IDEwMDAsXG4gICAgICBwZXJrczoge1xuICAgICAgICBib251c0dvbGRQZXJjZW50OiA1LFxuICAgICAgICBib251c0RhbWFnZVBlcmNlbnQ6IDMsXG4gICAgICB9LFxuICAgICAgd2Vla2x5UXVlc3Q6IHtcbiAgICAgICAgdGl0bGU6ICfQo9C90LjRh9GC0L7QttC40YLRjCA1MDAg0LLRgNCw0LPQvtCyINCyINC60L7QvtC/0LUnLFxuICAgICAgICBwcm9ncmVzczogMCxcbiAgICAgICAgZ29hbDogNTAwLFxuICAgICAgICByZXdhcmRHZW1zOiAxMDAsXG4gICAgICB9LFxuICAgIH07XG5cbiAgICBzZXRDbGFucygocHJldikgPT4gW25ld0NsYW4sIC4uLnByZXZdKTtcbiAgICBzZXRVc2VyKChwcmV2KSA9PiAoe1xuICAgICAgLi4ucHJldixcbiAgICAgIGNvaW5zOiBwcmV2LmNvaW5zIC0gMTAwMCxcbiAgICAgIGNsYW5JZDogbmV3Q2xhbi5pZCxcbiAgICAgIGNsYW5OYW1lOiBuZXdDbGFuLm5hbWUsXG4gICAgICBjbGFuUm9sZTogJ2xlYWRlcicsXG4gICAgfSkpO1xuXG4gICAgc291bmRzLnBsYXlWaWN0b3J5KCk7XG4gICAgc2V0QWN0aXZlVGFiKCdteWNsYW4nKTtcbiAgfTtcblxuICBjb25zdCBoYW5kbGVTZW5kQ2hhdE1lc3NhZ2UgPSAoZTogUmVhY3QuRm9ybUV2ZW50KSA9PiB7XG4gICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgIGlmICghY2hhdElucHV0LnRyaW0oKSkgcmV0dXJuO1xuXG4gICAgY29uc3QgbG93ZXIgPSBjaGF0SW5wdXQudHJpbSgpLnRvTG93ZXJDYXNlKCk7XG4gICAgaWYgKGxvd2VyID09PSAn0LPQviBrZWtjJyB8fCBsb3dlciA9PT0gJ9Cz0L4g0LrQtdC60YEnIHx8IGxvd2VyID09PSAna2VrYycgfHwgbG93ZXIgPT09ICfQutC10LrRgScpIHtcbiAgICAgIGlmIChvblRyaWdnZXJTZWNyZXRLZWtjKSB7XG4gICAgICAgIG9uVHJpZ2dlclNlY3JldEtla2MoKTtcbiAgICAgIH1cbiAgICB9XG5cbiAgICBjb25zdCBuZXdNc2c6IENsYW5DaGF0TWVzc2FnZSA9IHtcbiAgICAgIGlkOiAnbXNnXycgKyBNYXRoLnJhbmRvbSgpLnRvU3RyaW5nKCksXG4gICAgICBzZW5kZXI6IHVzZXIudXNlcm5hbWUsXG4gICAgICByb2xlOiB1c2VyLmNsYW5Sb2xlID09PSAnbGVhZGVyJyA/ICfQm9C40LTQtdGAJyA6IHVzZXIuY2xhblJvbGUgPT09ICdvZmZpY2VyJyA/ICfQntGE0LjRhtC10YAnIDogJ9CR0L7QtdGGJyxcbiAgICAgIG1lc3NhZ2U6IGNoYXRJbnB1dC50cmltKCksXG4gICAgICB0aW1lc3RhbXA6IG5ldyBEYXRlKCkudG9Mb2NhbGVUaW1lU3RyaW5nKFtdLCB7IGhvdXI6ICcyLWRpZ2l0JywgbWludXRlOiAnMi1kaWdpdCcgfSksXG4gICAgfTtcblxuICAgIHNldENoYXQoKHByZXYpID0+IFsuLi5wcmV2LCBuZXdNc2ddKTtcbiAgICBzZXRDaGF0SW5wdXQoJycpO1xuICAgIHNvdW5kcy5wbGF5Q29pbigpO1xuICB9O1xuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJmaXhlZCBpbnNldC0wIHotNTAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgYmctc2xhdGUtOTUwLzg1IGJhY2tkcm9wLWJsdXItbWQgcC00XCI+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXNsYXRlLTkwMCBib3JkZXItMiBib3JkZXItaW5kaWdvLTUwMC80MCByb3VuZGVkLTN4bCBwLTYgbWF4LXctM3hsIHctZnVsbCBzaGFkb3ctMnhsIHRleHQtc2xhdGUtMTAwIG1heC1oLVs5MHZoXSBmbGV4IGZsZXgtY29sXCI+XG4gICAgICAgIHsvKiBIZWFkZXIgKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHBiLTQgYm9yZGVyLWIgYm9yZGVyLXNsYXRlLTgwMFwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgc3BhY2UteC0zXCI+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LTN4bFwiPvCfj7A8L3NwYW4+XG4gICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC14bCBmb250LWJsYWNrIHRleHQtaW5kaWdvLTQwMFwiPtCh0LjRgdGC0LXQvNCwINCa0LvQsNC90L7QsjwvaDI+XG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS00MDBcIj5cbiAgICAgICAgICAgICAgICDQntCx0YnQuNC1INCx0L7QvdGD0YHRiyDQuiDQt9C+0LvQvtGC0YMg0Lgg0YPRgNC+0L3Rgywg0LrQu9Cw0L3QvtCy0YvQtSDRgNC10LnQtNGLINC4INC30LDQutGA0YvRgtGL0Lkg0YfQsNGCXG4gICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgIG9uQ2xpY2s9e29uQ2xvc2V9XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTggaC04IHJvdW5kZWQtZnVsbCBiZy1zbGF0ZS04MDAgaG92ZXI6Ymctc2xhdGUtNzAwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHRleHQtc2xhdGUtNDAwIGhvdmVyOnRleHQtd2hpdGVcIlxuICAgICAgICAgID5cbiAgICAgICAgICAgIOKclVxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICB7LyogVGFiIHN3aXRjaGVyICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIHNwYWNlLXgtMiBteS00IGJvcmRlci1iIGJvcmRlci1zbGF0ZS04MDAgcGItMlwiPlxuICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEFjdGl2ZVRhYignbXljbGFuJyl9XG4gICAgICAgICAgICBjbGFzc05hbWU9e2BweC00IHB5LTIgcm91bmRlZC14bCB0ZXh0LXhzIGZvbnQtYm9sZCB0cmFuc2l0aW9uLWFsbCAke1xuICAgICAgICAgICAgICBhY3RpdmVUYWIgPT09ICdteWNsYW4nXG4gICAgICAgICAgICAgICAgPyAnYmctaW5kaWdvLTYwMCB0ZXh0LXdoaXRlIHNoYWRvdy1tZCdcbiAgICAgICAgICAgICAgICA6ICd0ZXh0LXNsYXRlLTQwMCBob3Zlcjp0ZXh0LXdoaXRlIGhvdmVyOmJnLXNsYXRlLTgwMCdcbiAgICAgICAgICAgIH1gfVxuICAgICAgICAgID5cbiAgICAgICAgICAgIPCfm6HvuI8g0JzQvtC5INCa0LvQsNC9IHtjdXJyZW50Q2xhbiA/IGBbJHtjdXJyZW50Q2xhbi50YWd9XWAgOiAnJ31cbiAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRBY3RpdmVUYWIoJ2Jyb3dzZScpfVxuICAgICAgICAgICAgY2xhc3NOYW1lPXtgcHgtNCBweS0yIHJvdW5kZWQteGwgdGV4dC14cyBmb250LWJvbGQgdHJhbnNpdGlvbi1hbGwgJHtcbiAgICAgICAgICAgICAgYWN0aXZlVGFiID09PSAnYnJvd3NlJ1xuICAgICAgICAgICAgICAgID8gJ2JnLWluZGlnby02MDAgdGV4dC13aGl0ZSBzaGFkb3ctbWQnXG4gICAgICAgICAgICAgICAgOiAndGV4dC1zbGF0ZS00MDAgaG92ZXI6dGV4dC13aGl0ZSBob3ZlcjpiZy1zbGF0ZS04MDAnXG4gICAgICAgICAgICB9YH1cbiAgICAgICAgICA+XG4gICAgICAgICAgICDwn5OcINCh0L/QuNGB0L7QuiDQmtC70LDQvdC+0LIgKHtjbGFucy5sZW5ndGh9KVxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEFjdGl2ZVRhYignY3JlYXRlJyl9XG4gICAgICAgICAgICBjbGFzc05hbWU9e2BweC00IHB5LTIgcm91bmRlZC14bCB0ZXh0LXhzIGZvbnQtYm9sZCB0cmFuc2l0aW9uLWFsbCAke1xuICAgICAgICAgICAgICBhY3RpdmVUYWIgPT09ICdjcmVhdGUnXG4gICAgICAgICAgICAgICAgPyAnYmctaW5kaWdvLTYwMCB0ZXh0LXdoaXRlIHNoYWRvdy1tZCdcbiAgICAgICAgICAgICAgICA6ICd0ZXh0LXNsYXRlLTQwMCBob3Zlcjp0ZXh0LXdoaXRlIGhvdmVyOmJnLXNsYXRlLTgwMCdcbiAgICAgICAgICAgIH1gfVxuICAgICAgICAgID5cbiAgICAgICAgICAgIOKalO+4jyDQodC+0LfQtNCw0YLRjCDQodCy0L7QuSDQmtC70LDQvVxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICB7LyogQ29udGVudDogTXkgQ2xhbiAqL31cbiAgICAgICAge2FjdGl2ZVRhYiA9PT0gJ215Y2xhbicgJiYgKFxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xIG92ZXJmbG93LXktYXV0byBwci0xIHNwYWNlLXktNFwiPlxuICAgICAgICAgICAge2N1cnJlbnRDbGFuID8gKFxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNFwiPlxuICAgICAgICAgICAgICAgIHsvKiBDbGFuIEJhbm5lciAqL31cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNCBiZy1zbGF0ZS05NTAvODAgYm9yZGVyIGJvcmRlci1pbmRpZ28tNTAwLzMwIHJvdW5kZWQtMnhsIGZsZXggZmxleC1jb2wgc206ZmxleC1yb3cgaXRlbXMtc3RhcnQgc206aXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtM1wiPlxuICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBzcGFjZS14LTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LTJ4bFwiPntjdXJyZW50Q2xhbi5iYWRnZX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1ibGFjayB0ZXh0LXdoaXRlXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICB7Y3VycmVudENsYW4ubmFtZX17JyAnfVxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1pbmRpZ28tNDAwIGZvbnQtbW9ub1wiPlt7Y3VycmVudENsYW4udGFnfV08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgPC9oMz5cbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJweC0yIHB5LTAuNSByb3VuZGVkLWZ1bGwgdGV4dC1bMTBweF0gZm9udC1ib2xkIGJnLWluZGlnby05NTAgdGV4dC1pbmRpZ28tMzAwIGJvcmRlciBib3JkZXItaW5kaWdvLTcwMFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAg0KPRgC4ge2N1cnJlbnRDbGFuLmxldmVsfVxuICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS00MDAgbXQtMVwiPntjdXJyZW50Q2xhbi5kZXNjcmlwdGlvbn08L3A+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1zbGF0ZS01MDAgbXQtMVwiPlxuICAgICAgICAgICAgICAgICAgICAgINCb0LjQtNC10YA6IDxiIGNsYXNzTmFtZT1cInRleHQtc2xhdGUtMzAwXCI+e2N1cnJlbnRDbGFuLmxlYWRlck5hbWV9PC9iPiAmYnVsbDsg0KPRh9Cw0YHRgtC90LjQutC4OnsnICd9XG4gICAgICAgICAgICAgICAgICAgICAgPGIgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS0zMDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgIHtjdXJyZW50Q2xhbi5tZW1iZXJzQ291bnR9IC8ge2N1cnJlbnRDbGFuLm1heE1lbWJlcnN9XG4gICAgICAgICAgICAgICAgICAgICAgPC9iPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZUxlYXZlQ2xhbn1cbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtMyBweS0xLjUgcm91bmRlZC14bCB0ZXh0LXhzIGZvbnQtYm9sZCBiZy1yb3NlLTk1MC82MCB0ZXh0LXJvc2UtMzAwIGJvcmRlciBib3JkZXItcm9zZS04MDAvNDAgaG92ZXI6Ymctcm9zZS05MDBcIlxuICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICDQn9C+0LrQuNC90YPRgtGMINC60LvQsNC9XG4gICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIHsvKiBDbGFuIFBlcmtzICYgV2Vla2x5IFF1ZXN0ICovfVxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBzbTpncmlkLWNvbHMtMiBnYXAtM1wiPlxuICAgICAgICAgICAgICAgICAgey8qIFBlcmtzICovfVxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTMgYmctc2xhdGUtOTUwLzcwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHJvdW5kZWQtMnhsXCI+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHRleHQtYW1iZXItNDAwIHVwcGVyY2FzZVwiPlxuICAgICAgICAgICAgICAgICAgICAgIOKaoSDQkNC60YLQuNCy0L3Ri9C1INC/0LDRgdGB0LjQstC90YvQtSDQsdC+0L3Rg9GB0Ys6XG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPHVsIGNsYXNzTmFtZT1cIm10LTIgc3BhY2UteS0xIHRleHQteHMgdGV4dC1zbGF0ZS0zMDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8bGk+4oCiICt7Y3VycmVudENsYW4ucGVya3MuYm9udXNHb2xkUGVyY2VudH0lINC30L7Qu9C+0YLQsCDQt9CwINC/0YDQvtGF0L7QttC00LXQvdC40LUg0LLQvtC70L08L2xpPlxuICAgICAgICAgICAgICAgICAgICAgIDxsaT7igKIgK3tjdXJyZW50Q2xhbi5wZXJrcy5ib251c0RhbWFnZVBlcmNlbnR9JSDQsdCw0LfQvtCy0L7Qs9C+INGD0YDQvtC90LAg0LLRgdC10YUg0LHQsNGI0LXQvTwvbGk+XG4gICAgICAgICAgICAgICAgICAgIDwvdWw+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgey8qIFdlZWtseSBRdWVzdCAqL31cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0zIGJnLXNsYXRlLTk1MC83MCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLTJ4bFwiPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHRleHQtY3lhbi00MDAgdXBwZXJjYXNlXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICDwn46vINCV0LbQtdC90LXQtNC10LvRjNC90YvQuSDQmtCy0LXRgdGCOlxuICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtbW9ubyBmb250LWJvbGQgdGV4dC1hbWJlci00MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICt7Y3VycmVudENsYW4ud2Vla2x5UXVlc3QucmV3YXJkR2Vtc30g8J+SjlxuICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS0yMDAgbXQtMSBmb250LXNlbWlib2xkXCI+XG4gICAgICAgICAgICAgICAgICAgICAge2N1cnJlbnRDbGFuLndlZWtseVF1ZXN0LnRpdGxlfVxuICAgICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMlwiPlxuICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gdGV4dC1bMTFweF0gZm9udC1tb25vIHRleHQtc2xhdGUtNDAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj7Qn9GA0L7Qs9GA0LXRgdGBPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtjdXJyZW50Q2xhbi53ZWVrbHlRdWVzdC5wcm9ncmVzc30gLyB7Y3VycmVudENsYW4ud2Vla2x5UXVlc3QuZ29hbH1cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctZnVsbCBoLTIgYmctc2xhdGUtODAwIHJvdW5kZWQtZnVsbCBvdmVyZmxvdy1oaWRkZW4gbXQtMVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdlxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJoLWZ1bGwgYmctY3lhbi01MDAgcm91bmRlZC1mdWxsXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3tcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB3aWR0aDogYCR7TWF0aC5taW4oXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAxMDAsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAoY3VycmVudENsYW4ud2Vla2x5UXVlc3QucHJvZ3Jlc3MgLyBjdXJyZW50Q2xhbi53ZWVrbHlRdWVzdC5nb2FsKSAqIDEwMFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9JWAsXG4gICAgICAgICAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgey8qIENsYW4gTGl2ZSBDaGF0ICovfVxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC0zIGJnLXNsYXRlLTk1MC84MCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCByb3VuZGVkLTJ4bCBmbGV4IGZsZXgtY29sIGgtNTZcIj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1ib2xkIHRleHQtc2xhdGUtNDAwIG1iLTJcIj7wn5KsINCn0LDRgiDQmtC70LDQvdCwOjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xIG92ZXJmbG93LXktYXV0byBzcGFjZS15LTEuNSBwci0yIHRleHQteHNcIj5cbiAgICAgICAgICAgICAgICAgICAge2NoYXQubWFwKChtc2cpID0+IChcbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2XG4gICAgICAgICAgICAgICAgICAgICAgICBrZXk9e21zZy5pZH1cbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHAtMS41IHJvdW5kZWQtbGcgJHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgbXNnLmlzU3lzdGVtXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPyAnYmctaW5kaWdvLTk1MC81MCB0ZXh0LWluZGlnby0zMDAgdGV4dC1jZW50ZXIgZm9udC1zZW1pYm9sZCdcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA6ICdiZy1zbGF0ZS05MDAnXG4gICAgICAgICAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgICB7IW1zZy5pc1N5c3RlbSAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHRleHQtWzEwcHhdIHRleHQtc2xhdGUtNDAwXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtY3lhbi00MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFt7bXNnLnJvbGV9XSB7bXNnLnNlbmRlcn1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1tb25vXCI+e21zZy50aW1lc3RhbXB9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTIwMCBtdC0wLjVcIj57bXNnLm1lc3NhZ2V9PC9wPlxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICA8Zm9ybSBvblN1Ym1pdD17aGFuZGxlU2VuZENoYXRNZXNzYWdlfSBjbGFzc05hbWU9XCJtdC0yIGZsZXggc3BhY2UteC0yXCI+XG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17Y2hhdElucHV0fVxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0Q2hhdElucHV0KGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cItCd0LDQv9C40YHQsNGC0Ywg0YHQvtC+0LHRidC10L3QuNC1INGB0L7QutC70LDQvdC+0LLRhtCw0LwuLi5cIlxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXgtMSBiZy1zbGF0ZS05MDAgYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAgcm91bmRlZC14bCBweC0zIHB5LTEuNSB0ZXh0LXhzIHRleHQtd2hpdGUgZm9jdXM6b3V0bGluZS1ub25lIGZvY3VzOmJvcmRlci1pbmRpZ28tNTAwXCJcbiAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJzdWJtaXRcIlxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTQgcHktMS41IGJnLWluZGlnby02MDAgaG92ZXI6YmctaW5kaWdvLTUwMCB0ZXh0LXdoaXRlIHJvdW5kZWQteGwgdGV4dC14cyBmb250LWJvbGRcIlxuICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAg0J7RgtC/0YDQsNCy0LjRgtGMXG4gICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgPC9mb3JtPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXIgcC04IGJnLXNsYXRlLTk1MC81MCByb3VuZGVkLTJ4bCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMFwiPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtNHhsIG1iLTIgYmxvY2tcIj7wn4+wPC9zcGFuPlxuICAgICAgICAgICAgICAgIDxoMyBjbGFzc05hbWU9XCJmb250LWJsYWNrIHRleHQtbGcgdGV4dC13aGl0ZVwiPtCS0Ysg0LXRidC1INC90LUg0YHQvtGB0YLQvtC40YLQtSDQsiDQutC70LDQvdC1PC9oMz5cbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNDAwIG1heC13LXNtIG14LWF1dG8gbXQtMSBtYi00XCI+XG4gICAgICAgICAgICAgICAgICDQktGB0YLRg9C/0LDQudGC0LUg0LIg0YHRg9GJ0LXRgdGC0LLRg9GO0YnQuNC5INC60LvQsNC9INC40Lcg0YHQv9C40YHQutCwINC40LvQuCDRgdC+0LfQtNCw0LnRgtC1INGB0LLQvtC5INGB0L7QsdGB0YLQstC10L3QvdGL0LksINGH0YLQvtCx0Ysg0L/QvtC70YPRh9Cw0YLRjFxuICAgICAgICAgICAgICAgICAg0LHQvtC90YPRgdGLINC6INC30L7Qu9C+0YLRgyDQuCDQv9GA0L7QutCw0YfQutC1IVxuICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRBY3RpdmVUYWIoJ2Jyb3dzZScpfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicHgtNSBweS0yIGJnLWluZGlnby02MDAgaG92ZXI6YmctaW5kaWdvLTUwMCB0ZXh0LXdoaXRlIHJvdW5kZWQteGwgZm9udC1ib2xkIHRleHQteHNcIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgINCS0YvQsdGA0LDRgtGMINCa0LvQsNC9XG4gICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKX1cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgKX1cblxuICAgICAgICB7LyogQ29udGVudDogQnJvd3NlIENsYW5zICovfVxuICAgICAgICB7YWN0aXZlVGFiID09PSAnYnJvd3NlJyAmJiAoXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTEgb3ZlcmZsb3cteS1hdXRvIHByLTEgc3BhY2UteS0yLjVcIj5cbiAgICAgICAgICAgIHtjbGFucy5tYXAoKGNsYW4pID0+IChcbiAgICAgICAgICAgICAgPGRpdlxuICAgICAgICAgICAgICAgIGtleT17Y2xhbi5pZH1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwLTMuNSBiZy1zbGF0ZS05NTAvNzAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgaG92ZXI6Ym9yZGVyLXNsYXRlLTcwMCByb3VuZGVkLTJ4bCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIlxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBzcGFjZS14LTNcIj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtMnhsXCI+e2NsYW4uYmFkZ2V9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBzcGFjZS14LTJcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwiZm9udC1leHRyYWJvbGQgdGV4dC1zbSB0ZXh0LXdoaXRlXCI+e2NsYW4ubmFtZX08L2g0PlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1tb25vIGZvbnQtYm9sZCB0ZXh0LWluZGlnby00MDBcIj5be2NsYW4udGFnfV08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gcHgtMS41IHB5LTAuMiBiZy1zbGF0ZS04MDAgdGV4dC1zbGF0ZS0zMDAgcm91bmRlZFwiPlxuICAgICAgICAgICAgICAgICAgICAgICAg0KPRgC4ge2NsYW4ubGV2ZWx9XG4gICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTQwMCBtdC0wLjVcIj57Y2xhbi5kZXNjcmlwdGlvbn08L3A+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1zbGF0ZS01MDAgbXQtMC41XCI+XG4gICAgICAgICAgICAgICAgICAgICAg0JvQuNC00LXRgDoge2NsYW4ubGVhZGVyTmFtZX0gJmJ1bGw7INCj0YfQsNGB0YLQvdC40LrQuDoge2NsYW4ubWVtYmVyc0NvdW50fS97Y2xhbi5tYXhNZW1iZXJzfVxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAge3VzZXIuY2xhbklkID09PSBjbGFuLmlkID8gKFxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJvbGQgdGV4dC1pbmRpZ28tNDAwIHB4LTMgcHktMSBiZy1pbmRpZ28tOTUwIHJvdW5kZWQteGxcIj5cbiAgICAgICAgICAgICAgICAgICAg0JLQsNGIINC60LvQsNC9IOKck1xuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZUpvaW5DbGFuKGNsYW4pfVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC00IHB5LTIgYmctaW5kaWdvLTYwMCBob3ZlcjpiZy1pbmRpZ28tNTAwIHRleHQtd2hpdGUgcm91bmRlZC14bCB0ZXh0LXhzIGZvbnQtYm9sZFwiXG4gICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgINCS0YHRgtGD0L/QuNGC0YxcbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKSl9XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICl9XG5cbiAgICAgICAgey8qIENvbnRlbnQ6IENyZWF0ZSBDbGFuICovfVxuICAgICAgICB7YWN0aXZlVGFiID09PSAnY3JlYXRlJyAmJiAoXG4gICAgICAgICAgPGZvcm0gb25TdWJtaXQ9e2hhbmRsZUNyZWF0ZUNsYW59IGNsYXNzTmFtZT1cImZsZXgtMSBvdmVyZmxvdy15LWF1dG8gcHItMSBzcGFjZS15LTRcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC00IGJnLWluZGlnby05NTAvNDAgYm9yZGVyIGJvcmRlci1pbmRpZ28tNjAwLzMwIHJvdW5kZWQtMnhsIHRleHQteHMgdGV4dC1pbmRpZ28tMjAwXCI+XG4gICAgICAgICAgICAgIPCfkqEg0KHQvtC30LTQsNC90LjQtSDQutC70LDQvdCwINGB0YLQvtC40YIgPGIgY2xhc3NOYW1lPVwidGV4dC1hbWJlci00MDAgZm9udC1tb25vXCI+MSwwMDAg0LzQvtC90LXRgjwvYj4uINCb0LjQtNC10YBcbiAgICAgICAgICAgICAg0LzQvtC20LXRgiDQv9GA0LjQs9C70LDRiNCw0YLRjCDQuNCz0YDQvtC60L7Qsiwg0L3QsNGB0YLRgNCw0LjQstCw0YLRjCDQs9C10YDQsSDQuCDRgNCw0YHQv9GA0LXQtNC10LvRj9GC0Ywg0L3QsNCz0YDQsNC00Ysg0LfQsCDQutCy0LXRgdGC0YsuXG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTNcIj5cbiAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwiYmxvY2sgdGV4dC14cyBmb250LWJvbGQgdGV4dC1zbGF0ZS00MDAgbWItMVwiPlxuICAgICAgICAgICAgICAgICAg0J3QsNC30LLQsNC90LjQtSDQutC70LDQvdCwOlxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICByZXF1aXJlZFxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCLQndCw0L/RgNC40LzQtdGAOiDQm9C10LPQtdC90LTRiyDQnNGP0YNcIlxuICAgICAgICAgICAgICAgICAgdmFsdWU9e25ld0NsYW5OYW1lfVxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXROZXdDbGFuTmFtZShlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgYmctc2xhdGUtOTUwIGJvcmRlciBib3JkZXItc2xhdGUtNzAwIHJvdW5kZWQteGwgcHgtMyBweS0yIHRleHQteHMgdGV4dC13aGl0ZSBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6Ym9yZGVyLWluZGlnby01MDBcIlxuICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQteHMgZm9udC1ib2xkIHRleHQtc2xhdGUtNDAwIG1iLTFcIj5cbiAgICAgICAgICAgICAgICAgINCa0LvQsNC90L7QstGL0Lkg0YLQtdCzICjQtNC+IDUg0YHQuNC80LLQvtC70L7Qsik6XG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgICAgIG1heExlbmd0aD17NX1cbiAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXG4gICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIk1FT1dcIlxuICAgICAgICAgICAgICAgICAgdmFsdWU9e25ld0NsYW5UYWd9XG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldE5ld0NsYW5UYWcoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIGJnLXNsYXRlLTk1MCBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMCByb3VuZGVkLXhsIHB4LTMgcHktMiB0ZXh0LXhzIHRleHQtd2hpdGUgdXBwZXJjYXNlIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpib3JkZXItaW5kaWdvLTUwMCBmb250LW1vbm9cIlxuICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cImJsb2NrIHRleHQteHMgZm9udC1ib2xkIHRleHQtc2xhdGUtNDAwIG1iLTFcIj5cbiAgICAgICAgICAgICAgICAgINCU0LXQstC40LcgLyDQntC/0LjRgdCw0L3QuNC1OlxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICAgPHRleHRhcmVhXG4gICAgICAgICAgICAgICAgICByb3dzPXszfVxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCLQntC/0LjRiNC40YLQtSDRhtC10LvQuCDQstCw0YjQtdCz0L4g0LrQu9Cw0L3QsC4uLlwiXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17bmV3Q2xhbkRlc2N9XG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldE5ld0NsYW5EZXNjKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInctZnVsbCBiZy1zbGF0ZS05NTAgYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAgcm91bmRlZC14bCBweC0zIHB5LTIgdGV4dC14cyB0ZXh0LXdoaXRlIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpib3JkZXItaW5kaWdvLTUwMFwiXG4gICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICB0eXBlPVwic3VibWl0XCJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsIHB5LTMgYmctZ3JhZGllbnQtdG8tciBmcm9tLWluZGlnby01MDAgdG8tcHVycGxlLTYwMCBob3Zlcjpmcm9tLWluZGlnby00MDAgaG92ZXI6dG8tcHVycGxlLTUwMCB0ZXh0LXdoaXRlIHJvdW5kZWQteGwgZm9udC1ibGFjayB0ZXh0LXNtIHNoYWRvdy14bCBhY3RpdmU6c2NhbGUtOTUgdHJhbnNpdGlvbi10cmFuc2Zvcm1cIlxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICDQntGB0L3QvtCy0LDRgtGMINCa0LvQsNC9INC30LAgMSwwMDAg8J+qmVxuICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgPC9mb3JtPlxuICAgICAgICApfVxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG4gICk7XG59O1xuIl19