const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=1e19e0c2";
import { sounds } from "/src/utils/sound.ts";
var _jsxFileName = "/app/applet/src/components/CoopLobbyModal.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=1e19e0c2";
export const CoopLobbyModal = ({ isCoopActive, onStartCoopGame, onLeaveCoop, onClose }) => {
	const [roomCode, setRoomCode] = useState("CAT-7742");
	const [inputCode, setInputCode] = useState("");
	const [isSearching, setIsSearching] = useState(false);
	const [partnerFound, setPartnerFound] = useState(isCoopActive ? {
		name: "ProBacon_99",
		avatar: "🥓",
		rank: "Ветеран"
	} : null);
	const handleCreateRoom = () => {
		const code = "CAT-" + Math.floor(1e3 + Math.random() * 9e3);
		setRoomCode(code);
		setIsSearching(true);
		setTimeout(() => {
			setIsSearching(false);
			setPartnerFound({
				name: "CoolCat_3000",
				avatar: "🐱",
				rank: "Мастер Защиты"
			});
			sounds.playCoin();
		}, 1200);
	};
	const handleJoinByCode = (e) => {
		e.preventDefault();
		if (!inputCode.trim()) return;
		setIsSearching(true);
		setTimeout(() => {
			setIsSearching(false);
			setPartnerFound({
				name: "ViperX_Friend",
				avatar: "🤠",
				rank: "Хардкорный Защитник"
			});
			sounds.playCoin();
		}, 1e3);
	};
	const handleLaunchCoop = () => {
		if (!partnerFound) return;
		sounds.playWaveStart();
		onStartCoopGame(roomCode, partnerFound.name);
		onClose();
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "fixed inset-0 z-50 flex items-center justify-center bg-slate-950/85 backdrop-blur-md p-4",
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: "bg-slate-900 border-2 border-cyan-500/50 rounded-3xl p-6 max-w-lg w-full shadow-2xl text-slate-100",
			children: [/* @__PURE__ */ _jsxDEV("div", {
				className: "flex items-center justify-between pb-4 border-b border-slate-800",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center space-x-3",
					children: [/* @__PURE__ */ _jsxDEV("span", {
						className: "text-3xl",
						children: "🤝"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 71,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h2", {
						className: "text-xl font-black text-cyan-400",
						children: "Кооператив с Друзьями"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 73,
						columnNumber: 15
					}, this), /* @__PURE__ */ _jsxDEV("p", {
						className: "text-xs text-slate-400",
						children: "Защищайте базу вдвоем, ставьте башни на общей карте и делите победу!"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 74,
						columnNumber: 15
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 72,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 70,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("button", {
					onClick: onClose,
					className: "w-8 h-8 rounded-full bg-slate-800 hover:bg-slate-700 flex items-center justify-center text-slate-400 hover:text-white",
					children: "✕"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 79,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 69,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("div", {
				className: "my-5 space-y-4",
				children: !partnerFound && !isSearching ? /* @__PURE__ */ _jsxDEV("div", {
					className: "space-y-4",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "p-4 bg-slate-950 border border-slate-800 rounded-2xl flex items-center justify-between",
						children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h4", {
							className: "font-extrabold text-sm text-white",
							children: "Создать новую комнату"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 94,
							columnNumber: 19
						}, this), /* @__PURE__ */ _jsxDEV("p", {
							className: "text-xs text-slate-400",
							children: "Получите код лобби и поделитесь с другом"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 95,
							columnNumber: 19
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 93,
							columnNumber: 17
						}, this), /* @__PURE__ */ _jsxDEV("button", {
							onClick: handleCreateRoom,
							className: "px-4 py-2 bg-cyan-600 hover:bg-cyan-500 text-white rounded-xl font-bold text-xs shadow-md",
							children: "Создать"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 99,
							columnNumber: 17
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 92,
						columnNumber: 15
					}, this), /* @__PURE__ */ _jsxDEV("form", {
						onSubmit: handleJoinByCode,
						className: "p-4 bg-slate-950 border border-slate-800 rounded-2xl space-y-2",
						children: [/* @__PURE__ */ _jsxDEV("h4", {
							className: "font-extrabold text-sm text-white",
							children: "Войти по коду друга"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 112,
							columnNumber: 17
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "flex space-x-2",
							children: [/* @__PURE__ */ _jsxDEV("input", {
								type: "text",
								required: true,
								placeholder: "Например: CAT-4821",
								value: inputCode,
								onChange: (e) => setInputCode(e.target.value.toUpperCase()),
								className: "flex-1 bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white uppercase font-mono focus:outline-none focus:border-cyan-500"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 114,
								columnNumber: 19
							}, this), /* @__PURE__ */ _jsxDEV("button", {
								type: "submit",
								className: "px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl font-bold text-xs",
								children: "Подключиться"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 122,
								columnNumber: 19
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 113,
							columnNumber: 17
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 108,
						columnNumber: 15
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 90,
					columnNumber: 13
				}, this) : isSearching ? /* @__PURE__ */ _jsxDEV("div", {
					className: "p-8 text-center space-y-3",
					children: [/* @__PURE__ */ _jsxDEV("div", { className: "w-10 h-10 border-4 border-cyan-500 border-t-transparent rounded-full animate-spin mx-auto" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 133,
						columnNumber: 15
					}, this), /* @__PURE__ */ _jsxDEV("p", {
						className: "text-sm font-bold text-cyan-300",
						children: "Поиск напарника в сети Роблокс..."
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 134,
						columnNumber: 15
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 132,
					columnNumber: 13
				}, this) : /* @__PURE__ */ _jsxDEV("div", {
					className: "p-4 bg-cyan-950/40 border border-cyan-500/40 rounded-2xl space-y-3",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center justify-between border-b border-cyan-800/50 pb-2",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "text-xs text-slate-400",
								children: "Код комнаты:"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 139,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "font-mono text-sm font-black text-cyan-400 bg-black/40 px-2 py-0.5 rounded",
								children: roomCode
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 140,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 138,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center space-x-3",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "w-12 h-12 rounded-xl bg-slate-800 border border-cyan-400 flex items-center justify-center text-2xl",
								children: partnerFound?.avatar
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 146,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center space-x-2",
								children: [/* @__PURE__ */ _jsxDEV("h4", {
									className: "font-black text-sm text-white",
									children: partnerFound?.name
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 151,
									columnNumber: 21
								}, this), /* @__PURE__ */ _jsxDEV("span", { className: "w-2 h-2 rounded-full bg-emerald-400 animate-pulse" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 152,
									columnNumber: 21
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 150,
								columnNumber: 19
							}, this), /* @__PURE__ */ _jsxDEV("p", {
								className: "text-xs text-cyan-300 font-mono",
								children: partnerFound?.rank
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 154,
								columnNumber: 19
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 149,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 145,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "p-2.5 bg-slate-900/80 rounded-xl text-xs text-slate-300 space-y-1",
							children: [
								/* @__PURE__ */ _jsxDEV("div", { children: "✓ Общее здоровье замка базы" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 159,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("div", { children: "✓ Напарник автономно выставляет оборонительные башни" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 160,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("div", { children: "✓ Удвоенные награды за победу над боссами" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 161,
									columnNumber: 17
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 158,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex space-x-2 pt-2",
							children: [/* @__PURE__ */ _jsxDEV("button", {
								onClick: handleLaunchCoop,
								className: "flex-1 py-2.5 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-black rounded-xl text-xs shadow-lg active:scale-95 transition-transform",
								children: "🚀 В бой в Коопе!"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 165,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("button", {
								onClick: () => {
									setPartnerFound(null);
									onLeaveCoop();
								},
								className: "px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-bold",
								children: "Выйти"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 171,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 164,
							columnNumber: 15
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 137,
					columnNumber: 13
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 88,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 67,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 66,
		columnNumber: 5
	}, this);
};

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLGdCQUFnQjtBQUNoQyxTQUFTLGNBQWM7OztBQVN2QixPQUFPLE1BQU0sa0JBQWlELEVBQzVELGNBQ0EsaUJBQ0EsYUFDQSxjQUNJO0NBQ0osTUFBTSxDQUFDLFVBQVUsZUFBZSxTQUFTLFVBQVU7Q0FDbkQsTUFBTSxDQUFDLFdBQVcsZ0JBQWdCLFNBQVMsRUFBRTtDQUM3QyxNQUFNLENBQUMsYUFBYSxrQkFBa0IsU0FBUyxLQUFLO0NBQ3BELE1BQU0sQ0FBQyxjQUFjLG1CQUFtQixTQUk5QixlQUFlO0VBQUUsTUFBTTtFQUFlLFFBQVE7RUFBTSxNQUFNO0NBQVUsSUFBSSxJQUFJO0NBRXRGLE1BQU0seUJBQXlCO0VBQzdCLE1BQU0sT0FBTyxTQUFTLEtBQUssTUFBTSxNQUFPLEtBQUssT0FBTyxJQUFJLEdBQUk7RUFDNUQsWUFBWSxJQUFJO0VBQ2hCLGVBQWUsSUFBSTtFQUVuQixpQkFBaUI7R0FDZixlQUFlLEtBQUs7R0FDcEIsZ0JBQWdCO0lBQ2QsTUFBTTtJQUNOLFFBQVE7SUFDUixNQUFNO0dBQ1IsQ0FBQztHQUNELE9BQU8sU0FBUztFQUNsQixHQUFHLElBQUk7Q0FDVDtDQUVBLE1BQU0sb0JBQW9CLE1BQXVCO0VBQy9DLEVBQUUsZUFBZTtFQUNqQixJQUFJLENBQUMsVUFBVSxLQUFLLEdBQUc7RUFFdkIsZUFBZSxJQUFJO0VBQ25CLGlCQUFpQjtHQUNmLGVBQWUsS0FBSztHQUNwQixnQkFBZ0I7SUFDZCxNQUFNO0lBQ04sUUFBUTtJQUNSLE1BQU07R0FDUixDQUFDO0dBQ0QsT0FBTyxTQUFTO0VBQ2xCLEdBQUcsR0FBSTtDQUNUO0NBRUEsTUFBTSx5QkFBeUI7RUFDN0IsSUFBSSxDQUFDLGNBQWM7RUFDbkIsT0FBTyxjQUFjO0VBQ3JCLGdCQUFnQixVQUFVLGFBQWEsSUFBSTtFQUMzQyxRQUFRO0NBQ1Y7Q0FFQSxPQUNFLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQ2Isd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFBZixDQUVFLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsUUFBRDtNQUFNLFdBQVU7Z0JBQVc7S0FBUTs7OztlQUNuQyx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsTUFBRDtNQUFJLFdBQVU7Z0JBQW1DO0tBQXlCOzs7O2VBQzFFLHdCQUFDLEtBQUQ7TUFBRyxXQUFVO2dCQUF5QjtLQUVuQzs7OzthQUNBOzs7O2FBQ0Y7Ozs7O2NBQ0wsd0JBQUMsVUFBRDtLQUNFLFNBQVM7S0FDVCxXQUFVO2VBQ1g7SUFFTzs7OztZQUNMOzs7OzthQUdMLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQ1osQ0FBQyxnQkFBZ0IsQ0FBQyxjQUNqQix3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBRUUsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsTUFBRDtPQUFJLFdBQVU7aUJBQW9DO01BQXlCOzs7O2dCQUMzRSx3QkFBQyxLQUFEO09BQUcsV0FBVTtpQkFBeUI7TUFFbkM7Ozs7Y0FDQTs7OztnQkFDTCx3QkFBQyxVQUFEO09BQ0UsU0FBUztPQUNULFdBQVU7aUJBQ1g7TUFFTzs7OztjQUNMOzs7OztlQUdMLHdCQUFDLFFBQUQ7TUFDRSxVQUFVO01BQ1YsV0FBVTtnQkFGWixDQUlFLHdCQUFDLE1BQUQ7T0FBSSxXQUFVO2lCQUFvQztNQUF1Qjs7OztnQkFDekUsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxTQUFEO1FBQ0UsTUFBSztRQUNMO1FBQ0EsYUFBWTtRQUNaLE9BQU87UUFDUCxXQUFXLE1BQU0sYUFBYSxFQUFFLE9BQU8sTUFBTSxZQUFZLENBQUM7UUFDMUQsV0FBVTtPQUNYOzs7O2lCQUNELHdCQUFDLFVBQUQ7UUFDRSxNQUFLO1FBQ0wsV0FBVTtrQkFDWDtPQUVPOzs7O2VBQ0w7Ozs7O2NBQ0Q7Ozs7O2FBQ0g7Ozs7O2VBQ0gsY0FDRix3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsT0FBRCxFQUFLLFdBQVUsNEZBQTZGOzs7O2VBQzVHLHdCQUFDLEtBQUQ7TUFBRyxXQUFVO2dCQUFrQztLQUFvQzs7OzthQUNoRjs7Ozs7ZUFFTCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmO01BQ0Usd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBeUI7T0FBa0I7Ozs7aUJBQzNELHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUNiO09BQ0c7Ozs7ZUFDSDs7Ozs7O01BRUwsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFDWixjQUFjO09BQ1o7Ozs7aUJBQ0wsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsTUFBRDtTQUFJLFdBQVU7bUJBQWlDLGNBQWM7UUFBUzs7OztrQkFDdEUsd0JBQUMsUUFBRCxFQUFNLFdBQVUsb0RBQXFEOzs7O2dCQUNsRTs7Ozs7aUJBQ0wsd0JBQUMsS0FBRDtRQUFHLFdBQVU7a0JBQW1DLGNBQWM7T0FBUTs7OztlQUNuRTs7OztlQUNGOzs7Ozs7TUFFTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZjtRQUNFLHdCQUFDLE9BQUQsWUFBSyw4QkFBZ0M7Ozs7O1FBQ3JDLHdCQUFDLE9BQUQsWUFBSyx1REFBeUQ7Ozs7O1FBQzlELHdCQUFDLE9BQUQsWUFBSyw0Q0FBOEM7Ozs7O09BQ2hEOzs7Ozs7TUFFTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLFVBQUQ7UUFDRSxTQUFTO1FBQ1QsV0FBVTtrQkFDWDtPQUVPOzs7O2lCQUNSLHdCQUFDLFVBQUQ7UUFDRSxlQUFlO1NBQ2IsZ0JBQWdCLElBQUk7U0FDcEIsWUFBWTtRQUNkO1FBQ0EsV0FBVTtrQkFDWDtPQUVPOzs7O2VBQ0w7Ozs7OztLQUNGOzs7Ozs7R0FFSjs7OztXQUNGOzs7Ozs7Q0FDRjs7Ozs7QUFFVCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJDb29wTG9iYnlNb2RhbC50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgc291bmRzIH0gZnJvbSAnLi4vdXRpbHMvc291bmQnO1xuXG5pbnRlcmZhY2UgQ29vcExvYmJ5TW9kYWxQcm9wcyB7XG4gIGlzQ29vcEFjdGl2ZTogYm9vbGVhbjtcbiAgb25TdGFydENvb3BHYW1lOiAocm9vbUNvZGU6IHN0cmluZywgYWxseU5hbWU6IHN0cmluZykgPT4gdm9pZDtcbiAgb25MZWF2ZUNvb3A6ICgpID0+IHZvaWQ7XG4gIG9uQ2xvc2U6ICgpID0+IHZvaWQ7XG59XG5cbmV4cG9ydCBjb25zdCBDb29wTG9iYnlNb2RhbDogUmVhY3QuRkM8Q29vcExvYmJ5TW9kYWxQcm9wcz4gPSAoe1xuICBpc0Nvb3BBY3RpdmUsXG4gIG9uU3RhcnRDb29wR2FtZSxcbiAgb25MZWF2ZUNvb3AsXG4gIG9uQ2xvc2UsXG59KSA9PiB7XG4gIGNvbnN0IFtyb29tQ29kZSwgc2V0Um9vbUNvZGVdID0gdXNlU3RhdGUoJ0NBVC03NzQyJyk7XG4gIGNvbnN0IFtpbnB1dENvZGUsIHNldElucHV0Q29kZV0gPSB1c2VTdGF0ZSgnJyk7XG4gIGNvbnN0IFtpc1NlYXJjaGluZywgc2V0SXNTZWFyY2hpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xuICBjb25zdCBbcGFydG5lckZvdW5kLCBzZXRQYXJ0bmVyRm91bmRdID0gdXNlU3RhdGU8e1xuICAgIG5hbWU6IHN0cmluZztcbiAgICBhdmF0YXI6IHN0cmluZztcbiAgICByYW5rOiBzdHJpbmc7XG4gIH0gfCBudWxsPihpc0Nvb3BBY3RpdmUgPyB7IG5hbWU6ICdQcm9CYWNvbl85OScsIGF2YXRhcjogJ/CfpZMnLCByYW5rOiAn0JLQtdGC0LXRgNCw0L0nIH0gOiBudWxsKTtcblxuICBjb25zdCBoYW5kbGVDcmVhdGVSb29tID0gKCkgPT4ge1xuICAgIGNvbnN0IGNvZGUgPSAnQ0FULScgKyBNYXRoLmZsb29yKDEwMDAgKyBNYXRoLnJhbmRvbSgpICogOTAwMCk7XG4gICAgc2V0Um9vbUNvZGUoY29kZSk7XG4gICAgc2V0SXNTZWFyY2hpbmcodHJ1ZSk7XG5cbiAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgIHNldElzU2VhcmNoaW5nKGZhbHNlKTtcbiAgICAgIHNldFBhcnRuZXJGb3VuZCh7XG4gICAgICAgIG5hbWU6ICdDb29sQ2F0XzMwMDAnLFxuICAgICAgICBhdmF0YXI6ICfwn5CxJyxcbiAgICAgICAgcmFuazogJ9Cc0LDRgdGC0LXRgCDQl9Cw0YnQuNGC0YsnLFxuICAgICAgfSk7XG4gICAgICBzb3VuZHMucGxheUNvaW4oKTtcbiAgICB9LCAxMjAwKTtcbiAgfTtcblxuICBjb25zdCBoYW5kbGVKb2luQnlDb2RlID0gKGU6IFJlYWN0LkZvcm1FdmVudCkgPT4ge1xuICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICBpZiAoIWlucHV0Q29kZS50cmltKCkpIHJldHVybjtcblxuICAgIHNldElzU2VhcmNoaW5nKHRydWUpO1xuICAgIHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgc2V0SXNTZWFyY2hpbmcoZmFsc2UpO1xuICAgICAgc2V0UGFydG5lckZvdW5kKHtcbiAgICAgICAgbmFtZTogJ1ZpcGVyWF9GcmllbmQnLFxuICAgICAgICBhdmF0YXI6ICfwn6SgJyxcbiAgICAgICAgcmFuazogJ9Cl0LDRgNC00LrQvtGA0L3Ri9C5INCX0LDRidC40YLQvdC40LonLFxuICAgICAgfSk7XG4gICAgICBzb3VuZHMucGxheUNvaW4oKTtcbiAgICB9LCAxMDAwKTtcbiAgfTtcblxuICBjb25zdCBoYW5kbGVMYXVuY2hDb29wID0gKCkgPT4ge1xuICAgIGlmICghcGFydG5lckZvdW5kKSByZXR1cm47XG4gICAgc291bmRzLnBsYXlXYXZlU3RhcnQoKTtcbiAgICBvblN0YXJ0Q29vcEdhbWUocm9vbUNvZGUsIHBhcnRuZXJGb3VuZC5uYW1lKTtcbiAgICBvbkNsb3NlKCk7XG4gIH07XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImZpeGVkIGluc2V0LTAgei01MCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBiZy1zbGF0ZS05NTAvODUgYmFja2Ryb3AtYmx1ci1tZCBwLTRcIj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTAwIGJvcmRlci0yIGJvcmRlci1jeWFuLTUwMC81MCByb3VuZGVkLTN4bCBwLTYgbWF4LXctbGcgdy1mdWxsIHNoYWRvdy0yeGwgdGV4dC1zbGF0ZS0xMDBcIj5cbiAgICAgICAgey8qIEhlYWRlciAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gcGItNCBib3JkZXItYiBib3JkZXItc2xhdGUtODAwXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBzcGFjZS14LTNcIj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtM3hsXCI+8J+knTwvc3Bhbj5cbiAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtYmxhY2sgdGV4dC1jeWFuLTQwMFwiPtCa0L7QvtC/0LXRgNCw0YLQuNCyINGBINCU0YDRg9C30YzRj9C80Lg8L2gyPlxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNDAwXCI+XG4gICAgICAgICAgICAgICAg0JfQsNGJ0LjRidCw0LnRgtC1INCx0LDQt9GDINCy0LTQstC+0LXQvCwg0YHRgtCw0LLRjNGC0LUg0LHQsNGI0L3QuCDQvdCwINC+0LHRidC10Lkg0LrQsNGA0YLQtSDQuCDQtNC10LvQuNGC0LUg0L/QvtCx0LXQtNGDIVxuICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICBvbkNsaWNrPXtvbkNsb3NlfVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwidy04IGgtOCByb3VuZGVkLWZ1bGwgYmctc2xhdGUtODAwIGhvdmVyOmJnLXNsYXRlLTcwMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciB0ZXh0LXNsYXRlLTQwMCBob3Zlcjp0ZXh0LXdoaXRlXCJcbiAgICAgICAgICA+XG4gICAgICAgICAgICDinJVcbiAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgey8qIEJvZHkgKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXktNSBzcGFjZS15LTRcIj5cbiAgICAgICAgICB7IXBhcnRuZXJGb3VuZCAmJiAhaXNTZWFyY2hpbmcgPyAoXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNwYWNlLXktNFwiPlxuICAgICAgICAgICAgICB7LyogT3B0aW9uIDE6IFF1aWNrIENyZWF0ZSAqL31cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTQgYmctc2xhdGUtOTUwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHJvdW5kZWQtMnhsIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxuICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwiZm9udC1leHRyYWJvbGQgdGV4dC1zbSB0ZXh0LXdoaXRlXCI+0KHQvtC30LTQsNGC0Ywg0L3QvtCy0YPRjiDQutC+0LzQvdCw0YLRgzwvaDQ+XG4gICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNDAwXCI+XG4gICAgICAgICAgICAgICAgICAgINCf0L7Qu9GD0YfQuNGC0LUg0LrQvtC0INC70L7QsdCx0Lgg0Lgg0L/QvtC00LXQu9C40YLQtdGB0Ywg0YEg0LTRgNGD0LPQvtC8XG4gICAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlQ3JlYXRlUm9vbX1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTQgcHktMiBiZy1jeWFuLTYwMCBob3ZlcjpiZy1jeWFuLTUwMCB0ZXh0LXdoaXRlIHJvdW5kZWQteGwgZm9udC1ib2xkIHRleHQteHMgc2hhZG93LW1kXCJcbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICDQodC+0LfQtNCw0YLRjFxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICB7LyogT3B0aW9uIDI6IEpvaW4gYnkgY29kZSAqL31cbiAgICAgICAgICAgICAgPGZvcm1cbiAgICAgICAgICAgICAgICBvblN1Ym1pdD17aGFuZGxlSm9pbkJ5Q29kZX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwLTQgYmctc2xhdGUtOTUwIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHJvdW5kZWQtMnhsIHNwYWNlLXktMlwiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwiZm9udC1leHRyYWJvbGQgdGV4dC1zbSB0ZXh0LXdoaXRlXCI+0JLQvtC50YLQuCDQv9C+INC60L7QtNGDINC00YDRg9Cz0LA8L2g0PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBzcGFjZS14LTJcIj5cbiAgICAgICAgICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXG4gICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwi0J3QsNC/0YDQuNC80LXRgDogQ0FULTQ4MjFcIlxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17aW5wdXRDb2RlfVxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldElucHV0Q29kZShlLnRhcmdldC52YWx1ZS50b1VwcGVyQ2FzZSgpKX1cbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleC0xIGJnLXNsYXRlLTkwMCBib3JkZXIgYm9yZGVyLXNsYXRlLTcwMCByb3VuZGVkLXhsIHB4LTMgcHktMiB0ZXh0LXhzIHRleHQtd2hpdGUgdXBwZXJjYXNlIGZvbnQtbW9ubyBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6Ym9yZGVyLWN5YW4tNTAwXCJcbiAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJzdWJtaXRcIlxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC00IHB5LTIgYmctc2xhdGUtODAwIGhvdmVyOmJnLXNsYXRlLTcwMCB0ZXh0LXNsYXRlLTIwMCByb3VuZGVkLXhsIGZvbnQtYm9sZCB0ZXh0LXhzXCJcbiAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAg0J/QvtC00LrQu9GO0YfQuNGC0YzRgdGPXG4gICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9mb3JtPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKSA6IGlzU2VhcmNoaW5nID8gKFxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTggdGV4dC1jZW50ZXIgc3BhY2UteS0zXCI+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xMCBoLTEwIGJvcmRlci00IGJvcmRlci1jeWFuLTUwMCBib3JkZXItdC10cmFuc3BhcmVudCByb3VuZGVkLWZ1bGwgYW5pbWF0ZS1zcGluIG14LWF1dG9cIiAvPlxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtYm9sZCB0ZXh0LWN5YW4tMzAwXCI+0J/QvtC40YHQuiDQvdCw0L/QsNGA0L3QuNC60LAg0LIg0YHQtdGC0Lgg0KDQvtCx0LvQvtC60YEuLi48L3A+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICApIDogKFxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTQgYmctY3lhbi05NTAvNDAgYm9yZGVyIGJvcmRlci1jeWFuLTUwMC80MCByb3VuZGVkLTJ4bCBzcGFjZS15LTNcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gYm9yZGVyLWIgYm9yZGVyLWN5YW4tODAwLzUwIHBiLTJcIj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNDAwXCI+0JrQvtC0INC60L7QvNC90LDRgtGLOjwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LW1vbm8gdGV4dC1zbSBmb250LWJsYWNrIHRleHQtY3lhbi00MDAgYmctYmxhY2svNDAgcHgtMiBweS0wLjUgcm91bmRlZFwiPlxuICAgICAgICAgICAgICAgICAge3Jvb21Db2RlfVxuICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBzcGFjZS14LTNcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctMTIgaC0xMiByb3VuZGVkLXhsIGJnLXNsYXRlLTgwMCBib3JkZXIgYm9yZGVyLWN5YW4tNDAwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHRleHQtMnhsXCI+XG4gICAgICAgICAgICAgICAgICB7cGFydG5lckZvdW5kPy5hdmF0YXJ9XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgc3BhY2UteC0yXCI+XG4gICAgICAgICAgICAgICAgICAgIDxoNCBjbGFzc05hbWU9XCJmb250LWJsYWNrIHRleHQtc20gdGV4dC13aGl0ZVwiPntwYXJ0bmVyRm91bmQ/Lm5hbWV9PC9oND5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidy0yIGgtMiByb3VuZGVkLWZ1bGwgYmctZW1lcmFsZC00MDAgYW5pbWF0ZS1wdWxzZVwiIC8+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1jeWFuLTMwMCBmb250LW1vbm9cIj57cGFydG5lckZvdW5kPy5yYW5rfTwvcD5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwLTIuNSBiZy1zbGF0ZS05MDAvODAgcm91bmRlZC14bCB0ZXh0LXhzIHRleHQtc2xhdGUtMzAwIHNwYWNlLXktMVwiPlxuICAgICAgICAgICAgICAgIDxkaXY+4pyTINCe0LHRidC10LUg0LfQtNC+0YDQvtCy0YzQtSDQt9Cw0LzQutCwINCx0LDQt9GLPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdj7inJMg0J3QsNC/0LDRgNC90LjQuiDQsNCy0YLQvtC90L7QvNC90L4g0LLRi9GB0YLQsNCy0LvRj9C10YIg0L7QsdC+0YDQvtC90LjRgtC10LvRjNC90YvQtSDQsdCw0YjQvdC4PC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdj7inJMg0KPQtNCy0L7QtdC90L3Ri9C1INC90LDQs9GA0LDQtNGLINC30LAg0L/QvtCx0LXQtNGDINC90LDQtCDQsdC+0YHRgdCw0LzQuDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggc3BhY2UteC0yIHB0LTJcIj5cbiAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVMYXVuY2hDb29wfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleC0xIHB5LTIuNSBiZy1ncmFkaWVudC10by1yIGZyb20tY3lhbi01MDAgdG8tYmx1ZS02MDAgaG92ZXI6ZnJvbS1jeWFuLTQwMCBob3Zlcjp0by1ibHVlLTUwMCB0ZXh0LXNsYXRlLTk1MCBmb250LWJsYWNrIHJvdW5kZWQteGwgdGV4dC14cyBzaGFkb3ctbGcgYWN0aXZlOnNjYWxlLTk1IHRyYW5zaXRpb24tdHJhbnNmb3JtXCJcbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICDwn5qAINCSINCx0L7QuSDQsiDQmtC+0L7Qv9C1IVxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgc2V0UGFydG5lckZvdW5kKG51bGwpO1xuICAgICAgICAgICAgICAgICAgICBvbkxlYXZlQ29vcCgpO1xuICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTQgcHktMi41IGJnLXNsYXRlLTgwMCBob3ZlcjpiZy1zbGF0ZS03MDAgdGV4dC1zbGF0ZS0zMDAgcm91bmRlZC14bCB0ZXh0LXhzIGZvbnQtYm9sZFwiXG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAg0JLRi9C50YLQuFxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICl9XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG4gICk7XG59O1xuIl19