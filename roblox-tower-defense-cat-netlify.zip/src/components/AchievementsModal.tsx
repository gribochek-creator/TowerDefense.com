const React = __vite__cjsImport0_react;const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=1e19e0c2";
import confetti from "/node_modules/.vite/deps/canvas-confetti.js?v=601c4ae1";
import { sounds } from "/src/utils/sound.ts";
var _jsxFileName = "/app/applet/src/components/AchievementsModal.tsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=1e19e0c2";
export const AchievementsModal = ({ achievements, setAchievements, setUser, onClose }) => {
	const handleClaim = (ach) => {
		if (ach.claimed || ach.progress < ach.maxProgress) return;
		sounds.playVictory();
		confetti({
			particleCount: 50,
			spread: 60
		});
		setAchievements((prev) => prev.map((a) => a.id === ach.id ? {
			...a,
			claimed: true
		} : a));
		setUser((prev) => ({
			...prev,
			coins: prev.coins + ach.rewardCoins,
			gems: prev.gems + ach.rewardGems,
			xp: prev.xp + 100
		}));
	};
	const completedCount = achievements.filter((a) => a.claimed).length;
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "fixed inset-0 z-50 flex items-center justify-center bg-slate-950/85 backdrop-blur-md p-4",
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: "bg-slate-900 border-2 border-cyan-500/40 rounded-3xl p-6 max-w-2xl w-full shadow-2xl text-slate-100 max-h-[85vh] flex flex-col",
			children: [
				/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center justify-between pb-4 border-b border-slate-800",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center space-x-3",
						children: [/* @__PURE__ */ _jsxDEV("span", {
							className: "text-3xl",
							children: "🎖️"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 46,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h2", {
							className: "text-xl font-black text-cyan-400",
							children: "Система Достижений"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 48,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("p", {
							className: "text-xs text-slate-400",
							children: "Выполняйте задания, прокачивайте героя и получайте монеты и кристаллы"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 49,
							columnNumber: 15
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 47,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 45,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("button", {
						onClick: onClose,
						className: "w-8 h-8 rounded-full bg-slate-800 hover:bg-slate-700 flex items-center justify-center text-slate-400 hover:text-white",
						children: "✕"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 54,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 44,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "my-3 p-3 bg-slate-950/70 border border-slate-800 rounded-2xl flex items-center justify-between text-xs",
					children: [/* @__PURE__ */ _jsxDEV("span", {
						className: "font-bold text-slate-300",
						children: [
							"Получено наград: ",
							/* @__PURE__ */ _jsxDEV("b", {
								className: "text-cyan-400",
								children: completedCount
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 65,
								columnNumber: 30
							}, this),
							" из ",
							achievements.length
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 64,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "w-40 h-2 bg-slate-800 rounded-full overflow-hidden",
						children: /* @__PURE__ */ _jsxDEV("div", {
							className: "h-full bg-cyan-400 transition-all duration-300",
							style: { width: `${completedCount / achievements.length * 100}%` }
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 68,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 67,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 63,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "flex-1 overflow-y-auto pr-1 space-y-2.5",
					children: achievements.map((ach) => {
						const isReadyToClaim = !ach.claimed && ach.progress >= ach.maxProgress;
						const pct = Math.min(100, ach.progress / ach.maxProgress * 100);
						return /* @__PURE__ */ _jsxDEV("div", {
							className: `p-3.5 rounded-2xl border flex items-center justify-between gap-3 ${ach.claimed ? "bg-slate-950/40 border-slate-800/80 opacity-70" : isReadyToClaim ? "bg-cyan-950/30 border-cyan-500 shadow-md" : "bg-slate-950/70 border-slate-800"}`,
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center space-x-3",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "w-12 h-12 rounded-xl bg-slate-800 border border-slate-700 flex items-center justify-center text-2xl shrink-0",
									children: ach.icon
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 93,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("div", { children: [
									/* @__PURE__ */ _jsxDEV("h4", {
										className: "font-extrabold text-sm text-white",
										children: ach.title
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 97,
										columnNumber: 21
									}, this),
									/* @__PURE__ */ _jsxDEV("p", {
										className: "text-xs text-slate-400 mt-0.5",
										children: ach.description
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 98,
										columnNumber: 21
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "mt-1.5 flex items-center space-x-2",
										children: [/* @__PURE__ */ _jsxDEV("div", {
											className: "w-28 h-1.5 bg-slate-800 rounded-full overflow-hidden",
											children: /* @__PURE__ */ _jsxDEV("div", {
												className: "h-full bg-cyan-500 rounded-full",
												style: { width: `${pct}%` }
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 102,
												columnNumber: 25
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 101,
											columnNumber: 23
										}, this), /* @__PURE__ */ _jsxDEV("span", {
											className: "text-[10px] text-slate-400 font-mono",
											children: [
												ach.progress,
												" / ",
												ach.maxProgress
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 107,
											columnNumber: 23
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 100,
										columnNumber: 21
									}, this)
								] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 96,
									columnNumber: 19
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 92,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "text-right shrink-0",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "text-xs font-mono font-bold text-amber-400 mb-1",
									children: [
										"+",
										ach.rewardCoins,
										" 🪙 • +",
										ach.rewardGems,
										" 💎"
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 115,
									columnNumber: 19
								}, this), ach.claimed ? /* @__PURE__ */ _jsxDEV("span", {
									className: "text-xs text-slate-500 font-bold",
									children: "Получено ✓"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 119,
									columnNumber: 21
								}, this) : isReadyToClaim ? /* @__PURE__ */ _jsxDEV("button", {
									onClick: () => handleClaim(ach),
									className: "px-3 py-1.5 bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-black rounded-xl text-xs shadow-md animate-bounce cursor-pointer",
									children: "Забрать!"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 121,
									columnNumber: 21
								}, this) : /* @__PURE__ */ _jsxDEV("span", {
									className: "text-xs text-slate-500 font-mono",
									children: "В процессе"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 128,
									columnNumber: 21
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 114,
								columnNumber: 17
							}, this)]
						}, ach.id, true, {
							fileName: _jsxFileName,
							lineNumber: 82,
							columnNumber: 15
						}, this);
					})
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 76,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 42,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 41,
		columnNumber: 5
	}, this);
};

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxXQUFXO0FBQ2xCLE9BQU8sY0FBYztBQUVyQixTQUFTLGNBQWM7OztBQVV2QixPQUFPLE1BQU0scUJBQXVELEVBQ2xFLGNBQ0EsaUJBQ0EsU0FDQSxjQUNJO0NBQ0osTUFBTSxlQUFlLFFBQXFCO0VBQ3hDLElBQUksSUFBSSxXQUFXLElBQUksV0FBVyxJQUFJLGFBQWE7RUFFbkQsT0FBTyxZQUFZO0VBQ25CLFNBQVM7R0FBRSxlQUFlO0dBQUksUUFBUTtFQUFHLENBQUM7RUFFMUMsaUJBQWlCLFNBQ2YsS0FBSyxLQUFLLE1BQU8sRUFBRSxPQUFPLElBQUksS0FBSztHQUFFLEdBQUc7R0FBRyxTQUFTO0VBQUssSUFBSSxDQUFFLENBQ2pFO0VBRUEsU0FBUyxVQUFVO0dBQ2pCLEdBQUc7R0FDSCxPQUFPLEtBQUssUUFBUSxJQUFJO0dBQ3hCLE1BQU0sS0FBSyxPQUFPLElBQUk7R0FDdEIsSUFBSSxLQUFLLEtBQUs7RUFDaEIsRUFBRTtDQUNKO0NBRUEsTUFBTSxpQkFBaUIsYUFBYSxRQUFRLE1BQU0sRUFBRSxPQUFPLENBQUMsQ0FBQztDQUU3RCxPQUNFLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQ2Isd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFBZjtJQUVFLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLFFBQUQ7T0FBTSxXQUFVO2lCQUFXO01BQVM7Ozs7Z0JBQ3BDLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxNQUFEO09BQUksV0FBVTtpQkFBbUM7TUFBc0I7Ozs7Z0JBQ3ZFLHdCQUFDLEtBQUQ7T0FBRyxXQUFVO2lCQUF5QjtNQUVuQzs7OztjQUNBOzs7O2NBQ0Y7Ozs7O2VBQ0wsd0JBQUMsVUFBRDtNQUNFLFNBQVM7TUFDVCxXQUFVO2dCQUNYO0tBRU87Ozs7YUFDTDs7Ozs7O0lBR0wsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLFFBQUQ7TUFBTSxXQUFVO2dCQUFoQjtPQUEyQztPQUN4Qix3QkFBQyxLQUFEO1FBQUcsV0FBVTtrQkFBaUI7T0FBa0I7Ozs7O09BQUM7T0FBSyxhQUFhO01BQ2hGOzs7OztlQUNOLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUNiLHdCQUFDLE9BQUQ7T0FDRSxXQUFVO09BQ1YsT0FBTyxFQUFFLE9BQU8sR0FBSSxpQkFBaUIsYUFBYSxTQUFVLElBQUksR0FBRztNQUNwRTs7Ozs7S0FDRTs7OzthQUNGOzs7Ozs7SUFHTCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUNaLGFBQWEsS0FBSyxRQUFRO01BQ3pCLE1BQU0saUJBQWlCLENBQUMsSUFBSSxXQUFXLElBQUksWUFBWSxJQUFJO01BQzNELE1BQU0sTUFBTSxLQUFLLElBQUksS0FBTSxJQUFJLFdBQVcsSUFBSSxjQUFlLEdBQUc7TUFFaEUsT0FDRSx3QkFBQyxPQUFEO09BRUUsV0FBVyxvRUFDVCxJQUFJLFVBQ0EsbURBQ0EsaUJBQ0EsNkNBQ0E7aUJBUFIsQ0FVRSx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUNaLElBQUk7UUFDRjs7OztrQkFDTCx3QkFBQyxPQUFEO1NBQ0Usd0JBQUMsTUFBRDtVQUFJLFdBQVU7b0JBQXFDLElBQUk7U0FBVTs7Ozs7U0FDakUsd0JBQUMsS0FBRDtVQUFHLFdBQVU7b0JBQWlDLElBQUk7U0FBZTs7Ozs7U0FFakUsd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWYsQ0FDRSx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFDYix3QkFBQyxPQUFEO1lBQ0UsV0FBVTtZQUNWLE9BQU8sRUFBRSxPQUFPLEdBQUcsSUFBSSxHQUFHO1dBQzNCOzs7OztVQUNFOzs7O29CQUNMLHdCQUFDLFFBQUQ7V0FBTSxXQUFVO3FCQUFoQjtZQUNHLElBQUk7WUFBUztZQUFJLElBQUk7V0FDbEI7Ozs7O2tCQUNIOzs7Ozs7UUFDRjs7OztnQkFDRjs7Ozs7aUJBRUwsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZjtVQUFpRTtVQUM3RCxJQUFJO1VBQVk7VUFBYSxJQUFJO1VBQVc7U0FDM0M7Ozs7O2tCQUNKLElBQUksVUFDSCx3QkFBQyxRQUFEO1NBQU0sV0FBVTttQkFBbUM7UUFBZ0I7Ozs7bUJBQ2pFLGlCQUNGLHdCQUFDLFVBQUQ7U0FDRSxlQUFlLFlBQVksR0FBRztTQUM5QixXQUFVO21CQUNYO1FBRU87Ozs7bUJBRVIsd0JBQUMsUUFBRDtTQUFNLFdBQVU7bUJBQW1DO1FBQWdCOzs7O2dCQUVsRTs7Ozs7ZUFDRjtTQWhERSxJQUFJOzs7O2FBZ0ROO0tBRVQsQ0FBQztJQUNFOzs7OztHQUNGOzs7Ozs7Q0FDRjs7Ozs7QUFFVCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJBY2hpZXZlbWVudHNNb2RhbC50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCBjb25mZXR0aSBmcm9tICdjYW52YXMtY29uZmV0dGknO1xuaW1wb3J0IHsgQWNoaWV2ZW1lbnQsIFVzZXJQcm9maWxlIH0gZnJvbSAnLi4vdHlwZXMvZ2FtZSc7XG5pbXBvcnQgeyBzb3VuZHMgfSBmcm9tICcuLi91dGlscy9zb3VuZCc7XG5cbmludGVyZmFjZSBBY2hpZXZlbWVudHNNb2RhbFByb3BzIHtcbiAgYWNoaWV2ZW1lbnRzOiBBY2hpZXZlbWVudFtdO1xuICBzZXRBY2hpZXZlbWVudHM6IFJlYWN0LkRpc3BhdGNoPFJlYWN0LlNldFN0YXRlQWN0aW9uPEFjaGlldmVtZW50W10+PjtcbiAgdXNlcjogVXNlclByb2ZpbGU7XG4gIHNldFVzZXI6IFJlYWN0LkRpc3BhdGNoPFJlYWN0LlNldFN0YXRlQWN0aW9uPFVzZXJQcm9maWxlPj47XG4gIG9uQ2xvc2U6ICgpID0+IHZvaWQ7XG59XG5cbmV4cG9ydCBjb25zdCBBY2hpZXZlbWVudHNNb2RhbDogUmVhY3QuRkM8QWNoaWV2ZW1lbnRzTW9kYWxQcm9wcz4gPSAoe1xuICBhY2hpZXZlbWVudHMsXG4gIHNldEFjaGlldmVtZW50cyxcbiAgc2V0VXNlcixcbiAgb25DbG9zZSxcbn0pID0+IHtcbiAgY29uc3QgaGFuZGxlQ2xhaW0gPSAoYWNoOiBBY2hpZXZlbWVudCkgPT4ge1xuICAgIGlmIChhY2guY2xhaW1lZCB8fCBhY2gucHJvZ3Jlc3MgPCBhY2gubWF4UHJvZ3Jlc3MpIHJldHVybjtcblxuICAgIHNvdW5kcy5wbGF5VmljdG9yeSgpO1xuICAgIGNvbmZldHRpKHsgcGFydGljbGVDb3VudDogNTAsIHNwcmVhZDogNjAgfSk7XG5cbiAgICBzZXRBY2hpZXZlbWVudHMoKHByZXYpID0+XG4gICAgICBwcmV2Lm1hcCgoYSkgPT4gKGEuaWQgPT09IGFjaC5pZCA/IHsgLi4uYSwgY2xhaW1lZDogdHJ1ZSB9IDogYSkpXG4gICAgKTtcblxuICAgIHNldFVzZXIoKHByZXYpID0+ICh7XG4gICAgICAuLi5wcmV2LFxuICAgICAgY29pbnM6IHByZXYuY29pbnMgKyBhY2gucmV3YXJkQ29pbnMsXG4gICAgICBnZW1zOiBwcmV2LmdlbXMgKyBhY2gucmV3YXJkR2VtcyxcbiAgICAgIHhwOiBwcmV2LnhwICsgMTAwLFxuICAgIH0pKTtcbiAgfTtcblxuICBjb25zdCBjb21wbGV0ZWRDb3VudCA9IGFjaGlldmVtZW50cy5maWx0ZXIoKGEpID0+IGEuY2xhaW1lZCkubGVuZ3RoO1xuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJmaXhlZCBpbnNldC0wIHotNTAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgYmctc2xhdGUtOTUwLzg1IGJhY2tkcm9wLWJsdXItbWQgcC00XCI+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXNsYXRlLTkwMCBib3JkZXItMiBib3JkZXItY3lhbi01MDAvNDAgcm91bmRlZC0zeGwgcC02IG1heC13LTJ4bCB3LWZ1bGwgc2hhZG93LTJ4bCB0ZXh0LXNsYXRlLTEwMCBtYXgtaC1bODV2aF0gZmxleCBmbGV4LWNvbFwiPlxuICAgICAgICB7LyogSGVhZGVyICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBwYi00IGJvcmRlci1iIGJvcmRlci1zbGF0ZS04MDBcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIHNwYWNlLXgtM1wiPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC0zeGxcIj7wn46W77iPPC9zcGFuPlxuICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1ibGFjayB0ZXh0LWN5YW4tNDAwXCI+0KHQuNGB0YLQtdC80LAg0JTQvtGB0YLQuNC20LXQvdC40Lk8L2gyPlxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNDAwXCI+XG4gICAgICAgICAgICAgICAg0JLRi9C/0L7Qu9C90Y/QudGC0LUg0LfQsNC00LDQvdC40Y8sINC/0YDQvtC60LDRh9C40LLQsNC50YLQtSDQs9C10YDQvtGPINC4INC/0L7Qu9GD0YfQsNC50YLQtSDQvNC+0L3QtdGC0Ysg0Lgg0LrRgNC40YHRgtCw0LvQu9GLXG4gICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgIG9uQ2xpY2s9e29uQ2xvc2V9XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTggaC04IHJvdW5kZWQtZnVsbCBiZy1zbGF0ZS04MDAgaG92ZXI6Ymctc2xhdGUtNzAwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHRleHQtc2xhdGUtNDAwIGhvdmVyOnRleHQtd2hpdGVcIlxuICAgICAgICAgID5cbiAgICAgICAgICAgIOKclVxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICB7LyogT3ZlcmFsbCBQcm9ncmVzcyAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJteS0zIHAtMyBiZy1zbGF0ZS05NTAvNzAgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgcm91bmRlZC0yeGwgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHRleHQteHNcIj5cbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1zbGF0ZS0zMDBcIj5cbiAgICAgICAgICAgINCf0L7Qu9GD0YfQtdC90L4g0L3QsNCz0YDQsNC0OiA8YiBjbGFzc05hbWU9XCJ0ZXh0LWN5YW4tNDAwXCI+e2NvbXBsZXRlZENvdW50fTwvYj4g0LjQtyB7YWNoaWV2ZW1lbnRzLmxlbmd0aH1cbiAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTQwIGgtMiBiZy1zbGF0ZS04MDAgcm91bmRlZC1mdWxsIG92ZXJmbG93LWhpZGRlblwiPlxuICAgICAgICAgICAgPGRpdlxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJoLWZ1bGwgYmctY3lhbi00MDAgdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMzAwXCJcbiAgICAgICAgICAgICAgc3R5bGU9e3sgd2lkdGg6IGAkeyhjb21wbGV0ZWRDb3VudCAvIGFjaGlldmVtZW50cy5sZW5ndGgpICogMTAwfSVgIH19XG4gICAgICAgICAgICAvPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICB7LyogTGlzdCAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTEgb3ZlcmZsb3cteS1hdXRvIHByLTEgc3BhY2UteS0yLjVcIj5cbiAgICAgICAgICB7YWNoaWV2ZW1lbnRzLm1hcCgoYWNoKSA9PiB7XG4gICAgICAgICAgICBjb25zdCBpc1JlYWR5VG9DbGFpbSA9ICFhY2guY2xhaW1lZCAmJiBhY2gucHJvZ3Jlc3MgPj0gYWNoLm1heFByb2dyZXNzO1xuICAgICAgICAgICAgY29uc3QgcGN0ID0gTWF0aC5taW4oMTAwLCAoYWNoLnByb2dyZXNzIC8gYWNoLm1heFByb2dyZXNzKSAqIDEwMCk7XG5cbiAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgICAgICBrZXk9e2FjaC5pZH1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BwLTMuNSByb3VuZGVkLTJ4bCBib3JkZXIgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC0zICR7XG4gICAgICAgICAgICAgICAgICBhY2guY2xhaW1lZFxuICAgICAgICAgICAgICAgICAgICA/ICdiZy1zbGF0ZS05NTAvNDAgYm9yZGVyLXNsYXRlLTgwMC84MCBvcGFjaXR5LTcwJ1xuICAgICAgICAgICAgICAgICAgICA6IGlzUmVhZHlUb0NsYWltXG4gICAgICAgICAgICAgICAgICAgID8gJ2JnLWN5YW4tOTUwLzMwIGJvcmRlci1jeWFuLTUwMCBzaGFkb3ctbWQnXG4gICAgICAgICAgICAgICAgICAgIDogJ2JnLXNsYXRlLTk1MC83MCBib3JkZXItc2xhdGUtODAwJ1xuICAgICAgICAgICAgICAgIH1gfVxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBzcGFjZS14LTNcIj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xMiBoLTEyIHJvdW5kZWQteGwgYmctc2xhdGUtODAwIGJvcmRlciBib3JkZXItc2xhdGUtNzAwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHRleHQtMnhsIHNocmluay0wXCI+XG4gICAgICAgICAgICAgICAgICAgIHthY2guaWNvbn1cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgPGg0IGNsYXNzTmFtZT1cImZvbnQtZXh0cmFib2xkIHRleHQtc20gdGV4dC13aGl0ZVwiPnthY2gudGl0bGV9PC9oND5cbiAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTQwMCBtdC0wLjVcIj57YWNoLmRlc2NyaXB0aW9ufTwvcD5cbiAgICAgICAgICAgICAgICAgICAgey8qIFByb2dyZXNzIEJhciAqL31cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0xLjUgZmxleCBpdGVtcy1jZW50ZXIgc3BhY2UteC0yXCI+XG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTI4IGgtMS41IGJnLXNsYXRlLTgwMCByb3VuZGVkLWZ1bGwgb3ZlcmZsb3ctaGlkZGVuXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2XG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImgtZnVsbCBiZy1jeWFuLTUwMCByb3VuZGVkLWZ1bGxcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICBzdHlsZT17eyB3aWR0aDogYCR7cGN0fSVgIH19XG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHRleHQtc2xhdGUtNDAwIGZvbnQtbW9ub1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAge2FjaC5wcm9ncmVzc30gLyB7YWNoLm1heFByb2dyZXNzfVxuICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1yaWdodCBzaHJpbmstMFwiPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtbW9ubyBmb250LWJvbGQgdGV4dC1hbWJlci00MDAgbWItMVwiPlxuICAgICAgICAgICAgICAgICAgICAre2FjaC5yZXdhcmRDb2luc30g8J+qmSAmYnVsbDsgK3thY2gucmV3YXJkR2Vtc30g8J+SjlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICB7YWNoLmNsYWltZWQgPyAoXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS01MDAgZm9udC1ib2xkXCI+0J/QvtC70YPRh9C10L3QviDinJM8L3NwYW4+XG4gICAgICAgICAgICAgICAgICApIDogaXNSZWFkeVRvQ2xhaW0gPyAoXG4gICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVDbGFpbShhY2gpfVxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInB4LTMgcHktMS41IGJnLWN5YW4tNTAwIGhvdmVyOmJnLWN5YW4tNDAwIHRleHQtc2xhdGUtOTUwIGZvbnQtYmxhY2sgcm91bmRlZC14bCB0ZXh0LXhzIHNoYWRvdy1tZCBhbmltYXRlLWJvdW5jZSBjdXJzb3ItcG9pbnRlclwiXG4gICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICDQl9Cw0LHRgNCw0YLRjCFcbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNTAwIGZvbnQtbW9ub1wiPtCSINC/0YDQvtGG0LXRgdGB0LU8L3NwYW4+XG4gICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICk7XG4gICAgICAgICAgfSl9XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG4gICk7XG59O1xuIl19