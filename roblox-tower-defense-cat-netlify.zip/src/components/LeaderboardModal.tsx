const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=1e19e0c2";
var _jsxFileName = "/app/applet/src/components/LeaderboardModal.tsx";
import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=1e19e0c2";
export const LeaderboardModal = ({ leaderboard, currentUsername, onClose }) => {
	const [filterDifficulty, setFilterDifficulty] = useState("all");
	const filtered = leaderboard.filter((item) => {
		if (filterDifficulty === "all") return true;
		return item.difficulty === filterDifficulty;
	});
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "fixed inset-0 z-50 flex items-center justify-center bg-slate-950/85 backdrop-blur-md p-4",
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: "bg-slate-900 border-2 border-amber-500/40 rounded-3xl p-6 max-w-2xl w-full shadow-2xl text-slate-100 max-h-[85vh] flex flex-col",
			children: [
				/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center justify-between pb-4 border-b border-slate-800",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center space-x-3",
						children: [/* @__PURE__ */ _jsxDEV("span", {
							className: "text-3xl",
							children: "🏆"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 28,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h2", {
							className: "text-xl font-black text-amber-400",
							children: "Таблица Лидеров"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 30,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("p", {
							className: "text-xs text-slate-400",
							children: "Мировой рейтинг игроков Roblox Tower Defense по очкам и волнам"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 31,
							columnNumber: 15
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 29,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 27,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("button", {
						onClick: onClose,
						className: "w-8 h-8 rounded-full bg-slate-800 hover:bg-slate-700 flex items-center justify-center text-slate-400 hover:text-white",
						children: "✕"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 36,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 26,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center space-x-1.5 my-3 text-xs font-bold",
					children: [/* @__PURE__ */ _jsxDEV("span", {
						className: "text-slate-400 px-1",
						children: "Сложность:"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 46,
						columnNumber: 11
					}, this), [
						{
							id: "all",
							label: "Все"
						},
						{
							id: "easy",
							label: "Лёгкий"
						},
						{
							id: "normal",
							label: "Обычный"
						},
						{
							id: "hard",
							label: "Хардкор"
						},
						{
							id: "insane",
							label: "Кошмар"
						}
					].map((f) => /* @__PURE__ */ _jsxDEV("button", {
						onClick: () => setFilterDifficulty(f.id),
						className: `px-3 py-1.5 rounded-xl transition-all ${filterDifficulty === f.id ? "bg-amber-500 text-slate-950 font-black shadow-md" : "bg-slate-800 text-slate-400 hover:text-white"}`,
						children: f.label
					}, f.id, false, {
						fileName: _jsxFileName,
						lineNumber: 54,
						columnNumber: 13
					}, this))]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 45,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "flex-1 overflow-y-auto pr-1 space-y-2",
					children: filtered.map((item, index) => {
						const isMe = item.username.includes(currentUsername) || item.username.includes("(Вы)");
						const isTop3 = index < 3;
						return /* @__PURE__ */ _jsxDEV("div", {
							className: `p-3 rounded-2xl border flex items-center justify-between transition-all ${isMe ? "bg-amber-500/15 border-amber-400 shadow-md" : "bg-slate-950/70 border-slate-800"}`,
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center space-x-3",
								children: [
									/* @__PURE__ */ _jsxDEV("div", {
										className: "w-8 text-center font-black font-mono text-sm",
										children: index === 0 ? "🥇" : index === 1 ? "🥈" : index === 2 ? "🥉" : `#${index + 1}`
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 84,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("div", {
										className: "w-9 h-9 rounded-xl bg-slate-800 border border-slate-700 overflow-hidden flex items-center justify-center shrink-0",
										children: item.avatar.startsWith("/") ? /* @__PURE__ */ _jsxDEV("img", {
											src: item.avatar,
											alt: "Avatar",
											className: "w-full h-full object-cover"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 90,
											columnNumber: 23
										}, this) : /* @__PURE__ */ _jsxDEV("span", {
											className: "text-lg",
											children: item.avatar
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 92,
											columnNumber: 23
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 88,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-center space-x-1.5",
										children: [/* @__PURE__ */ _jsxDEV("span", {
											className: `font-extrabold text-xs ${isMe ? "text-amber-300" : "text-white"}`,
											children: item.username
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 98,
											columnNumber: 23
										}, this), item.clanTag && /* @__PURE__ */ _jsxDEV("span", {
											className: "text-[10px] font-mono font-bold text-indigo-400 bg-indigo-950 px-1.5 py-0.2 rounded border border-indigo-800",
											children: [
												"[",
												item.clanTag,
												"]"
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 102,
											columnNumber: 25
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 97,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV("div", {
										className: "text-[11px] text-slate-400 font-mono mt-0.5",
										children: [
											"Пройдено волн: ",
											/* @__PURE__ */ _jsxDEV("b", {
												className: "text-slate-200",
												children: item.wavesBeaten
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 108,
												columnNumber: 38
											}, this),
											" • ",
											item.date
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 107,
										columnNumber: 21
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 96,
										columnNumber: 19
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 83,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "text-right",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "font-black text-sm text-amber-400 font-mono",
									children: item.score.toLocaleString()
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 114,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "text-[10px] font-bold uppercase text-slate-500",
									children: item.difficulty
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 117,
									columnNumber: 19
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 113,
								columnNumber: 17
							}, this)]
						}, index, true, {
							fileName: _jsxFileName,
							lineNumber: 75,
							columnNumber: 15
						}, this);
					})
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 69,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 24,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 23,
		columnNumber: 5
	}, this);
};

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLGdCQUFnQjs7O0FBU2hDLE9BQU8sTUFBTSxvQkFBcUQsRUFDaEUsYUFDQSxpQkFDQSxjQUNJO0NBQ0osTUFBTSxDQUFDLGtCQUFrQix1QkFBdUIsU0FBaUIsS0FBSztDQUV0RSxNQUFNLFdBQVcsWUFBWSxRQUFRLFNBQVM7RUFDNUMsSUFBSSxxQkFBcUIsT0FBTyxPQUFPO0VBQ3ZDLE9BQU8sS0FBSyxlQUFlO0NBQzdCLENBQUM7Q0FFRCxPQUNFLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQ2Isd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFBZjtJQUVFLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLFFBQUQ7T0FBTSxXQUFVO2lCQUFXO01BQVE7Ozs7Z0JBQ25DLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxNQUFEO09BQUksV0FBVTtpQkFBb0M7TUFBbUI7Ozs7Z0JBQ3JFLHdCQUFDLEtBQUQ7T0FBRyxXQUFVO2lCQUF5QjtNQUVuQzs7OztjQUNBOzs7O2NBQ0Y7Ozs7O2VBQ0wsd0JBQUMsVUFBRDtNQUNFLFNBQVM7TUFDVCxXQUFVO2dCQUNYO0tBRU87Ozs7YUFDTDs7Ozs7O0lBR0wsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLFFBQUQ7TUFBTSxXQUFVO2dCQUFzQjtLQUFnQjs7OztlQUNyRDtNQUNDO09BQUUsSUFBSTtPQUFPLE9BQU87TUFBTTtNQUMxQjtPQUFFLElBQUk7T0FBUSxPQUFPO01BQVM7TUFDOUI7T0FBRSxJQUFJO09BQVUsT0FBTztNQUFVO01BQ2pDO09BQUUsSUFBSTtPQUFRLE9BQU87TUFBVTtNQUMvQjtPQUFFLElBQUk7T0FBVSxPQUFPO01BQVM7S0FDbEMsQ0FBQyxDQUFDLEtBQUssTUFDTCx3QkFBQyxVQUFEO01BRUUsZUFBZSxvQkFBb0IsRUFBRSxFQUFFO01BQ3ZDLFdBQVcseUNBQ1QscUJBQXFCLEVBQUUsS0FDbkIscURBQ0E7Z0JBR0wsRUFBRTtLQUNHLEdBVEQsRUFBRTs7OztZQVNELENBQ1QsQ0FDRTs7Ozs7O0lBR0wsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFDWixTQUFTLEtBQUssTUFBTSxVQUFVO01BQzdCLE1BQU0sT0FBTyxLQUFLLFNBQVMsU0FBUyxlQUFlLEtBQUssS0FBSyxTQUFTLFNBQVMsTUFBTTtNQUNyRixNQUFNLFNBQVMsUUFBUTtNQUV2QixPQUNFLHdCQUFDLE9BQUQ7T0FFRSxXQUFXLDJFQUNULE9BQ0ksK0NBQ0E7aUJBTFIsQ0FRRSx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZjtTQUNFLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUNaLFVBQVUsSUFBSSxPQUFPLFVBQVUsSUFBSSxPQUFPLFVBQVUsSUFBSSxPQUFPLElBQUksUUFBUTtTQUN6RTs7Ozs7U0FFTCx3QkFBQyxPQUFEO1VBQUssV0FBVTtvQkFDWixLQUFLLE9BQU8sV0FBVyxHQUFHLElBQ3pCLHdCQUFDLE9BQUQ7V0FBSyxLQUFLLEtBQUs7V0FBUSxLQUFJO1dBQVMsV0FBVTtVQUE4Qjs7OztxQkFFNUUsd0JBQUMsUUFBRDtXQUFNLFdBQVU7cUJBQVcsS0FBSztVQUFhOzs7OztTQUU1Qzs7Ozs7U0FFTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWYsQ0FDRSx3QkFBQyxRQUFEO1dBQU0sV0FBVywwQkFBMEIsT0FBTyxtQkFBbUI7cUJBQ2xFLEtBQUs7VUFDRjs7OztvQkFDTCxLQUFLLFdBQ0osd0JBQUMsUUFBRDtXQUFNLFdBQVU7cUJBQWhCO1lBQStIO1lBQzNILEtBQUs7WUFBUTtXQUNYOzs7OztrQkFFTDs7Ozs7bUJBQ0wsd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWY7V0FBNkQ7V0FDNUMsd0JBQUMsS0FBRDtZQUFHLFdBQVU7c0JBQWtCLEtBQUs7V0FBZTs7Ozs7V0FBQztXQUFTLEtBQUs7VUFDOUU7Ozs7O2lCQUNGOzs7OztRQUNGOzs7OztpQkFFTCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUNaLEtBQUssTUFBTSxlQUFlO1FBQ3hCOzs7O2tCQUNMLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUNaLEtBQUs7UUFDSDs7OztnQkFDRjs7Ozs7ZUFDRjtTQTdDRTs7OzthQTZDRjtLQUVULENBQUM7SUFDRTs7Ozs7R0FDRjs7Ozs7O0NBQ0Y7Ozs7O0FBRVQiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiTGVhZGVyYm9hcmRNb2RhbC50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgTGVhZGVyYm9hcmRFbnRyeSB9IGZyb20gJy4uL3R5cGVzL2dhbWUnO1xuXG5pbnRlcmZhY2UgTGVhZGVyYm9hcmRNb2RhbFByb3BzIHtcbiAgbGVhZGVyYm9hcmQ6IExlYWRlcmJvYXJkRW50cnlbXTtcbiAgY3VycmVudFVzZXJuYW1lOiBzdHJpbmc7XG4gIG9uQ2xvc2U6ICgpID0+IHZvaWQ7XG59XG5cbmV4cG9ydCBjb25zdCBMZWFkZXJib2FyZE1vZGFsOiBSZWFjdC5GQzxMZWFkZXJib2FyZE1vZGFsUHJvcHM+ID0gKHtcbiAgbGVhZGVyYm9hcmQsXG4gIGN1cnJlbnRVc2VybmFtZSxcbiAgb25DbG9zZSxcbn0pID0+IHtcbiAgY29uc3QgW2ZpbHRlckRpZmZpY3VsdHksIHNldEZpbHRlckRpZmZpY3VsdHldID0gdXNlU3RhdGU8c3RyaW5nPignYWxsJyk7XG5cbiAgY29uc3QgZmlsdGVyZWQgPSBsZWFkZXJib2FyZC5maWx0ZXIoKGl0ZW0pID0+IHtcbiAgICBpZiAoZmlsdGVyRGlmZmljdWx0eSA9PT0gJ2FsbCcpIHJldHVybiB0cnVlO1xuICAgIHJldHVybiBpdGVtLmRpZmZpY3VsdHkgPT09IGZpbHRlckRpZmZpY3VsdHk7XG4gIH0pO1xuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJmaXhlZCBpbnNldC0wIHotNTAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgYmctc2xhdGUtOTUwLzg1IGJhY2tkcm9wLWJsdXItbWQgcC00XCI+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXNsYXRlLTkwMCBib3JkZXItMiBib3JkZXItYW1iZXItNTAwLzQwIHJvdW5kZWQtM3hsIHAtNiBtYXgtdy0yeGwgdy1mdWxsIHNoYWRvdy0yeGwgdGV4dC1zbGF0ZS0xMDAgbWF4LWgtWzg1dmhdIGZsZXggZmxleC1jb2xcIj5cbiAgICAgICAgey8qIEhlYWRlciAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gcGItNCBib3JkZXItYiBib3JkZXItc2xhdGUtODAwXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBzcGFjZS14LTNcIj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtM3hsXCI+8J+Phjwvc3Bhbj5cbiAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtYmxhY2sgdGV4dC1hbWJlci00MDBcIj7QotCw0LHQu9C40YbQsCDQm9C40LTQtdGA0L7QsjwvaDI+XG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS00MDBcIj5cbiAgICAgICAgICAgICAgICDQnNC40YDQvtCy0L7QuSDRgNC10LnRgtC40L3QsyDQuNCz0YDQvtC60L7QsiBSb2Jsb3ggVG93ZXIgRGVmZW5zZSDQv9C+INC+0YfQutCw0Lwg0Lgg0LLQvtC70L3QsNC8XG4gICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgIG9uQ2xpY2s9e29uQ2xvc2V9XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTggaC04IHJvdW5kZWQtZnVsbCBiZy1zbGF0ZS04MDAgaG92ZXI6Ymctc2xhdGUtNzAwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHRleHQtc2xhdGUtNDAwIGhvdmVyOnRleHQtd2hpdGVcIlxuICAgICAgICAgID5cbiAgICAgICAgICAgIOKclVxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICB7LyogRmlsdGVycyAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBzcGFjZS14LTEuNSBteS0zIHRleHQteHMgZm9udC1ib2xkXCI+XG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS00MDAgcHgtMVwiPtCh0LvQvtC20L3QvtGB0YLRjDo8L3NwYW4+XG4gICAgICAgICAge1tcbiAgICAgICAgICAgIHsgaWQ6ICdhbGwnLCBsYWJlbDogJ9CS0YHQtScgfSxcbiAgICAgICAgICAgIHsgaWQ6ICdlYXN5JywgbGFiZWw6ICfQm9GR0LPQutC40LknIH0sXG4gICAgICAgICAgICB7IGlkOiAnbm9ybWFsJywgbGFiZWw6ICfQntCx0YvRh9C90YvQuScgfSxcbiAgICAgICAgICAgIHsgaWQ6ICdoYXJkJywgbGFiZWw6ICfQpdCw0YDQtNC60L7RgCcgfSxcbiAgICAgICAgICAgIHsgaWQ6ICdpbnNhbmUnLCBsYWJlbDogJ9Ca0L7RiNC80LDRgCcgfSxcbiAgICAgICAgICBdLm1hcCgoZikgPT4gKFxuICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICBrZXk9e2YuaWR9XG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldEZpbHRlckRpZmZpY3VsdHkoZi5pZCl9XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT17YHB4LTMgcHktMS41IHJvdW5kZWQteGwgdHJhbnNpdGlvbi1hbGwgJHtcbiAgICAgICAgICAgICAgICBmaWx0ZXJEaWZmaWN1bHR5ID09PSBmLmlkXG4gICAgICAgICAgICAgICAgICA/ICdiZy1hbWJlci01MDAgdGV4dC1zbGF0ZS05NTAgZm9udC1ibGFjayBzaGFkb3ctbWQnXG4gICAgICAgICAgICAgICAgICA6ICdiZy1zbGF0ZS04MDAgdGV4dC1zbGF0ZS00MDAgaG92ZXI6dGV4dC13aGl0ZSdcbiAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIHtmLmxhYmVsfVxuICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgKSl9XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIHsvKiBMaXN0ICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtMSBvdmVyZmxvdy15LWF1dG8gcHItMSBzcGFjZS15LTJcIj5cbiAgICAgICAgICB7ZmlsdGVyZWQubWFwKChpdGVtLCBpbmRleCkgPT4ge1xuICAgICAgICAgICAgY29uc3QgaXNNZSA9IGl0ZW0udXNlcm5hbWUuaW5jbHVkZXMoY3VycmVudFVzZXJuYW1lKSB8fCBpdGVtLnVzZXJuYW1lLmluY2x1ZGVzKCco0JLRiyknKTtcbiAgICAgICAgICAgIGNvbnN0IGlzVG9wMyA9IGluZGV4IDwgMztcblxuICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgPGRpdlxuICAgICAgICAgICAgICAgIGtleT17aW5kZXh9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtgcC0zIHJvdW5kZWQtMnhsIGJvcmRlciBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gdHJhbnNpdGlvbi1hbGwgJHtcbiAgICAgICAgICAgICAgICAgIGlzTWVcbiAgICAgICAgICAgICAgICAgICAgPyAnYmctYW1iZXItNTAwLzE1IGJvcmRlci1hbWJlci00MDAgc2hhZG93LW1kJ1xuICAgICAgICAgICAgICAgICAgICA6ICdiZy1zbGF0ZS05NTAvNzAgYm9yZGVyLXNsYXRlLTgwMCdcbiAgICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgc3BhY2UteC0zXCI+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInctOCB0ZXh0LWNlbnRlciBmb250LWJsYWNrIGZvbnQtbW9ubyB0ZXh0LXNtXCI+XG4gICAgICAgICAgICAgICAgICAgIHtpbmRleCA9PT0gMCA/ICfwn6WHJyA6IGluZGV4ID09PSAxID8gJ/CfpYgnIDogaW5kZXggPT09IDIgPyAn8J+liScgOiBgIyR7aW5kZXggKyAxfWB9XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ3LTkgaC05IHJvdW5kZWQteGwgYmctc2xhdGUtODAwIGJvcmRlciBib3JkZXItc2xhdGUtNzAwIG92ZXJmbG93LWhpZGRlbiBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBzaHJpbmstMFwiPlxuICAgICAgICAgICAgICAgICAgICB7aXRlbS5hdmF0YXIuc3RhcnRzV2l0aCgnLycpID8gKFxuICAgICAgICAgICAgICAgICAgICAgIDxpbWcgc3JjPXtpdGVtLmF2YXRhcn0gYWx0PVwiQXZhdGFyXCIgY2xhc3NOYW1lPVwidy1mdWxsIGgtZnVsbCBvYmplY3QtY292ZXJcIiAvPlxuICAgICAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtbGdcIj57aXRlbS5hdmF0YXJ9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgc3BhY2UteC0xLjVcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9e2Bmb250LWV4dHJhYm9sZCB0ZXh0LXhzICR7aXNNZSA/ICd0ZXh0LWFtYmVyLTMwMCcgOiAndGV4dC13aGl0ZSd9YH0+XG4gICAgICAgICAgICAgICAgICAgICAgICB7aXRlbS51c2VybmFtZX1cbiAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAge2l0ZW0uY2xhblRhZyAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSBmb250LW1vbm8gZm9udC1ib2xkIHRleHQtaW5kaWdvLTQwMCBiZy1pbmRpZ28tOTUwIHB4LTEuNSBweS0wLjIgcm91bmRlZCBib3JkZXIgYm9yZGVyLWluZGlnby04MDBcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgW3tpdGVtLmNsYW5UYWd9XVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtWzExcHhdIHRleHQtc2xhdGUtNDAwIGZvbnQtbW9ubyBtdC0wLjVcIj5cbiAgICAgICAgICAgICAgICAgICAgICDQn9GA0L7QudC00LXQvdC+INCy0L7Qu9C9OiA8YiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTIwMFwiPntpdGVtLndhdmVzQmVhdGVufTwvYj4gJmJ1bGw7IHtpdGVtLmRhdGV9XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtcmlnaHRcIj5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9udC1ibGFjayB0ZXh0LXNtIHRleHQtYW1iZXItNDAwIGZvbnQtbW9ub1wiPlxuICAgICAgICAgICAgICAgICAgICB7aXRlbS5zY29yZS50b0xvY2FsZVN0cmluZygpfVxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIGZvbnQtYm9sZCB1cHBlcmNhc2UgdGV4dC1zbGF0ZS01MDBcIj5cbiAgICAgICAgICAgICAgICAgICAge2l0ZW0uZGlmZmljdWx0eX1cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICk7XG4gICAgICAgICAgfSl9XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG4gICk7XG59O1xuIl19