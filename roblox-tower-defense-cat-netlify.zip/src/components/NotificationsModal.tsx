const React = __vite__cjsImport0_react;const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=1e19e0c2";
var _jsxFileName = "/app/applet/src/components/NotificationsModal.tsx";
import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=1e19e0c2";
export const NotificationsModal = ({ notifications, setNotifications, onClose }) => {
	const handleMarkAllRead = () => {
		setNotifications((prev) => prev.map((n) => ({
			...n,
			read: true
		})));
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "fixed inset-0 z-50 flex items-center justify-center bg-slate-950/85 backdrop-blur-md p-4",
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: "bg-slate-900 border-2 border-slate-700 rounded-3xl p-6 max-w-lg w-full shadow-2xl text-slate-100 max-h-[85vh] flex flex-col",
			children: [
				/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center justify-between pb-4 border-b border-slate-800",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center space-x-3",
						children: [/* @__PURE__ */ _jsxDEV("span", {
							className: "text-3xl",
							children: "🔔"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 25,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h2", {
							className: "text-xl font-black text-cyan-400",
							children: "Центр Уведомлений и Акций"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 27,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("p", {
							className: "text-xs text-slate-400",
							children: "Push-уведомления о доставке валюты, акциях и событиях"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 28,
							columnNumber: 15
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 26,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 24,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("button", {
						onClick: onClose,
						className: "w-8 h-8 rounded-full bg-slate-800 hover:bg-slate-700 flex items-center justify-center text-slate-400 hover:text-white",
						children: "✕"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 33,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 23,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center justify-between my-3 text-xs",
					children: [/* @__PURE__ */ _jsxDEV("span", {
						className: "text-slate-400 font-bold",
						children: ["Всего уведомлений: ", notifications.length]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 43,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("button", {
						onClick: handleMarkAllRead,
						className: "text-cyan-400 hover:text-cyan-300 font-bold",
						children: "Прочитать все ✓"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 46,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 42,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "flex-1 overflow-y-auto space-y-2.5 pr-1",
					children: notifications.map((notif) => /* @__PURE__ */ _jsxDEV("div", {
						className: `p-3.5 rounded-2xl border transition-all ${!notif.read ? "bg-slate-950 border-cyan-500/60 shadow-md" : "bg-slate-950/50 border-slate-800/80 opacity-80"}`,
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-start justify-between",
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center space-x-2",
									children: [/* @__PURE__ */ _jsxDEV("h4", {
										className: "font-extrabold text-sm text-white",
										children: notif.title
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 67,
										columnNumber: 19
									}, this), notif.badge && /* @__PURE__ */ _jsxDEV("span", {
										className: "px-1.5 py-0.5 rounded text-[9px] font-black uppercase bg-rose-600 text-white",
										children: notif.badge
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 69,
										columnNumber: 21
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 66,
									columnNumber: 17
								}, this), !notif.read && /* @__PURE__ */ _jsxDEV("span", { className: "w-2 h-2 rounded-full bg-cyan-400 shrink-0 mt-1" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 74,
									columnNumber: 33
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 65,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("p", {
								className: "text-xs text-slate-300 mt-1 leading-relaxed",
								children: notif.message
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 77,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "text-[10px] text-slate-500 font-mono mt-2",
								children: notif.timestamp
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 78,
								columnNumber: 15
							}, this)
						]
					}, notif.id, true, {
						fileName: _jsxFileName,
						lineNumber: 57,
						columnNumber: 13
					}, this))
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 55,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 21,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 20,
		columnNumber: 5
	}, this);
};

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxXQUFXOzs7QUFTbEIsT0FBTyxNQUFNLHNCQUF5RCxFQUNwRSxlQUNBLGtCQUNBLGNBQ0k7Q0FDSixNQUFNLDBCQUEwQjtFQUM5QixrQkFBa0IsU0FBUyxLQUFLLEtBQUssT0FBTztHQUFFLEdBQUc7R0FBRyxNQUFNO0VBQUssRUFBRSxDQUFDO0NBQ3BFO0NBRUEsT0FDRSx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUNiLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQWY7SUFFRSx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxRQUFEO09BQU0sV0FBVTtpQkFBVztNQUFROzs7O2dCQUNuQyx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsTUFBRDtPQUFJLFdBQVU7aUJBQW1DO01BQTZCOzs7O2dCQUM5RSx3QkFBQyxLQUFEO09BQUcsV0FBVTtpQkFBeUI7TUFFbkM7Ozs7Y0FDQTs7OztjQUNGOzs7OztlQUNMLHdCQUFDLFVBQUQ7TUFDRSxTQUFTO01BQ1QsV0FBVTtnQkFDWDtLQUVPOzs7O2FBQ0w7Ozs7OztJQUdMLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxRQUFEO01BQU0sV0FBVTtnQkFBaEIsQ0FBMkMsdUJBQ3JCLGNBQWMsTUFDOUI7Ozs7O2VBQ04sd0JBQUMsVUFBRDtNQUNFLFNBQVM7TUFDVCxXQUFVO2dCQUNYO0tBRU87Ozs7YUFDTDs7Ozs7O0lBR0wsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFDWixjQUFjLEtBQUssVUFDbEIsd0JBQUMsT0FBRDtNQUVFLFdBQVcsMkNBQ1QsQ0FBQyxNQUFNLE9BQ0gsOENBQ0E7Z0JBTFI7T0FRRSx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0Usd0JBQUMsTUFBRDtVQUFJLFdBQVU7b0JBQXFDLE1BQU07U0FBVTs7OzttQkFDbEUsTUFBTSxTQUNMLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUNiLE1BQU07U0FDSDs7OztpQkFFTDs7Ozs7a0JBQ0osQ0FBQyxNQUFNLFFBQVEsd0JBQUMsUUFBRCxFQUFNLFdBQVUsaURBQWtEOzs7O2dCQUMvRTs7Ozs7O09BRUwsd0JBQUMsS0FBRDtRQUFHLFdBQVU7a0JBQStDLE1BQU07T0FBVzs7Ozs7T0FDN0Usd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQTZDLE1BQU07T0FBZTs7Ozs7TUFDOUU7UUFyQkUsTUFBTTs7OztZQXFCUixDQUNOO0lBQ0U7Ozs7O0dBQ0Y7Ozs7OztDQUNGOzs7OztBQUVUIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIk5vdGlmaWNhdGlvbnNNb2RhbC50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IEluR2FtZU5vdGlmaWNhdGlvbiB9IGZyb20gJy4uL3R5cGVzL2dhbWUnO1xuXG5pbnRlcmZhY2UgTm90aWZpY2F0aW9uc01vZGFsUHJvcHMge1xuICBub3RpZmljYXRpb25zOiBJbkdhbWVOb3RpZmljYXRpb25bXTtcbiAgc2V0Tm90aWZpY2F0aW9uczogUmVhY3QuRGlzcGF0Y2g8UmVhY3QuU2V0U3RhdGVBY3Rpb248SW5HYW1lTm90aWZpY2F0aW9uW10+PjtcbiAgb25DbG9zZTogKCkgPT4gdm9pZDtcbn1cblxuZXhwb3J0IGNvbnN0IE5vdGlmaWNhdGlvbnNNb2RhbDogUmVhY3QuRkM8Tm90aWZpY2F0aW9uc01vZGFsUHJvcHM+ID0gKHtcbiAgbm90aWZpY2F0aW9ucyxcbiAgc2V0Tm90aWZpY2F0aW9ucyxcbiAgb25DbG9zZSxcbn0pID0+IHtcbiAgY29uc3QgaGFuZGxlTWFya0FsbFJlYWQgPSAoKSA9PiB7XG4gICAgc2V0Tm90aWZpY2F0aW9ucygocHJldikgPT4gcHJldi5tYXAoKG4pID0+ICh7IC4uLm4sIHJlYWQ6IHRydWUgfSkpKTtcbiAgfTtcblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiZml4ZWQgaW5zZXQtMCB6LTUwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGJnLXNsYXRlLTk1MC84NSBiYWNrZHJvcC1ibHVyLW1kIHAtNFwiPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1zbGF0ZS05MDAgYm9yZGVyLTIgYm9yZGVyLXNsYXRlLTcwMCByb3VuZGVkLTN4bCBwLTYgbWF4LXctbGcgdy1mdWxsIHNoYWRvdy0yeGwgdGV4dC1zbGF0ZS0xMDAgbWF4LWgtWzg1dmhdIGZsZXggZmxleC1jb2xcIj5cbiAgICAgICAgey8qIEhlYWRlciAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gcGItNCBib3JkZXItYiBib3JkZXItc2xhdGUtODAwXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBzcGFjZS14LTNcIj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtM3hsXCI+8J+UlDwvc3Bhbj5cbiAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtYmxhY2sgdGV4dC1jeWFuLTQwMFwiPtCm0LXQvdGC0YAg0KPQstC10LTQvtC80LvQtdC90LjQuSDQuCDQkNC60YbQuNC5PC9oMj5cbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTQwMFwiPlxuICAgICAgICAgICAgICAgIFB1c2gt0YPQstC10LTQvtC80LvQtdC90LjRjyDQviDQtNC+0YHRgtCw0LLQutC1INCy0LDQu9GO0YLRiywg0LDQutGG0LjRj9GFINC4INGB0L7QsdGL0YLQuNGP0YVcbiAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgb25DbGljaz17b25DbG9zZX1cbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInctOCBoLTggcm91bmRlZC1mdWxsIGJnLXNsYXRlLTgwMCBob3ZlcjpiZy1zbGF0ZS03MDAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgdGV4dC1zbGF0ZS00MDAgaG92ZXI6dGV4dC13aGl0ZVwiXG4gICAgICAgICAgPlxuICAgICAgICAgICAg4pyVXG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIHsvKiBBY3Rpb24gYmFyICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBteS0zIHRleHQteHNcIj5cbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQwMCBmb250LWJvbGRcIj5cbiAgICAgICAgICAgINCS0YHQtdCz0L4g0YPQstC10LTQvtC80LvQtdC90LjQuToge25vdGlmaWNhdGlvbnMubGVuZ3RofVxuICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVNYXJrQWxsUmVhZH1cbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtY3lhbi00MDAgaG92ZXI6dGV4dC1jeWFuLTMwMCBmb250LWJvbGRcIlxuICAgICAgICAgID5cbiAgICAgICAgICAgINCf0YDQvtGH0LjRgtCw0YLRjCDQstGB0LUg4pyTXG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIHsvKiBOb3RpZmljYXRpb25zIExpc3QgKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xIG92ZXJmbG93LXktYXV0byBzcGFjZS15LTIuNSBwci0xXCI+XG4gICAgICAgICAge25vdGlmaWNhdGlvbnMubWFwKChub3RpZikgPT4gKFxuICAgICAgICAgICAgPGRpdlxuICAgICAgICAgICAgICBrZXk9e25vdGlmLmlkfVxuICAgICAgICAgICAgICBjbGFzc05hbWU9e2BwLTMuNSByb3VuZGVkLTJ4bCBib3JkZXIgdHJhbnNpdGlvbi1hbGwgJHtcbiAgICAgICAgICAgICAgICAhbm90aWYucmVhZFxuICAgICAgICAgICAgICAgICAgPyAnYmctc2xhdGUtOTUwIGJvcmRlci1jeWFuLTUwMC82MCBzaGFkb3ctbWQnXG4gICAgICAgICAgICAgICAgICA6ICdiZy1zbGF0ZS05NTAvNTAgYm9yZGVyLXNsYXRlLTgwMC84MCBvcGFjaXR5LTgwJ1xuICAgICAgICAgICAgICB9YH1cbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLXN0YXJ0IGp1c3RpZnktYmV0d2VlblwiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgc3BhY2UteC0yXCI+XG4gICAgICAgICAgICAgICAgICA8aDQgY2xhc3NOYW1lPVwiZm9udC1leHRyYWJvbGQgdGV4dC1zbSB0ZXh0LXdoaXRlXCI+e25vdGlmLnRpdGxlfTwvaDQ+XG4gICAgICAgICAgICAgICAgICB7bm90aWYuYmFkZ2UgJiYgKFxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJweC0xLjUgcHktMC41IHJvdW5kZWQgdGV4dC1bOXB4XSBmb250LWJsYWNrIHVwcGVyY2FzZSBiZy1yb3NlLTYwMCB0ZXh0LXdoaXRlXCI+XG4gICAgICAgICAgICAgICAgICAgICAge25vdGlmLmJhZGdlfVxuICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIHshbm90aWYucmVhZCAmJiA8c3BhbiBjbGFzc05hbWU9XCJ3LTIgaC0yIHJvdW5kZWQtZnVsbCBiZy1jeWFuLTQwMCBzaHJpbmstMCBtdC0xXCIgLz59XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS0zMDAgbXQtMSBsZWFkaW5nLXJlbGF4ZWRcIj57bm90aWYubWVzc2FnZX08L3A+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC1zbGF0ZS01MDAgZm9udC1tb25vIG10LTJcIj57bm90aWYudGltZXN0YW1wfTwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKSl9XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG4gICk7XG59O1xuIl19