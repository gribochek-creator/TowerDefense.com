const React = __vite__cjsImport0_react;const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=1e19e0c2";
import confetti from "/node_modules/.vite/deps/canvas-confetti.js?v=601c4ae1";
import { CAT_IMAGE_URL } from "/src/data/constants.ts";
var _jsxFileName = "/app/applet/src/components/GameOverModal.tsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=1e19e0c2";
export const GameOverModal = ({ victory, wavesCompleted, score, onRestart }) => {
	React.useEffect(() => {
		if (victory) {
			confetti({
				particleCount: 100,
				spread: 80,
				origin: { y: .5 }
			});
		}
	}, [victory]);
	const earnedCoins = wavesCompleted * 120 + (victory ? 1e3 : 0);
	const earnedGems = Math.floor(wavesCompleted * 3.5) + (victory ? 50 : 0);
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "fixed inset-0 z-50 flex items-center justify-center bg-slate-950/90 backdrop-blur-md p-4 select-none",
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: `bg-slate-900 border-2 rounded-3xl p-6 max-w-md w-full shadow-2xl text-center space-y-4 animate-in zoom-in-95 duration-200 ${victory ? "border-amber-400" : "border-rose-500"}`,
			children: [
				/* @__PURE__ */ _jsxDEV("div", {
					className: "relative w-20 h-20 mx-auto rounded-2xl overflow-hidden border-2 border-cyan-400 bg-slate-950 shadow-lg",
					children: [/* @__PURE__ */ _jsxDEV("img", {
						src: CAT_IMAGE_URL,
						alt: "Cat",
						className: "w-full h-full object-cover"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 39,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("span", {
						className: "absolute bottom-0 right-0 text-xl",
						children: victory ? "👑" : "💀"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 40,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 38,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h2", {
					className: `text-2xl font-black ${victory ? "text-amber-400" : "text-rose-500"}`,
					children: victory ? "🏆 ПОБЕДА! КАРТА ЗАЧИЩЕНА!" : "💀 го KEKC"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 44,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("p", {
					className: "text-xs text-slate-400 mt-1",
					children: victory ? "Легендарный кот в очках и его команда разгромили всех титанов!" : "го KEKC! Враги снесли замок, кот в очках требует реванш!"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 47,
					columnNumber: 11
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 43,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "p-4 bg-slate-950 rounded-2xl border border-slate-800 space-y-2 text-xs",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex justify-between text-slate-300",
							children: [/* @__PURE__ */ _jsxDEV("span", { children: "Пройдено волн:" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 57,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("b", {
								className: "text-cyan-400 font-mono text-sm",
								children: wavesCompleted
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 58,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 56,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex justify-between text-slate-300",
							children: [/* @__PURE__ */ _jsxDEV("span", { children: "Итоговые очки:" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 61,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("b", {
								className: "text-amber-400 font-mono text-sm",
								children: score.toLocaleString()
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 62,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 60,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "pt-2 border-t border-slate-800 flex justify-between font-bold",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "text-slate-400",
								children: "Награда за матч:"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 65,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "text-emerald-400 font-mono",
								children: [
									"+",
									earnedCoins,
									" 🪙 • +",
									earnedGems,
									" 💎"
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 66,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 64,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 55,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("button", {
					onClick: onRestart,
					className: `w-full py-3 rounded-2xl font-black text-sm shadow-xl active:scale-95 transition-transform ${victory ? "bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 text-slate-950" : "bg-gradient-to-r from-rose-500 to-red-600 hover:from-rose-400 text-white"}`,
					children: victory ? "✨ Играть Следующую Карту" : "🔄 го KEKC (Возродиться)"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 72,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 33,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 32,
		columnNumber: 5
	}, this);
};

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxXQUFXO0FBQ2xCLE9BQU8sY0FBYztBQUNyQixTQUFTLHFCQUFxQjs7O0FBUzlCLE9BQU8sTUFBTSxpQkFBK0MsRUFDMUQsU0FDQSxnQkFDQSxPQUNBLGdCQUNJO0NBQ0osTUFBTSxnQkFBZ0I7RUFDcEIsSUFBSSxTQUFTO0dBQ1gsU0FBUztJQUNQLGVBQWU7SUFDZixRQUFRO0lBQ1IsUUFBUSxFQUFFLEdBQUcsR0FBSTtHQUNuQixDQUFDO0VBQ0g7Q0FDRixHQUFHLENBQUMsT0FBTyxDQUFDO0NBRVosTUFBTSxjQUFjLGlCQUFpQixPQUFPLFVBQVUsTUFBTztDQUM3RCxNQUFNLGFBQWEsS0FBSyxNQUFNLGlCQUFpQixHQUFHLEtBQUssVUFBVSxLQUFLO0NBRXRFLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFDYix3QkFBQyxPQUFEO0dBQ0UsV0FBVyw2SEFDVCxVQUFVLHFCQUFxQjthQUZuQztJQUtFLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxPQUFEO01BQUssS0FBSztNQUFlLEtBQUk7TUFBTSxXQUFVO0tBQThCOzs7O2VBQzNFLHdCQUFDLFFBQUQ7TUFBTSxXQUFVO2dCQUFxQyxVQUFVLE9BQU87S0FBVzs7OzthQUM5RTs7Ozs7O0lBRUwsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLE1BQUQ7S0FBSSxXQUFXLHVCQUF1QixVQUFVLG1CQUFtQjtlQUNoRSxVQUFVLCtCQUErQjtJQUN4Qzs7OztjQUNKLHdCQUFDLEtBQUQ7S0FBRyxXQUFVO2VBQ1YsVUFDRyxtRUFDQTtJQUNIOzs7O1lBQ0E7Ozs7O0lBR0wsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZjtNQUNFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsUUFBRCxZQUFNLGlCQUFvQjs7OztpQkFDMUIsd0JBQUMsS0FBRDtRQUFHLFdBQVU7a0JBQW1DO09BQWtCOzs7O2VBQy9EOzs7Ozs7TUFDTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLFFBQUQsWUFBTSxpQkFBb0I7Ozs7aUJBQzFCLHdCQUFDLEtBQUQ7UUFBRyxXQUFVO2tCQUFvQyxNQUFNLGVBQWU7T0FBSzs7OztlQUN4RTs7Ozs7O01BQ0wsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBaUI7T0FBc0I7Ozs7aUJBQ3ZELHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUFoQjtTQUE2QztTQUN6QztTQUFZO1NBQWE7U0FBVztRQUNsQzs7Ozs7ZUFDSDs7Ozs7O0tBQ0Y7Ozs7OztJQUVMLHdCQUFDLFVBQUQ7S0FDRSxTQUFTO0tBQ1QsV0FBVyw2RkFDVCxVQUNJLHFGQUNBO2VBR0wsVUFBVSw2QkFBNkI7SUFDbEM7Ozs7O0dBQ0w7Ozs7OztDQUNGOzs7OztBQUVUIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkdhbWVPdmVyTW9kYWwudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgY29uZmV0dGkgZnJvbSAnY2FudmFzLWNvbmZldHRpJztcbmltcG9ydCB7IENBVF9JTUFHRV9VUkwgfSBmcm9tICcuLi9kYXRhL2NvbnN0YW50cyc7XG5cbmludGVyZmFjZSBHYW1lT3Zlck1vZGFsUHJvcHMge1xuICB2aWN0b3J5OiBib29sZWFuO1xuICB3YXZlc0NvbXBsZXRlZDogbnVtYmVyO1xuICBzY29yZTogbnVtYmVyO1xuICBvblJlc3RhcnQ6ICgpID0+IHZvaWQ7XG59XG5cbmV4cG9ydCBjb25zdCBHYW1lT3Zlck1vZGFsOiBSZWFjdC5GQzxHYW1lT3Zlck1vZGFsUHJvcHM+ID0gKHtcbiAgdmljdG9yeSxcbiAgd2F2ZXNDb21wbGV0ZWQsXG4gIHNjb3JlLFxuICBvblJlc3RhcnQsXG59KSA9PiB7XG4gIFJlYWN0LnVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKHZpY3RvcnkpIHtcbiAgICAgIGNvbmZldHRpKHtcbiAgICAgICAgcGFydGljbGVDb3VudDogMTAwLFxuICAgICAgICBzcHJlYWQ6IDgwLFxuICAgICAgICBvcmlnaW46IHsgeTogMC41IH0sXG4gICAgICB9KTtcbiAgICB9XG4gIH0sIFt2aWN0b3J5XSk7XG5cbiAgY29uc3QgZWFybmVkQ29pbnMgPSB3YXZlc0NvbXBsZXRlZCAqIDEyMCArICh2aWN0b3J5ID8gMTAwMCA6IDApO1xuICBjb25zdCBlYXJuZWRHZW1zID0gTWF0aC5mbG9vcih3YXZlc0NvbXBsZXRlZCAqIDMuNSkgKyAodmljdG9yeSA/IDUwIDogMCk7XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImZpeGVkIGluc2V0LTAgei01MCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBiZy1zbGF0ZS05NTAvOTAgYmFja2Ryb3AtYmx1ci1tZCBwLTQgc2VsZWN0LW5vbmVcIj5cbiAgICAgIDxkaXZcbiAgICAgICAgY2xhc3NOYW1lPXtgYmctc2xhdGUtOTAwIGJvcmRlci0yIHJvdW5kZWQtM3hsIHAtNiBtYXgtdy1tZCB3LWZ1bGwgc2hhZG93LTJ4bCB0ZXh0LWNlbnRlciBzcGFjZS15LTQgYW5pbWF0ZS1pbiB6b29tLWluLTk1IGR1cmF0aW9uLTIwMCAke1xuICAgICAgICAgIHZpY3RvcnkgPyAnYm9yZGVyLWFtYmVyLTQwMCcgOiAnYm9yZGVyLXJvc2UtNTAwJ1xuICAgICAgICB9YH1cbiAgICAgID5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSB3LTIwIGgtMjAgbXgtYXV0byByb3VuZGVkLTJ4bCBvdmVyZmxvdy1oaWRkZW4gYm9yZGVyLTIgYm9yZGVyLWN5YW4tNDAwIGJnLXNsYXRlLTk1MCBzaGFkb3ctbGdcIj5cbiAgICAgICAgICA8aW1nIHNyYz17Q0FUX0lNQUdFX1VSTH0gYWx0PVwiQ2F0XCIgY2xhc3NOYW1lPVwidy1mdWxsIGgtZnVsbCBvYmplY3QtY292ZXJcIiAvPlxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImFic29sdXRlIGJvdHRvbS0wIHJpZ2h0LTAgdGV4dC14bFwiPnt2aWN0b3J5ID8gJ/CfkZEnIDogJ/CfkoAnfTwvc3Bhbj5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgPGRpdj5cbiAgICAgICAgICA8aDIgY2xhc3NOYW1lPXtgdGV4dC0yeGwgZm9udC1ibGFjayAke3ZpY3RvcnkgPyAndGV4dC1hbWJlci00MDAnIDogJ3RleHQtcm9zZS01MDAnfWB9PlxuICAgICAgICAgICAge3ZpY3RvcnkgPyAn8J+PhiDQn9Ce0JHQldCU0JAhINCa0JDQoNCi0JAg0JfQkNCn0JjQqdCV0J3QkCEnIDogJ/CfkoAg0LPQviBLRUtDJ31cbiAgICAgICAgICA8L2gyPlxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS00MDAgbXQtMVwiPlxuICAgICAgICAgICAge3ZpY3RvcnlcbiAgICAgICAgICAgICAgPyAn0JvQtdCz0LXQvdC00LDRgNC90YvQuSDQutC+0YIg0LIg0L7Rh9C60LDRhSDQuCDQtdCz0L4g0LrQvtC80LDQvdC00LAg0YDQsNC30LPRgNC+0LzQuNC70Lgg0LLRgdC10YUg0YLQuNGC0LDQvdC+0LIhJ1xuICAgICAgICAgICAgICA6ICfQs9C+IEtFS0MhINCS0YDQsNCz0Lgg0YHQvdC10YHQu9C4INC30LDQvNC+0LosINC60L7RgiDQsiDQvtGH0LrQsNGFINGC0YDQtdCx0YPQtdGCINGA0LXQstCw0L3RiCEnfVxuICAgICAgICAgIDwvcD5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgey8qIFN0YXRzICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtNCBiZy1zbGF0ZS05NTAgcm91bmRlZC0yeGwgYm9yZGVyIGJvcmRlci1zbGF0ZS04MDAgc3BhY2UteS0yIHRleHQteHNcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIHRleHQtc2xhdGUtMzAwXCI+XG4gICAgICAgICAgICA8c3Bhbj7Qn9GA0L7QudC00LXQvdC+INCy0L7Qu9C9Ojwvc3Bhbj5cbiAgICAgICAgICAgIDxiIGNsYXNzTmFtZT1cInRleHQtY3lhbi00MDAgZm9udC1tb25vIHRleHQtc21cIj57d2F2ZXNDb21wbGV0ZWR9PC9iPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gdGV4dC1zbGF0ZS0zMDBcIj5cbiAgICAgICAgICAgIDxzcGFuPtCY0YLQvtCz0L7QstGL0LUg0L7Rh9C60Lg6PC9zcGFuPlxuICAgICAgICAgICAgPGIgY2xhc3NOYW1lPVwidGV4dC1hbWJlci00MDAgZm9udC1tb25vIHRleHQtc21cIj57c2NvcmUudG9Mb2NhbGVTdHJpbmcoKX08L2I+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwdC0yIGJvcmRlci10IGJvcmRlci1zbGF0ZS04MDAgZmxleCBqdXN0aWZ5LWJldHdlZW4gZm9udC1ib2xkXCI+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNsYXRlLTQwMFwiPtCd0LDQs9GA0LDQtNCwINC30LAg0LzQsNGC0Yc6PC9zcGFuPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1lbWVyYWxkLTQwMCBmb250LW1vbm9cIj5cbiAgICAgICAgICAgICAgK3tlYXJuZWRDb2luc30g8J+qmSAmYnVsbDsgK3tlYXJuZWRHZW1zfSDwn5KOXG4gICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIDxidXR0b25cbiAgICAgICAgICBvbkNsaWNrPXtvblJlc3RhcnR9XG4gICAgICAgICAgY2xhc3NOYW1lPXtgdy1mdWxsIHB5LTMgcm91bmRlZC0yeGwgZm9udC1ibGFjayB0ZXh0LXNtIHNoYWRvdy14bCBhY3RpdmU6c2NhbGUtOTUgdHJhbnNpdGlvbi10cmFuc2Zvcm0gJHtcbiAgICAgICAgICAgIHZpY3RvcnlcbiAgICAgICAgICAgICAgPyAnYmctZ3JhZGllbnQtdG8tciBmcm9tLWFtYmVyLTQwMCB0by1hbWJlci01MDAgaG92ZXI6ZnJvbS1hbWJlci0zMDAgdGV4dC1zbGF0ZS05NTAnXG4gICAgICAgICAgICAgIDogJ2JnLWdyYWRpZW50LXRvLXIgZnJvbS1yb3NlLTUwMCB0by1yZWQtNjAwIGhvdmVyOmZyb20tcm9zZS00MDAgdGV4dC13aGl0ZSdcbiAgICAgICAgICB9YH1cbiAgICAgICAgPlxuICAgICAgICAgIHt2aWN0b3J5ID8gJ+KcqCDQmNCz0YDQsNGC0Ywg0KHQu9C10LTRg9GO0YnRg9GOINCa0LDRgNGC0YMnIDogJ/CflIQg0LPQviBLRUtDICjQktC+0LfRgNC+0LTQuNGC0YzRgdGPKSd9XG4gICAgICAgIDwvYnV0dG9uPlxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG4gICk7XG59O1xuIl19