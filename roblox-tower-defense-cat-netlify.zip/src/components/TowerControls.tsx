const React = __vite__cjsImport0_react;const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=1e19e0c2";
import { TOWERS_DATA } from "/src/data/constants.ts";
import { sounds } from "/src/utils/sound.ts";
var _jsxFileName = "/app/applet/src/components/TowerControls.tsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=1e19e0c2";
export const TowerControls = ({ selectedTower, cash, setCash, onClose, onUpgradeTower, onSellTower, onChangeTargetMode }) => {
	if (!selectedTower) return null;
	const def = TOWERS_DATA.find((t) => t.id === selectedTower.towerId);
	if (!def) return null;
	const currentLevelConfig = def.levels[Math.min(selectedTower.level, def.levels.length - 1)];
	const nextLevel = selectedTower.level + 1;
	const nextLevelConfig = nextLevel < def.levels.length ? def.levels[nextLevel] : null;
	// Exact matching for Cat requirements:
	// Lvl 0: 5 dmg, 1s
	// Upgrade to Lvl 1: $300, 7 dmg, 10m
	// Upgrade to Lvl 2: 20 dmg, 20m
	// Upgrade to Lvl 3: 50 dmg, 30m + Unique Slow Down
	const upgradeCost = nextLevelConfig ? nextLevelConfig.cost : null;
	const canAffordUpgrade = upgradeCost !== null && cash >= upgradeCost;
	const refundAmount = Math.round(selectedTower.totalInvested * .7);
	const handleUpgrade = () => {
		if (!nextLevelConfig || upgradeCost === null || cash < upgradeCost) return;
		setCash((c) => c - upgradeCost);
		sounds.playUpgrade();
		onUpgradeTower(selectedTower);
	};
	const handleSell = () => {
		setCash((c) => c + refundAmount);
		sounds.playCoin();
		onSellTower(selectedTower);
		onClose();
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "bg-slate-900 border-2 border-cyan-500/50 rounded-2xl p-4 shadow-2xl text-slate-100 flex flex-col md:flex-row items-center justify-between gap-4",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "flex items-center space-x-3 w-full md:w-auto",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "relative w-14 h-14 rounded-xl bg-slate-800 border-2 border-cyan-400 flex items-center justify-center overflow-hidden shrink-0",
					children: [def.image ? /* @__PURE__ */ _jsxDEV("img", {
						src: def.image,
						alt: def.name,
						className: "w-full h-full object-cover"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 64,
						columnNumber: 13
					}, this) : /* @__PURE__ */ _jsxDEV("span", {
						className: "text-3xl",
						children: def.icon
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 66,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("span", {
						className: "absolute bottom-0 right-0 px-1 text-[10px] font-bold bg-cyan-600 text-white rounded-tl",
						children: ["Lv.", selectedTower.level]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 68,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 62,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", { children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center space-x-2",
						children: [/* @__PURE__ */ _jsxDEV("h3", {
							className: "font-extrabold text-base text-white",
							children: def.name
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 75,
							columnNumber: 13
						}, this), selectedTower.level >= 3 && /* @__PURE__ */ _jsxDEV("span", {
							className: "text-xs px-2 py-0.5 rounded-full bg-cyan-900/80 text-cyan-300 border border-cyan-500 font-bold",
							children: "MAX УРОВЕНЬ"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 77,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 74,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("p", {
						className: "text-xs text-slate-300 font-mono mt-0.5",
						children: [
							"Урон: ",
							/* @__PURE__ */ _jsxDEV("b", {
								className: "text-amber-400",
								children: currentLevelConfig.damage
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 83,
								columnNumber: 19
							}, this),
							" / ",
							currentLevelConfig.fireRate,
							"с • Дальность: ",
							/* @__PURE__ */ _jsxDEV("b", {
								className: "text-cyan-400",
								children: [Math.round(currentLevelConfig.range / 8), "м"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 83,
								columnNumber: 132
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 82,
						columnNumber: 11
					}, this),
					currentLevelConfig.special && /* @__PURE__ */ _jsxDEV("p", {
						className: "text-xs text-cyan-300 font-semibold mt-0.5",
						children: ["✨ ", currentLevelConfig.special]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 86,
						columnNumber: 13
					}, this)
				] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 73,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 61,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "flex items-center space-x-1 bg-slate-950/70 p-1.5 rounded-xl border border-slate-800 text-xs",
				children: [/* @__PURE__ */ _jsxDEV("span", {
					className: "text-slate-400 px-2 font-bold hidden sm:inline",
					children: "Цель:"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 95,
					columnNumber: 9
				}, this), [
					"first",
					"strongest",
					"weakest",
					"last"
				].map((mode) => /* @__PURE__ */ _jsxDEV("button", {
					onClick: () => onChangeTargetMode(mode),
					className: `px-2.5 py-1 rounded-lg font-bold transition-all ${selectedTower.targetMode === mode ? "bg-cyan-500 text-slate-950 shadow-md" : "text-slate-400 hover:text-white hover:bg-slate-800"}`,
					children: mode === "first" ? "Первый" : mode === "strongest" ? "Босс" : mode === "weakest" ? "Слабый" : "Последний"
				}, mode, false, {
					fileName: _jsxFileName,
					lineNumber: 97,
					columnNumber: 11
				}, this))]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 94,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "flex items-center space-x-2 w-full md:w-auto justify-end",
				children: [
					nextLevelConfig && upgradeCost !== null ? /* @__PURE__ */ _jsxDEV("button", {
						onClick: handleUpgrade,
						disabled: !canAffordUpgrade,
						className: `px-4 py-2 rounded-xl font-black text-sm flex items-center space-x-2 shadow-lg transition-all ${canAffordUpgrade ? "bg-gradient-to-r from-emerald-500 to-green-600 hover:from-emerald-400 hover:to-green-500 text-slate-950 cursor-pointer active:scale-95" : "bg-slate-800 text-slate-500 cursor-not-allowed border border-slate-700"}`,
						children: [/* @__PURE__ */ _jsxDEV("span", { children: ["⬆️ Прокачать до Lv.", nextLevel] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 123,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("span", {
							className: "bg-black/25 px-2 py-0.5 rounded-md font-mono text-xs",
							children: ["$", upgradeCost]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 124,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 114,
						columnNumber: 11
					}, this) : /* @__PURE__ */ _jsxDEV("div", {
						className: "px-3 py-1.5 text-xs font-bold text-amber-400 bg-amber-950/40 border border-amber-600/40 rounded-xl",
						children: "🏆 Максимальная прокачка"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 129,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("button", {
						onClick: handleSell,
						className: "px-3 py-2 rounded-xl text-xs font-bold bg-rose-950/60 hover:bg-rose-900/80 text-rose-300 border border-rose-800/50 transition-colors",
						title: "Продать башню за 70% стоимости",
						children: [
							"Продать (+$",
							refundAmount,
							")"
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 135,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("button", {
						onClick: onClose,
						className: "p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white",
						children: "✕"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 144,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 112,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 59,
		columnNumber: 5
	}, this);
};

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxXQUFXO0FBRWxCLFNBQVMsbUJBQW1CO0FBQzVCLFNBQVMsY0FBYzs7O0FBWXZCLE9BQU8sTUFBTSxpQkFBK0MsRUFDMUQsZUFDQSxNQUNBLFNBQ0EsU0FDQSxnQkFDQSxhQUNBLHlCQUNJO0NBQ0osSUFBSSxDQUFDLGVBQWUsT0FBTztDQUUzQixNQUFNLE1BQU0sWUFBWSxNQUFNLE1BQU0sRUFBRSxPQUFPLGNBQWMsT0FBTztDQUNsRSxJQUFJLENBQUMsS0FBSyxPQUFPO0NBRWpCLE1BQU0scUJBQXFCLElBQUksT0FBTyxLQUFLLElBQUksY0FBYyxPQUFPLElBQUksT0FBTyxTQUFTLENBQUM7Q0FDekYsTUFBTSxZQUFZLGNBQWMsUUFBUTtDQUN4QyxNQUFNLGtCQUFrQixZQUFZLElBQUksT0FBTyxTQUFTLElBQUksT0FBTyxhQUFhOzs7Ozs7Q0FPaEYsTUFBTSxjQUFjLGtCQUFrQixnQkFBZ0IsT0FBTztDQUM3RCxNQUFNLG1CQUFtQixnQkFBZ0IsUUFBUSxRQUFRO0NBRXpELE1BQU0sZUFBZSxLQUFLLE1BQU0sY0FBYyxnQkFBZ0IsRUFBRztDQUVqRSxNQUFNLHNCQUFzQjtFQUMxQixJQUFJLENBQUMsbUJBQW1CLGdCQUFnQixRQUFRLE9BQU8sYUFBYTtFQUNwRSxTQUFTLE1BQU0sSUFBSSxXQUFXO0VBQzlCLE9BQU8sWUFBWTtFQUNuQixlQUFlLGFBQWE7Q0FDOUI7Q0FFQSxNQUFNLG1CQUFtQjtFQUN2QixTQUFTLE1BQU0sSUFBSSxZQUFZO0VBQy9CLE9BQU8sU0FBUztFQUNoQixZQUFZLGFBQWE7RUFDekIsUUFBUTtDQUNWO0NBRUEsT0FDRSx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUFmO0dBRUUsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRyxJQUFJLFFBQ0gsd0JBQUMsT0FBRDtNQUFLLEtBQUssSUFBSTtNQUFPLEtBQUssSUFBSTtNQUFNLFdBQVU7S0FBOEI7Ozs7Z0JBRTVFLHdCQUFDLFFBQUQ7TUFBTSxXQUFVO2dCQUFZLElBQUk7S0FBVzs7OztlQUU3Qyx3QkFBQyxRQUFEO01BQU0sV0FBVTtnQkFBaEIsQ0FBeUcsT0FDbkcsY0FBYyxLQUNkOzs7OzthQUNIOzs7OztjQUVMLHdCQUFDLE9BQUQ7S0FDRSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLE1BQUQ7T0FBSSxXQUFVO2lCQUF1QyxJQUFJO01BQVM7Ozs7Z0JBQ2pFLGNBQWMsU0FBUyxLQUN0Qix3QkFBQyxRQUFEO09BQU0sV0FBVTtpQkFBaUc7TUFFM0c7Ozs7Y0FFTDs7Ozs7O0tBQ0wsd0JBQUMsS0FBRDtNQUFHLFdBQVU7Z0JBQWI7T0FBdUQ7T0FDL0Msd0JBQUMsS0FBRDtRQUFHLFdBQVU7a0JBQWtCLG1CQUFtQjtPQUFVOzs7OztPQUFDO09BQUksbUJBQW1CO09BQVM7T0FBb0Isd0JBQUMsS0FBRDtRQUFHLFdBQVU7a0JBQWIsQ0FBOEIsS0FBSyxNQUFNLG1CQUFtQixRQUFRLENBQUMsR0FBRSxHQUFJOzs7Ozs7TUFDak07Ozs7OztLQUNGLG1CQUFtQixXQUNsQix3QkFBQyxLQUFEO01BQUcsV0FBVTtnQkFBYixDQUEwRCxNQUNyRCxtQkFBbUIsT0FDckI7Ozs7OztJQUVGOzs7O1lBQ0Y7Ozs7OztHQUdMLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxRQUFEO0tBQU0sV0FBVTtlQUFpRDtJQUFXOzs7O2NBQzFFO0tBQUM7S0FBUztLQUFhO0tBQVc7SUFBTSxDQUFDLENBQVcsS0FBSyxTQUN6RCx3QkFBQyxVQUFEO0tBRUUsZUFBZSxtQkFBbUIsSUFBSTtLQUN0QyxXQUFXLG1EQUNULGNBQWMsZUFBZSxPQUN6Qix5Q0FDQTtlQUdMLFNBQVMsVUFBVSxXQUFXLFNBQVMsY0FBYyxTQUFTLFNBQVMsWUFBWSxXQUFXO0lBQ3pGLEdBVEQ7Ozs7V0FTQyxDQUNULENBQ0U7Ozs7OztHQUdMLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWY7S0FDRyxtQkFBbUIsZ0JBQWdCLE9BQ2xDLHdCQUFDLFVBQUQ7TUFDRSxTQUFTO01BQ1QsVUFBVSxDQUFDO01BQ1gsV0FBVyxnR0FDVCxtQkFDSSwySUFDQTtnQkFOUixDQVNFLHdCQUFDLFFBQUQsYUFBTSx1QkFBb0IsU0FBZ0I7Ozs7Z0JBQzFDLHdCQUFDLFFBQUQ7T0FBTSxXQUFVO2lCQUFoQixDQUF1RSxLQUNuRSxXQUNFOzs7OztjQUNBOzs7OztnQkFFUix3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBcUc7S0FFL0c7Ozs7O0tBSVAsd0JBQUMsVUFBRDtNQUNFLFNBQVM7TUFDVCxXQUFVO01BQ1YsT0FBTTtnQkFIUjtPQUlDO09BQ2E7T0FBYTtNQUNuQjs7Ozs7O0tBR1Isd0JBQUMsVUFBRDtNQUNFLFNBQVM7TUFDVCxXQUFVO2dCQUNYO0tBRU87Ozs7O0lBQ0w7Ozs7OztFQUNGOzs7Ozs7QUFFVCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJUb3dlckNvbnRyb2xzLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgUGxhY2VkVG93ZXIgfSBmcm9tICcuLi90eXBlcy9nYW1lJztcbmltcG9ydCB7IFRPV0VSU19EQVRBIH0gZnJvbSAnLi4vZGF0YS9jb25zdGFudHMnO1xuaW1wb3J0IHsgc291bmRzIH0gZnJvbSAnLi4vdXRpbHMvc291bmQnO1xuXG5pbnRlcmZhY2UgVG93ZXJDb250cm9sc1Byb3BzIHtcbiAgc2VsZWN0ZWRUb3dlcjogUGxhY2VkVG93ZXIgfCBudWxsO1xuICBjYXNoOiBudW1iZXI7XG4gIHNldENhc2g6IFJlYWN0LkRpc3BhdGNoPFJlYWN0LlNldFN0YXRlQWN0aW9uPG51bWJlcj4+O1xuICBvbkNsb3NlOiAoKSA9PiB2b2lkO1xuICBvblVwZ3JhZGVUb3dlcjogKHRvd2VyOiBQbGFjZWRUb3dlcikgPT4gdm9pZDtcbiAgb25TZWxsVG93ZXI6ICh0b3dlcjogUGxhY2VkVG93ZXIpID0+IHZvaWQ7XG4gIG9uQ2hhbmdlVGFyZ2V0TW9kZTogKG1vZGU6ICdmaXJzdCcgfCAnbGFzdCcgfCAnc3Ryb25nZXN0JyB8ICd3ZWFrZXN0JykgPT4gdm9pZDtcbn1cblxuZXhwb3J0IGNvbnN0IFRvd2VyQ29udHJvbHM6IFJlYWN0LkZDPFRvd2VyQ29udHJvbHNQcm9wcz4gPSAoe1xuICBzZWxlY3RlZFRvd2VyLFxuICBjYXNoLFxuICBzZXRDYXNoLFxuICBvbkNsb3NlLFxuICBvblVwZ3JhZGVUb3dlcixcbiAgb25TZWxsVG93ZXIsXG4gIG9uQ2hhbmdlVGFyZ2V0TW9kZSxcbn0pID0+IHtcbiAgaWYgKCFzZWxlY3RlZFRvd2VyKSByZXR1cm4gbnVsbDtcblxuICBjb25zdCBkZWYgPSBUT1dFUlNfREFUQS5maW5kKCh0KSA9PiB0LmlkID09PSBzZWxlY3RlZFRvd2VyLnRvd2VySWQpO1xuICBpZiAoIWRlZikgcmV0dXJuIG51bGw7XG5cbiAgY29uc3QgY3VycmVudExldmVsQ29uZmlnID0gZGVmLmxldmVsc1tNYXRoLm1pbihzZWxlY3RlZFRvd2VyLmxldmVsLCBkZWYubGV2ZWxzLmxlbmd0aCAtIDEpXTtcbiAgY29uc3QgbmV4dExldmVsID0gc2VsZWN0ZWRUb3dlci5sZXZlbCArIDE7XG4gIGNvbnN0IG5leHRMZXZlbENvbmZpZyA9IG5leHRMZXZlbCA8IGRlZi5sZXZlbHMubGVuZ3RoID8gZGVmLmxldmVsc1tuZXh0TGV2ZWxdIDogbnVsbDtcblxuICAvLyBFeGFjdCBtYXRjaGluZyBmb3IgQ2F0IHJlcXVpcmVtZW50czpcbiAgLy8gTHZsIDA6IDUgZG1nLCAxc1xuICAvLyBVcGdyYWRlIHRvIEx2bCAxOiAkMzAwLCA3IGRtZywgMTBtXG4gIC8vIFVwZ3JhZGUgdG8gTHZsIDI6IDIwIGRtZywgMjBtXG4gIC8vIFVwZ3JhZGUgdG8gTHZsIDM6IDUwIGRtZywgMzBtICsgVW5pcXVlIFNsb3cgRG93blxuICBjb25zdCB1cGdyYWRlQ29zdCA9IG5leHRMZXZlbENvbmZpZyA/IG5leHRMZXZlbENvbmZpZy5jb3N0IDogbnVsbDtcbiAgY29uc3QgY2FuQWZmb3JkVXBncmFkZSA9IHVwZ3JhZGVDb3N0ICE9PSBudWxsICYmIGNhc2ggPj0gdXBncmFkZUNvc3Q7XG5cbiAgY29uc3QgcmVmdW5kQW1vdW50ID0gTWF0aC5yb3VuZChzZWxlY3RlZFRvd2VyLnRvdGFsSW52ZXN0ZWQgKiAwLjcpO1xuXG4gIGNvbnN0IGhhbmRsZVVwZ3JhZGUgPSAoKSA9PiB7XG4gICAgaWYgKCFuZXh0TGV2ZWxDb25maWcgfHwgdXBncmFkZUNvc3QgPT09IG51bGwgfHwgY2FzaCA8IHVwZ3JhZGVDb3N0KSByZXR1cm47XG4gICAgc2V0Q2FzaCgoYykgPT4gYyAtIHVwZ3JhZGVDb3N0KTtcbiAgICBzb3VuZHMucGxheVVwZ3JhZGUoKTtcbiAgICBvblVwZ3JhZGVUb3dlcihzZWxlY3RlZFRvd2VyKTtcbiAgfTtcblxuICBjb25zdCBoYW5kbGVTZWxsID0gKCkgPT4ge1xuICAgIHNldENhc2goKGMpID0+IGMgKyByZWZ1bmRBbW91bnQpO1xuICAgIHNvdW5kcy5wbGF5Q29pbigpO1xuICAgIG9uU2VsbFRvd2VyKHNlbGVjdGVkVG93ZXIpO1xuICAgIG9uQ2xvc2UoKTtcbiAgfTtcblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctc2xhdGUtOTAwIGJvcmRlci0yIGJvcmRlci1jeWFuLTUwMC81MCByb3VuZGVkLTJ4bCBwLTQgc2hhZG93LTJ4bCB0ZXh0LXNsYXRlLTEwMCBmbGV4IGZsZXgtY29sIG1kOmZsZXgtcm93IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTRcIj5cbiAgICAgIHsvKiBMZWZ0OiBUb3dlciBJZGVudGl0eSAmIEN1cnJlbnQgU3RhdHMgKi99XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIHNwYWNlLXgtMyB3LWZ1bGwgbWQ6dy1hdXRvXCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgdy0xNCBoLTE0IHJvdW5kZWQteGwgYmctc2xhdGUtODAwIGJvcmRlci0yIGJvcmRlci1jeWFuLTQwMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBvdmVyZmxvdy1oaWRkZW4gc2hyaW5rLTBcIj5cbiAgICAgICAgICB7ZGVmLmltYWdlID8gKFxuICAgICAgICAgICAgPGltZyBzcmM9e2RlZi5pbWFnZX0gYWx0PXtkZWYubmFtZX0gY2xhc3NOYW1lPVwidy1mdWxsIGgtZnVsbCBvYmplY3QtY292ZXJcIiAvPlxuICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LTN4bFwiPntkZWYuaWNvbn08L3NwYW4+XG4gICAgICAgICAgKX1cbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJhYnNvbHV0ZSBib3R0b20tMCByaWdodC0wIHB4LTEgdGV4dC1bMTBweF0gZm9udC1ib2xkIGJnLWN5YW4tNjAwIHRleHQtd2hpdGUgcm91bmRlZC10bFwiPlxuICAgICAgICAgICAgTHYue3NlbGVjdGVkVG93ZXIubGV2ZWx9XG4gICAgICAgICAgPC9zcGFuPlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICA8ZGl2PlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgc3BhY2UteC0yXCI+XG4gICAgICAgICAgICA8aDMgY2xhc3NOYW1lPVwiZm9udC1leHRyYWJvbGQgdGV4dC1iYXNlIHRleHQtd2hpdGVcIj57ZGVmLm5hbWV9PC9oMz5cbiAgICAgICAgICAgIHtzZWxlY3RlZFRvd2VyLmxldmVsID49IDMgJiYgKFxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHB4LTIgcHktMC41IHJvdW5kZWQtZnVsbCBiZy1jeWFuLTkwMC84MCB0ZXh0LWN5YW4tMzAwIGJvcmRlciBib3JkZXItY3lhbi01MDAgZm9udC1ib2xkXCI+XG4gICAgICAgICAgICAgICAgTUFYINCj0KDQntCS0JXQndCsXG4gICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICl9XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTMwMCBmb250LW1vbm8gbXQtMC41XCI+XG4gICAgICAgICAgICDQo9GA0L7QvTogPGIgY2xhc3NOYW1lPVwidGV4dC1hbWJlci00MDBcIj57Y3VycmVudExldmVsQ29uZmlnLmRhbWFnZX08L2I+IC8ge2N1cnJlbnRMZXZlbENvbmZpZy5maXJlUmF0ZX3RgSAmYnVsbDsg0JTQsNC70YzQvdC+0YHRgtGMOiA8YiBjbGFzc05hbWU9XCJ0ZXh0LWN5YW4tNDAwXCI+e01hdGgucm91bmQoY3VycmVudExldmVsQ29uZmlnLnJhbmdlIC8gOCl90Lw8L2I+XG4gICAgICAgICAgPC9wPlxuICAgICAgICAgIHtjdXJyZW50TGV2ZWxDb25maWcuc3BlY2lhbCAmJiAoXG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtY3lhbi0zMDAgZm9udC1zZW1pYm9sZCBtdC0wLjVcIj5cbiAgICAgICAgICAgICAg4pyoIHtjdXJyZW50TGV2ZWxDb25maWcuc3BlY2lhbH1cbiAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICApfVxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7LyogTWlkZGxlOiBUYXJnZXQgTW9kZSBTZWxlY3RvciAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgc3BhY2UteC0xIGJnLXNsYXRlLTk1MC83MCBwLTEuNSByb3VuZGVkLXhsIGJvcmRlciBib3JkZXItc2xhdGUtODAwIHRleHQteHNcIj5cbiAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS00MDAgcHgtMiBmb250LWJvbGQgaGlkZGVuIHNtOmlubGluZVwiPtCm0LXQu9GMOjwvc3Bhbj5cbiAgICAgICAgeyhbJ2ZpcnN0JywgJ3N0cm9uZ2VzdCcsICd3ZWFrZXN0JywgJ2xhc3QnXSBhcyBjb25zdCkubWFwKChtb2RlKSA9PiAoXG4gICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAga2V5PXttb2RlfVxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gb25DaGFuZ2VUYXJnZXRNb2RlKG1vZGUpfVxuICAgICAgICAgICAgY2xhc3NOYW1lPXtgcHgtMi41IHB5LTEgcm91bmRlZC1sZyBmb250LWJvbGQgdHJhbnNpdGlvbi1hbGwgJHtcbiAgICAgICAgICAgICAgc2VsZWN0ZWRUb3dlci50YXJnZXRNb2RlID09PSBtb2RlXG4gICAgICAgICAgICAgICAgPyAnYmctY3lhbi01MDAgdGV4dC1zbGF0ZS05NTAgc2hhZG93LW1kJ1xuICAgICAgICAgICAgICAgIDogJ3RleHQtc2xhdGUtNDAwIGhvdmVyOnRleHQtd2hpdGUgaG92ZXI6Ymctc2xhdGUtODAwJ1xuICAgICAgICAgICAgfWB9XG4gICAgICAgICAgPlxuICAgICAgICAgICAge21vZGUgPT09ICdmaXJzdCcgPyAn0J/QtdGA0LLRi9C5JyA6IG1vZGUgPT09ICdzdHJvbmdlc3QnID8gJ9CR0L7RgdGBJyA6IG1vZGUgPT09ICd3ZWFrZXN0JyA/ICfQodC70LDQsdGL0LknIDogJ9Cf0L7RgdC70LXQtNC90LjQuSd9XG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICkpfVxuICAgICAgPC9kaXY+XG5cbiAgICAgIHsvKiBSaWdodDogVXBncmFkZSAmIFNlbGwgQnV0dG9ucyAqL31cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgc3BhY2UteC0yIHctZnVsbCBtZDp3LWF1dG8ganVzdGlmeS1lbmRcIj5cbiAgICAgICAge25leHRMZXZlbENvbmZpZyAmJiB1cGdyYWRlQ29zdCAhPT0gbnVsbCA/IChcbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVVcGdyYWRlfVxuICAgICAgICAgICAgZGlzYWJsZWQ9eyFjYW5BZmZvcmRVcGdyYWRlfVxuICAgICAgICAgICAgY2xhc3NOYW1lPXtgcHgtNCBweS0yIHJvdW5kZWQteGwgZm9udC1ibGFjayB0ZXh0LXNtIGZsZXggaXRlbXMtY2VudGVyIHNwYWNlLXgtMiBzaGFkb3ctbGcgdHJhbnNpdGlvbi1hbGwgJHtcbiAgICAgICAgICAgICAgY2FuQWZmb3JkVXBncmFkZVxuICAgICAgICAgICAgICAgID8gJ2JnLWdyYWRpZW50LXRvLXIgZnJvbS1lbWVyYWxkLTUwMCB0by1ncmVlbi02MDAgaG92ZXI6ZnJvbS1lbWVyYWxkLTQwMCBob3Zlcjp0by1ncmVlbi01MDAgdGV4dC1zbGF0ZS05NTAgY3Vyc29yLXBvaW50ZXIgYWN0aXZlOnNjYWxlLTk1J1xuICAgICAgICAgICAgICAgIDogJ2JnLXNsYXRlLTgwMCB0ZXh0LXNsYXRlLTUwMCBjdXJzb3Itbm90LWFsbG93ZWQgYm9yZGVyIGJvcmRlci1zbGF0ZS03MDAnXG4gICAgICAgICAgICB9YH1cbiAgICAgICAgICA+XG4gICAgICAgICAgICA8c3Bhbj7irIbvuI8g0J/RgNC+0LrQsNGH0LDRgtGMINC00L4gTHYue25leHRMZXZlbH08L3NwYW4+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJiZy1ibGFjay8yNSBweC0yIHB5LTAuNSByb3VuZGVkLW1kIGZvbnQtbW9ubyB0ZXh0LXhzXCI+XG4gICAgICAgICAgICAgICR7dXBncmFkZUNvc3R9XG4gICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICkgOiAoXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJweC0zIHB5LTEuNSB0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LWFtYmVyLTQwMCBiZy1hbWJlci05NTAvNDAgYm9yZGVyIGJvcmRlci1hbWJlci02MDAvNDAgcm91bmRlZC14bFwiPlxuICAgICAgICAgICAg8J+PhiDQnNCw0LrRgdC40LzQsNC70YzQvdCw0Y8g0L/RgNC+0LrQsNGH0LrQsFxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICApfVxuXG4gICAgICAgIHsvKiBTZWxsIFRvd2VyICovfVxuICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgb25DbGljaz17aGFuZGxlU2VsbH1cbiAgICAgICAgICBjbGFzc05hbWU9XCJweC0zIHB5LTIgcm91bmRlZC14bCB0ZXh0LXhzIGZvbnQtYm9sZCBiZy1yb3NlLTk1MC82MCBob3ZlcjpiZy1yb3NlLTkwMC84MCB0ZXh0LXJvc2UtMzAwIGJvcmRlciBib3JkZXItcm9zZS04MDAvNTAgdHJhbnNpdGlvbi1jb2xvcnNcIlxuICAgICAgICAgIHRpdGxlPVwi0J/RgNC+0LTQsNGC0Ywg0LHQsNGI0L3RjiDQt9CwIDcwJSDRgdGC0L7QuNC80L7RgdGC0LhcIlxuICAgICAgICA+XG4gICAgICAgICAg0J/RgNC+0LTQsNGC0YwgKCske3JlZnVuZEFtb3VudH0pXG4gICAgICAgIDwvYnV0dG9uPlxuXG4gICAgICAgIHsvKiBDbG9zZSBCdXR0b24gKi99XG4gICAgICAgIDxidXR0b25cbiAgICAgICAgICBvbkNsaWNrPXtvbkNsb3NlfVxuICAgICAgICAgIGNsYXNzTmFtZT1cInAtMiByb3VuZGVkLXhsIGJnLXNsYXRlLTgwMCBob3ZlcjpiZy1zbGF0ZS03MDAgdGV4dC1zbGF0ZS00MDAgaG92ZXI6dGV4dC13aGl0ZVwiXG4gICAgICAgID5cbiAgICAgICAgICDinJVcbiAgICAgICAgPC9idXR0b24+XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgKTtcbn07XG4iXX0=