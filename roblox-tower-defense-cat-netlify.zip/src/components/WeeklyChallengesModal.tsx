const React = __vite__cjsImport0_react;const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=1e19e0c2";
import { WEEKLY_CHALLENGE_DATA, CAT_IMAGE_URL } from "/src/data/constants.ts";
import { sounds } from "/src/utils/sound.ts";
var _jsxFileName = "/app/applet/src/components/WeeklyChallengesModal.tsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=1e19e0c2";
export const WeeklyChallengesModal = ({ onStartChallenge, onClose }) => {
	const challenge = WEEKLY_CHALLENGE_DATA;
	const handleLaunch = () => {
		sounds.playWaveStart();
		onStartChallenge(challenge.restrictedTowers || []);
		onClose();
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "fixed inset-0 z-50 flex items-center justify-center bg-slate-950/85 backdrop-blur-md p-4",
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: "bg-slate-900 border-2 border-purple-500/50 rounded-3xl p-6 max-w-xl w-full shadow-2xl text-slate-100 relative",
			children: [
				/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center justify-between pb-4 border-b border-slate-800",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center space-x-3",
						children: [/* @__PURE__ */ _jsxDEV("span", {
							className: "text-3xl",
							children: "⚔️"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 28,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
							className: "text-[10px] font-black uppercase tracking-wider text-purple-400 bg-purple-950 px-2 py-0.5 rounded-full border border-purple-700",
							children: challenge.theme
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 30,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("h2", {
							className: "text-xl font-black text-white mt-1",
							children: challenge.title
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 33,
							columnNumber: 15
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 29,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 27,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("button", {
						onClick: onClose,
						className: "w-8 h-8 rounded-full bg-slate-800 hover:bg-slate-700 flex items-center justify-center text-slate-400 hover:text-white",
						children: "✕"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 36,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 26,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "my-4 p-4 bg-gradient-to-br from-purple-950/40 to-slate-950 border border-purple-600/40 rounded-2xl space-y-3",
					children: [
						/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center space-x-3",
							children: [/* @__PURE__ */ _jsxDEV("div", {
								className: "w-14 h-14 rounded-xl overflow-hidden border-2 border-purple-400 shrink-0",
								children: /* @__PURE__ */ _jsxDEV("img", {
									src: CAT_IMAGE_URL,
									alt: "Cat",
									className: "w-full h-full object-cover"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 48,
									columnNumber: 15
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 47,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("p", {
								className: "text-xs text-slate-300 leading-relaxed",
								children: challenge.description
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 51,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "text-[11px] text-purple-300 font-mono mt-1",
								children: ["⏳ Сброс испытания через: ", /* @__PURE__ */ _jsxDEV("b", { children: [challenge.endsInDays, " дня 12 часов"] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 53,
									columnNumber: 42
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 52,
								columnNumber: 15
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 50,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 46,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "space-y-1.5 pt-2 border-t border-purple-900/50",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "text-xs font-bold text-amber-400",
								children: "⚡ Особые правила раунда:"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 60,
								columnNumber: 13
							}, this), challenge.modifiers.map((mod, idx) => /* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center space-x-2 text-xs text-slate-300",
								children: [/* @__PURE__ */ _jsxDEV("span", {
									className: "text-purple-400",
									children: "✦"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 63,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("span", { children: mod }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 64,
									columnNumber: 17
								}, this)]
							}, idx, true, {
								fileName: _jsxFileName,
								lineNumber: 62,
								columnNumber: 15
							}, this))]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 59,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("div", {
							className: "p-3 bg-slate-950/80 rounded-xl border border-slate-800 flex items-center justify-between",
							children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "text-[10px] uppercase font-bold text-slate-400",
								children: "Цель:"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 72,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "text-xs font-black text-white",
								children: [
									"Выстоять ",
									challenge.targetWave,
									" волн"
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 73,
								columnNumber: 15
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 71,
								columnNumber: 13
							}, this), /* @__PURE__ */ _jsxDEV("div", {
								className: "text-right",
								children: [/* @__PURE__ */ _jsxDEV("span", {
									className: "text-[10px] uppercase font-bold text-slate-400",
									children: "Награда за победу:"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 78,
									columnNumber: 15
								}, this), /* @__PURE__ */ _jsxDEV("div", {
									className: "text-xs font-mono font-black text-amber-400",
									children: [
										"+",
										challenge.rewardCoins,
										" 🪙 • +",
										challenge.rewardGems,
										" 💎"
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 79,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 77,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 70,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 45,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("button", {
					onClick: handleLaunch,
					className: "w-full py-3 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white rounded-xl font-black text-sm shadow-xl active:scale-95 transition-transform flex items-center justify-center space-x-2",
					children: /* @__PURE__ */ _jsxDEV("span", { children: "🚀 Запустить Еженедельное Испытание" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 91,
						columnNumber: 11
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 87,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 24,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 23,
		columnNumber: 5
	}, this);
};

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxXQUFXO0FBQ2xCLFNBQVMsdUJBQXVCLHFCQUFxQjtBQUNyRCxTQUFTLGNBQWM7OztBQU92QixPQUFPLE1BQU0seUJBQStELEVBQzFFLGtCQUNBLGNBQ0k7Q0FDSixNQUFNLFlBQVk7Q0FFbEIsTUFBTSxxQkFBcUI7RUFDekIsT0FBTyxjQUFjO0VBQ3JCLGlCQUFpQixVQUFVLG9CQUFvQixDQUFDLENBQUM7RUFDakQsUUFBUTtDQUNWO0NBRUEsT0FDRSx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUNiLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQWY7SUFFRSx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxRQUFEO09BQU0sV0FBVTtpQkFBVztNQUFROzs7O2dCQUNuQyx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsUUFBRDtPQUFNLFdBQVU7aUJBQ2IsVUFBVTtNQUNQOzs7O2dCQUNOLHdCQUFDLE1BQUQ7T0FBSSxXQUFVO2lCQUFzQyxVQUFVO01BQVU7Ozs7Y0FDckU7Ozs7Y0FDRjs7Ozs7ZUFDTCx3QkFBQyxVQUFEO01BQ0UsU0FBUztNQUNULFdBQVU7Z0JBQ1g7S0FFTzs7OzthQUNMOzs7Ozs7SUFHTCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmO01BQ0Usd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFDYix3QkFBQyxPQUFEO1NBQUssS0FBSztTQUFlLEtBQUk7U0FBTSxXQUFVO1FBQThCOzs7OztPQUN4RTs7OztpQkFDTCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsS0FBRDtRQUFHLFdBQVU7a0JBQTBDLFVBQVU7T0FBZTs7OztpQkFDaEYsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FBNEQsNkJBQ2pDLHdCQUFDLEtBQUQsYUFBSSxVQUFVLFlBQVcsZUFBZ0I7Ozs7Z0JBQy9EOzs7OztlQUNGOzs7O2VBQ0Y7Ozs7OztNQUdMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQW1DO09BQThCOzs7O2lCQUNoRixVQUFVLFVBQVUsS0FBSyxLQUFLLFFBQzdCLHdCQUFDLE9BQUQ7UUFBZSxXQUFVO2tCQUF6QixDQUNFLHdCQUFDLFFBQUQ7U0FBTSxXQUFVO21CQUFrQjtRQUFPOzs7O2tCQUN6Qyx3QkFBQyxRQUFELFlBQU8sSUFBVTs7OztnQkFDZDtVQUhLOzs7O2NBR0wsQ0FDTixDQUNFOzs7Ozs7TUFHTCx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBaUQ7T0FBVzs7OztpQkFDNUUsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWY7U0FBK0M7U0FDbkMsVUFBVTtTQUFXO1FBQzVCOzs7OztlQUNGOzs7O2lCQUNMLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsUUFBRDtTQUFNLFdBQVU7bUJBQWlEO1FBQXdCOzs7O2tCQUN6Rix3QkFBQyxPQUFEO1NBQUssV0FBVTttQkFBZjtVQUE2RDtVQUN6RCxVQUFVO1VBQVk7VUFBYSxVQUFVO1VBQVc7U0FDdkQ7Ozs7O2dCQUNGOzs7OztlQUNGOzs7Ozs7S0FDRjs7Ozs7O0lBR0wsd0JBQUMsVUFBRDtLQUNFLFNBQVM7S0FDVCxXQUFVO2VBRVYsd0JBQUMsUUFBRCxZQUFNLHNDQUF5Qzs7Ozs7SUFDekM7Ozs7O0dBQ0w7Ozs7OztDQUNGOzs7OztBQUVUIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIldlZWtseUNoYWxsZW5nZXNNb2RhbC50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IFdFRUtMWV9DSEFMTEVOR0VfREFUQSwgQ0FUX0lNQUdFX1VSTCB9IGZyb20gJy4uL2RhdGEvY29uc3RhbnRzJztcbmltcG9ydCB7IHNvdW5kcyB9IGZyb20gJy4uL3V0aWxzL3NvdW5kJztcblxuaW50ZXJmYWNlIFdlZWtseUNoYWxsZW5nZXNNb2RhbFByb3BzIHtcbiAgb25TdGFydENoYWxsZW5nZTogKHJlc3RyaWN0ZWRUb3dlcnM6IHN0cmluZ1tdKSA9PiB2b2lkO1xuICBvbkNsb3NlOiAoKSA9PiB2b2lkO1xufVxuXG5leHBvcnQgY29uc3QgV2Vla2x5Q2hhbGxlbmdlc01vZGFsOiBSZWFjdC5GQzxXZWVrbHlDaGFsbGVuZ2VzTW9kYWxQcm9wcz4gPSAoe1xuICBvblN0YXJ0Q2hhbGxlbmdlLFxuICBvbkNsb3NlLFxufSkgPT4ge1xuICBjb25zdCBjaGFsbGVuZ2UgPSBXRUVLTFlfQ0hBTExFTkdFX0RBVEE7XG5cbiAgY29uc3QgaGFuZGxlTGF1bmNoID0gKCkgPT4ge1xuICAgIHNvdW5kcy5wbGF5V2F2ZVN0YXJ0KCk7XG4gICAgb25TdGFydENoYWxsZW5nZShjaGFsbGVuZ2UucmVzdHJpY3RlZFRvd2VycyB8fCBbXSk7XG4gICAgb25DbG9zZSgpO1xuICB9O1xuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJmaXhlZCBpbnNldC0wIHotNTAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgYmctc2xhdGUtOTUwLzg1IGJhY2tkcm9wLWJsdXItbWQgcC00XCI+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXNsYXRlLTkwMCBib3JkZXItMiBib3JkZXItcHVycGxlLTUwMC81MCByb3VuZGVkLTN4bCBwLTYgbWF4LXcteGwgdy1mdWxsIHNoYWRvdy0yeGwgdGV4dC1zbGF0ZS0xMDAgcmVsYXRpdmVcIj5cbiAgICAgICAgey8qIEhlYWRlciAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gcGItNCBib3JkZXItYiBib3JkZXItc2xhdGUtODAwXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBzcGFjZS14LTNcIj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtM3hsXCI+4pqU77iPPC9zcGFuPlxuICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gZm9udC1ibGFjayB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXIgdGV4dC1wdXJwbGUtNDAwIGJnLXB1cnBsZS05NTAgcHgtMiBweS0wLjUgcm91bmRlZC1mdWxsIGJvcmRlciBib3JkZXItcHVycGxlLTcwMFwiPlxuICAgICAgICAgICAgICAgIHtjaGFsbGVuZ2UudGhlbWV9XG4gICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1ibGFjayB0ZXh0LXdoaXRlIG10LTFcIj57Y2hhbGxlbmdlLnRpdGxlfTwvaDI+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICBvbkNsaWNrPXtvbkNsb3NlfVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwidy04IGgtOCByb3VuZGVkLWZ1bGwgYmctc2xhdGUtODAwIGhvdmVyOmJnLXNsYXRlLTcwMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciB0ZXh0LXNsYXRlLTQwMCBob3Zlcjp0ZXh0LXdoaXRlXCJcbiAgICAgICAgICA+XG4gICAgICAgICAgICDinJVcbiAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgey8qIENoYWxsZW5nZSBQcmV2aWV3IENhcmQgKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXktNCBwLTQgYmctZ3JhZGllbnQtdG8tYnIgZnJvbS1wdXJwbGUtOTUwLzQwIHRvLXNsYXRlLTk1MCBib3JkZXIgYm9yZGVyLXB1cnBsZS02MDAvNDAgcm91bmRlZC0yeGwgc3BhY2UteS0zXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBzcGFjZS14LTNcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidy0xNCBoLTE0IHJvdW5kZWQteGwgb3ZlcmZsb3ctaGlkZGVuIGJvcmRlci0yIGJvcmRlci1wdXJwbGUtNDAwIHNocmluay0wXCI+XG4gICAgICAgICAgICAgIDxpbWcgc3JjPXtDQVRfSU1BR0VfVVJMfSBhbHQ9XCJDYXRcIiBjbGFzc05hbWU9XCJ3LWZ1bGwgaC1mdWxsIG9iamVjdC1jb3ZlclwiIC8+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1zbGF0ZS0zMDAgbGVhZGluZy1yZWxheGVkXCI+e2NoYWxsZW5nZS5kZXNjcmlwdGlvbn08L3A+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1bMTFweF0gdGV4dC1wdXJwbGUtMzAwIGZvbnQtbW9ubyBtdC0xXCI+XG4gICAgICAgICAgICAgICAg4o+zINCh0LHRgNC+0YEg0LjRgdC/0YvRgtCw0L3QuNGPINGH0LXRgNC10Lc6IDxiPntjaGFsbGVuZ2UuZW5kc0luRGF5c30g0LTQvdGPIDEyINGH0LDRgdC+0LI8L2I+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICB7LyogTW9kaWZpZXJzIExpc3QgKi99XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTEuNSBwdC0yIGJvcmRlci10IGJvcmRlci1wdXJwbGUtOTAwLzUwXCI+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtYm9sZCB0ZXh0LWFtYmVyLTQwMFwiPuKaoSDQntGB0L7QsdGL0LUg0L/RgNCw0LLQuNC70LAg0YDQsNGD0L3QtNCwOjwvc3Bhbj5cbiAgICAgICAgICAgIHtjaGFsbGVuZ2UubW9kaWZpZXJzLm1hcCgobW9kLCBpZHgpID0+IChcbiAgICAgICAgICAgICAgPGRpdiBrZXk9e2lkeH0gY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgc3BhY2UteC0yIHRleHQteHMgdGV4dC1zbGF0ZS0zMDBcIj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXB1cnBsZS00MDBcIj7inKY8L3NwYW4+XG4gICAgICAgICAgICAgICAgPHNwYW4+e21vZH08L3NwYW4+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgKSl9XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICB7LyogVGFyZ2V0ICYgUmV3YXJkcyAqL31cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMyBiZy1zbGF0ZS05NTAvODAgcm91bmRlZC14bCBib3JkZXIgYm9yZGVyLXNsYXRlLTgwMCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cbiAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtWzEwcHhdIHVwcGVyY2FzZSBmb250LWJvbGQgdGV4dC1zbGF0ZS00MDBcIj7QptC10LvRjDo8L3NwYW4+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC14cyBmb250LWJsYWNrIHRleHQtd2hpdGVcIj5cbiAgICAgICAgICAgICAgICDQktGL0YHRgtC+0Y/RgtGMIHtjaGFsbGVuZ2UudGFyZ2V0V2F2ZX0g0LLQvtC70L1cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1yaWdodFwiPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSB1cHBlcmNhc2UgZm9udC1ib2xkIHRleHQtc2xhdGUtNDAwXCI+0J3QsNCz0YDQsNC00LAg0LfQsCDQv9C+0LHQtdC00YM6PC9zcGFuPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQteHMgZm9udC1tb25vIGZvbnQtYmxhY2sgdGV4dC1hbWJlci00MDBcIj5cbiAgICAgICAgICAgICAgICAre2NoYWxsZW5nZS5yZXdhcmRDb2luc30g8J+qmSAmYnVsbDsgK3tjaGFsbGVuZ2UucmV3YXJkR2Vtc30g8J+SjlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICB7LyogQWN0aW9uIEJ1dHRvbiAqL31cbiAgICAgICAgPGJ1dHRvblxuICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZUxhdW5jaH1cbiAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGwgcHktMyBiZy1ncmFkaWVudC10by1yIGZyb20tcHVycGxlLTYwMCB0by1pbmRpZ28tNjAwIGhvdmVyOmZyb20tcHVycGxlLTUwMCBob3Zlcjp0by1pbmRpZ28tNTAwIHRleHQtd2hpdGUgcm91bmRlZC14bCBmb250LWJsYWNrIHRleHQtc20gc2hhZG93LXhsIGFjdGl2ZTpzY2FsZS05NSB0cmFuc2l0aW9uLXRyYW5zZm9ybSBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBzcGFjZS14LTJcIlxuICAgICAgICA+XG4gICAgICAgICAgPHNwYW4+8J+agCDQl9Cw0L/Rg9GB0YLQuNGC0Ywg0JXQttC10L3QtdC00LXQu9GM0L3QvtC1INCY0YHQv9GL0YLQsNC90LjQtTwvc3Bhbj5cbiAgICAgICAgPC9idXR0b24+XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgKTtcbn07XG4iXX0=