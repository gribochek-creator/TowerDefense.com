const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=1e19e0c2";
import confetti from "/node_modules/.vite/deps/canvas-confetti.js?v=601c4ae1";
import { INITIAL_DAILY_REWARDS, CAT_IMAGE_URL } from "/src/data/constants.ts";
import { sounds } from "/src/utils/sound.ts";
var _jsxFileName = "/app/applet/src/components/DailyRewardsModal.tsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=1e19e0c2";
export const DailyRewardsModal = ({ user, setUser, onClose }) => {
	const [claimedToday, setClaimedToday] = useState(false);
	const currentStreak = user.dailyStreak;
	const handleClaim = (dayIndex) => {
		if (claimedToday) return;
		const reward = INITIAL_DAILY_REWARDS[dayIndex];
		if (!reward) return;
		sounds.playVictory();
		confetti({
			particleCount: 80,
			spread: 70,
			origin: { y: .6 }
		});
		setUser((prev) => {
			const nextStreak = prev.dailyStreak % 7 + 1;
			const updatedSkins = [...prev.inventorySkins];
			if (reward.specialSkin && !updatedSkins.includes(reward.specialSkin)) {
				updatedSkins.push(reward.specialSkin);
			}
			return {
				...prev,
				coins: prev.coins + reward.coins,
				gems: prev.gems + reward.gems,
				dailyStreak: nextStreak,
				lastDailyClaim: new Date().toISOString(),
				inventorySkins: updatedSkins
			};
		});
		setClaimedToday(true);
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm p-4",
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: "bg-slate-900 border-2 border-amber-500/50 rounded-3xl p-6 max-w-xl w-full shadow-2xl text-slate-100 relative animate-in fade-in zoom-in-95 duration-200",
			children: [
				/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center justify-between pb-4 border-b border-slate-800",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center space-x-3",
						children: [/* @__PURE__ */ _jsxDEV("span", {
							className: "text-3xl",
							children: "🎁"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 60,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h2", {
							className: "text-xl font-black text-amber-400",
							children: "Ежедневные Награды за Вход"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 62,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("p", {
							className: "text-xs text-slate-400",
							children: "Заходите каждый день и получайте горы монет, кристаллов и скинов!"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 63,
							columnNumber: 15
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 61,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 59,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("button", {
						onClick: onClose,
						className: "w-8 h-8 rounded-full bg-slate-800 hover:bg-slate-700 flex items-center justify-center text-slate-400 hover:text-white",
						children: "✕"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 68,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 58,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "my-4 p-3 bg-amber-950/40 border border-amber-600/30 rounded-2xl flex items-center justify-between",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "flex items-center space-x-2",
						children: [/* @__PURE__ */ _jsxDEV("span", {
							className: "text-2xl",
							children: "🔥"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 79,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
							className: "text-xs text-slate-400 font-bold uppercase",
							children: "Ваша серия входов:"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 81,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "text-lg font-black text-amber-300",
							children: [currentStreak, " дня подряд"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 82,
							columnNumber: 15
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 80,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 78,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "text-right text-xs text-slate-400 font-mono",
						children: ["Обновление через: ", /* @__PURE__ */ _jsxDEV("b", {
							className: "text-slate-200",
							children: "14ч 32м"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 86,
							columnNumber: 31
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 85,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 77,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "grid grid-cols-2 sm:grid-cols-4 gap-3 my-4",
					children: INITIAL_DAILY_REWARDS.map((item, idx) => {
						const isToday = idx === (currentStreak - 1) % 7;
						const isClaimedPast = idx < (currentStreak - 1) % 7;
						const isSuperPrize = idx === 6;
						return /* @__PURE__ */ _jsxDEV("div", {
							className: `relative p-3 rounded-2xl border-2 flex flex-col items-center justify-between text-center transition-all ${isToday ? "bg-amber-500/20 border-amber-400 shadow-lg shadow-amber-500/20 scale-105" : isClaimedPast ? "bg-slate-950/80 border-slate-800 opacity-60" : "bg-slate-800/60 border-slate-700"} ${isSuperPrize ? "col-span-2 sm:col-span-2 bg-gradient-to-br from-purple-950/40 to-amber-950/40 border-amber-400" : ""}`,
							children: [
								/* @__PURE__ */ _jsxDEV("span", {
									className: "text-[11px] font-bold text-slate-400 uppercase",
									children: item.label
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 109,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "my-2 flex flex-col items-center",
									children: [
										isSuperPrize ? /* @__PURE__ */ _jsxDEV("div", {
											className: "relative w-12 h-12 rounded-xl overflow-hidden border border-amber-400 mb-1",
											children: [/* @__PURE__ */ _jsxDEV("img", {
												src: CAT_IMAGE_URL,
												alt: "Prize",
												className: "w-full h-full object-cover"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 117,
												columnNumber: 23
											}, this), /* @__PURE__ */ _jsxDEV("span", {
												className: "absolute bottom-0 right-0 text-[10px]",
												children: "👑"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 118,
												columnNumber: 23
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 116,
											columnNumber: 21
										}, this) : /* @__PURE__ */ _jsxDEV("span", {
											className: "text-2xl mb-1",
											children: item.icon
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 121,
											columnNumber: 21
										}, this),
										/* @__PURE__ */ _jsxDEV("span", {
											className: "font-black text-xs text-amber-300",
											children: [
												"+",
												item.coins,
												" 🪙"
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 123,
											columnNumber: 19
										}, this),
										/* @__PURE__ */ _jsxDEV("span", {
											className: "font-bold text-xs text-cyan-400",
											children: [
												"+",
												item.gems,
												" 💎"
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 124,
											columnNumber: 19
										}, this),
										item.specialSkin && /* @__PURE__ */ _jsxDEV("span", {
											className: "text-[10px] text-purple-300 font-bold mt-0.5",
											children: "+Скин Неон!"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 126,
											columnNumber: 21
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 114,
									columnNumber: 17
								}, this),
								isClaimedPast ? /* @__PURE__ */ _jsxDEV("span", {
									className: "text-[10px] font-bold text-slate-500",
									children: "✓ Забрано"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 134,
									columnNumber: 19
								}, this) : isToday ? /* @__PURE__ */ _jsxDEV("button", {
									onClick: () => handleClaim(idx),
									disabled: claimedToday,
									className: `w-full py-1.5 rounded-xl text-xs font-black transition-all ${claimedToday ? "bg-slate-700 text-slate-400 cursor-not-allowed" : "bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-slate-950 shadow-md cursor-pointer active:scale-95"}`,
									children: claimedToday ? "Получено!" : "Забрать!"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 136,
									columnNumber: 19
								}, this) : /* @__PURE__ */ _jsxDEV("span", {
									className: "text-[10px] font-bold text-slate-500",
									children: "Заблокировано"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 148,
									columnNumber: 19
								}, this)
							]
						}, item.day, true, {
							fileName: _jsxFileName,
							lineNumber: 98,
							columnNumber: 15
						}, this);
					})
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 91,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "mt-4 text-center",
					children: /* @__PURE__ */ _jsxDEV("button", {
						onClick: onClose,
						className: "px-6 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-bold",
						children: "Закрыть окно"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 157,
						columnNumber: 11
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 156,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 56,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 55,
		columnNumber: 5
	}, this);
};

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLGdCQUFnQjtBQUNoQyxPQUFPLGNBQWM7QUFFckIsU0FBUyx1QkFBdUIscUJBQXFCO0FBQ3JELFNBQVMsY0FBYzs7O0FBUXZCLE9BQU8sTUFBTSxxQkFBdUQsRUFDbEUsTUFDQSxTQUNBLGNBQ0k7Q0FDSixNQUFNLENBQUMsY0FBYyxtQkFBbUIsU0FBUyxLQUFLO0NBQ3RELE1BQU0sZ0JBQWdCLEtBQUs7Q0FFM0IsTUFBTSxlQUFlLGFBQXFCO0VBQ3hDLElBQUksY0FBYztFQUVsQixNQUFNLFNBQVMsc0JBQXNCO0VBQ3JDLElBQUksQ0FBQyxRQUFRO0VBRWIsT0FBTyxZQUFZO0VBQ25CLFNBQVM7R0FDUCxlQUFlO0dBQ2YsUUFBUTtHQUNSLFFBQVEsRUFBRSxHQUFHLEdBQUk7RUFDbkIsQ0FBQztFQUVELFNBQVMsU0FBUztHQUNoQixNQUFNLGFBQWMsS0FBSyxjQUFjLElBQUs7R0FDNUMsTUFBTSxlQUFlLENBQUMsR0FBRyxLQUFLLGNBQWM7R0FDNUMsSUFBSSxPQUFPLGVBQWUsQ0FBQyxhQUFhLFNBQVMsT0FBTyxXQUFXLEdBQUc7SUFDcEUsYUFBYSxLQUFLLE9BQU8sV0FBVztHQUN0QztHQUVBLE9BQU87SUFDTCxHQUFHO0lBQ0gsT0FBTyxLQUFLLFFBQVEsT0FBTztJQUMzQixNQUFNLEtBQUssT0FBTyxPQUFPO0lBQ3pCLGFBQWE7SUFDYixnQkFBZ0IsSUFBSSxLQUFLLENBQUMsQ0FBQyxZQUFZO0lBQ3ZDLGdCQUFnQjtHQUNsQjtFQUNGLENBQUM7RUFFRCxnQkFBZ0IsSUFBSTtDQUN0QjtDQUVBLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFDYix3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFmO0lBRUUsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsUUFBRDtPQUFNLFdBQVU7aUJBQVc7TUFBUTs7OztnQkFDbkMsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLE1BQUQ7T0FBSSxXQUFVO2lCQUFvQztNQUE4Qjs7OztnQkFDaEYsd0JBQUMsS0FBRDtPQUFHLFdBQVU7aUJBQXlCO01BRW5DOzs7O2NBQ0E7Ozs7Y0FDRjs7Ozs7ZUFDTCx3QkFBQyxVQUFEO01BQ0UsU0FBUztNQUNULFdBQVU7Z0JBQ1g7S0FFTzs7OzthQUNMOzs7Ozs7SUFHTCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxRQUFEO09BQU0sV0FBVTtpQkFBVztNQUFROzs7O2dCQUNuQyx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsUUFBRDtPQUFNLFdBQVU7aUJBQTZDO01BQXdCOzs7O2dCQUNyRix3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUFvRCxlQUFjLGFBQWdCOzs7OztjQUMvRTs7OztjQUNGOzs7OztlQUNMLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQTZELHNCQUN6Qyx3QkFBQyxLQUFEO09BQUcsV0FBVTtpQkFBaUI7TUFBVTs7OztjQUN2RDs7Ozs7YUFDRjs7Ozs7O0lBR0wsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFDWixzQkFBc0IsS0FBSyxNQUFNLFFBQVE7TUFDeEMsTUFBTSxVQUFVLFNBQVMsZ0JBQWdCLEtBQUs7TUFDOUMsTUFBTSxnQkFBZ0IsT0FBTyxnQkFBZ0IsS0FBSztNQUNsRCxNQUFNLGVBQWUsUUFBUTtNQUU3QixPQUNFLHdCQUFDLE9BQUQ7T0FFRSxXQUFXLDJHQUNULFVBQ0ksNkVBQ0EsZ0JBQ0EsZ0RBQ0EsbUNBQ0wsR0FBRyxlQUFlLG1HQUFtRztpQkFSeEg7UUFXRSx3QkFBQyxRQUFEO1NBQU0sV0FBVTttQkFDYixLQUFLO1FBQ0Y7Ozs7O1FBR04sd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWY7VUFDRyxlQUNDLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUFmLENBQ0Usd0JBQUMsT0FBRDtZQUFLLEtBQUs7WUFBZSxLQUFJO1lBQVEsV0FBVTtXQUE4Qjs7OztxQkFDN0Usd0JBQUMsUUFBRDtZQUFNLFdBQVU7c0JBQXdDO1dBQVE7Ozs7bUJBQzdEOzs7OztxQkFFTCx3QkFBQyxRQUFEO1dBQU0sV0FBVTtxQkFBaUIsS0FBSztVQUFXOzs7OztVQUVuRCx3QkFBQyxRQUFEO1dBQU0sV0FBVTtxQkFBaEI7WUFBb0Q7WUFBRSxLQUFLO1lBQU07V0FBUzs7Ozs7O1VBQzFFLHdCQUFDLFFBQUQ7V0FBTSxXQUFVO3FCQUFoQjtZQUFrRDtZQUFFLEtBQUs7WUFBSztXQUFTOzs7Ozs7VUFDdEUsS0FBSyxlQUNKLHdCQUFDLFFBQUQ7V0FBTSxXQUFVO3FCQUErQztVQUV6RDs7Ozs7U0FFTDs7Ozs7O1FBR0osZ0JBQ0Msd0JBQUMsUUFBRDtTQUFNLFdBQVU7bUJBQXVDO1FBQWU7Ozs7bUJBQ3BFLFVBQ0Ysd0JBQUMsVUFBRDtTQUNFLGVBQWUsWUFBWSxHQUFHO1NBQzlCLFVBQVU7U0FDVixXQUFXLDhEQUNULGVBQ0ksbURBQ0E7bUJBR0wsZUFBZSxjQUFjO1FBQ3hCOzs7O21CQUVSLHdCQUFDLFFBQUQ7U0FBTSxXQUFVO21CQUF1QztRQUFtQjs7Ozs7T0FFekU7U0FuREUsS0FBSzs7OzthQW1EUDtLQUVULENBQUM7SUFDRTs7Ozs7SUFHTCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUNiLHdCQUFDLFVBQUQ7TUFDRSxTQUFTO01BQ1QsV0FBVTtnQkFDWDtLQUVPOzs7OztJQUNMOzs7OztHQUNGOzs7Ozs7Q0FDRjs7Ozs7QUFFVCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJEYWlseVJld2FyZHNNb2RhbC50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IGNvbmZldHRpIGZyb20gJ2NhbnZhcy1jb25mZXR0aSc7XG5pbXBvcnQgeyBVc2VyUHJvZmlsZSB9IGZyb20gJy4uL3R5cGVzL2dhbWUnO1xuaW1wb3J0IHsgSU5JVElBTF9EQUlMWV9SRVdBUkRTLCBDQVRfSU1BR0VfVVJMIH0gZnJvbSAnLi4vZGF0YS9jb25zdGFudHMnO1xuaW1wb3J0IHsgc291bmRzIH0gZnJvbSAnLi4vdXRpbHMvc291bmQnO1xuXG5pbnRlcmZhY2UgRGFpbHlSZXdhcmRzTW9kYWxQcm9wcyB7XG4gIHVzZXI6IFVzZXJQcm9maWxlO1xuICBzZXRVc2VyOiBSZWFjdC5EaXNwYXRjaDxSZWFjdC5TZXRTdGF0ZUFjdGlvbjxVc2VyUHJvZmlsZT4+O1xuICBvbkNsb3NlOiAoKSA9PiB2b2lkO1xufVxuXG5leHBvcnQgY29uc3QgRGFpbHlSZXdhcmRzTW9kYWw6IFJlYWN0LkZDPERhaWx5UmV3YXJkc01vZGFsUHJvcHM+ID0gKHtcbiAgdXNlcixcbiAgc2V0VXNlcixcbiAgb25DbG9zZSxcbn0pID0+IHtcbiAgY29uc3QgW2NsYWltZWRUb2RheSwgc2V0Q2xhaW1lZFRvZGF5XSA9IHVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3QgY3VycmVudFN0cmVhayA9IHVzZXIuZGFpbHlTdHJlYWs7XG5cbiAgY29uc3QgaGFuZGxlQ2xhaW0gPSAoZGF5SW5kZXg6IG51bWJlcikgPT4ge1xuICAgIGlmIChjbGFpbWVkVG9kYXkpIHJldHVybjtcblxuICAgIGNvbnN0IHJld2FyZCA9IElOSVRJQUxfREFJTFlfUkVXQVJEU1tkYXlJbmRleF07XG4gICAgaWYgKCFyZXdhcmQpIHJldHVybjtcblxuICAgIHNvdW5kcy5wbGF5VmljdG9yeSgpO1xuICAgIGNvbmZldHRpKHtcbiAgICAgIHBhcnRpY2xlQ291bnQ6IDgwLFxuICAgICAgc3ByZWFkOiA3MCxcbiAgICAgIG9yaWdpbjogeyB5OiAwLjYgfSxcbiAgICB9KTtcblxuICAgIHNldFVzZXIoKHByZXYpID0+IHtcbiAgICAgIGNvbnN0IG5leHRTdHJlYWsgPSAocHJldi5kYWlseVN0cmVhayAlIDcpICsgMTtcbiAgICAgIGNvbnN0IHVwZGF0ZWRTa2lucyA9IFsuLi5wcmV2LmludmVudG9yeVNraW5zXTtcbiAgICAgIGlmIChyZXdhcmQuc3BlY2lhbFNraW4gJiYgIXVwZGF0ZWRTa2lucy5pbmNsdWRlcyhyZXdhcmQuc3BlY2lhbFNraW4pKSB7XG4gICAgICAgIHVwZGF0ZWRTa2lucy5wdXNoKHJld2FyZC5zcGVjaWFsU2tpbik7XG4gICAgICB9XG5cbiAgICAgIHJldHVybiB7XG4gICAgICAgIC4uLnByZXYsXG4gICAgICAgIGNvaW5zOiBwcmV2LmNvaW5zICsgcmV3YXJkLmNvaW5zLFxuICAgICAgICBnZW1zOiBwcmV2LmdlbXMgKyByZXdhcmQuZ2VtcyxcbiAgICAgICAgZGFpbHlTdHJlYWs6IG5leHRTdHJlYWssXG4gICAgICAgIGxhc3REYWlseUNsYWltOiBuZXcgRGF0ZSgpLnRvSVNPU3RyaW5nKCksXG4gICAgICAgIGludmVudG9yeVNraW5zOiB1cGRhdGVkU2tpbnMsXG4gICAgICB9O1xuICAgIH0pO1xuXG4gICAgc2V0Q2xhaW1lZFRvZGF5KHRydWUpO1xuICB9O1xuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJmaXhlZCBpbnNldC0wIHotNTAgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgYmctc2xhdGUtOTUwLzgwIGJhY2tkcm9wLWJsdXItc20gcC00XCI+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXNsYXRlLTkwMCBib3JkZXItMiBib3JkZXItYW1iZXItNTAwLzUwIHJvdW5kZWQtM3hsIHAtNiBtYXgtdy14bCB3LWZ1bGwgc2hhZG93LTJ4bCB0ZXh0LXNsYXRlLTEwMCByZWxhdGl2ZSBhbmltYXRlLWluIGZhZGUtaW4gem9vbS1pbi05NSBkdXJhdGlvbi0yMDBcIj5cbiAgICAgICAgey8qIEhlYWRlciAqL31cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gcGItNCBib3JkZXItYiBib3JkZXItc2xhdGUtODAwXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBzcGFjZS14LTNcIj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtM3hsXCI+8J+OgTwvc3Bhbj5cbiAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtYmxhY2sgdGV4dC1hbWJlci00MDBcIj7QldC20LXQtNC90LXQstC90YvQtSDQndCw0LPRgNCw0LTRiyDQt9CwINCS0YXQvtC0PC9oMj5cbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXNsYXRlLTQwMFwiPlxuICAgICAgICAgICAgICAgINCX0LDRhdC+0LTQuNGC0LUg0LrQsNC20LTRi9C5INC00LXQvdGMINC4INC/0L7Qu9GD0YfQsNC50YLQtSDQs9C+0YDRiyDQvNC+0L3QtdGCLCDQutGA0LjRgdGC0LDQu9C70L7QsiDQuCDRgdC60LjQvdC+0LIhXG4gICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgIG9uQ2xpY2s9e29uQ2xvc2V9XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJ3LTggaC04IHJvdW5kZWQtZnVsbCBiZy1zbGF0ZS04MDAgaG92ZXI6Ymctc2xhdGUtNzAwIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHRleHQtc2xhdGUtNDAwIGhvdmVyOnRleHQtd2hpdGVcIlxuICAgICAgICAgID5cbiAgICAgICAgICAgIOKclVxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICB7LyogU3RyZWFrIENvdW50ZXIgKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXktNCBwLTMgYmctYW1iZXItOTUwLzQwIGJvcmRlciBib3JkZXItYW1iZXItNjAwLzMwIHJvdW5kZWQtMnhsIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlblwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgc3BhY2UteC0yXCI+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LTJ4bFwiPvCflKU8L3NwYW4+XG4gICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtc2xhdGUtNDAwIGZvbnQtYm9sZCB1cHBlcmNhc2VcIj7QktCw0YjQsCDRgdC10YDQuNGPINCy0YXQvtC00L7Qsjo8L3NwYW4+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LWJsYWNrIHRleHQtYW1iZXItMzAwXCI+e2N1cnJlbnRTdHJlYWt9INC00L3RjyDQv9C+0LTRgNGP0LQ8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1yaWdodCB0ZXh0LXhzIHRleHQtc2xhdGUtNDAwIGZvbnQtbW9ub1wiPlxuICAgICAgICAgICAg0J7QsdC90L7QstC70LXQvdC40LUg0YfQtdGA0LXQtzogPGIgY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS0yMDBcIj4xNNGHIDMy0Lw8L2I+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIHsvKiA3LURheSBSZXdhcmRzIEdyaWQgKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMiBzbTpncmlkLWNvbHMtNCBnYXAtMyBteS00XCI+XG4gICAgICAgICAge0lOSVRJQUxfREFJTFlfUkVXQVJEUy5tYXAoKGl0ZW0sIGlkeCkgPT4ge1xuICAgICAgICAgICAgY29uc3QgaXNUb2RheSA9IGlkeCA9PT0gKGN1cnJlbnRTdHJlYWsgLSAxKSAlIDc7XG4gICAgICAgICAgICBjb25zdCBpc0NsYWltZWRQYXN0ID0gaWR4IDwgKGN1cnJlbnRTdHJlYWsgLSAxKSAlIDc7XG4gICAgICAgICAgICBjb25zdCBpc1N1cGVyUHJpemUgPSBpZHggPT09IDY7XG5cbiAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgICAgICBrZXk9e2l0ZW0uZGF5fVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHJlbGF0aXZlIHAtMyByb3VuZGVkLTJ4bCBib3JkZXItMiBmbGV4IGZsZXgtY29sIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gdGV4dC1jZW50ZXIgdHJhbnNpdGlvbi1hbGwgJHtcbiAgICAgICAgICAgICAgICAgIGlzVG9kYXlcbiAgICAgICAgICAgICAgICAgICAgPyAnYmctYW1iZXItNTAwLzIwIGJvcmRlci1hbWJlci00MDAgc2hhZG93LWxnIHNoYWRvdy1hbWJlci01MDAvMjAgc2NhbGUtMTA1J1xuICAgICAgICAgICAgICAgICAgICA6IGlzQ2xhaW1lZFBhc3RcbiAgICAgICAgICAgICAgICAgICAgPyAnYmctc2xhdGUtOTUwLzgwIGJvcmRlci1zbGF0ZS04MDAgb3BhY2l0eS02MCdcbiAgICAgICAgICAgICAgICAgICAgOiAnYmctc2xhdGUtODAwLzYwIGJvcmRlci1zbGF0ZS03MDAnXG4gICAgICAgICAgICAgICAgfSAke2lzU3VwZXJQcml6ZSA/ICdjb2wtc3Bhbi0yIHNtOmNvbC1zcGFuLTIgYmctZ3JhZGllbnQtdG8tYnIgZnJvbS1wdXJwbGUtOTUwLzQwIHRvLWFtYmVyLTk1MC80MCBib3JkZXItYW1iZXItNDAwJyA6ICcnfWB9XG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICB7LyogRGF5IFRhZyAqL31cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMXB4XSBmb250LWJvbGQgdGV4dC1zbGF0ZS00MDAgdXBwZXJjYXNlXCI+XG4gICAgICAgICAgICAgICAgICB7aXRlbS5sYWJlbH1cbiAgICAgICAgICAgICAgICA8L3NwYW4+XG5cbiAgICAgICAgICAgICAgICB7LyogUmV3YXJkIFZpc3VhbCAqL31cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm15LTIgZmxleCBmbGV4LWNvbCBpdGVtcy1jZW50ZXJcIj5cbiAgICAgICAgICAgICAgICAgIHtpc1N1cGVyUHJpemUgPyAoXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgdy0xMiBoLTEyIHJvdW5kZWQteGwgb3ZlcmZsb3ctaGlkZGVuIGJvcmRlciBib3JkZXItYW1iZXItNDAwIG1iLTFcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8aW1nIHNyYz17Q0FUX0lNQUdFX1VSTH0gYWx0PVwiUHJpemVcIiBjbGFzc05hbWU9XCJ3LWZ1bGwgaC1mdWxsIG9iamVjdC1jb3ZlclwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiYWJzb2x1dGUgYm90dG9tLTAgcmlnaHQtMCB0ZXh0LVsxMHB4XVwiPvCfkZE8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC0yeGwgbWItMVwiPntpdGVtLmljb259PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtYmxhY2sgdGV4dC14cyB0ZXh0LWFtYmVyLTMwMFwiPit7aXRlbS5jb2luc30g8J+qmTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LXhzIHRleHQtY3lhbi00MDBcIj4re2l0ZW0uZ2Vtc30g8J+Sjjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIHtpdGVtLnNwZWNpYWxTa2luICYmIChcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gdGV4dC1wdXJwbGUtMzAwIGZvbnQtYm9sZCBtdC0wLjVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAr0KHQutC40L0g0J3QtdC+0L0hXG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICB7LyogQ2xhaW0gc3RhdGUgLyBidXR0b24gKi99XG4gICAgICAgICAgICAgICAge2lzQ2xhaW1lZFBhc3QgPyAoXG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LVsxMHB4XSBmb250LWJvbGQgdGV4dC1zbGF0ZS01MDBcIj7inJMg0JfQsNCx0YDQsNC90L48L3NwYW4+XG4gICAgICAgICAgICAgICAgKSA6IGlzVG9kYXkgPyAoXG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZUNsYWltKGlkeCl9XG4gICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtjbGFpbWVkVG9kYXl9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17YHctZnVsbCBweS0xLjUgcm91bmRlZC14bCB0ZXh0LXhzIGZvbnQtYmxhY2sgdHJhbnNpdGlvbi1hbGwgJHtcbiAgICAgICAgICAgICAgICAgICAgICBjbGFpbWVkVG9kYXlcbiAgICAgICAgICAgICAgICAgICAgICAgID8gJ2JnLXNsYXRlLTcwMCB0ZXh0LXNsYXRlLTQwMCBjdXJzb3Itbm90LWFsbG93ZWQnXG4gICAgICAgICAgICAgICAgICAgICAgICA6ICdiZy1ncmFkaWVudC10by1yIGZyb20tYW1iZXItNDAwIHRvLWFtYmVyLTUwMCBob3Zlcjpmcm9tLWFtYmVyLTMwMCBob3Zlcjp0by1hbWJlci00MDAgdGV4dC1zbGF0ZS05NTAgc2hhZG93LW1kIGN1cnNvci1wb2ludGVyIGFjdGl2ZTpzY2FsZS05NSdcbiAgICAgICAgICAgICAgICAgICAgfWB9XG4gICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIHtjbGFpbWVkVG9kYXkgPyAn0J/QvtC70YPRh9C10L3QviEnIDogJ9CX0LDQsdGA0LDRgtGMISd9XG4gICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1bMTBweF0gZm9udC1ib2xkIHRleHQtc2xhdGUtNTAwXCI+0JfQsNCx0LvQvtC60LjRgNC+0LLQsNC90L48L3NwYW4+XG4gICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICApO1xuICAgICAgICAgIH0pfVxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICB7LyogRm9vdGVyIGluZm8gKi99XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNCB0ZXh0LWNlbnRlclwiPlxuICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgIG9uQ2xpY2s9e29uQ2xvc2V9XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJweC02IHB5LTIgYmctc2xhdGUtODAwIGhvdmVyOmJnLXNsYXRlLTcwMCB0ZXh0LXNsYXRlLTMwMCByb3VuZGVkLXhsIHRleHQteHMgZm9udC1ib2xkXCJcbiAgICAgICAgICA+XG4gICAgICAgICAgICDQl9Cw0LrRgNGL0YLRjCDQvtC60L3QvlxuICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICApO1xufTtcbiJdfQ==