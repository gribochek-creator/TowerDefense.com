const React = __vite__cjsImport0_react; const useState = __vite__cjsImport0_react["useState"]; const useEffect = __vite__cjsImport0_react["useEffect"]; const useCallback = __vite__cjsImport0_react["useCallback"];const _jsxDEV = __vite__cjsImport20_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=1e19e0c2";
import { loadUserProfile, saveUserProfile, loadOrders, saveOrders, loadClans, saveClans, loadClanChat, saveClanChat, loadLeaderboard, loadAchievements, saveAchievements, loadNotifications, saveNotifications } from "/src/utils/storage.ts";
import { Navbar } from "/src/components/Navbar.tsx";
import { GameCanvas } from "/src/components/GameCanvas.tsx";
import { TowerDock } from "/src/components/TowerDock.tsx";
import { TowerControls } from "/src/components/TowerControls.tsx";
import { DailyRewardsModal } from "/src/components/DailyRewardsModal.tsx";
import { ShopModal } from "/src/components/ShopModal.tsx";
import { ClansModal } from "/src/components/ClansModal.tsx";
import { WeeklyChallengesModal } from "/src/components/WeeklyChallengesModal.tsx";
import { CoopLobbyModal } from "/src/components/CoopLobbyModal.tsx";
import { LeaderboardModal } from "/src/components/LeaderboardModal.tsx";
import { AchievementsModal } from "/src/components/AchievementsModal.tsx";
import { ProfileModal } from "/src/components/ProfileModal.tsx";
import { NotificationsModal } from "/src/components/NotificationsModal.tsx";
import { GameOverModal } from "/src/components/GameOverModal.tsx";
import { SecretHintModal } from "/src/components/SecretHintModal.tsx";
import { SecretUnlockedModal } from "/src/components/SecretUnlockedModal.tsx";
import { NetlifyDownloadModal } from "/src/components/NetlifyDownloadModal.tsx";
import { TOWERS_DATA } from "/src/data/constants.ts";
var _jsxFileName = "/app/applet/src/App.tsx";
import __vite__cjsImport20_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=1e19e0c2";
export default function App() {
	// User Profile & Storage State
	const [user, setUser] = useState(loadUserProfile);
	const [orders, setOrders] = useState(loadOrders);
	const [clans, setClans] = useState(loadClans);
	const [clanChat, setClanChat] = useState(loadClanChat);
	const [leaderboard, setLeaderboard] = useState(loadLeaderboard);
	const [achievements, setAchievements] = useState(loadAchievements);
	const [notifications, setNotifications] = useState(loadNotifications);
	// Game Engine State
	const [difficulty, setDifficulty] = useState("normal");
	const [inGameCash, setInGameCash] = useState(750);
	const [placedTowers, setPlacedTowers] = useState([]);
	const [selectedTowerToPlace, setSelectedTowerToPlace] = useState(null);
	const [selectedPlacedTower, setSelectedPlacedTower] = useState(null);
	// Easter Egg 'го KEKC'
	const [showSecretHintModal, setShowSecretHintModal] = useState(false);
	const [showSecretUnlockedModal, setShowSecretUnlockedModal] = useState(false);
	const [isSecretKekcUnlocked, setIsSecretKekcUnlocked] = useState(false);
	// Netlify Download Modal
	const [showNetlifyModal, setShowNetlifyModal] = useState(false);
	// Waves
	const [wave, setWave] = useState(0);
	const maxWaves = difficulty === "easy" ? 15 : difficulty === "normal" ? 25 : difficulty === "hard" ? 35 : 40;
	const [gameSpeed, setGameSpeed] = useState(1);
	const [isPaused, setIsPaused] = useState(false);
	const [gameActive, setGameActive] = useState(true);
	const [upgradeTrigger, setUpgradeTrigger] = useState(0);
	// Co-op Mode State
	const [isCoop, setIsCoop] = useState(false);
	const [coopRoomCode, setCoopRoomCode] = useState(null);
	const [coopMessages, setCoopMessages] = useState(["Напарник присоединился к сессии!", "Готов к обороне базы!"]);
	// Weekly Challenge Active Modifiers
	const [restrictedTowers, setRestrictedTowers] = useState(undefined);
	// Active Open Modal
	const [activeModal, setActiveModal] = useState(null);
	// Game Over / Victory Modal
	const [gameOverResult, setGameOverResult] = useState(null);
	// Auto-save changes to localStorage
	useEffect(() => {
		saveUserProfile(user);
	}, [user]);
	useEffect(() => {
		saveOrders(orders);
	}, [orders]);
	useEffect(() => {
		saveClans(clans);
	}, [clans]);
	useEffect(() => {
		saveClanChat(clanChat);
	}, [clanChat]);
	useEffect(() => {
		saveAchievements(achievements);
	}, [achievements]);
	useEffect(() => {
		saveNotifications(notifications);
	}, [notifications]);
	// Handle Starting Cash based on difficulty (Buffed for smoother gameplay!)
	const resetGame = useCallback((diff = difficulty) => {
		const startingCash = diff === "easy" ? 950 : diff === "normal" ? 750 : diff === "hard" ? 550 : 400;
		setInGameCash(startingCash);
		setWave(0);
		setPlacedTowers([]);
		setSelectedTowerToPlace(null);
		setSelectedPlacedTower(null);
		setGameOverResult(null);
		setGameActive(true);
		setIsPaused(false);
	}, [difficulty]);
	// Trigger secret easter egg 'го KEKC'
	const handleTriggerSecretKekc = () => {
		if (!isSecretKekcUnlocked) {
			setUser((prev) => ({
				...prev,
				coins: prev.coins + 1500,
				gems: prev.gems + 150,
				title: "👑 Повелитель КЕКСА"
			}));
			setNotifications((prev) => [{
				id: "notif_kekc_" + Date.now(),
				title: "🎉 Секретка «го KEKC» Активирована!",
				message: "Вы разгадали пасхалку Роблокса! Начислено +1,500 🪙 и +150 💎, а также титул «Повелитель КЕКСА».",
				type: "reward",
				timestamp: "Только что",
				read: false,
				badge: "SECRET"
			}, ...prev]);
			setIsSecretKekcUnlocked(true);
		}
		setShowSecretUnlockedModal(true);
	};
	const handleDifficultyChange = (diff) => {
		setDifficulty(diff);
		resetGame(diff);
	};
	// Achievement tracker helper
	const updateAchievementProgress = (achId, delta = 1) => {
		setAchievements((prev) => prev.map((a) => {
			if (a.id === achId && !a.claimed) {
				const updated = Math.min(a.maxProgress, a.progress + delta);
				return {
					...a,
					progress: updated
				};
			}
			return a;
		}));
	};
	// Tower Placed Callback
	const handleTowerPlacedSuccess = (towerId) => {
		if (towerId === "cat") {
			updateAchievementProgress("first_cat", 1);
		}
	};
	// Tower Upgraded Callback
	const handleTowerUpgradedSuccess = (towerId, newLevel) => {
		if (towerId === "cat") {
			if (newLevel >= 1) {
				updateAchievementProgress("cat_level_1", 1);
			}
			if (newLevel >= 3) {
				updateAchievementProgress("cat_max_slow", 1);
			}
		}
		setUpgradeTrigger((p) => p + 1);
	};
	// Game Over Handler
	const handleGameOver = (wavesCompleted, score, victory) => {
		setGameActive(false);
		setGameOverResult({
			victory,
			wavesCompleted,
			score
		});
		// Rewards
		const coinsReward = wavesCompleted * 120 + (victory ? 1e3 : 0);
		const gemsReward = Math.floor(wavesCompleted * 3.5) + (victory ? 50 : 0);
		setUser((prev) => ({
			...prev,
			coins: prev.coins + coinsReward,
			gems: prev.gems + gemsReward,
			xp: prev.xp + wavesCompleted * 40
		}));
		if (wavesCompleted >= 15) {
			updateAchievementProgress("waves_15", wavesCompleted);
		}
		if (victory && isCoop) {
			updateAchievementProgress("coop_victory", 1);
		}
	};
	// Co-op Ping Dispatcher
	const handleSendCoopPing = (msg) => {
		setCoopMessages((prev) => [...prev.slice(-6), msg]);
	};
	// Upgrade selected tower from Controls
	const handleUpgradePlacedTower = (tower) => {
		const def = TOWERS_DATA.find((t) => t.id === tower.towerId);
		if (!def) return;
		const nextLvl = tower.level + 1;
		if (nextLvl < def.levels.length) {
			const cost = def.levels[nextLvl].cost;
			tower.level = nextLvl;
			tower.totalInvested += cost;
			handleTowerUpgradedSuccess(tower.towerId, nextLvl);
		}
	};
	// Sell selected tower
	const handleSellPlacedTower = (tower) => {
		setPlacedTowers((prev) => prev.filter((t) => t.instanceId !== tower.instanceId));
		setSelectedPlacedTower(null);
	};
	// Target mode change
	const handleChangeTargetMode = (mode) => {
		if (!selectedPlacedTower) return;
		selectedPlacedTower.targetMode = mode;
		setUpgradeTrigger((p) => p + 1);
	};
	const unreadNotifs = notifications.filter((n) => !n.read).length;
	return /* @__PURE__ */ _jsxDEV("div", {
		className: `min-h-screen ${user.theme === "cyber" ? "bg-slate-950 text-cyan-50" : "bg-slate-950 text-slate-100"} flex flex-col font-sans select-none antialiased`,
		children: [
			/* @__PURE__ */ _jsxDEV(Navbar, {
				user,
				difficulty,
				onChangeDifficulty: handleDifficultyChange,
				inGameCash,
				unreadNotifsCount: unreadNotifs,
				onOpenModal: (m) => setActiveModal(m),
				onResetGame: () => resetGame(),
				onOpenSecretHint: () => setShowSecretHintModal(true),
				onTriggerSecretKekc: handleTriggerSecretKekc,
				onOpenNetlifyDownload: () => setShowNetlifyModal(true)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 269,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("main", {
				className: "flex-1 max-w-7xl w-full mx-auto p-4 flex flex-col gap-4",
				children: [
					restrictedTowers && /* @__PURE__ */ _jsxDEV("div", {
						className: "p-3 bg-purple-950/80 border border-purple-500 rounded-2xl flex items-center justify-between text-xs",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center space-x-2",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "text-xl",
								children: "⚔️"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 288,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "font-black text-purple-300 uppercase",
								children: "Испытание Недели:"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 290,
								columnNumber: 17
							}, this), /* @__PURE__ */ _jsxDEV("span", {
								className: "text-white ml-2",
								children: "Разрешены только кошачьи башни! Все коты имеют +25% дальности."
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 291,
								columnNumber: 17
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 289,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 287,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("button", {
							onClick: () => setRestrictedTowers(undefined),
							className: "text-purple-400 hover:text-white underline font-bold",
							children: "Сбросить ограничение"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 294,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 286,
						columnNumber: 11
					}, this),
					isCoop && /* @__PURE__ */ _jsxDEV("div", {
						className: "p-2.5 bg-cyan-950/80 border border-cyan-500 rounded-2xl flex items-center justify-between text-xs",
						children: [/* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center space-x-2",
							children: [
								/* @__PURE__ */ _jsxDEV("span", { className: "w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 307,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("span", {
									className: "font-black text-cyan-300",
									children: [
										"Кооперативный Режим (Комната: ",
										coopRoomCode || "CAT-COOP",
										")"
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 308,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("span", {
									className: "text-slate-400",
									children: "• Напарник помогает удерживать замок"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 311,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 306,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "flex items-center space-x-2",
							children: [/* @__PURE__ */ _jsxDEV("button", {
								onClick: () => handleSendCoopPing("Улучши башню на перекрестке!"),
								className: "px-2.5 py-1 bg-cyan-800 hover:bg-cyan-700 text-white rounded-lg font-bold text-[11px]",
								children: "💬 Отправить Пинг"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 314,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("button", {
								onClick: () => setIsCoop(false),
								className: "px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg font-bold text-[11px]",
								children: "Выйти из Коопа"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 320,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 313,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 305,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV(GameCanvas, {
						difficulty,
						isCoop,
						gameActive,
						onGameOver: handleGameOver,
						selectedTowerToPlace,
						onSelectPlacedTower: (tower) => setSelectedPlacedTower(tower),
						selectedPlacedTowerId: selectedPlacedTower?.instanceId || null,
						cash: inGameCash,
						setCash: setInGameCash,
						onTowerPlacedSuccess: handleTowerPlacedSuccess,
						onTowerUpgradedSuccess: handleTowerUpgradedSuccess,
						wave,
						setWave,
						maxWaves,
						gameSpeed,
						setGameSpeed,
						isPaused,
						setIsPaused,
						upgradeTrigger,
						coopMessages,
						onSendCoopPing: handleSendCoopPing,
						placedTowers,
						setPlacedTowers
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 331,
						columnNumber: 9
					}, this),
					selectedPlacedTower ? /* @__PURE__ */ _jsxDEV(TowerControls, {
						selectedTower: selectedPlacedTower,
						cash: inGameCash,
						setCash: setInGameCash,
						onClose: () => setSelectedPlacedTower(null),
						onUpgradeTower: handleUpgradePlacedTower,
						onSellTower: handleSellPlacedTower,
						onChangeTargetMode: handleChangeTargetMode
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 359,
						columnNumber: 11
					}, this) : /* @__PURE__ */ _jsxDEV(TowerDock, {
						cash: inGameCash,
						selectedTowerToPlace,
						onSelectTowerToPlace: (id) => setSelectedTowerToPlace(id),
						restrictedTowers
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 369,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 283,
				columnNumber: 7
			}, this),
			activeModal === "daily" && /* @__PURE__ */ _jsxDEV(DailyRewardsModal, {
				user,
				setUser,
				onClose: () => setActiveModal(null)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 380,
				columnNumber: 9
			}, this),
			activeModal === "shop" && /* @__PURE__ */ _jsxDEV(ShopModal, {
				user,
				setUser,
				orders,
				setOrders,
				notifications,
				setNotifications,
				onClose: () => setActiveModal(null)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 388,
				columnNumber: 9
			}, this),
			activeModal === "clans" && /* @__PURE__ */ _jsxDEV(ClansModal, {
				user,
				setUser,
				clans,
				setClans,
				chat: clanChat,
				setChat: setClanChat,
				onClose: () => setActiveModal(null),
				onTriggerSecretKekc: handleTriggerSecretKekc
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 400,
				columnNumber: 9
			}, this),
			activeModal === "weekly" && /* @__PURE__ */ _jsxDEV(WeeklyChallengesModal, {
				onStartChallenge: (restricted) => {
					setRestrictedTowers(restricted);
					resetGame("hard");
				},
				onClose: () => setActiveModal(null)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 413,
				columnNumber: 9
			}, this),
			activeModal === "coop" && /* @__PURE__ */ _jsxDEV(CoopLobbyModal, {
				isCoopActive: isCoop,
				onStartCoopGame: (roomCode) => {
					setIsCoop(true);
					setCoopRoomCode(roomCode);
					resetGame("normal");
				},
				onLeaveCoop: () => setIsCoop(false),
				onClose: () => setActiveModal(null)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 423,
				columnNumber: 9
			}, this),
			activeModal === "leaderboard" && /* @__PURE__ */ _jsxDEV(LeaderboardModal, {
				leaderboard,
				currentUsername: user.username,
				onClose: () => setActiveModal(null)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 436,
				columnNumber: 9
			}, this),
			activeModal === "achievements" && /* @__PURE__ */ _jsxDEV(AchievementsModal, {
				achievements,
				setAchievements,
				user,
				setUser,
				onClose: () => setActiveModal(null)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 444,
				columnNumber: 9
			}, this),
			activeModal === "profile" && /* @__PURE__ */ _jsxDEV(ProfileModal, {
				user,
				setUser,
				onClose: () => setActiveModal(null),
				onOpenShopOrders: () => setActiveModal("shop"),
				onOpenNetlifyDownload: () => setShowNetlifyModal(true)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 454,
				columnNumber: 9
			}, this),
			activeModal === "notifications" && /* @__PURE__ */ _jsxDEV(NotificationsModal, {
				notifications,
				setNotifications,
				onClose: () => setActiveModal(null)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 464,
				columnNumber: 9
			}, this),
			gameOverResult && /* @__PURE__ */ _jsxDEV(GameOverModal, {
				victory: gameOverResult.victory,
				wavesCompleted: gameOverResult.wavesCompleted,
				score: gameOverResult.score,
				onRestart: () => resetGame()
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 472,
				columnNumber: 9
			}, this),
			showSecretHintModal && /* @__PURE__ */ _jsxDEV(SecretHintModal, {
				onUnlockSecret: handleTriggerSecretKekc,
				isAlreadyUnlocked: isSecretKekcUnlocked,
				onClose: () => setShowSecretHintModal(false)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 482,
				columnNumber: 9
			}, this),
			showSecretUnlockedModal && /* @__PURE__ */ _jsxDEV(SecretUnlockedModal, { onClose: () => setShowSecretUnlockedModal(false) }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 491,
				columnNumber: 9
			}, this),
			showNetlifyModal && /* @__PURE__ */ _jsxDEV(NetlifyDownloadModal, { onClose: () => setShowNetlifyModal(false) }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 498,
				columnNumber: 9
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 267,
		columnNumber: 5
	}, this);
}

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxTQUFTLFVBQVUsV0FBVyxtQkFBbUI7QUFFeEQsU0FDRSxpQkFDQSxpQkFDQSxZQUNBLFlBQ0EsV0FDQSxXQUNBLGNBQ0EsY0FDQSxpQkFDQSxrQkFDQSxrQkFDQSxtQkFDQSx5QkFDSztBQUNQLFNBQVMsY0FBYztBQUN2QixTQUFTLGtCQUFrQjtBQUMzQixTQUFTLGlCQUFpQjtBQUMxQixTQUFTLHFCQUFxQjtBQUM5QixTQUFTLHlCQUF5QjtBQUNsQyxTQUFTLGlCQUFpQjtBQUMxQixTQUFTLGtCQUFrQjtBQUMzQixTQUFTLDZCQUE2QjtBQUN0QyxTQUFTLHNCQUFzQjtBQUMvQixTQUFTLHdCQUF3QjtBQUNqQyxTQUFTLHlCQUF5QjtBQUNsQyxTQUFTLG9CQUFvQjtBQUM3QixTQUFTLDBCQUEwQjtBQUNuQyxTQUFTLHFCQUFxQjtBQUM5QixTQUFTLHVCQUF1QjtBQUNoQyxTQUFTLDJCQUEyQjtBQUNwQyxTQUFTLDRCQUE0QjtBQUNyQyxTQUFTLG1CQUFtQjs7O0FBRTVCLGVBQWUsU0FBUyxNQUFNOztDQUU1QixNQUFNLENBQUMsTUFBTSxXQUFXLFNBQXNCLGVBQWU7Q0FDN0QsTUFBTSxDQUFDLFFBQVEsYUFBYSxTQUFzQixVQUFVO0NBQzVELE1BQU0sQ0FBQyxPQUFPLFlBQVksU0FBaUIsU0FBUztDQUNwRCxNQUFNLENBQUMsVUFBVSxlQUFlLFNBQTRCLFlBQVk7Q0FDeEUsTUFBTSxDQUFDLGFBQWEsa0JBQWtCLFNBQTZCLGVBQWU7Q0FDbEYsTUFBTSxDQUFDLGNBQWMsbUJBQW1CLFNBQXdCLGdCQUFnQjtDQUNoRixNQUFNLENBQUMsZUFBZSxvQkFBb0IsU0FBK0IsaUJBQWlCOztDQUcxRixNQUFNLENBQUMsWUFBWSxpQkFBaUIsU0FBcUIsUUFBUTtDQUNqRSxNQUFNLENBQUMsWUFBWSxpQkFBaUIsU0FBaUIsR0FBRztDQUN4RCxNQUFNLENBQUMsY0FBYyxtQkFBbUIsU0FBd0IsQ0FBQyxDQUFDO0NBQ2xFLE1BQU0sQ0FBQyxzQkFBc0IsMkJBQTJCLFNBQXdCLElBQUk7Q0FDcEYsTUFBTSxDQUFDLHFCQUFxQiwwQkFBMEIsU0FBNkIsSUFBSTs7Q0FHdkYsTUFBTSxDQUFDLHFCQUFxQiwwQkFBMEIsU0FBa0IsS0FBSztDQUM3RSxNQUFNLENBQUMseUJBQXlCLDhCQUE4QixTQUFrQixLQUFLO0NBQ3JGLE1BQU0sQ0FBQyxzQkFBc0IsMkJBQTJCLFNBQWtCLEtBQUs7O0NBRy9FLE1BQU0sQ0FBQyxrQkFBa0IsdUJBQXVCLFNBQWtCLEtBQUs7O0NBR3ZFLE1BQU0sQ0FBQyxNQUFNLFdBQVcsU0FBaUIsQ0FBQztDQUMxQyxNQUFNLFdBQVcsZUFBZSxTQUFTLEtBQUssZUFBZSxXQUFXLEtBQUssZUFBZSxTQUFTLEtBQUs7Q0FDMUcsTUFBTSxDQUFDLFdBQVcsZ0JBQWdCLFNBQWlCLENBQUM7Q0FDcEQsTUFBTSxDQUFDLFVBQVUsZUFBZSxTQUFrQixLQUFLO0NBQ3ZELE1BQU0sQ0FBQyxZQUFZLGlCQUFpQixTQUFrQixJQUFJO0NBQzFELE1BQU0sQ0FBQyxnQkFBZ0IscUJBQXFCLFNBQWlCLENBQUM7O0NBRzlELE1BQU0sQ0FBQyxRQUFRLGFBQWEsU0FBa0IsS0FBSztDQUNuRCxNQUFNLENBQUMsY0FBYyxtQkFBbUIsU0FBd0IsSUFBSTtDQUNwRSxNQUFNLENBQUMsY0FBYyxtQkFBbUIsU0FBbUIsQ0FDekQsb0NBQ0EsdUJBQ0YsQ0FBQzs7Q0FHRCxNQUFNLENBQUMsa0JBQWtCLHVCQUF1QixTQUErQixTQUFTOztDQUd4RixNQUFNLENBQUMsYUFBYSxrQkFBa0IsU0FXcEMsSUFBSTs7Q0FHTixNQUFNLENBQUMsZ0JBQWdCLHFCQUFxQixTQUlsQyxJQUFJOztDQUdkLGdCQUFnQjtFQUNkLGdCQUFnQixJQUFJO0NBQ3RCLEdBQUcsQ0FBQyxJQUFJLENBQUM7Q0FFVCxnQkFBZ0I7RUFDZCxXQUFXLE1BQU07Q0FDbkIsR0FBRyxDQUFDLE1BQU0sQ0FBQztDQUVYLGdCQUFnQjtFQUNkLFVBQVUsS0FBSztDQUNqQixHQUFHLENBQUMsS0FBSyxDQUFDO0NBRVYsZ0JBQWdCO0VBQ2QsYUFBYSxRQUFRO0NBQ3ZCLEdBQUcsQ0FBQyxRQUFRLENBQUM7Q0FFYixnQkFBZ0I7RUFDZCxpQkFBaUIsWUFBWTtDQUMvQixHQUFHLENBQUMsWUFBWSxDQUFDO0NBRWpCLGdCQUFnQjtFQUNkLGtCQUFrQixhQUFhO0NBQ2pDLEdBQUcsQ0FBQyxhQUFhLENBQUM7O0NBR2xCLE1BQU0sWUFBWSxhQUNmLE9BQW1CLGVBQWU7RUFDakMsTUFBTSxlQUFlLFNBQVMsU0FBUyxNQUFNLFNBQVMsV0FBVyxNQUFNLFNBQVMsU0FBUyxNQUFNO0VBQy9GLGNBQWMsWUFBWTtFQUMxQixRQUFRLENBQUM7RUFDVCxnQkFBZ0IsQ0FBQyxDQUFDO0VBQ2xCLHdCQUF3QixJQUFJO0VBQzVCLHVCQUF1QixJQUFJO0VBQzNCLGtCQUFrQixJQUFJO0VBQ3RCLGNBQWMsSUFBSTtFQUNsQixZQUFZLEtBQUs7Q0FDbkIsR0FDQSxDQUFDLFVBQVUsQ0FDYjs7Q0FHQSxNQUFNLGdDQUFnQztFQUNwQyxJQUFJLENBQUMsc0JBQXNCO0dBQ3pCLFNBQVMsVUFBVTtJQUNqQixHQUFHO0lBQ0gsT0FBTyxLQUFLLFFBQVE7SUFDcEIsTUFBTSxLQUFLLE9BQU87SUFDbEIsT0FBTztHQUNULEVBQUU7R0FFRixrQkFBa0IsU0FBUyxDQUN6QjtJQUNFLElBQUksZ0JBQWdCLEtBQUssSUFBSTtJQUM3QixPQUFPO0lBQ1AsU0FBUztJQUNULE1BQU07SUFDTixXQUFXO0lBQ1gsTUFBTTtJQUNOLE9BQU87R0FDVCxHQUNBLEdBQUcsSUFDTCxDQUFDO0dBRUQsd0JBQXdCLElBQUk7RUFDOUI7RUFDQSwyQkFBMkIsSUFBSTtDQUNqQztDQUVBLE1BQU0sMEJBQTBCLFNBQXFCO0VBQ25ELGNBQWMsSUFBSTtFQUNsQixVQUFVLElBQUk7Q0FDaEI7O0NBR0EsTUFBTSw2QkFBNkIsT0FBZSxRQUFnQixNQUFNO0VBQ3RFLGlCQUFpQixTQUNmLEtBQUssS0FBSyxNQUFNO0dBQ2QsSUFBSSxFQUFFLE9BQU8sU0FBUyxDQUFDLEVBQUUsU0FBUztJQUNoQyxNQUFNLFVBQVUsS0FBSyxJQUFJLEVBQUUsYUFBYSxFQUFFLFdBQVcsS0FBSztJQUMxRCxPQUFPO0tBQUUsR0FBRztLQUFHLFVBQVU7SUFBUTtHQUNuQztHQUNBLE9BQU87RUFDVCxDQUFDLENBQ0g7Q0FDRjs7Q0FHQSxNQUFNLDRCQUE0QixZQUFvQjtFQUNwRCxJQUFJLFlBQVksT0FBTztHQUNyQiwwQkFBMEIsYUFBYSxDQUFDO0VBQzFDO0NBQ0Y7O0NBR0EsTUFBTSw4QkFBOEIsU0FBaUIsYUFBcUI7RUFDeEUsSUFBSSxZQUFZLE9BQU87R0FDckIsSUFBSSxZQUFZLEdBQUc7SUFDakIsMEJBQTBCLGVBQWUsQ0FBQztHQUM1QztHQUNBLElBQUksWUFBWSxHQUFHO0lBQ2pCLDBCQUEwQixnQkFBZ0IsQ0FBQztHQUM3QztFQUNGO0VBQ0EsbUJBQW1CLE1BQU0sSUFBSSxDQUFDO0NBQ2hDOztDQUdBLE1BQU0sa0JBQWtCLGdCQUF3QixPQUFlLFlBQXFCO0VBQ2xGLGNBQWMsS0FBSztFQUNuQixrQkFBa0I7R0FBRTtHQUFTO0dBQWdCO0VBQU0sQ0FBQzs7RUFHcEQsTUFBTSxjQUFjLGlCQUFpQixPQUFPLFVBQVUsTUFBTztFQUM3RCxNQUFNLGFBQWEsS0FBSyxNQUFNLGlCQUFpQixHQUFHLEtBQUssVUFBVSxLQUFLO0VBRXRFLFNBQVMsVUFBVTtHQUNqQixHQUFHO0dBQ0gsT0FBTyxLQUFLLFFBQVE7R0FDcEIsTUFBTSxLQUFLLE9BQU87R0FDbEIsSUFBSSxLQUFLLEtBQUssaUJBQWlCO0VBQ2pDLEVBQUU7RUFFRixJQUFJLGtCQUFrQixJQUFJO0dBQ3hCLDBCQUEwQixZQUFZLGNBQWM7RUFDdEQ7RUFDQSxJQUFJLFdBQVcsUUFBUTtHQUNyQiwwQkFBMEIsZ0JBQWdCLENBQUM7RUFDN0M7Q0FDRjs7Q0FHQSxNQUFNLHNCQUFzQixRQUFnQjtFQUMxQyxpQkFBaUIsU0FBUyxDQUFDLEdBQUcsS0FBSyxNQUFNLENBQUMsQ0FBQyxHQUFHLEdBQUcsQ0FBQztDQUNwRDs7Q0FHQSxNQUFNLDRCQUE0QixVQUF1QjtFQUN2RCxNQUFNLE1BQU0sWUFBWSxNQUFNLE1BQU0sRUFBRSxPQUFPLE1BQU0sT0FBTztFQUMxRCxJQUFJLENBQUMsS0FBSztFQUNWLE1BQU0sVUFBVSxNQUFNLFFBQVE7RUFDOUIsSUFBSSxVQUFVLElBQUksT0FBTyxRQUFRO0dBQy9CLE1BQU0sT0FBTyxJQUFJLE9BQU8sUUFBUSxDQUFDO0dBQ2pDLE1BQU0sUUFBUTtHQUNkLE1BQU0saUJBQWlCO0dBQ3ZCLDJCQUEyQixNQUFNLFNBQVMsT0FBTztFQUNuRDtDQUNGOztDQUdBLE1BQU0seUJBQXlCLFVBQXVCO0VBQ3BELGlCQUFpQixTQUFTLEtBQUssUUFBUSxNQUFNLEVBQUUsZUFBZSxNQUFNLFVBQVUsQ0FBQztFQUMvRSx1QkFBdUIsSUFBSTtDQUM3Qjs7Q0FHQSxNQUFNLDBCQUEwQixTQUFxRDtFQUNuRixJQUFJLENBQUMscUJBQXFCO0VBQzFCLG9CQUFvQixhQUFhO0VBQ2pDLG1CQUFtQixNQUFNLElBQUksQ0FBQztDQUNoQztDQUVBLE1BQU0sZUFBZSxjQUFjLFFBQVEsTUFBTSxDQUFDLEVBQUUsSUFBSSxDQUFDLENBQUM7Q0FFMUQsT0FDRSx3QkFBQyxPQUFEO0VBQUssV0FBVyxnQkFBZ0IsS0FBSyxVQUFVLFVBQVUsOEJBQThCLDhCQUE4QjtZQUFySDtHQUVFLHdCQUFDLFFBQUQ7SUFDUTtJQUNNO0lBQ1osb0JBQW9CO0lBQ1I7SUFDWixtQkFBbUI7SUFDbkIsY0FBYyxNQUFNLGVBQWUsQ0FBQztJQUNwQyxtQkFBbUIsVUFBVTtJQUM3Qix3QkFBd0IsdUJBQXVCLElBQUk7SUFDbkQscUJBQXFCO0lBQ3JCLDZCQUE2QixvQkFBb0IsSUFBSTtHQUN0RDs7Ozs7R0FHRCx3QkFBQyxRQUFEO0lBQU0sV0FBVTtjQUFoQjtLQUVHLG9CQUNDLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBVTtPQUFROzs7O2lCQUNsQyx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsUUFBRDtRQUFNLFdBQVU7a0JBQXVDO09BQXVCOzs7O2lCQUM5RSx3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBa0I7T0FBb0U7Ozs7ZUFDbkc7Ozs7ZUFDRjs7Ozs7Z0JBQ0wsd0JBQUMsVUFBRDtPQUNFLGVBQWUsb0JBQW9CLFNBQVM7T0FDNUMsV0FBVTtpQkFDWDtNQUVPOzs7O2NBQ0w7Ozs7OztLQUlOLFVBQ0Msd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZjtRQUNFLHdCQUFDLFFBQUQsRUFBTSxXQUFVLHdEQUF5RDs7Ozs7UUFDekUsd0JBQUMsUUFBRDtTQUFNLFdBQVU7bUJBQWhCO1VBQTJDO1VBQ1YsZ0JBQWdCO1VBQVc7U0FDdEQ7Ozs7OztRQUNOLHdCQUFDLFFBQUQ7U0FBTSxXQUFVO21CQUFpQjtRQUErQzs7Ozs7T0FDN0U7Ozs7O2dCQUNMLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsVUFBRDtRQUNFLGVBQWUsbUJBQW1CLDhCQUE4QjtRQUNoRSxXQUFVO2tCQUNYO09BRU87Ozs7aUJBQ1Isd0JBQUMsVUFBRDtRQUNFLGVBQWUsVUFBVSxLQUFLO1FBQzlCLFdBQVU7a0JBQ1g7T0FFTzs7OztlQUNMOzs7OztjQUNGOzs7Ozs7S0FJUCx3QkFBQyxZQUFEO01BQ2M7TUFDSjtNQUNJO01BQ1osWUFBWTtNQUNVO01BQ3RCLHNCQUFzQixVQUFVLHVCQUF1QixLQUFLO01BQzVELHVCQUF1QixxQkFBcUIsY0FBYztNQUMxRCxNQUFNO01BQ04sU0FBUztNQUNULHNCQUFzQjtNQUN0Qix3QkFBd0I7TUFDbEI7TUFDRztNQUNDO01BQ0M7TUFDRztNQUNKO01BQ0c7TUFDRztNQUNGO01BQ2QsZ0JBQWdCO01BQ0Y7TUFDRztLQUNsQjs7Ozs7S0FHQSxzQkFDQyx3QkFBQyxlQUFEO01BQ0UsZUFBZTtNQUNmLE1BQU07TUFDTixTQUFTO01BQ1QsZUFBZSx1QkFBdUIsSUFBSTtNQUMxQyxnQkFBZ0I7TUFDaEIsYUFBYTtNQUNiLG9CQUFvQjtLQUNyQjs7OztnQkFFRCx3QkFBQyxXQUFEO01BQ0UsTUFBTTtNQUNnQjtNQUN0Qix1QkFBdUIsT0FBTyx3QkFBd0IsRUFBRTtNQUN0QztLQUNuQjs7Ozs7SUFFQzs7Ozs7O0dBR0wsZ0JBQWdCLFdBQ2Ysd0JBQUMsbUJBQUQ7SUFDUTtJQUNHO0lBQ1QsZUFBZSxlQUFlLElBQUk7R0FDbkM7Ozs7O0dBR0YsZ0JBQWdCLFVBQ2Ysd0JBQUMsV0FBRDtJQUNRO0lBQ0c7SUFDRDtJQUNHO0lBQ0k7SUFDRztJQUNsQixlQUFlLGVBQWUsSUFBSTtHQUNuQzs7Ozs7R0FHRixnQkFBZ0IsV0FDZix3QkFBQyxZQUFEO0lBQ1E7SUFDRztJQUNGO0lBQ0c7SUFDVixNQUFNO0lBQ04sU0FBUztJQUNULGVBQWUsZUFBZSxJQUFJO0lBQ2xDLHFCQUFxQjtHQUN0Qjs7Ozs7R0FHRixnQkFBZ0IsWUFDZix3QkFBQyx1QkFBRDtJQUNFLG1CQUFtQixlQUFlO0tBQ2hDLG9CQUFvQixVQUFVO0tBQzlCLFVBQVUsTUFBTTtJQUNsQjtJQUNBLGVBQWUsZUFBZSxJQUFJO0dBQ25DOzs7OztHQUdGLGdCQUFnQixVQUNmLHdCQUFDLGdCQUFEO0lBQ0UsY0FBYztJQUNkLGtCQUFrQixhQUFhO0tBQzdCLFVBQVUsSUFBSTtLQUNkLGdCQUFnQixRQUFRO0tBQ3hCLFVBQVUsUUFBUTtJQUNwQjtJQUNBLG1CQUFtQixVQUFVLEtBQUs7SUFDbEMsZUFBZSxlQUFlLElBQUk7R0FDbkM7Ozs7O0dBR0YsZ0JBQWdCLGlCQUNmLHdCQUFDLGtCQUFEO0lBQ2U7SUFDYixpQkFBaUIsS0FBSztJQUN0QixlQUFlLGVBQWUsSUFBSTtHQUNuQzs7Ozs7R0FHRixnQkFBZ0Isa0JBQ2Ysd0JBQUMsbUJBQUQ7SUFDZ0I7SUFDRztJQUNYO0lBQ0c7SUFDVCxlQUFlLGVBQWUsSUFBSTtHQUNuQzs7Ozs7R0FHRixnQkFBZ0IsYUFDZix3QkFBQyxjQUFEO0lBQ1E7SUFDRztJQUNULGVBQWUsZUFBZSxJQUFJO0lBQ2xDLHdCQUF3QixlQUFlLE1BQU07SUFDN0MsNkJBQTZCLG9CQUFvQixJQUFJO0dBQ3REOzs7OztHQUdGLGdCQUFnQixtQkFDZix3QkFBQyxvQkFBRDtJQUNpQjtJQUNHO0lBQ2xCLGVBQWUsZUFBZSxJQUFJO0dBQ25DOzs7OztHQUdGLGtCQUNDLHdCQUFDLGVBQUQ7SUFDRSxTQUFTLGVBQWU7SUFDeEIsZ0JBQWdCLGVBQWU7SUFDL0IsT0FBTyxlQUFlO0lBQ3RCLGlCQUFpQixVQUFVO0dBQzVCOzs7OztHQUlGLHVCQUNDLHdCQUFDLGlCQUFEO0lBQ0UsZ0JBQWdCO0lBQ2hCLG1CQUFtQjtJQUNuQixlQUFlLHVCQUF1QixLQUFLO0dBQzVDOzs7OztHQUlGLDJCQUNDLHdCQUFDLHFCQUFELEVBQ0UsZUFBZSwyQkFBMkIsS0FBSyxFQUNoRDs7Ozs7R0FJRixvQkFDQyx3QkFBQyxzQkFBRCxFQUNFLGVBQWUsb0JBQW9CLEtBQUssRUFDekM7Ozs7O0VBRUE7Ozs7OztBQUVUIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkFwcC50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZVN0YXRlLCB1c2VFZmZlY3QsIHVzZUNhbGxiYWNrIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgUGxhY2VkVG93ZXIsIERpZmZpY3VsdHksIFVzZXJQcm9maWxlLCBPcmRlckl0ZW0sIENsYW4sIENsYW5DaGF0TWVzc2FnZSwgTGVhZGVyYm9hcmRFbnRyeSwgQWNoaWV2ZW1lbnQsIEluR2FtZU5vdGlmaWNhdGlvbiB9IGZyb20gJy4vdHlwZXMvZ2FtZSc7XG5pbXBvcnQge1xuICBsb2FkVXNlclByb2ZpbGUsXG4gIHNhdmVVc2VyUHJvZmlsZSxcbiAgbG9hZE9yZGVycyxcbiAgc2F2ZU9yZGVycyxcbiAgbG9hZENsYW5zLFxuICBzYXZlQ2xhbnMsXG4gIGxvYWRDbGFuQ2hhdCxcbiAgc2F2ZUNsYW5DaGF0LFxuICBsb2FkTGVhZGVyYm9hcmQsXG4gIGxvYWRBY2hpZXZlbWVudHMsXG4gIHNhdmVBY2hpZXZlbWVudHMsXG4gIGxvYWROb3RpZmljYXRpb25zLFxuICBzYXZlTm90aWZpY2F0aW9ucyxcbn0gZnJvbSAnLi91dGlscy9zdG9yYWdlJztcbmltcG9ydCB7IE5hdmJhciB9IGZyb20gJy4vY29tcG9uZW50cy9OYXZiYXInO1xuaW1wb3J0IHsgR2FtZUNhbnZhcyB9IGZyb20gJy4vY29tcG9uZW50cy9HYW1lQ2FudmFzJztcbmltcG9ydCB7IFRvd2VyRG9jayB9IGZyb20gJy4vY29tcG9uZW50cy9Ub3dlckRvY2snO1xuaW1wb3J0IHsgVG93ZXJDb250cm9scyB9IGZyb20gJy4vY29tcG9uZW50cy9Ub3dlckNvbnRyb2xzJztcbmltcG9ydCB7IERhaWx5UmV3YXJkc01vZGFsIH0gZnJvbSAnLi9jb21wb25lbnRzL0RhaWx5UmV3YXJkc01vZGFsJztcbmltcG9ydCB7IFNob3BNb2RhbCB9IGZyb20gJy4vY29tcG9uZW50cy9TaG9wTW9kYWwnO1xuaW1wb3J0IHsgQ2xhbnNNb2RhbCB9IGZyb20gJy4vY29tcG9uZW50cy9DbGFuc01vZGFsJztcbmltcG9ydCB7IFdlZWtseUNoYWxsZW5nZXNNb2RhbCB9IGZyb20gJy4vY29tcG9uZW50cy9XZWVrbHlDaGFsbGVuZ2VzTW9kYWwnO1xuaW1wb3J0IHsgQ29vcExvYmJ5TW9kYWwgfSBmcm9tICcuL2NvbXBvbmVudHMvQ29vcExvYmJ5TW9kYWwnO1xuaW1wb3J0IHsgTGVhZGVyYm9hcmRNb2RhbCB9IGZyb20gJy4vY29tcG9uZW50cy9MZWFkZXJib2FyZE1vZGFsJztcbmltcG9ydCB7IEFjaGlldmVtZW50c01vZGFsIH0gZnJvbSAnLi9jb21wb25lbnRzL0FjaGlldmVtZW50c01vZGFsJztcbmltcG9ydCB7IFByb2ZpbGVNb2RhbCB9IGZyb20gJy4vY29tcG9uZW50cy9Qcm9maWxlTW9kYWwnO1xuaW1wb3J0IHsgTm90aWZpY2F0aW9uc01vZGFsIH0gZnJvbSAnLi9jb21wb25lbnRzL05vdGlmaWNhdGlvbnNNb2RhbCc7XG5pbXBvcnQgeyBHYW1lT3Zlck1vZGFsIH0gZnJvbSAnLi9jb21wb25lbnRzL0dhbWVPdmVyTW9kYWwnO1xuaW1wb3J0IHsgU2VjcmV0SGludE1vZGFsIH0gZnJvbSAnLi9jb21wb25lbnRzL1NlY3JldEhpbnRNb2RhbCc7XG5pbXBvcnQgeyBTZWNyZXRVbmxvY2tlZE1vZGFsIH0gZnJvbSAnLi9jb21wb25lbnRzL1NlY3JldFVubG9ja2VkTW9kYWwnO1xuaW1wb3J0IHsgTmV0bGlmeURvd25sb2FkTW9kYWwgfSBmcm9tICcuL2NvbXBvbmVudHMvTmV0bGlmeURvd25sb2FkTW9kYWwnO1xuaW1wb3J0IHsgVE9XRVJTX0RBVEEgfSBmcm9tICcuL2RhdGEvY29uc3RhbnRzJztcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gQXBwKCkge1xuICAvLyBVc2VyIFByb2ZpbGUgJiBTdG9yYWdlIFN0YXRlXG4gIGNvbnN0IFt1c2VyLCBzZXRVc2VyXSA9IHVzZVN0YXRlPFVzZXJQcm9maWxlPihsb2FkVXNlclByb2ZpbGUpO1xuICBjb25zdCBbb3JkZXJzLCBzZXRPcmRlcnNdID0gdXNlU3RhdGU8T3JkZXJJdGVtW10+KGxvYWRPcmRlcnMpO1xuICBjb25zdCBbY2xhbnMsIHNldENsYW5zXSA9IHVzZVN0YXRlPENsYW5bXT4obG9hZENsYW5zKTtcbiAgY29uc3QgW2NsYW5DaGF0LCBzZXRDbGFuQ2hhdF0gPSB1c2VTdGF0ZTxDbGFuQ2hhdE1lc3NhZ2VbXT4obG9hZENsYW5DaGF0KTtcbiAgY29uc3QgW2xlYWRlcmJvYXJkLCBzZXRMZWFkZXJib2FyZF0gPSB1c2VTdGF0ZTxMZWFkZXJib2FyZEVudHJ5W10+KGxvYWRMZWFkZXJib2FyZCk7XG4gIGNvbnN0IFthY2hpZXZlbWVudHMsIHNldEFjaGlldmVtZW50c10gPSB1c2VTdGF0ZTxBY2hpZXZlbWVudFtdPihsb2FkQWNoaWV2ZW1lbnRzKTtcbiAgY29uc3QgW25vdGlmaWNhdGlvbnMsIHNldE5vdGlmaWNhdGlvbnNdID0gdXNlU3RhdGU8SW5HYW1lTm90aWZpY2F0aW9uW10+KGxvYWROb3RpZmljYXRpb25zKTtcblxuICAvLyBHYW1lIEVuZ2luZSBTdGF0ZVxuICBjb25zdCBbZGlmZmljdWx0eSwgc2V0RGlmZmljdWx0eV0gPSB1c2VTdGF0ZTxEaWZmaWN1bHR5Pignbm9ybWFsJyk7XG4gIGNvbnN0IFtpbkdhbWVDYXNoLCBzZXRJbkdhbWVDYXNoXSA9IHVzZVN0YXRlPG51bWJlcj4oNzUwKTtcbiAgY29uc3QgW3BsYWNlZFRvd2Vycywgc2V0UGxhY2VkVG93ZXJzXSA9IHVzZVN0YXRlPFBsYWNlZFRvd2VyW10+KFtdKTtcbiAgY29uc3QgW3NlbGVjdGVkVG93ZXJUb1BsYWNlLCBzZXRTZWxlY3RlZFRvd2VyVG9QbGFjZV0gPSB1c2VTdGF0ZTxzdHJpbmcgfCBudWxsPihudWxsKTtcbiAgY29uc3QgW3NlbGVjdGVkUGxhY2VkVG93ZXIsIHNldFNlbGVjdGVkUGxhY2VkVG93ZXJdID0gdXNlU3RhdGU8UGxhY2VkVG93ZXIgfCBudWxsPihudWxsKTtcblxuICAvLyBFYXN0ZXIgRWdnICfQs9C+IEtFS0MnXG4gIGNvbnN0IFtzaG93U2VjcmV0SGludE1vZGFsLCBzZXRTaG93U2VjcmV0SGludE1vZGFsXSA9IHVzZVN0YXRlPGJvb2xlYW4+KGZhbHNlKTtcbiAgY29uc3QgW3Nob3dTZWNyZXRVbmxvY2tlZE1vZGFsLCBzZXRTaG93U2VjcmV0VW5sb2NrZWRNb2RhbF0gPSB1c2VTdGF0ZTxib29sZWFuPihmYWxzZSk7XG4gIGNvbnN0IFtpc1NlY3JldEtla2NVbmxvY2tlZCwgc2V0SXNTZWNyZXRLZWtjVW5sb2NrZWRdID0gdXNlU3RhdGU8Ym9vbGVhbj4oZmFsc2UpO1xuXG4gIC8vIE5ldGxpZnkgRG93bmxvYWQgTW9kYWxcbiAgY29uc3QgW3Nob3dOZXRsaWZ5TW9kYWwsIHNldFNob3dOZXRsaWZ5TW9kYWxdID0gdXNlU3RhdGU8Ym9vbGVhbj4oZmFsc2UpO1xuXG4gIC8vIFdhdmVzXG4gIGNvbnN0IFt3YXZlLCBzZXRXYXZlXSA9IHVzZVN0YXRlPG51bWJlcj4oMCk7XG4gIGNvbnN0IG1heFdhdmVzID0gZGlmZmljdWx0eSA9PT0gJ2Vhc3knID8gMTUgOiBkaWZmaWN1bHR5ID09PSAnbm9ybWFsJyA/IDI1IDogZGlmZmljdWx0eSA9PT0gJ2hhcmQnID8gMzUgOiA0MDtcbiAgY29uc3QgW2dhbWVTcGVlZCwgc2V0R2FtZVNwZWVkXSA9IHVzZVN0YXRlPG51bWJlcj4oMSk7XG4gIGNvbnN0IFtpc1BhdXNlZCwgc2V0SXNQYXVzZWRdID0gdXNlU3RhdGU8Ym9vbGVhbj4oZmFsc2UpO1xuICBjb25zdCBbZ2FtZUFjdGl2ZSwgc2V0R2FtZUFjdGl2ZV0gPSB1c2VTdGF0ZTxib29sZWFuPih0cnVlKTtcbiAgY29uc3QgW3VwZ3JhZGVUcmlnZ2VyLCBzZXRVcGdyYWRlVHJpZ2dlcl0gPSB1c2VTdGF0ZTxudW1iZXI+KDApO1xuXG4gIC8vIENvLW9wIE1vZGUgU3RhdGVcbiAgY29uc3QgW2lzQ29vcCwgc2V0SXNDb29wXSA9IHVzZVN0YXRlPGJvb2xlYW4+KGZhbHNlKTtcbiAgY29uc3QgW2Nvb3BSb29tQ29kZSwgc2V0Q29vcFJvb21Db2RlXSA9IHVzZVN0YXRlPHN0cmluZyB8IG51bGw+KG51bGwpO1xuICBjb25zdCBbY29vcE1lc3NhZ2VzLCBzZXRDb29wTWVzc2FnZXNdID0gdXNlU3RhdGU8c3RyaW5nW10+KFtcbiAgICAn0J3QsNC/0LDRgNC90LjQuiDQv9GA0LjRgdC+0LXQtNC40L3QuNC70YHRjyDQuiDRgdC10YHRgdC40LghJyxcbiAgICAn0JPQvtGC0L7QsiDQuiDQvtCx0L7RgNC+0L3QtSDQsdCw0LfRiyEnLFxuICBdKTtcblxuICAvLyBXZWVrbHkgQ2hhbGxlbmdlIEFjdGl2ZSBNb2RpZmllcnNcbiAgY29uc3QgW3Jlc3RyaWN0ZWRUb3dlcnMsIHNldFJlc3RyaWN0ZWRUb3dlcnNdID0gdXNlU3RhdGU8c3RyaW5nW10gfCB1bmRlZmluZWQ+KHVuZGVmaW5lZCk7XG5cbiAgLy8gQWN0aXZlIE9wZW4gTW9kYWxcbiAgY29uc3QgW2FjdGl2ZU1vZGFsLCBzZXRBY3RpdmVNb2RhbF0gPSB1c2VTdGF0ZTxcbiAgICB8IG51bGxcbiAgICB8ICdkYWlseSdcbiAgICB8ICdzaG9wJ1xuICAgIHwgJ2NsYW5zJ1xuICAgIHwgJ2xlYWRlcmJvYXJkJ1xuICAgIHwgJ3dlZWtseSdcbiAgICB8ICdjb29wJ1xuICAgIHwgJ2FjaGlldmVtZW50cydcbiAgICB8ICdwcm9maWxlJ1xuICAgIHwgJ25vdGlmaWNhdGlvbnMnXG4gID4obnVsbCk7XG5cbiAgLy8gR2FtZSBPdmVyIC8gVmljdG9yeSBNb2RhbFxuICBjb25zdCBbZ2FtZU92ZXJSZXN1bHQsIHNldEdhbWVPdmVyUmVzdWx0XSA9IHVzZVN0YXRlPHtcbiAgICB2aWN0b3J5OiBib29sZWFuO1xuICAgIHdhdmVzQ29tcGxldGVkOiBudW1iZXI7XG4gICAgc2NvcmU6IG51bWJlcjtcbiAgfSB8IG51bGw+KG51bGwpO1xuXG4gIC8vIEF1dG8tc2F2ZSBjaGFuZ2VzIHRvIGxvY2FsU3RvcmFnZVxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIHNhdmVVc2VyUHJvZmlsZSh1c2VyKTtcbiAgfSwgW3VzZXJdKTtcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIHNhdmVPcmRlcnMob3JkZXJzKTtcbiAgfSwgW29yZGVyc10pO1xuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgc2F2ZUNsYW5zKGNsYW5zKTtcbiAgfSwgW2NsYW5zXSk7XG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBzYXZlQ2xhbkNoYXQoY2xhbkNoYXQpO1xuICB9LCBbY2xhbkNoYXRdKTtcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIHNhdmVBY2hpZXZlbWVudHMoYWNoaWV2ZW1lbnRzKTtcbiAgfSwgW2FjaGlldmVtZW50c10pO1xuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgc2F2ZU5vdGlmaWNhdGlvbnMobm90aWZpY2F0aW9ucyk7XG4gIH0sIFtub3RpZmljYXRpb25zXSk7XG5cbiAgLy8gSGFuZGxlIFN0YXJ0aW5nIENhc2ggYmFzZWQgb24gZGlmZmljdWx0eSAoQnVmZmVkIGZvciBzbW9vdGhlciBnYW1lcGxheSEpXG4gIGNvbnN0IHJlc2V0R2FtZSA9IHVzZUNhbGxiYWNrKFxuICAgIChkaWZmOiBEaWZmaWN1bHR5ID0gZGlmZmljdWx0eSkgPT4ge1xuICAgICAgY29uc3Qgc3RhcnRpbmdDYXNoID0gZGlmZiA9PT0gJ2Vhc3knID8gOTUwIDogZGlmZiA9PT0gJ25vcm1hbCcgPyA3NTAgOiBkaWZmID09PSAnaGFyZCcgPyA1NTAgOiA0MDA7XG4gICAgICBzZXRJbkdhbWVDYXNoKHN0YXJ0aW5nQ2FzaCk7XG4gICAgICBzZXRXYXZlKDApO1xuICAgICAgc2V0UGxhY2VkVG93ZXJzKFtdKTtcbiAgICAgIHNldFNlbGVjdGVkVG93ZXJUb1BsYWNlKG51bGwpO1xuICAgICAgc2V0U2VsZWN0ZWRQbGFjZWRUb3dlcihudWxsKTtcbiAgICAgIHNldEdhbWVPdmVyUmVzdWx0KG51bGwpO1xuICAgICAgc2V0R2FtZUFjdGl2ZSh0cnVlKTtcbiAgICAgIHNldElzUGF1c2VkKGZhbHNlKTtcbiAgICB9LFxuICAgIFtkaWZmaWN1bHR5XVxuICApO1xuXG4gIC8vIFRyaWdnZXIgc2VjcmV0IGVhc3RlciBlZ2cgJ9Cz0L4gS0VLQydcbiAgY29uc3QgaGFuZGxlVHJpZ2dlclNlY3JldEtla2MgPSAoKSA9PiB7XG4gICAgaWYgKCFpc1NlY3JldEtla2NVbmxvY2tlZCkge1xuICAgICAgc2V0VXNlcigocHJldikgPT4gKHtcbiAgICAgICAgLi4ucHJldixcbiAgICAgICAgY29pbnM6IHByZXYuY29pbnMgKyAxNTAwLFxuICAgICAgICBnZW1zOiBwcmV2LmdlbXMgKyAxNTAsXG4gICAgICAgIHRpdGxlOiAn8J+RkSDQn9C+0LLQtdC70LjRgtC10LvRjCDQmtCV0JrQodCQJyxcbiAgICAgIH0pKTtcblxuICAgICAgc2V0Tm90aWZpY2F0aW9ucygocHJldikgPT4gW1xuICAgICAgICB7XG4gICAgICAgICAgaWQ6ICdub3RpZl9rZWtjXycgKyBEYXRlLm5vdygpLFxuICAgICAgICAgIHRpdGxlOiAn8J+OiSDQodC10LrRgNC10YLQutCwIMKr0LPQviBLRUtDwrsg0JDQutGC0LjQstC40YDQvtCy0LDQvdCwIScsXG4gICAgICAgICAgbWVzc2FnZTogJ9CS0Ysg0YDQsNC30LPQsNC00LDQu9C4INC/0LDRgdGF0LDQu9C60YMg0KDQvtCx0LvQvtC60YHQsCEg0J3QsNGH0LjRgdC70LXQvdC+ICsxLDUwMCDwn6qZINC4ICsxNTAg8J+Sjiwg0LAg0YLQsNC60LbQtSDRgtC40YLRg9C7IMKr0J/QvtCy0LXQu9C40YLQtdC70Ywg0JrQldCa0KHQkMK7LicsXG4gICAgICAgICAgdHlwZTogJ3Jld2FyZCcsXG4gICAgICAgICAgdGltZXN0YW1wOiAn0KLQvtC70YzQutC+INGH0YLQvicsXG4gICAgICAgICAgcmVhZDogZmFsc2UsXG4gICAgICAgICAgYmFkZ2U6ICdTRUNSRVQnLFxuICAgICAgICB9LFxuICAgICAgICAuLi5wcmV2LFxuICAgICAgXSk7XG5cbiAgICAgIHNldElzU2VjcmV0S2VrY1VubG9ja2VkKHRydWUpO1xuICAgIH1cbiAgICBzZXRTaG93U2VjcmV0VW5sb2NrZWRNb2RhbCh0cnVlKTtcbiAgfTtcblxuICBjb25zdCBoYW5kbGVEaWZmaWN1bHR5Q2hhbmdlID0gKGRpZmY6IERpZmZpY3VsdHkpID0+IHtcbiAgICBzZXREaWZmaWN1bHR5KGRpZmYpO1xuICAgIHJlc2V0R2FtZShkaWZmKTtcbiAgfTtcblxuICAvLyBBY2hpZXZlbWVudCB0cmFja2VyIGhlbHBlclxuICBjb25zdCB1cGRhdGVBY2hpZXZlbWVudFByb2dyZXNzID0gKGFjaElkOiBzdHJpbmcsIGRlbHRhOiBudW1iZXIgPSAxKSA9PiB7XG4gICAgc2V0QWNoaWV2ZW1lbnRzKChwcmV2KSA9PlxuICAgICAgcHJldi5tYXAoKGEpID0+IHtcbiAgICAgICAgaWYgKGEuaWQgPT09IGFjaElkICYmICFhLmNsYWltZWQpIHtcbiAgICAgICAgICBjb25zdCB1cGRhdGVkID0gTWF0aC5taW4oYS5tYXhQcm9ncmVzcywgYS5wcm9ncmVzcyArIGRlbHRhKTtcbiAgICAgICAgICByZXR1cm4geyAuLi5hLCBwcm9ncmVzczogdXBkYXRlZCB9O1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBhO1xuICAgICAgfSlcbiAgICApO1xuICB9O1xuXG4gIC8vIFRvd2VyIFBsYWNlZCBDYWxsYmFja1xuICBjb25zdCBoYW5kbGVUb3dlclBsYWNlZFN1Y2Nlc3MgPSAodG93ZXJJZDogc3RyaW5nKSA9PiB7XG4gICAgaWYgKHRvd2VySWQgPT09ICdjYXQnKSB7XG4gICAgICB1cGRhdGVBY2hpZXZlbWVudFByb2dyZXNzKCdmaXJzdF9jYXQnLCAxKTtcbiAgICB9XG4gIH07XG5cbiAgLy8gVG93ZXIgVXBncmFkZWQgQ2FsbGJhY2tcbiAgY29uc3QgaGFuZGxlVG93ZXJVcGdyYWRlZFN1Y2Nlc3MgPSAodG93ZXJJZDogc3RyaW5nLCBuZXdMZXZlbDogbnVtYmVyKSA9PiB7XG4gICAgaWYgKHRvd2VySWQgPT09ICdjYXQnKSB7XG4gICAgICBpZiAobmV3TGV2ZWwgPj0gMSkge1xuICAgICAgICB1cGRhdGVBY2hpZXZlbWVudFByb2dyZXNzKCdjYXRfbGV2ZWxfMScsIDEpO1xuICAgICAgfVxuICAgICAgaWYgKG5ld0xldmVsID49IDMpIHtcbiAgICAgICAgdXBkYXRlQWNoaWV2ZW1lbnRQcm9ncmVzcygnY2F0X21heF9zbG93JywgMSk7XG4gICAgICB9XG4gICAgfVxuICAgIHNldFVwZ3JhZGVUcmlnZ2VyKChwKSA9PiBwICsgMSk7XG4gIH07XG5cbiAgLy8gR2FtZSBPdmVyIEhhbmRsZXJcbiAgY29uc3QgaGFuZGxlR2FtZU92ZXIgPSAod2F2ZXNDb21wbGV0ZWQ6IG51bWJlciwgc2NvcmU6IG51bWJlciwgdmljdG9yeTogYm9vbGVhbikgPT4ge1xuICAgIHNldEdhbWVBY3RpdmUoZmFsc2UpO1xuICAgIHNldEdhbWVPdmVyUmVzdWx0KHsgdmljdG9yeSwgd2F2ZXNDb21wbGV0ZWQsIHNjb3JlIH0pO1xuXG4gICAgLy8gUmV3YXJkc1xuICAgIGNvbnN0IGNvaW5zUmV3YXJkID0gd2F2ZXNDb21wbGV0ZWQgKiAxMjAgKyAodmljdG9yeSA/IDEwMDAgOiAwKTtcbiAgICBjb25zdCBnZW1zUmV3YXJkID0gTWF0aC5mbG9vcih3YXZlc0NvbXBsZXRlZCAqIDMuNSkgKyAodmljdG9yeSA/IDUwIDogMCk7XG5cbiAgICBzZXRVc2VyKChwcmV2KSA9PiAoe1xuICAgICAgLi4ucHJldixcbiAgICAgIGNvaW5zOiBwcmV2LmNvaW5zICsgY29pbnNSZXdhcmQsXG4gICAgICBnZW1zOiBwcmV2LmdlbXMgKyBnZW1zUmV3YXJkLFxuICAgICAgeHA6IHByZXYueHAgKyB3YXZlc0NvbXBsZXRlZCAqIDQwLFxuICAgIH0pKTtcblxuICAgIGlmICh3YXZlc0NvbXBsZXRlZCA+PSAxNSkge1xuICAgICAgdXBkYXRlQWNoaWV2ZW1lbnRQcm9ncmVzcygnd2F2ZXNfMTUnLCB3YXZlc0NvbXBsZXRlZCk7XG4gICAgfVxuICAgIGlmICh2aWN0b3J5ICYmIGlzQ29vcCkge1xuICAgICAgdXBkYXRlQWNoaWV2ZW1lbnRQcm9ncmVzcygnY29vcF92aWN0b3J5JywgMSk7XG4gICAgfVxuICB9O1xuXG4gIC8vIENvLW9wIFBpbmcgRGlzcGF0Y2hlclxuICBjb25zdCBoYW5kbGVTZW5kQ29vcFBpbmcgPSAobXNnOiBzdHJpbmcpID0+IHtcbiAgICBzZXRDb29wTWVzc2FnZXMoKHByZXYpID0+IFsuLi5wcmV2LnNsaWNlKC02KSwgbXNnXSk7XG4gIH07XG5cbiAgLy8gVXBncmFkZSBzZWxlY3RlZCB0b3dlciBmcm9tIENvbnRyb2xzXG4gIGNvbnN0IGhhbmRsZVVwZ3JhZGVQbGFjZWRUb3dlciA9ICh0b3dlcjogUGxhY2VkVG93ZXIpID0+IHtcbiAgICBjb25zdCBkZWYgPSBUT1dFUlNfREFUQS5maW5kKCh0KSA9PiB0LmlkID09PSB0b3dlci50b3dlcklkKTtcbiAgICBpZiAoIWRlZikgcmV0dXJuO1xuICAgIGNvbnN0IG5leHRMdmwgPSB0b3dlci5sZXZlbCArIDE7XG4gICAgaWYgKG5leHRMdmwgPCBkZWYubGV2ZWxzLmxlbmd0aCkge1xuICAgICAgY29uc3QgY29zdCA9IGRlZi5sZXZlbHNbbmV4dEx2bF0uY29zdDtcbiAgICAgIHRvd2VyLmxldmVsID0gbmV4dEx2bDtcbiAgICAgIHRvd2VyLnRvdGFsSW52ZXN0ZWQgKz0gY29zdDtcbiAgICAgIGhhbmRsZVRvd2VyVXBncmFkZWRTdWNjZXNzKHRvd2VyLnRvd2VySWQsIG5leHRMdmwpO1xuICAgIH1cbiAgfTtcblxuICAvLyBTZWxsIHNlbGVjdGVkIHRvd2VyXG4gIGNvbnN0IGhhbmRsZVNlbGxQbGFjZWRUb3dlciA9ICh0b3dlcjogUGxhY2VkVG93ZXIpID0+IHtcbiAgICBzZXRQbGFjZWRUb3dlcnMoKHByZXYpID0+IHByZXYuZmlsdGVyKCh0KSA9PiB0Lmluc3RhbmNlSWQgIT09IHRvd2VyLmluc3RhbmNlSWQpKTtcbiAgICBzZXRTZWxlY3RlZFBsYWNlZFRvd2VyKG51bGwpO1xuICB9O1xuXG4gIC8vIFRhcmdldCBtb2RlIGNoYW5nZVxuICBjb25zdCBoYW5kbGVDaGFuZ2VUYXJnZXRNb2RlID0gKG1vZGU6ICdmaXJzdCcgfCAnbGFzdCcgfCAnc3Ryb25nZXN0JyB8ICd3ZWFrZXN0JykgPT4ge1xuICAgIGlmICghc2VsZWN0ZWRQbGFjZWRUb3dlcikgcmV0dXJuO1xuICAgIHNlbGVjdGVkUGxhY2VkVG93ZXIudGFyZ2V0TW9kZSA9IG1vZGU7XG4gICAgc2V0VXBncmFkZVRyaWdnZXIoKHApID0+IHAgKyAxKTtcbiAgfTtcblxuICBjb25zdCB1bnJlYWROb3RpZnMgPSBub3RpZmljYXRpb25zLmZpbHRlcigobikgPT4gIW4ucmVhZCkubGVuZ3RoO1xuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9e2BtaW4taC1zY3JlZW4gJHt1c2VyLnRoZW1lID09PSAnY3liZXInID8gJ2JnLXNsYXRlLTk1MCB0ZXh0LWN5YW4tNTAnIDogJ2JnLXNsYXRlLTk1MCB0ZXh0LXNsYXRlLTEwMCd9IGZsZXggZmxleC1jb2wgZm9udC1zYW5zIHNlbGVjdC1ub25lIGFudGlhbGlhc2VkYH0+XG4gICAgICB7LyogSGVhZGVyICYgTmF2ICovfVxuICAgICAgPE5hdmJhclxuICAgICAgICB1c2VyPXt1c2VyfVxuICAgICAgICBkaWZmaWN1bHR5PXtkaWZmaWN1bHR5fVxuICAgICAgICBvbkNoYW5nZURpZmZpY3VsdHk9e2hhbmRsZURpZmZpY3VsdHlDaGFuZ2V9XG4gICAgICAgIGluR2FtZUNhc2g9e2luR2FtZUNhc2h9XG4gICAgICAgIHVucmVhZE5vdGlmc0NvdW50PXt1bnJlYWROb3RpZnN9XG4gICAgICAgIG9uT3Blbk1vZGFsPXsobSkgPT4gc2V0QWN0aXZlTW9kYWwobSl9XG4gICAgICAgIG9uUmVzZXRHYW1lPXsoKSA9PiByZXNldEdhbWUoKX1cbiAgICAgICAgb25PcGVuU2VjcmV0SGludD17KCkgPT4gc2V0U2hvd1NlY3JldEhpbnRNb2RhbCh0cnVlKX1cbiAgICAgICAgb25UcmlnZ2VyU2VjcmV0S2VrYz17aGFuZGxlVHJpZ2dlclNlY3JldEtla2N9XG4gICAgICAgIG9uT3Blbk5ldGxpZnlEb3dubG9hZD17KCkgPT4gc2V0U2hvd05ldGxpZnlNb2RhbCh0cnVlKX1cbiAgICAgIC8+XG5cbiAgICAgIHsvKiBNYWluIEJvZHkgKi99XG4gICAgICA8bWFpbiBjbGFzc05hbWU9XCJmbGV4LTEgbWF4LXctN3hsIHctZnVsbCBteC1hdXRvIHAtNCBmbGV4IGZsZXgtY29sIGdhcC00XCI+XG4gICAgICAgIHsvKiBXZWVrbHkgQ2hhbGxlbmdlIEJhbm5lciBpZiBhY3RpdmUgKi99XG4gICAgICAgIHtyZXN0cmljdGVkVG93ZXJzICYmIChcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMyBiZy1wdXJwbGUtOTUwLzgwIGJvcmRlciBib3JkZXItcHVycGxlLTUwMCByb3VuZGVkLTJ4bCBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gdGV4dC14c1wiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBzcGFjZS14LTJcIj5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14bFwiPuKalO+4jzwvc3Bhbj5cbiAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LWJsYWNrIHRleHQtcHVycGxlLTMwMCB1cHBlcmNhc2VcIj7QmNGB0L/Ri9GC0LDQvdC40LUg0J3QtdC00LXQu9C4Ojwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXdoaXRlIG1sLTJcIj7QoNCw0LfRgNC10YjQtdC90Ysg0YLQvtC70YzQutC+INC60L7RiNCw0YfRjNC4INCx0LDRiNC90LghINCS0YHQtSDQutC+0YLRiyDQuNC80LXRjtGCICsyNSUg0LTQsNC70YzQvdC+0YHRgtC4Ljwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0UmVzdHJpY3RlZFRvd2Vycyh1bmRlZmluZWQpfVxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LXB1cnBsZS00MDAgaG92ZXI6dGV4dC13aGl0ZSB1bmRlcmxpbmUgZm9udC1ib2xkXCJcbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAg0KHQsdGA0L7RgdC40YLRjCDQvtCz0YDQsNC90LjRh9C10L3QuNC1XG4gICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgKX1cblxuICAgICAgICB7LyogQ28tb3AgTW9kZSBCYW5uZXIgaWYgYWN0aXZlICovfVxuICAgICAgICB7aXNDb29wICYmIChcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtMi41IGJnLWN5YW4tOTUwLzgwIGJvcmRlciBib3JkZXItY3lhbi01MDAgcm91bmRlZC0yeGwgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHRleHQteHNcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgc3BhY2UteC0yXCI+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInctMi41IGgtMi41IHJvdW5kZWQtZnVsbCBiZy1lbWVyYWxkLTQwMCBhbmltYXRlLXB1bHNlXCIgLz5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1ibGFjayB0ZXh0LWN5YW4tMzAwXCI+XG4gICAgICAgICAgICAgICAg0JrQvtC+0L/QtdGA0LDRgtC40LLQvdGL0Lkg0KDQtdC20LjQvCAo0JrQvtC80L3QsNGC0LA6IHtjb29wUm9vbUNvZGUgfHwgJ0NBVC1DT09QJ30pXG4gICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbGF0ZS00MDBcIj4mYnVsbDsg0J3QsNC/0LDRgNC90LjQuiDQv9C+0LzQvtCz0LDQtdGCINGD0LTQtdGA0LbQuNCy0LDRgtGMINC30LDQvNC+0Lo8L3NwYW4+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgc3BhY2UteC0yXCI+XG4gICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVTZW5kQ29vcFBpbmcoJ9Cj0LvRg9GH0YjQuCDQsdCw0YjQvdGOINC90LAg0L/QtdGA0LXQutGA0LXRgdGC0LrQtSEnKX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC0yLjUgcHktMSBiZy1jeWFuLTgwMCBob3ZlcjpiZy1jeWFuLTcwMCB0ZXh0LXdoaXRlIHJvdW5kZWQtbGcgZm9udC1ib2xkIHRleHQtWzExcHhdXCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIPCfkqwg0J7RgtC/0YDQsNCy0LjRgtGMINCf0LjQvdCzXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0SXNDb29wKGZhbHNlKX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJweC0yLjUgcHktMSBiZy1zbGF0ZS04MDAgaG92ZXI6Ymctc2xhdGUtNzAwIHRleHQtc2xhdGUtMzAwIHJvdW5kZWQtbGcgZm9udC1ib2xkIHRleHQtWzExcHhdXCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgINCS0YvQudGC0Lgg0LjQtyDQmtC+0L7Qv9CwXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICl9XG5cbiAgICAgICAgey8qIENhbnZhcyBFbmdpbmUgKi99XG4gICAgICAgIDxHYW1lQ2FudmFzXG4gICAgICAgICAgZGlmZmljdWx0eT17ZGlmZmljdWx0eX1cbiAgICAgICAgICBpc0Nvb3A9e2lzQ29vcH1cbiAgICAgICAgICBnYW1lQWN0aXZlPXtnYW1lQWN0aXZlfVxuICAgICAgICAgIG9uR2FtZU92ZXI9e2hhbmRsZUdhbWVPdmVyfVxuICAgICAgICAgIHNlbGVjdGVkVG93ZXJUb1BsYWNlPXtzZWxlY3RlZFRvd2VyVG9QbGFjZX1cbiAgICAgICAgICBvblNlbGVjdFBsYWNlZFRvd2VyPXsodG93ZXIpID0+IHNldFNlbGVjdGVkUGxhY2VkVG93ZXIodG93ZXIpfVxuICAgICAgICAgIHNlbGVjdGVkUGxhY2VkVG93ZXJJZD17c2VsZWN0ZWRQbGFjZWRUb3dlcj8uaW5zdGFuY2VJZCB8fCBudWxsfVxuICAgICAgICAgIGNhc2g9e2luR2FtZUNhc2h9XG4gICAgICAgICAgc2V0Q2FzaD17c2V0SW5HYW1lQ2FzaH1cbiAgICAgICAgICBvblRvd2VyUGxhY2VkU3VjY2Vzcz17aGFuZGxlVG93ZXJQbGFjZWRTdWNjZXNzfVxuICAgICAgICAgIG9uVG93ZXJVcGdyYWRlZFN1Y2Nlc3M9e2hhbmRsZVRvd2VyVXBncmFkZWRTdWNjZXNzfVxuICAgICAgICAgIHdhdmU9e3dhdmV9XG4gICAgICAgICAgc2V0V2F2ZT17c2V0V2F2ZX1cbiAgICAgICAgICBtYXhXYXZlcz17bWF4V2F2ZXN9XG4gICAgICAgICAgZ2FtZVNwZWVkPXtnYW1lU3BlZWR9XG4gICAgICAgICAgc2V0R2FtZVNwZWVkPXtzZXRHYW1lU3BlZWR9XG4gICAgICAgICAgaXNQYXVzZWQ9e2lzUGF1c2VkfVxuICAgICAgICAgIHNldElzUGF1c2VkPXtzZXRJc1BhdXNlZH1cbiAgICAgICAgICB1cGdyYWRlVHJpZ2dlcj17dXBncmFkZVRyaWdnZXJ9XG4gICAgICAgICAgY29vcE1lc3NhZ2VzPXtjb29wTWVzc2FnZXN9XG4gICAgICAgICAgb25TZW5kQ29vcFBpbmc9e2hhbmRsZVNlbmRDb29wUGluZ31cbiAgICAgICAgICBwbGFjZWRUb3dlcnM9e3BsYWNlZFRvd2Vyc31cbiAgICAgICAgICBzZXRQbGFjZWRUb3dlcnM9e3NldFBsYWNlZFRvd2Vyc31cbiAgICAgICAgLz5cblxuICAgICAgICB7LyogQm90dG9tIFNlY3Rpb246IFRvd2VyIFNlbGVjdGlvbiBEb2NrIG9yIEFjdGl2ZSBVcGdyYWRlIENhcmQgKi99XG4gICAgICAgIHtzZWxlY3RlZFBsYWNlZFRvd2VyID8gKFxuICAgICAgICAgIDxUb3dlckNvbnRyb2xzXG4gICAgICAgICAgICBzZWxlY3RlZFRvd2VyPXtzZWxlY3RlZFBsYWNlZFRvd2VyfVxuICAgICAgICAgICAgY2FzaD17aW5HYW1lQ2FzaH1cbiAgICAgICAgICAgIHNldENhc2g9e3NldEluR2FtZUNhc2h9XG4gICAgICAgICAgICBvbkNsb3NlPXsoKSA9PiBzZXRTZWxlY3RlZFBsYWNlZFRvd2VyKG51bGwpfVxuICAgICAgICAgICAgb25VcGdyYWRlVG93ZXI9e2hhbmRsZVVwZ3JhZGVQbGFjZWRUb3dlcn1cbiAgICAgICAgICAgIG9uU2VsbFRvd2VyPXtoYW5kbGVTZWxsUGxhY2VkVG93ZXJ9XG4gICAgICAgICAgICBvbkNoYW5nZVRhcmdldE1vZGU9e2hhbmRsZUNoYW5nZVRhcmdldE1vZGV9XG4gICAgICAgICAgLz5cbiAgICAgICAgKSA6IChcbiAgICAgICAgICA8VG93ZXJEb2NrXG4gICAgICAgICAgICBjYXNoPXtpbkdhbWVDYXNofVxuICAgICAgICAgICAgc2VsZWN0ZWRUb3dlclRvUGxhY2U9e3NlbGVjdGVkVG93ZXJUb1BsYWNlfVxuICAgICAgICAgICAgb25TZWxlY3RUb3dlclRvUGxhY2U9eyhpZCkgPT4gc2V0U2VsZWN0ZWRUb3dlclRvUGxhY2UoaWQpfVxuICAgICAgICAgICAgcmVzdHJpY3RlZFRvd2Vycz17cmVzdHJpY3RlZFRvd2Vyc31cbiAgICAgICAgICAvPlxuICAgICAgICApfVxuICAgICAgPC9tYWluPlxuXG4gICAgICB7LyogTU9EQUxTICovfVxuICAgICAge2FjdGl2ZU1vZGFsID09PSAnZGFpbHknICYmIChcbiAgICAgICAgPERhaWx5UmV3YXJkc01vZGFsXG4gICAgICAgICAgdXNlcj17dXNlcn1cbiAgICAgICAgICBzZXRVc2VyPXtzZXRVc2VyfVxuICAgICAgICAgIG9uQ2xvc2U9eygpID0+IHNldEFjdGl2ZU1vZGFsKG51bGwpfVxuICAgICAgICAvPlxuICAgICAgKX1cblxuICAgICAge2FjdGl2ZU1vZGFsID09PSAnc2hvcCcgJiYgKFxuICAgICAgICA8U2hvcE1vZGFsXG4gICAgICAgICAgdXNlcj17dXNlcn1cbiAgICAgICAgICBzZXRVc2VyPXtzZXRVc2VyfVxuICAgICAgICAgIG9yZGVycz17b3JkZXJzfVxuICAgICAgICAgIHNldE9yZGVycz17c2V0T3JkZXJzfVxuICAgICAgICAgIG5vdGlmaWNhdGlvbnM9e25vdGlmaWNhdGlvbnN9XG4gICAgICAgICAgc2V0Tm90aWZpY2F0aW9ucz17c2V0Tm90aWZpY2F0aW9uc31cbiAgICAgICAgICBvbkNsb3NlPXsoKSA9PiBzZXRBY3RpdmVNb2RhbChudWxsKX1cbiAgICAgICAgLz5cbiAgICAgICl9XG5cbiAgICAgIHthY3RpdmVNb2RhbCA9PT0gJ2NsYW5zJyAmJiAoXG4gICAgICAgIDxDbGFuc01vZGFsXG4gICAgICAgICAgdXNlcj17dXNlcn1cbiAgICAgICAgICBzZXRVc2VyPXtzZXRVc2VyfVxuICAgICAgICAgIGNsYW5zPXtjbGFuc31cbiAgICAgICAgICBzZXRDbGFucz17c2V0Q2xhbnN9XG4gICAgICAgICAgY2hhdD17Y2xhbkNoYXR9XG4gICAgICAgICAgc2V0Q2hhdD17c2V0Q2xhbkNoYXR9XG4gICAgICAgICAgb25DbG9zZT17KCkgPT4gc2V0QWN0aXZlTW9kYWwobnVsbCl9XG4gICAgICAgICAgb25UcmlnZ2VyU2VjcmV0S2VrYz17aGFuZGxlVHJpZ2dlclNlY3JldEtla2N9XG4gICAgICAgIC8+XG4gICAgICApfVxuXG4gICAgICB7YWN0aXZlTW9kYWwgPT09ICd3ZWVrbHknICYmIChcbiAgICAgICAgPFdlZWtseUNoYWxsZW5nZXNNb2RhbFxuICAgICAgICAgIG9uU3RhcnRDaGFsbGVuZ2U9eyhyZXN0cmljdGVkKSA9PiB7XG4gICAgICAgICAgICBzZXRSZXN0cmljdGVkVG93ZXJzKHJlc3RyaWN0ZWQpO1xuICAgICAgICAgICAgcmVzZXRHYW1lKCdoYXJkJyk7XG4gICAgICAgICAgfX1cbiAgICAgICAgICBvbkNsb3NlPXsoKSA9PiBzZXRBY3RpdmVNb2RhbChudWxsKX1cbiAgICAgICAgLz5cbiAgICAgICl9XG5cbiAgICAgIHthY3RpdmVNb2RhbCA9PT0gJ2Nvb3AnICYmIChcbiAgICAgICAgPENvb3BMb2JieU1vZGFsXG4gICAgICAgICAgaXNDb29wQWN0aXZlPXtpc0Nvb3B9XG4gICAgICAgICAgb25TdGFydENvb3BHYW1lPXsocm9vbUNvZGUpID0+IHtcbiAgICAgICAgICAgIHNldElzQ29vcCh0cnVlKTtcbiAgICAgICAgICAgIHNldENvb3BSb29tQ29kZShyb29tQ29kZSk7XG4gICAgICAgICAgICByZXNldEdhbWUoJ25vcm1hbCcpO1xuICAgICAgICAgIH19XG4gICAgICAgICAgb25MZWF2ZUNvb3A9eygpID0+IHNldElzQ29vcChmYWxzZSl9XG4gICAgICAgICAgb25DbG9zZT17KCkgPT4gc2V0QWN0aXZlTW9kYWwobnVsbCl9XG4gICAgICAgIC8+XG4gICAgICApfVxuXG4gICAgICB7YWN0aXZlTW9kYWwgPT09ICdsZWFkZXJib2FyZCcgJiYgKFxuICAgICAgICA8TGVhZGVyYm9hcmRNb2RhbFxuICAgICAgICAgIGxlYWRlcmJvYXJkPXtsZWFkZXJib2FyZH1cbiAgICAgICAgICBjdXJyZW50VXNlcm5hbWU9e3VzZXIudXNlcm5hbWV9XG4gICAgICAgICAgb25DbG9zZT17KCkgPT4gc2V0QWN0aXZlTW9kYWwobnVsbCl9XG4gICAgICAgIC8+XG4gICAgICApfVxuXG4gICAgICB7YWN0aXZlTW9kYWwgPT09ICdhY2hpZXZlbWVudHMnICYmIChcbiAgICAgICAgPEFjaGlldmVtZW50c01vZGFsXG4gICAgICAgICAgYWNoaWV2ZW1lbnRzPXthY2hpZXZlbWVudHN9XG4gICAgICAgICAgc2V0QWNoaWV2ZW1lbnRzPXtzZXRBY2hpZXZlbWVudHN9XG4gICAgICAgICAgdXNlcj17dXNlcn1cbiAgICAgICAgICBzZXRVc2VyPXtzZXRVc2VyfVxuICAgICAgICAgIG9uQ2xvc2U9eygpID0+IHNldEFjdGl2ZU1vZGFsKG51bGwpfVxuICAgICAgICAvPlxuICAgICAgKX1cblxuICAgICAge2FjdGl2ZU1vZGFsID09PSAncHJvZmlsZScgJiYgKFxuICAgICAgICA8UHJvZmlsZU1vZGFsXG4gICAgICAgICAgdXNlcj17dXNlcn1cbiAgICAgICAgICBzZXRVc2VyPXtzZXRVc2VyfVxuICAgICAgICAgIG9uQ2xvc2U9eygpID0+IHNldEFjdGl2ZU1vZGFsKG51bGwpfVxuICAgICAgICAgIG9uT3BlblNob3BPcmRlcnM9eygpID0+IHNldEFjdGl2ZU1vZGFsKCdzaG9wJyl9XG4gICAgICAgICAgb25PcGVuTmV0bGlmeURvd25sb2FkPXsoKSA9PiBzZXRTaG93TmV0bGlmeU1vZGFsKHRydWUpfVxuICAgICAgICAvPlxuICAgICAgKX1cblxuICAgICAge2FjdGl2ZU1vZGFsID09PSAnbm90aWZpY2F0aW9ucycgJiYgKFxuICAgICAgICA8Tm90aWZpY2F0aW9uc01vZGFsXG4gICAgICAgICAgbm90aWZpY2F0aW9ucz17bm90aWZpY2F0aW9uc31cbiAgICAgICAgICBzZXROb3RpZmljYXRpb25zPXtzZXROb3RpZmljYXRpb25zfVxuICAgICAgICAgIG9uQ2xvc2U9eygpID0+IHNldEFjdGl2ZU1vZGFsKG51bGwpfVxuICAgICAgICAvPlxuICAgICAgKX1cblxuICAgICAge2dhbWVPdmVyUmVzdWx0ICYmIChcbiAgICAgICAgPEdhbWVPdmVyTW9kYWxcbiAgICAgICAgICB2aWN0b3J5PXtnYW1lT3ZlclJlc3VsdC52aWN0b3J5fVxuICAgICAgICAgIHdhdmVzQ29tcGxldGVkPXtnYW1lT3ZlclJlc3VsdC53YXZlc0NvbXBsZXRlZH1cbiAgICAgICAgICBzY29yZT17Z2FtZU92ZXJSZXN1bHQuc2NvcmV9XG4gICAgICAgICAgb25SZXN0YXJ0PXsoKSA9PiByZXNldEdhbWUoKX1cbiAgICAgICAgLz5cbiAgICAgICl9XG5cbiAgICAgIHsvKiBTZWNyZXQgRWFzdGVyIEVnZyBIaW50IE1vZGFsICovfVxuICAgICAge3Nob3dTZWNyZXRIaW50TW9kYWwgJiYgKFxuICAgICAgICA8U2VjcmV0SGludE1vZGFsXG4gICAgICAgICAgb25VbmxvY2tTZWNyZXQ9e2hhbmRsZVRyaWdnZXJTZWNyZXRLZWtjfVxuICAgICAgICAgIGlzQWxyZWFkeVVubG9ja2VkPXtpc1NlY3JldEtla2NVbmxvY2tlZH1cbiAgICAgICAgICBvbkNsb3NlPXsoKSA9PiBzZXRTaG93U2VjcmV0SGludE1vZGFsKGZhbHNlKX1cbiAgICAgICAgLz5cbiAgICAgICl9XG5cbiAgICAgIHsvKiBTZWNyZXQgRWFzdGVyIEVnZyBVbmxvY2tlZCBDZWxlYnJhdGlvbiBNb2RhbCAqL31cbiAgICAgIHtzaG93U2VjcmV0VW5sb2NrZWRNb2RhbCAmJiAoXG4gICAgICAgIDxTZWNyZXRVbmxvY2tlZE1vZGFsXG4gICAgICAgICAgb25DbG9zZT17KCkgPT4gc2V0U2hvd1NlY3JldFVubG9ja2VkTW9kYWwoZmFsc2UpfVxuICAgICAgICAvPlxuICAgICAgKX1cblxuICAgICAgey8qIE5ldGxpZnkgRXhwb3J0ICYgRG93bmxvYWQgTW9kYWwgKi99XG4gICAgICB7c2hvd05ldGxpZnlNb2RhbCAmJiAoXG4gICAgICAgIDxOZXRsaWZ5RG93bmxvYWRNb2RhbFxuICAgICAgICAgIG9uQ2xvc2U9eygpID0+IHNldFNob3dOZXRsaWZ5TW9kYWwoZmFsc2UpfVxuICAgICAgICAvPlxuICAgICAgKX1cbiAgICA8L2Rpdj5cbiAgKTtcbn1cbiJdfQ==