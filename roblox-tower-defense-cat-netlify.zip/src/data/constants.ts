export const CAT_IMAGE_URL = "/assets/aistudio/5dcbe384-37cd-4f73-b297-5b25fdabce95_9dc95acb.jpg";
export const TOWERS_DATA = [
	{
		id: "cat",
		name: "Легендарный Кот",
		tagline: "Начальный герой с пиксельными очками и лазерами",
		baseCost: 150,
		type: "damage",
		icon: "🐱",
		image: CAT_IMAGE_URL,
		bulletColor: "#38bdf8",
		bulletType: "laser",
		levels: [
			{
				level: 0,
				name: "Кот в Очках (Базовый)",
				cost: 150,
				damage: 5,
				fireRate: .55,
				range: 70,
				description: "Стреляет скоростными пиксельными лучами. Урон: 5 / выстрел, Дальность: 8м"
			},
			{
				level: 1,
				name: "Кот 1-й Уровень",
				cost: 300,
				damage: 7,
				fireRate: .5,
				range: 90,
				description: "Улучшение за $300! 7 урона (скорострельность x2!), дальность 10 метров"
			},
			{
				level: 2,
				name: "Кот 2-й Уровень (Мем-Мастер)",
				cost: 750,
				damage: 20,
				fireRate: .45,
				range: 165,
				description: "Мощный скоростной кошачий залп! 20 урона за выстрел, дальность 20 метров"
			},
			{
				level: 3,
				name: "Кот 3-й Уровень (Ледяной Thug Life)",
				cost: 1600,
				damage: 50,
				fireRate: .4,
				range: 245,
				special: "Уникальное Замедление (-40% скорости врагов на 3 сек)",
				description: "50 урона за выстрел (суперскорость), дальность 30 метров + Уникальное замедление льдом!"
			}
		]
	},
	{
		id: "noob_knight",
		name: "Нуб-Рыцарь",
		tagline: "Классический воин Roblox с тяжелым молотом",
		baseCost: 200,
		type: "splash",
		icon: "🗡️",
		bulletColor: "#fbbf24",
		bulletType: "wave",
		levels: [
			{
				level: 0,
				name: "Желтый Нуб",
				cost: 200,
				damage: 15,
				fireRate: .65,
				range: 65,
				description: "Скоростные круговые удары молотом по площади"
			},
			{
				level: 1,
				name: "Бронированный Нуб",
				cost: 400,
				damage: 32,
				fireRate: .55,
				range: 80,
				description: "Быстрый сплеш-крит по толпе врагов"
			},
			{
				level: 2,
				name: "Паладин Блоксбурга",
				cost: 950,
				damage: 75,
				fireRate: .5,
				range: 100,
				description: "Оглушающие молниеносные удары молотом"
			},
			{
				level: 3,
				name: "Повелитель Блоков",
				cost: 2100,
				damage: 160,
				fireRate: .42,
				range: 120,
				special: "Двойной сплеш и стан на 0.8с",
				description: "Шквал сокрушительных ударов"
			}
		]
	},
	{
		id: "cyber_ranger",
		name: "Кибер-Снайпер",
		tagline: "Дальнобойная плазменная винтовка",
		baseCost: 250,
		type: "damage",
		icon: "🎯",
		bulletColor: "#ef4444",
		bulletType: "bullet",
		levels: [
			{
				level: 0,
				name: "Рейнджер",
				cost: 250,
				damage: 45,
				fireRate: 1,
				range: 200,
				description: "Скорострельная дальнобойная плазменная винтовка"
			},
			{
				level: 1,
				name: "Элитный Меткий Стрелок",
				cost: 500,
				damage: 95,
				fireRate: .85,
				range: 240,
				description: "Бронебойные очереди по боссам"
			},
			{
				level: 2,
				name: "Квантовый Снайпер",
				cost: 1100,
				damage: 210,
				fireRate: .75,
				range: 290,
				description: "Квантовый скорострельный лазер"
			},
			{
				level: 3,
				name: "Орбитальная Пушка",
				cost: 2600,
				damage: 520,
				fireRate: .65,
				range: 360,
				special: "Мгновенный пробой щитов боссов",
				description: "Непрерывный орбитальный лазерный огонь"
			}
		]
	},
	{
		id: "dj_blox",
		name: "DJ Блокс",
		tagline: "Ритм-генератор, ускоряющий и усиливающий союзников",
		baseCost: 300,
		type: "support",
		icon: "🎧",
		bulletColor: "#a855f7",
		bulletType: "wave",
		levels: [
			{
				level: 0,
				name: "Начинающий Диджей",
				cost: 300,
				damage: 5,
				fireRate: .45,
				range: 120,
				special: "Аура: +25% урона башням рядом",
				description: "Создает звуковые волны и усиливает соседние башни"
			},
			{
				level: 1,
				name: "Клубный Битмейкер",
				cost: 600,
				damage: 12,
				fireRate: .4,
				range: 150,
				special: "Аура: +35% урона и +25% скорости атаки",
				description: "Мощный бит ускоряет союзников вдвое"
			},
			{
				level: 2,
				name: "Звезда EDM Фестиваля",
				cost: 1300,
				damage: 28,
				fireRate: .35,
				range: 180,
				special: "Аура: +50% урона и +30% дальности",
				description: "Светомузыка и синхронизированные залпы"
			},
			{
				level: 3,
				name: "Легендарный Роблокс DJ",
				cost: 2800,
				damage: 60,
				fireRate: .28,
				range: 220,
				special: "Мега-бас: башни стреляют на 70% быстрее!",
				description: "Ультимативный усилитель всей команды в коопе"
			}
		]
	},
	{
		id: "banker_cat",
		name: "Кот-Банкир",
		tagline: "Финансовый магнат, приносящий золото каждую волну",
		baseCost: 220,
		type: "economy",
		icon: "💰",
		bulletColor: "#10b981",
		bulletType: "coin",
		levels: [
			{
				level: 0,
				name: "Свинья-Копилка",
				cost: 220,
				damage: 0,
				fireRate: 2,
				range: 70,
				special: "+$120 в конце каждой волны",
				description: "Приносит увеличенный пассивный доход в долларах"
			},
			{
				level: 1,
				name: "Золотой Банкомат",
				cost: 450,
				damage: 0,
				fireRate: 2,
				range: 80,
				special: "+$300 в конце каждой волны",
				description: "Утроенный денежный поток"
			},
			{
				level: 2,
				name: "Крипто-Ферма Блокси",
				cost: 1e3,
				damage: 0,
				fireRate: 2,
				range: 90,
				special: "+$750 в конце волны + 5 алмазов за победу",
				description: "Майнит валюту прямо на поле боя"
			},
			{
				level: 3,
				name: "Уолл-Стрит Корпорация",
				cost: 2200,
				damage: 0,
				fireRate: 2,
				range: 100,
				special: "+$1600 в конце волны + кешбэк 20% на покупки башен",
				description: "Финансовая мега-империя для легкой победы"
			}
		]
	},
	{
		id: "flamethrower_noob",
		name: "Огнеметчик Блокс",
		tagline: "Непрерывный поток раскаленного пламени",
		baseCost: 280,
		type: "splash",
		icon: "🔥",
		bulletColor: "#f97316",
		bulletType: "fire",
		levels: [
			{
				level: 0,
				name: "Новичок-Пиротехник",
				cost: 280,
				damage: 7,
				fireRate: .15,
				range: 80,
				description: "Струя огня, испепеляющая группы врагов на передовой"
			},
			{
				level: 1,
				name: "Огнеметчик Ветеран",
				cost: 480,
				damage: 15,
				fireRate: .12,
				range: 95,
				description: "Широкий конус пламени повышенной температуры"
			},
			{
				level: 2,
				name: "Напалмовый Штурмовик",
				cost: 1100,
				damage: 34,
				fireRate: .1,
				range: 115,
				special: "Напалм: горение врагов продолжается 2 секунды",
				description: "Заливает дорогу жидким огнем"
			},
			{
				level: 3,
				name: "Инферно-Титан",
				cost: 2400,
				damage: 78,
				fireRate: .08,
				range: 135,
				special: "Лавовый взрыв + расплавление брони боссов",
				description: "Ультимативное очищение поля боя огненным штормом"
			}
		]
	},
	{
		id: "mecha_cat",
		name: "Меха-Кот КЕКС",
		tagline: "Роботизированный кот с ракетными установками",
		baseCost: 350,
		type: "splash",
		icon: "🤖",
		bulletColor: "#e11d48",
		bulletType: "rocket",
		levels: [
			{
				level: 0,
				name: "Прототип Меха-Лапы",
				cost: 350,
				damage: 65,
				fireRate: 1,
				range: 155,
				special: "Ракетный сплеш-удар по площади (радиус 50px)",
				description: "Запускает тяжелые ракеты в скопления врагов"
			},
			{
				level: 1,
				name: "Боевой Дрон-Кот",
				cost: 650,
				damage: 140,
				fireRate: .9,
				range: 185,
				description: "Увеличенная скорость полета снарядов и площадь взрыва"
			},
			{
				level: 2,
				name: "Осадный Робо-Пантера",
				cost: 1400,
				damage: 310,
				fireRate: .78,
				range: 225,
				special: "Двойная боеголовка по боссам",
				description: "Крушит щиты бронированных противников"
			},
			{
				level: 3,
				name: "Титан КЕКС-3000",
				cost: 3100,
				damage: 750,
				fireRate: .65,
				range: 275,
				special: "Кассетный залп: 4 микро-ракеты за выстрел!",
				description: "Абсолютная огневая мощь секретной лаборатории"
			}
		]
	},
	{
		id: "tesla_wizard",
		name: "Тесла-Маг Роблокса",
		tagline: "Цепные электрические разряды и стан",
		baseCost: 320,
		type: "damage",
		icon: "⚡",
		bulletColor: "#a855f7",
		bulletType: "lightning",
		levels: [
			{
				level: 0,
				name: "Ученик Электричества",
				cost: 320,
				damage: 28,
				fireRate: .58,
				range: 135,
				special: "Цепная дуга: бьет сразу по 3 целям рядом",
				description: "Генерирует дуговой разряд тока между врагами"
			},
			{
				level: 1,
				name: "Шоковый Магистр",
				cost: 600,
				damage: 60,
				fireRate: .48,
				range: 160,
				special: "Цепная дуга: бьет по 4 целям",
				description: "Высоковольтные импульсы пробивают толпу"
			},
			{
				level: 2,
				name: "Архимаг Грозы",
				cost: 1250,
				damage: 135,
				fireRate: .42,
				range: 190,
				special: "Цепная дуга: 6 целей + микро-оглушение",
				description: "Разряды парализуют быстрых противников"
			},
			{
				level: 3,
				name: "Повелитель Тесла-Бури",
				cost: 2800,
				damage: 320,
				fireRate: .35,
				range: 235,
				special: "Шаровая молния: бьет до 8 целей со станом 0.5с",
				description: "Непрерывная буря плазмы парализует любые волны"
			}
		]
	},
	{
		id: "ninja_cat",
		name: "Кот-Шиноби",
		tagline: "Смертоносные сюрикены и критические удары",
		baseCost: 240,
		type: "damage",
		icon: "🥷",
		bulletColor: "#10b981",
		bulletType: "shuriken",
		levels: [
			{
				level: 0,
				name: "Ученик Додзё",
				cost: 240,
				damage: 18,
				fireRate: .38,
				range: 125,
				special: "Шанс крита 35% (x1.5 урона)",
				description: "Быстрые броски стальных звездочек"
			},
			{
				level: 1,
				name: "Теневой Кот",
				cost: 460,
				damage: 40,
				fireRate: .32,
				range: 145,
				special: "Шанс крита 45% (x1.8 урона)",
				description: "Отражает сюрикены с удвоенной силой"
			},
			{
				level: 2,
				name: "Мастер Ниндзюцу",
				cost: 1050,
				damage: 90,
				fireRate: .28,
				range: 170,
				special: "Шанс крита 55% (x2.0 урона) + пробивает скрытность",
				description: "Сверхзвуковые броски сквозь броню"
			},
			{
				level: 3,
				name: "Легендарный Грандмастер",
				cost: 2300,
				damage: 200,
				fireRate: .2,
				range: 205,
				special: "Веер сюрикенов: бросает 3 звездочки за раз!",
				description: "Молниеносный вихрь острых клинков"
			}
		]
	},
	{
		id: "freeze_penguin",
		name: "Ледяной Пингвин",
		tagline: "Магический холод и вечная мерзлота",
		baseCost: 270,
		type: "slow",
		icon: "🐧",
		bulletColor: "#06b6d4",
		bulletType: "frost",
		levels: [
			{
				level: 0,
				name: "Пингвин-Скаут",
				cost: 270,
				damage: 12,
				fireRate: .65,
				range: 115,
				special: "Замедление -35% на 2.5 сек",
				description: "Стреляет снежками, сковывающими врагов"
			},
			{
				level: 1,
				name: "Полярный Рейнджер",
				cost: 520,
				damage: 28,
				fireRate: .55,
				range: 135,
				special: "Замедление -50% на 3.0 сек",
				description: "Ледяные осколки рассекают группы"
			},
			{
				level: 2,
				name: "Шериф Антарктики",
				cost: 1150,
				damage: 65,
				fireRate: .48,
				range: 165,
				special: "Ледяной шторм: замедление -60% по площади",
				description: "Окутывает врагов сибирской метелью"
			},
			{
				level: 3,
				name: "Повелитель Близзарда",
				cost: 2500,
				damage: 155,
				fireRate: .38,
				range: 195,
				special: "Абсолютный ноль: заморозка на месте на 1с + замедление 70%",
				description: "Превращает поле боя в непроходимый ледник"
			}
		]
	}
];
export const SKINS_DATA = [
	{
		id: "cat_thug_life",
		towerId: "cat",
		name: "Thug Life Pixel (Оригинал)",
		rarity: "Legendary",
		costCoins: 0,
		costGems: 0,
		image: CAT_IMAGE_URL,
		description: "Легендарный крутой кот в 8-битных солнцезащитных очках",
		badgeColor: "#38bdf8"
	},
	{
		id: "cat_cyberpunk",
		towerId: "cat",
		name: "Киберпанк Неон",
		rarity: "Epic",
		costCoins: 1500,
		costGems: 75,
		description: "Неоновые визоры, хромированные когти и фиолетовые лазеры",
		badgeColor: "#c084fc"
	},
	{
		id: "cat_golden_king",
		towerId: "cat",
		name: "Золотой Король Мемов",
		rarity: "Mythic",
		costCoins: 5e3,
		costGems: 250,
		description: "Корона из чистейшего золота и кристаллов Роблокса",
		badgeColor: "#facc15"
	},
	{
		id: "cat_space_suit",
		towerId: "cat",
		name: "Астро-Кот 3000",
		rarity: "Rare",
		costCoins: 800,
		costGems: 40,
		description: "Герметичный шлем для космических волн защиты",
		badgeColor: "#60a5fa"
	},
	{
		id: "noob_golden_knight",
		towerId: "noob_knight",
		name: "Золотой Рыцарь Доминус",
		rarity: "Legendary",
		costCoins: 3e3,
		costGems: 150,
		description: "Инкрустированный шлем Доминус и пламенный молот",
		badgeColor: "#f59e0b"
	},
	{
		id: "dj_neon_party",
		towerId: "dj_blox",
		name: "Holo-DJ Винил",
		rarity: "Epic",
		costCoins: 2e3,
		costGems: 90,
		description: "Голографические пластинки и светомузыка",
		badgeColor: "#ec4899"
	}
];
export const ACHIEVEMENTS_DATA = [
	{
		id: "first_cat",
		title: "Первая лапка",
		description: "Разместите начальную башню \"Кот\"",
		icon: "🐾",
		rewardCoins: 200,
		rewardGems: 10,
		progress: 0,
		maxProgress: 1,
		claimed: false
	},
	{
		id: "cat_level_1",
		title: "Первая ступень",
		description: "Улучшите Кота до 1-го уровня ($300, 7 урона/сек)",
		icon: "⚡",
		rewardCoins: 300,
		rewardGems: 15,
		progress: 0,
		maxProgress: 1,
		claimed: false
	},
	{
		id: "cat_max_slow",
		title: "Ледяной Thug Life",
		description: "Прокачайте Кота до 3-го уровня с эффектом замедления (50 урона, 30м)",
		icon: "❄️",
		rewardCoins: 1e3,
		rewardGems: 50,
		progress: 0,
		maxProgress: 1,
		claimed: false
	},
	{
		id: "waves_15",
		title: "Защитник Базы",
		description: "Пройдите 15 волн на любой сложности",
		icon: "🛡️",
		rewardCoins: 500,
		rewardGems: 25,
		progress: 0,
		maxProgress: 15,
		claimed: false
	},
	{
		id: "boss_slayer",
		title: "Гроза Боссов",
		description: "Уничтожьте 5 главных боссов",
		icon: "👑",
		rewardCoins: 800,
		rewardGems: 40,
		progress: 0,
		maxProgress: 5,
		claimed: false
	},
	{
		id: "clan_join",
		title: "Сила Клана",
		description: "Вступите в клан или создайте свой",
		icon: "🏰",
		rewardCoins: 400,
		rewardGems: 20,
		progress: 0,
		maxProgress: 1,
		claimed: false
	},
	{
		id: "coop_victory",
		title: "Плечом к плечу",
		description: "Одержите победу в кооперативном режиме с другом",
		icon: "🤝",
		rewardCoins: 1200,
		rewardGems: 60,
		progress: 0,
		maxProgress: 1,
		claimed: false
	},
	{
		id: "skin_collector",
		title: "Модный Модник",
		description: "Разблокируйте 3 разных скина в магазине",
		icon: "✨",
		rewardCoins: 1500,
		rewardGems: 75,
		progress: 1,
		maxProgress: 3,
		claimed: false
	}
];
export const INITIAL_CLANS = [
	{
		id: "cat_cartel",
		name: "Кошачий Картель",
		tag: "CATZ",
		badge: "🐱👑",
		description: "Топ-1 клан любителей котов в очках! Делимся тактиками и бьем мировые рекорды.",
		level: 7,
		xp: 2840,
		membersCount: 29,
		maxMembers: 30,
		leaderName: "ThugCat_Supreme",
		ratingScore: 94200,
		perks: {
			bonusGoldPercent: 12,
			bonusDamagePercent: 8
		},
		weeklyQuest: {
			title: "Уничтожить 1000 врагов Котом 3-го уровня",
			progress: 742,
			goal: 1e3,
			rewardGems: 200
		}
	},
	{
		id: "blox_guardians",
		name: "Стражи Роблокса",
		tag: "BLOX",
		badge: "🛡️⚔️",
		description: "Хардкорные ветераны Tower Defense. Помогаем новичкам проходить сложнейшие карты.",
		level: 6,
		xp: 1950,
		membersCount: 24,
		maxMembers: 30,
		leaderName: "ViperX_Pro",
		ratingScore: 78500,
		perks: {
			bonusGoldPercent: 10,
			bonusDamagePercent: 6
		},
		weeklyQuest: {
			title: "Пройти 50 волн на Хардкоре",
			progress: 38,
			goal: 50,
			rewardGems: 180
		}
	},
	{
		id: "cyber_syndicate",
		name: "Кибер Синдикат",
		tag: "CYBER",
		badge: "🤖⚡",
		description: "Техно-гении с оптическими лазерами и роботами.",
		level: 5,
		xp: 1420,
		membersCount: 18,
		maxMembers: 25,
		leaderName: "NeonByte",
		ratingScore: 56300,
		perks: {
			bonusGoldPercent: 8,
			bonusDamagePercent: 5
		},
		weeklyQuest: {
			title: "Нанести 50,000 урона боссам",
			progress: 32100,
			goal: 5e4,
			rewardGems: 150
		}
	}
];
export const WEEKLY_CHALLENGE_DATA = {
	id: "cat_apocalypse_week",
	title: "Кошачий Триумф: Только Коты!",
	theme: "Особое Испытание Недели",
	description: "На поле боя разрешено ставить ТОЛЬКО кошачьи башни! Все коты получают +25% дальности, а враги двигаются на 20% быстрее.",
	modifiers: [
		"Только башни \"Кот\" и \"Кот-Банкир\"",
		"Враги на 20% быстрее",
		"Кот 3-го уровня замедляет на 55% вместо 40%",
		"+50% золота за каждого убитого босса"
	],
	restrictedTowers: ["cat", "banker_cat"],
	rewardCoins: 3500,
	rewardGems: 150,
	trophyName: "Золотой Кубок Мемного Кота",
	targetWave: 25,
	endsInDays: 4
};
export const INITIAL_NOTIFICATIONS = [
	{
		id: "notif_1",
		title: "🎉 Обновление: Кот в очках прибыл!",
		message: "Встречайте легендарного стартового героя с прогрессивной прокачкой урона и замедления!",
		type: "promo",
		timestamp: "Сегодня, 10:00",
		read: false,
		badge: "NEW"
	},
	{
		id: "notif_2",
		title: "💎 Х2 Кешбэк на донат-кристаллы",
		message: "Получайте 10% возврата в бонусных монетах за каждую покупку через СБП или карты!",
		type: "promo",
		timestamp: "Вчера, 18:30",
		read: false,
		badge: "HOT"
	},
	{
		id: "notif_3",
		title: "🤝 Кооперативный режим готов к бою",
		message: "Создайте лобби и зовите друзей или играйте с автоматическим подбором напарников.",
		type: "system",
		timestamp: "2 дня назад",
		read: true
	}
];
export const INITIAL_DAILY_REWARDS = [
	{
		day: 1,
		coins: 250,
		gems: 10,
		label: "День 1",
		icon: "🪙"
	},
	{
		day: 2,
		coins: 500,
		gems: 20,
		label: "День 2",
		icon: "💎"
	},
	{
		day: 3,
		coins: 800,
		gems: 35,
		label: "День 3",
		icon: "💰"
	},
	{
		day: 4,
		coins: 1200,
		gems: 50,
		label: "День 4",
		icon: "⚡"
	},
	{
		day: 5,
		coins: 1800,
		gems: 75,
		label: "День 5",
		icon: "🎁"
	},
	{
		day: 6,
		coins: 2500,
		gems: 100,
		label: "День 6",
		icon: "🏆"
	},
	{
		day: 7,
		coins: 5e3,
		gems: 200,
		specialSkin: "cat_cyberpunk",
		label: "День 7 (Супер-приз)",
		icon: "👑"
	}
];

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBRUEsT0FBTyxNQUFNLGdCQUFnQjtBQUU3QixPQUFPLE1BQU0sY0FBaUM7Q0FDNUM7RUFDRSxJQUFJO0VBQ0osTUFBTTtFQUNOLFNBQVM7RUFDVCxVQUFVO0VBQ1YsTUFBTTtFQUNOLE1BQU07RUFDTixPQUFPO0VBQ1AsYUFBYTtFQUNiLFlBQVk7RUFDWixRQUFRO0dBQ047SUFDRSxPQUFPO0lBQ1AsTUFBTTtJQUNOLE1BQU07SUFDTixRQUFRO0lBQ1IsVUFBVTtJQUNWLE9BQU87SUFDUCxhQUFhO0dBQ2Y7R0FDQTtJQUNFLE9BQU87SUFDUCxNQUFNO0lBQ04sTUFBTTtJQUNOLFFBQVE7SUFDUixVQUFVO0lBQ1YsT0FBTztJQUNQLGFBQWE7R0FDZjtHQUNBO0lBQ0UsT0FBTztJQUNQLE1BQU07SUFDTixNQUFNO0lBQ04sUUFBUTtJQUNSLFVBQVU7SUFDVixPQUFPO0lBQ1AsYUFBYTtHQUNmO0dBQ0E7SUFDRSxPQUFPO0lBQ1AsTUFBTTtJQUNOLE1BQU07SUFDTixRQUFRO0lBQ1IsVUFBVTtJQUNWLE9BQU87SUFDUCxTQUFTO0lBQ1QsYUFBYTtHQUNmO0VBQ0Y7Q0FDRjtDQUNBO0VBQ0UsSUFBSTtFQUNKLE1BQU07RUFDTixTQUFTO0VBQ1QsVUFBVTtFQUNWLE1BQU07RUFDTixNQUFNO0VBQ04sYUFBYTtFQUNiLFlBQVk7RUFDWixRQUFRO0dBQ047SUFDRSxPQUFPO0lBQ1AsTUFBTTtJQUNOLE1BQU07SUFDTixRQUFRO0lBQ1IsVUFBVTtJQUNWLE9BQU87SUFDUCxhQUFhO0dBQ2Y7R0FDQTtJQUNFLE9BQU87SUFDUCxNQUFNO0lBQ04sTUFBTTtJQUNOLFFBQVE7SUFDUixVQUFVO0lBQ1YsT0FBTztJQUNQLGFBQWE7R0FDZjtHQUNBO0lBQ0UsT0FBTztJQUNQLE1BQU07SUFDTixNQUFNO0lBQ04sUUFBUTtJQUNSLFVBQVU7SUFDVixPQUFPO0lBQ1AsYUFBYTtHQUNmO0dBQ0E7SUFDRSxPQUFPO0lBQ1AsTUFBTTtJQUNOLE1BQU07SUFDTixRQUFRO0lBQ1IsVUFBVTtJQUNWLE9BQU87SUFDUCxTQUFTO0lBQ1QsYUFBYTtHQUNmO0VBQ0Y7Q0FDRjtDQUNBO0VBQ0UsSUFBSTtFQUNKLE1BQU07RUFDTixTQUFTO0VBQ1QsVUFBVTtFQUNWLE1BQU07RUFDTixNQUFNO0VBQ04sYUFBYTtFQUNiLFlBQVk7RUFDWixRQUFRO0dBQ047SUFDRSxPQUFPO0lBQ1AsTUFBTTtJQUNOLE1BQU07SUFDTixRQUFRO0lBQ1IsVUFBVTtJQUNWLE9BQU87SUFDUCxhQUFhO0dBQ2Y7R0FDQTtJQUNFLE9BQU87SUFDUCxNQUFNO0lBQ04sTUFBTTtJQUNOLFFBQVE7SUFDUixVQUFVO0lBQ1YsT0FBTztJQUNQLGFBQWE7R0FDZjtHQUNBO0lBQ0UsT0FBTztJQUNQLE1BQU07SUFDTixNQUFNO0lBQ04sUUFBUTtJQUNSLFVBQVU7SUFDVixPQUFPO0lBQ1AsYUFBYTtHQUNmO0dBQ0E7SUFDRSxPQUFPO0lBQ1AsTUFBTTtJQUNOLE1BQU07SUFDTixRQUFRO0lBQ1IsVUFBVTtJQUNWLE9BQU87SUFDUCxTQUFTO0lBQ1QsYUFBYTtHQUNmO0VBQ0Y7Q0FDRjtDQUNBO0VBQ0UsSUFBSTtFQUNKLE1BQU07RUFDTixTQUFTO0VBQ1QsVUFBVTtFQUNWLE1BQU07RUFDTixNQUFNO0VBQ04sYUFBYTtFQUNiLFlBQVk7RUFDWixRQUFRO0dBQ047SUFDRSxPQUFPO0lBQ1AsTUFBTTtJQUNOLE1BQU07SUFDTixRQUFRO0lBQ1IsVUFBVTtJQUNWLE9BQU87SUFDUCxTQUFTO0lBQ1QsYUFBYTtHQUNmO0dBQ0E7SUFDRSxPQUFPO0lBQ1AsTUFBTTtJQUNOLE1BQU07SUFDTixRQUFRO0lBQ1IsVUFBVTtJQUNWLE9BQU87SUFDUCxTQUFTO0lBQ1QsYUFBYTtHQUNmO0dBQ0E7SUFDRSxPQUFPO0lBQ1AsTUFBTTtJQUNOLE1BQU07SUFDTixRQUFRO0lBQ1IsVUFBVTtJQUNWLE9BQU87SUFDUCxTQUFTO0lBQ1QsYUFBYTtHQUNmO0dBQ0E7SUFDRSxPQUFPO0lBQ1AsTUFBTTtJQUNOLE1BQU07SUFDTixRQUFRO0lBQ1IsVUFBVTtJQUNWLE9BQU87SUFDUCxTQUFTO0lBQ1QsYUFBYTtHQUNmO0VBQ0Y7Q0FDRjtDQUNBO0VBQ0UsSUFBSTtFQUNKLE1BQU07RUFDTixTQUFTO0VBQ1QsVUFBVTtFQUNWLE1BQU07RUFDTixNQUFNO0VBQ04sYUFBYTtFQUNiLFlBQVk7RUFDWixRQUFRO0dBQ047SUFDRSxPQUFPO0lBQ1AsTUFBTTtJQUNOLE1BQU07SUFDTixRQUFRO0lBQ1IsVUFBVTtJQUNWLE9BQU87SUFDUCxTQUFTO0lBQ1QsYUFBYTtHQUNmO0dBQ0E7SUFDRSxPQUFPO0lBQ1AsTUFBTTtJQUNOLE1BQU07SUFDTixRQUFRO0lBQ1IsVUFBVTtJQUNWLE9BQU87SUFDUCxTQUFTO0lBQ1QsYUFBYTtHQUNmO0dBQ0E7SUFDRSxPQUFPO0lBQ1AsTUFBTTtJQUNOLE1BQU07SUFDTixRQUFRO0lBQ1IsVUFBVTtJQUNWLE9BQU87SUFDUCxTQUFTO0lBQ1QsYUFBYTtHQUNmO0dBQ0E7SUFDRSxPQUFPO0lBQ1AsTUFBTTtJQUNOLE1BQU07SUFDTixRQUFRO0lBQ1IsVUFBVTtJQUNWLE9BQU87SUFDUCxTQUFTO0lBQ1QsYUFBYTtHQUNmO0VBQ0Y7Q0FDRjtDQUNBO0VBQ0UsSUFBSTtFQUNKLE1BQU07RUFDTixTQUFTO0VBQ1QsVUFBVTtFQUNWLE1BQU07RUFDTixNQUFNO0VBQ04sYUFBYTtFQUNiLFlBQVk7RUFDWixRQUFRO0dBQ047SUFDRSxPQUFPO0lBQ1AsTUFBTTtJQUNOLE1BQU07SUFDTixRQUFRO0lBQ1IsVUFBVTtJQUNWLE9BQU87SUFDUCxhQUFhO0dBQ2Y7R0FDQTtJQUNFLE9BQU87SUFDUCxNQUFNO0lBQ04sTUFBTTtJQUNOLFFBQVE7SUFDUixVQUFVO0lBQ1YsT0FBTztJQUNQLGFBQWE7R0FDZjtHQUNBO0lBQ0UsT0FBTztJQUNQLE1BQU07SUFDTixNQUFNO0lBQ04sUUFBUTtJQUNSLFVBQVU7SUFDVixPQUFPO0lBQ1AsU0FBUztJQUNULGFBQWE7R0FDZjtHQUNBO0lBQ0UsT0FBTztJQUNQLE1BQU07SUFDTixNQUFNO0lBQ04sUUFBUTtJQUNSLFVBQVU7SUFDVixPQUFPO0lBQ1AsU0FBUztJQUNULGFBQWE7R0FDZjtFQUNGO0NBQ0Y7Q0FDQTtFQUNFLElBQUk7RUFDSixNQUFNO0VBQ04sU0FBUztFQUNULFVBQVU7RUFDVixNQUFNO0VBQ04sTUFBTTtFQUNOLGFBQWE7RUFDYixZQUFZO0VBQ1osUUFBUTtHQUNOO0lBQ0UsT0FBTztJQUNQLE1BQU07SUFDTixNQUFNO0lBQ04sUUFBUTtJQUNSLFVBQVU7SUFDVixPQUFPO0lBQ1AsU0FBUztJQUNULGFBQWE7R0FDZjtHQUNBO0lBQ0UsT0FBTztJQUNQLE1BQU07SUFDTixNQUFNO0lBQ04sUUFBUTtJQUNSLFVBQVU7SUFDVixPQUFPO0lBQ1AsYUFBYTtHQUNmO0dBQ0E7SUFDRSxPQUFPO0lBQ1AsTUFBTTtJQUNOLE1BQU07SUFDTixRQUFRO0lBQ1IsVUFBVTtJQUNWLE9BQU87SUFDUCxTQUFTO0lBQ1QsYUFBYTtHQUNmO0dBQ0E7SUFDRSxPQUFPO0lBQ1AsTUFBTTtJQUNOLE1BQU07SUFDTixRQUFRO0lBQ1IsVUFBVTtJQUNWLE9BQU87SUFDUCxTQUFTO0lBQ1QsYUFBYTtHQUNmO0VBQ0Y7Q0FDRjtDQUNBO0VBQ0UsSUFBSTtFQUNKLE1BQU07RUFDTixTQUFTO0VBQ1QsVUFBVTtFQUNWLE1BQU07RUFDTixNQUFNO0VBQ04sYUFBYTtFQUNiLFlBQVk7RUFDWixRQUFRO0dBQ047SUFDRSxPQUFPO0lBQ1AsTUFBTTtJQUNOLE1BQU07SUFDTixRQUFRO0lBQ1IsVUFBVTtJQUNWLE9BQU87SUFDUCxTQUFTO0lBQ1QsYUFBYTtHQUNmO0dBQ0E7SUFDRSxPQUFPO0lBQ1AsTUFBTTtJQUNOLE1BQU07SUFDTixRQUFRO0lBQ1IsVUFBVTtJQUNWLE9BQU87SUFDUCxTQUFTO0lBQ1QsYUFBYTtHQUNmO0dBQ0E7SUFDRSxPQUFPO0lBQ1AsTUFBTTtJQUNOLE1BQU07SUFDTixRQUFRO0lBQ1IsVUFBVTtJQUNWLE9BQU87SUFDUCxTQUFTO0lBQ1QsYUFBYTtHQUNmO0dBQ0E7SUFDRSxPQUFPO0lBQ1AsTUFBTTtJQUNOLE1BQU07SUFDTixRQUFRO0lBQ1IsVUFBVTtJQUNWLE9BQU87SUFDUCxTQUFTO0lBQ1QsYUFBYTtHQUNmO0VBQ0Y7Q0FDRjtDQUNBO0VBQ0UsSUFBSTtFQUNKLE1BQU07RUFDTixTQUFTO0VBQ1QsVUFBVTtFQUNWLE1BQU07RUFDTixNQUFNO0VBQ04sYUFBYTtFQUNiLFlBQVk7RUFDWixRQUFRO0dBQ047SUFDRSxPQUFPO0lBQ1AsTUFBTTtJQUNOLE1BQU07SUFDTixRQUFRO0lBQ1IsVUFBVTtJQUNWLE9BQU87SUFDUCxTQUFTO0lBQ1QsYUFBYTtHQUNmO0dBQ0E7SUFDRSxPQUFPO0lBQ1AsTUFBTTtJQUNOLE1BQU07SUFDTixRQUFRO0lBQ1IsVUFBVTtJQUNWLE9BQU87SUFDUCxTQUFTO0lBQ1QsYUFBYTtHQUNmO0dBQ0E7SUFDRSxPQUFPO0lBQ1AsTUFBTTtJQUNOLE1BQU07SUFDTixRQUFRO0lBQ1IsVUFBVTtJQUNWLE9BQU87SUFDUCxTQUFTO0lBQ1QsYUFBYTtHQUNmO0dBQ0E7SUFDRSxPQUFPO0lBQ1AsTUFBTTtJQUNOLE1BQU07SUFDTixRQUFRO0lBQ1IsVUFBVTtJQUNWLE9BQU87SUFDUCxTQUFTO0lBQ1QsYUFBYTtHQUNmO0VBQ0Y7Q0FDRjtDQUNBO0VBQ0UsSUFBSTtFQUNKLE1BQU07RUFDTixTQUFTO0VBQ1QsVUFBVTtFQUNWLE1BQU07RUFDTixNQUFNO0VBQ04sYUFBYTtFQUNiLFlBQVk7RUFDWixRQUFRO0dBQ047SUFDRSxPQUFPO0lBQ1AsTUFBTTtJQUNOLE1BQU07SUFDTixRQUFRO0lBQ1IsVUFBVTtJQUNWLE9BQU87SUFDUCxTQUFTO0lBQ1QsYUFBYTtHQUNmO0dBQ0E7SUFDRSxPQUFPO0lBQ1AsTUFBTTtJQUNOLE1BQU07SUFDTixRQUFRO0lBQ1IsVUFBVTtJQUNWLE9BQU87SUFDUCxTQUFTO0lBQ1QsYUFBYTtHQUNmO0dBQ0E7SUFDRSxPQUFPO0lBQ1AsTUFBTTtJQUNOLE1BQU07SUFDTixRQUFRO0lBQ1IsVUFBVTtJQUNWLE9BQU87SUFDUCxTQUFTO0lBQ1QsYUFBYTtHQUNmO0dBQ0E7SUFDRSxPQUFPO0lBQ1AsTUFBTTtJQUNOLE1BQU07SUFDTixRQUFRO0lBQ1IsVUFBVTtJQUNWLE9BQU87SUFDUCxTQUFTO0lBQ1QsYUFBYTtHQUNmO0VBQ0Y7Q0FDRjtBQUNGO0FBRUEsT0FBTyxNQUFNLGFBQXFCO0NBQ2hDO0VBQ0UsSUFBSTtFQUNKLFNBQVM7RUFDVCxNQUFNO0VBQ04sUUFBUTtFQUNSLFdBQVc7RUFDWCxVQUFVO0VBQ1YsT0FBTztFQUNQLGFBQWE7RUFDYixZQUFZO0NBQ2Q7Q0FDQTtFQUNFLElBQUk7RUFDSixTQUFTO0VBQ1QsTUFBTTtFQUNOLFFBQVE7RUFDUixXQUFXO0VBQ1gsVUFBVTtFQUNWLGFBQWE7RUFDYixZQUFZO0NBQ2Q7Q0FDQTtFQUNFLElBQUk7RUFDSixTQUFTO0VBQ1QsTUFBTTtFQUNOLFFBQVE7RUFDUixXQUFXO0VBQ1gsVUFBVTtFQUNWLGFBQWE7RUFDYixZQUFZO0NBQ2Q7Q0FDQTtFQUNFLElBQUk7RUFDSixTQUFTO0VBQ1QsTUFBTTtFQUNOLFFBQVE7RUFDUixXQUFXO0VBQ1gsVUFBVTtFQUNWLGFBQWE7RUFDYixZQUFZO0NBQ2Q7Q0FDQTtFQUNFLElBQUk7RUFDSixTQUFTO0VBQ1QsTUFBTTtFQUNOLFFBQVE7RUFDUixXQUFXO0VBQ1gsVUFBVTtFQUNWLGFBQWE7RUFDYixZQUFZO0NBQ2Q7Q0FDQTtFQUNFLElBQUk7RUFDSixTQUFTO0VBQ1QsTUFBTTtFQUNOLFFBQVE7RUFDUixXQUFXO0VBQ1gsVUFBVTtFQUNWLGFBQWE7RUFDYixZQUFZO0NBQ2Q7QUFDRjtBQUVBLE9BQU8sTUFBTSxvQkFBbUM7Q0FDOUM7RUFDRSxJQUFJO0VBQ0osT0FBTztFQUNQLGFBQWE7RUFDYixNQUFNO0VBQ04sYUFBYTtFQUNiLFlBQVk7RUFDWixVQUFVO0VBQ1YsYUFBYTtFQUNiLFNBQVM7Q0FDWDtDQUNBO0VBQ0UsSUFBSTtFQUNKLE9BQU87RUFDUCxhQUFhO0VBQ2IsTUFBTTtFQUNOLGFBQWE7RUFDYixZQUFZO0VBQ1osVUFBVTtFQUNWLGFBQWE7RUFDYixTQUFTO0NBQ1g7Q0FDQTtFQUNFLElBQUk7RUFDSixPQUFPO0VBQ1AsYUFBYTtFQUNiLE1BQU07RUFDTixhQUFhO0VBQ2IsWUFBWTtFQUNaLFVBQVU7RUFDVixhQUFhO0VBQ2IsU0FBUztDQUNYO0NBQ0E7RUFDRSxJQUFJO0VBQ0osT0FBTztFQUNQLGFBQWE7RUFDYixNQUFNO0VBQ04sYUFBYTtFQUNiLFlBQVk7RUFDWixVQUFVO0VBQ1YsYUFBYTtFQUNiLFNBQVM7Q0FDWDtDQUNBO0VBQ0UsSUFBSTtFQUNKLE9BQU87RUFDUCxhQUFhO0VBQ2IsTUFBTTtFQUNOLGFBQWE7RUFDYixZQUFZO0VBQ1osVUFBVTtFQUNWLGFBQWE7RUFDYixTQUFTO0NBQ1g7Q0FDQTtFQUNFLElBQUk7RUFDSixPQUFPO0VBQ1AsYUFBYTtFQUNiLE1BQU07RUFDTixhQUFhO0VBQ2IsWUFBWTtFQUNaLFVBQVU7RUFDVixhQUFhO0VBQ2IsU0FBUztDQUNYO0NBQ0E7RUFDRSxJQUFJO0VBQ0osT0FBTztFQUNQLGFBQWE7RUFDYixNQUFNO0VBQ04sYUFBYTtFQUNiLFlBQVk7RUFDWixVQUFVO0VBQ1YsYUFBYTtFQUNiLFNBQVM7Q0FDWDtDQUNBO0VBQ0UsSUFBSTtFQUNKLE9BQU87RUFDUCxhQUFhO0VBQ2IsTUFBTTtFQUNOLGFBQWE7RUFDYixZQUFZO0VBQ1osVUFBVTtFQUNWLGFBQWE7RUFDYixTQUFTO0NBQ1g7QUFDRjtBQUVBLE9BQU8sTUFBTSxnQkFBd0I7Q0FDbkM7RUFDRSxJQUFJO0VBQ0osTUFBTTtFQUNOLEtBQUs7RUFDTCxPQUFPO0VBQ1AsYUFBYTtFQUNiLE9BQU87RUFDUCxJQUFJO0VBQ0osY0FBYztFQUNkLFlBQVk7RUFDWixZQUFZO0VBQ1osYUFBYTtFQUNiLE9BQU87R0FDTCxrQkFBa0I7R0FDbEIsb0JBQW9CO0VBQ3RCO0VBQ0EsYUFBYTtHQUNYLE9BQU87R0FDUCxVQUFVO0dBQ1YsTUFBTTtHQUNOLFlBQVk7RUFDZDtDQUNGO0NBQ0E7RUFDRSxJQUFJO0VBQ0osTUFBTTtFQUNOLEtBQUs7RUFDTCxPQUFPO0VBQ1AsYUFBYTtFQUNiLE9BQU87RUFDUCxJQUFJO0VBQ0osY0FBYztFQUNkLFlBQVk7RUFDWixZQUFZO0VBQ1osYUFBYTtFQUNiLE9BQU87R0FDTCxrQkFBa0I7R0FDbEIsb0JBQW9CO0VBQ3RCO0VBQ0EsYUFBYTtHQUNYLE9BQU87R0FDUCxVQUFVO0dBQ1YsTUFBTTtHQUNOLFlBQVk7RUFDZDtDQUNGO0NBQ0E7RUFDRSxJQUFJO0VBQ0osTUFBTTtFQUNOLEtBQUs7RUFDTCxPQUFPO0VBQ1AsYUFBYTtFQUNiLE9BQU87RUFDUCxJQUFJO0VBQ0osY0FBYztFQUNkLFlBQVk7RUFDWixZQUFZO0VBQ1osYUFBYTtFQUNiLE9BQU87R0FDTCxrQkFBa0I7R0FDbEIsb0JBQW9CO0VBQ3RCO0VBQ0EsYUFBYTtHQUNYLE9BQU87R0FDUCxVQUFVO0dBQ1YsTUFBTTtHQUNOLFlBQVk7RUFDZDtDQUNGO0FBQ0Y7QUFFQSxPQUFPLE1BQU0sd0JBQXlDO0NBQ3BELElBQUk7Q0FDSixPQUFPO0NBQ1AsT0FBTztDQUNQLGFBQWE7Q0FDYixXQUFXO0VBQ1Q7RUFDQTtFQUNBO0VBQ0E7Q0FDRjtDQUNBLGtCQUFrQixDQUFDLE9BQU8sWUFBWTtDQUN0QyxhQUFhO0NBQ2IsWUFBWTtDQUNaLFlBQVk7Q0FDWixZQUFZO0NBQ1osWUFBWTtBQUNkO0FBRUEsT0FBTyxNQUFNLHdCQUE4QztDQUN6RDtFQUNFLElBQUk7RUFDSixPQUFPO0VBQ1AsU0FBUztFQUNULE1BQU07RUFDTixXQUFXO0VBQ1gsTUFBTTtFQUNOLE9BQU87Q0FDVDtDQUNBO0VBQ0UsSUFBSTtFQUNKLE9BQU87RUFDUCxTQUFTO0VBQ1QsTUFBTTtFQUNOLFdBQVc7RUFDWCxNQUFNO0VBQ04sT0FBTztDQUNUO0NBQ0E7RUFDRSxJQUFJO0VBQ0osT0FBTztFQUNQLFNBQVM7RUFDVCxNQUFNO0VBQ04sV0FBVztFQUNYLE1BQU07Q0FDUjtBQUNGO0FBRUEsT0FBTyxNQUFNLHdCQUF3QjtDQUNuQztFQUFFLEtBQUs7RUFBRyxPQUFPO0VBQUssTUFBTTtFQUFJLE9BQU87RUFBVSxNQUFNO0NBQUs7Q0FDNUQ7RUFBRSxLQUFLO0VBQUcsT0FBTztFQUFLLE1BQU07RUFBSSxPQUFPO0VBQVUsTUFBTTtDQUFLO0NBQzVEO0VBQUUsS0FBSztFQUFHLE9BQU87RUFBSyxNQUFNO0VBQUksT0FBTztFQUFVLE1BQU07Q0FBSztDQUM1RDtFQUFFLEtBQUs7RUFBRyxPQUFPO0VBQU0sTUFBTTtFQUFJLE9BQU87RUFBVSxNQUFNO0NBQUk7Q0FDNUQ7RUFBRSxLQUFLO0VBQUcsT0FBTztFQUFNLE1BQU07RUFBSSxPQUFPO0VBQVUsTUFBTTtDQUFLO0NBQzdEO0VBQUUsS0FBSztFQUFHLE9BQU87RUFBTSxNQUFNO0VBQUssT0FBTztFQUFVLE1BQU07Q0FBSztDQUM5RDtFQUFFLEtBQUs7RUFBRyxPQUFPO0VBQU0sTUFBTTtFQUFLLGFBQWE7RUFBaUIsT0FBTztFQUF1QixNQUFNO0NBQUs7QUFDM0ciLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiY29uc3RhbnRzLnRzIl0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IFRvd2VyRGVmaW5pdGlvbiwgU2tpbiwgQWNoaWV2ZW1lbnQsIFdlZWtseUNoYWxsZW5nZSwgQ2xhbiwgSW5HYW1lTm90aWZpY2F0aW9uIH0gZnJvbSAnLi4vdHlwZXMvZ2FtZSc7XG5cbmV4cG9ydCBjb25zdCBDQVRfSU1BR0VfVVJMID0gJy9hc3NldHMvYWlzdHVkaW8vNWRjYmUzODQtMzdjZC00ZjczLWIyOTctNWIyNWZkYWJjZTk1XzlkYzk1YWNiLmpwZyc7XG5cbmV4cG9ydCBjb25zdCBUT1dFUlNfREFUQTogVG93ZXJEZWZpbml0aW9uW10gPSBbXG4gIHtcbiAgICBpZDogJ2NhdCcsXG4gICAgbmFtZTogJ9Cb0LXQs9C10L3QtNCw0YDQvdGL0Lkg0JrQvtGCJyxcbiAgICB0YWdsaW5lOiAn0J3QsNGH0LDQu9GM0L3Ri9C5INCz0LXRgNC+0Lkg0YEg0L/QuNC60YHQtdC70YzQvdGL0LzQuCDQvtGH0LrQsNC80Lgg0Lgg0LvQsNC30LXRgNCw0LzQuCcsXG4gICAgYmFzZUNvc3Q6IDE1MCxcbiAgICB0eXBlOiAnZGFtYWdlJyxcbiAgICBpY29uOiAn8J+QsScsXG4gICAgaW1hZ2U6IENBVF9JTUFHRV9VUkwsXG4gICAgYnVsbGV0Q29sb3I6ICcjMzhiZGY4JyxcbiAgICBidWxsZXRUeXBlOiAnbGFzZXInLFxuICAgIGxldmVsczogW1xuICAgICAge1xuICAgICAgICBsZXZlbDogMCxcbiAgICAgICAgbmFtZTogJ9Ca0L7RgiDQsiDQntGH0LrQsNGFICjQkdCw0LfQvtCy0YvQuSknLFxuICAgICAgICBjb3N0OiAxNTAsXG4gICAgICAgIGRhbWFnZTogNSxcbiAgICAgICAgZmlyZVJhdGU6IDAuNTUsIC8vINCj0LvRg9GH0YjQtdC90L3QsNGPINGB0LrQvtGA0L7RgdGC0YDQtdC70YzQvdC+0YHRgtGMOiDQv9GD0LvQtdC80LXRgtC90YvQuSDQu9Cw0LfQtdGAIVxuICAgICAgICByYW5nZTogNzAsIC8vIH44LjUg0LzQtdGC0YDQvtCyXG4gICAgICAgIGRlc2NyaXB0aW9uOiAn0KHRgtGA0LXQu9GP0LXRgiDRgdC60L7RgNC+0YHRgtC90YvQvNC4INC/0LjQutGB0LXQu9GM0L3Ri9C80Lgg0LvRg9GH0LDQvNC4LiDQo9GA0L7QvTogNSAvINCy0YvRgdGC0YDQtdC7LCDQlNCw0LvRjNC90L7RgdGC0Yw6IDjQvCcsXG4gICAgICB9LFxuICAgICAge1xuICAgICAgICBsZXZlbDogMSxcbiAgICAgICAgbmFtZTogJ9Ca0L7RgiAxLdC5INCj0YDQvtCy0LXQvdGMJyxcbiAgICAgICAgY29zdDogMzAwLCAvLyDQn9C+INCi0Jc6INGD0LvRg9GH0YjQtdC90LjQtSDRgdGC0L7QuNGCIDMwMCDQtNC+0LvQu9Cw0YDQvtCyXG4gICAgICAgIGRhbWFnZTogNyxcbiAgICAgICAgZmlyZVJhdGU6IDAuNSwgLy8gNyDRg9GA0L7QvdCwINC60LDQttC00YvQtSAwLjUg0YHQtdC6ICgxNCBEUFMhKVxuICAgICAgICByYW5nZTogOTAsIC8vIDEwINC80LXRgtGA0L7QslxuICAgICAgICBkZXNjcmlwdGlvbjogJ9Cj0LvRg9GH0YjQtdC90LjQtSDQt9CwICQzMDAhIDcg0YPRgNC+0L3QsCAo0YHQutC+0YDQvtGB0YLRgNC10LvRjNC90L7RgdGC0YwgeDIhKSwg0LTQsNC70YzQvdC+0YHRgtGMIDEwINC80LXRgtGA0L7QsicsXG4gICAgICB9LFxuICAgICAge1xuICAgICAgICBsZXZlbDogMixcbiAgICAgICAgbmFtZTogJ9Ca0L7RgiAyLdC5INCj0YDQvtCy0LXQvdGMICjQnNC10Lwt0JzQsNGB0YLQtdGAKScsXG4gICAgICAgIGNvc3Q6IDc1MCxcbiAgICAgICAgZGFtYWdlOiAyMCxcbiAgICAgICAgZmlyZVJhdGU6IDAuNDUsIC8vIDIwINGD0YDQvtC90LAg0LrQsNC20LTRi9C1IDAuNDUg0YHQtdC6ICg0NCsgRFBTISlcbiAgICAgICAgcmFuZ2U6IDE2NSwgLy8gMjAg0LzQtdGC0YDQvtCyXG4gICAgICAgIGRlc2NyaXB0aW9uOiAn0JzQvtGJ0L3Ri9C5INGB0LrQvtGA0L7RgdGC0L3QvtC5INC60L7RiNCw0YfQuNC5INC30LDQu9C/ISAyMCDRg9GA0L7QvdCwINC30LAg0LLRi9GB0YLRgNC10LssINC00LDQu9GM0L3QvtGB0YLRjCAyMCDQvNC10YLRgNC+0LInLFxuICAgICAgfSxcbiAgICAgIHtcbiAgICAgICAgbGV2ZWw6IDMsXG4gICAgICAgIG5hbWU6ICfQmtC+0YIgMy3QuSDQo9GA0L7QstC10L3RjCAo0JvQtdC00Y/QvdC+0LkgVGh1ZyBMaWZlKScsXG4gICAgICAgIGNvc3Q6IDE2MDAsXG4gICAgICAgIGRhbWFnZTogNTAsXG4gICAgICAgIGZpcmVSYXRlOiAwLjQsIC8vIDUwINGD0YDQvtC90LAg0LrQsNC20LTRi9C1IDAuNCDRgdC10LogKDEyNSBEUFMhKVxuICAgICAgICByYW5nZTogMjQ1LCAvLyAzMCDQvNC10YLRgNC+0LJcbiAgICAgICAgc3BlY2lhbDogJ9Cj0L3QuNC60LDQu9GM0L3QvtC1INCX0LDQvNC10LTQu9C10L3QuNC1ICgtNDAlINGB0LrQvtGA0L7RgdGC0Lgg0LLRgNCw0LPQvtCyINC90LAgMyDRgdC10LopJyxcbiAgICAgICAgZGVzY3JpcHRpb246ICc1MCDRg9GA0L7QvdCwINC30LAg0LLRi9GB0YLRgNC10LsgKNGB0YPQv9C10YDRgdC60L7RgNC+0YHRgtGMKSwg0LTQsNC70YzQvdC+0YHRgtGMIDMwINC80LXRgtGA0L7QsiArINCj0L3QuNC60LDQu9GM0L3QvtC1INC30LDQvNC10LTQu9C10L3QuNC1INC70YzQtNC+0LwhJyxcbiAgICAgIH0sXG4gICAgXSxcbiAgfSxcbiAge1xuICAgIGlkOiAnbm9vYl9rbmlnaHQnLFxuICAgIG5hbWU6ICfQndGD0LEt0KDRi9GG0LDRgNGMJyxcbiAgICB0YWdsaW5lOiAn0JrQu9Cw0YHRgdC40YfQtdGB0LrQuNC5INCy0L7QuNC9IFJvYmxveCDRgSDRgtGP0LbQtdC70YvQvCDQvNC+0LvQvtGC0L7QvCcsXG4gICAgYmFzZUNvc3Q6IDIwMCxcbiAgICB0eXBlOiAnc3BsYXNoJyxcbiAgICBpY29uOiAn8J+Xoe+4jycsXG4gICAgYnVsbGV0Q29sb3I6ICcjZmJiZjI0JyxcbiAgICBidWxsZXRUeXBlOiAnd2F2ZScsXG4gICAgbGV2ZWxzOiBbXG4gICAgICB7XG4gICAgICAgIGxldmVsOiAwLFxuICAgICAgICBuYW1lOiAn0JbQtdC70YLRi9C5INCd0YPQsScsXG4gICAgICAgIGNvc3Q6IDIwMCxcbiAgICAgICAgZGFtYWdlOiAxNSxcbiAgICAgICAgZmlyZVJhdGU6IDAuNjUsIC8vINCR0YvQu9C+IDEuNHMgLT4g0YHRgtCw0LvQviAwLjY1cyAo0LHQvtC70LXQtSDRh9C10Lwg0LIgMiDRgNCw0LfQsCDQsdGL0YHRgtGA0LXQtSEpXG4gICAgICAgIHJhbmdlOiA2NSxcbiAgICAgICAgZGVzY3JpcHRpb246ICfQodC60L7RgNC+0YHRgtC90YvQtSDQutGA0YPQs9C+0LLRi9C1INGD0LTQsNGA0Ysg0LzQvtC70L7RgtC+0Lwg0L/QviDQv9C70L7RidCw0LTQuCcsXG4gICAgICB9LFxuICAgICAge1xuICAgICAgICBsZXZlbDogMSxcbiAgICAgICAgbmFtZTogJ9CR0YDQvtC90LjRgNC+0LLQsNC90L3Ri9C5INCd0YPQsScsXG4gICAgICAgIGNvc3Q6IDQwMCxcbiAgICAgICAgZGFtYWdlOiAzMixcbiAgICAgICAgZmlyZVJhdGU6IDAuNTUsXG4gICAgICAgIHJhbmdlOiA4MCxcbiAgICAgICAgZGVzY3JpcHRpb246ICfQkdGL0YHRgtGA0YvQuSDRgdC/0LvQtdGILdC60YDQuNGCINC/0L4g0YLQvtC70L/QtSDQstGA0LDQs9C+0LInLFxuICAgICAgfSxcbiAgICAgIHtcbiAgICAgICAgbGV2ZWw6IDIsXG4gICAgICAgIG5hbWU6ICfQn9Cw0LvQsNC00LjQvSDQkdC70L7QutGB0LHRg9GA0LPQsCcsXG4gICAgICAgIGNvc3Q6IDk1MCxcbiAgICAgICAgZGFtYWdlOiA3NSxcbiAgICAgICAgZmlyZVJhdGU6IDAuNSxcbiAgICAgICAgcmFuZ2U6IDEwMCxcbiAgICAgICAgZGVzY3JpcHRpb246ICfQntCz0LvRg9GI0LDRjtGJ0LjQtSDQvNC+0LvQvdC40LXQvdC+0YHQvdGL0LUg0YPQtNCw0YDRiyDQvNC+0LvQvtGC0L7QvCcsXG4gICAgICB9LFxuICAgICAge1xuICAgICAgICBsZXZlbDogMyxcbiAgICAgICAgbmFtZTogJ9Cf0L7QstC10LvQuNGC0LXQu9GMINCR0LvQvtC60L7QsicsXG4gICAgICAgIGNvc3Q6IDIxMDAsXG4gICAgICAgIGRhbWFnZTogMTYwLFxuICAgICAgICBmaXJlUmF0ZTogMC40MixcbiAgICAgICAgcmFuZ2U6IDEyMCxcbiAgICAgICAgc3BlY2lhbDogJ9CU0LLQvtC50L3QvtC5INGB0L/Qu9C10Ygg0Lgg0YHRgtCw0L0g0L3QsCAwLjjRgScsXG4gICAgICAgIGRlc2NyaXB0aW9uOiAn0KjQutCy0LDQuyDRgdC+0LrRgNGD0YjQuNGC0LXQu9GM0L3Ri9GFINGD0LTQsNGA0L7QsicsXG4gICAgICB9LFxuICAgIF0sXG4gIH0sXG4gIHtcbiAgICBpZDogJ2N5YmVyX3JhbmdlcicsXG4gICAgbmFtZTogJ9Ca0LjQsdC10YAt0KHQvdCw0LnQv9C10YAnLFxuICAgIHRhZ2xpbmU6ICfQlNCw0LvRjNC90L7QsdC+0LnQvdCw0Y8g0L/Qu9Cw0LfQvNC10L3QvdCw0Y8g0LLQuNC90YLQvtCy0LrQsCcsXG4gICAgYmFzZUNvc3Q6IDI1MCxcbiAgICB0eXBlOiAnZGFtYWdlJyxcbiAgICBpY29uOiAn8J+OrycsXG4gICAgYnVsbGV0Q29sb3I6ICcjZWY0NDQ0JyxcbiAgICBidWxsZXRUeXBlOiAnYnVsbGV0JyxcbiAgICBsZXZlbHM6IFtcbiAgICAgIHtcbiAgICAgICAgbGV2ZWw6IDAsXG4gICAgICAgIG5hbWU6ICfQoNC10LnQvdC00LbQtdGAJyxcbiAgICAgICAgY29zdDogMjUwLFxuICAgICAgICBkYW1hZ2U6IDQ1LFxuICAgICAgICBmaXJlUmF0ZTogMS4wLCAvLyDQkdGL0LvQviAyLjJzIC0+INGB0YLQsNC70L4gMS4wcyAo0LHQvtC70LXQtSDRh9C10Lwg0LIgMiDRgNCw0LfQsCDQsdGL0YHRgtGA0LXQtSEpXG4gICAgICAgIHJhbmdlOiAyMDAsXG4gICAgICAgIGRlc2NyaXB0aW9uOiAn0KHQutC+0YDQvtGB0YLRgNC10LvRjNC90LDRjyDQtNCw0LvRjNC90L7QsdC+0LnQvdCw0Y8g0L/Qu9Cw0LfQvNC10L3QvdCw0Y8g0LLQuNC90YLQvtCy0LrQsCcsXG4gICAgICB9LFxuICAgICAge1xuICAgICAgICBsZXZlbDogMSxcbiAgICAgICAgbmFtZTogJ9Ct0LvQuNGC0L3Ri9C5INCc0LXRgtC60LjQuSDQodGC0YDQtdC70L7QuicsXG4gICAgICAgIGNvc3Q6IDUwMCxcbiAgICAgICAgZGFtYWdlOiA5NSxcbiAgICAgICAgZmlyZVJhdGU6IDAuODUsXG4gICAgICAgIHJhbmdlOiAyNDAsXG4gICAgICAgIGRlc2NyaXB0aW9uOiAn0JHRgNC+0L3QtdCx0L7QudC90YvQtSDQvtGH0LXRgNC10LTQuCDQv9C+INCx0L7RgdGB0LDQvCcsXG4gICAgICB9LFxuICAgICAge1xuICAgICAgICBsZXZlbDogMixcbiAgICAgICAgbmFtZTogJ9Ca0LLQsNC90YLQvtCy0YvQuSDQodC90LDQudC/0LXRgCcsXG4gICAgICAgIGNvc3Q6IDExMDAsXG4gICAgICAgIGRhbWFnZTogMjEwLFxuICAgICAgICBmaXJlUmF0ZTogMC43NSxcbiAgICAgICAgcmFuZ2U6IDI5MCxcbiAgICAgICAgZGVzY3JpcHRpb246ICfQmtCy0LDQvdGC0L7QstGL0Lkg0YHQutC+0YDQvtGB0YLRgNC10LvRjNC90YvQuSDQu9Cw0LfQtdGAJyxcbiAgICAgIH0sXG4gICAgICB7XG4gICAgICAgIGxldmVsOiAzLFxuICAgICAgICBuYW1lOiAn0J7RgNCx0LjRgtCw0LvRjNC90LDRjyDQn9GD0YjQutCwJyxcbiAgICAgICAgY29zdDogMjYwMCxcbiAgICAgICAgZGFtYWdlOiA1MjAsXG4gICAgICAgIGZpcmVSYXRlOiAwLjY1LFxuICAgICAgICByYW5nZTogMzYwLFxuICAgICAgICBzcGVjaWFsOiAn0JzQs9C90L7QstC10L3QvdGL0Lkg0L/RgNC+0LHQvtC5INGJ0LjRgtC+0LIg0LHQvtGB0YHQvtCyJyxcbiAgICAgICAgZGVzY3JpcHRpb246ICfQndC10L/RgNC10YDRi9Cy0L3Ri9C5INC+0YDQsdC40YLQsNC70YzQvdGL0Lkg0LvQsNC30LXRgNC90YvQuSDQvtCz0L7QvdGMJyxcbiAgICAgIH0sXG4gICAgXSxcbiAgfSxcbiAge1xuICAgIGlkOiAnZGpfYmxveCcsXG4gICAgbmFtZTogJ0RKINCR0LvQvtC60YEnLFxuICAgIHRhZ2xpbmU6ICfQoNC40YLQvC3Qs9C10L3QtdGA0LDRgtC+0YAsINGD0YHQutC+0YDRj9GO0YnQuNC5INC4INGD0YHQuNC70LjQstCw0Y7RidC40Lkg0YHQvtGO0LfQvdC40LrQvtCyJyxcbiAgICBiYXNlQ29zdDogMzAwLFxuICAgIHR5cGU6ICdzdXBwb3J0JyxcbiAgICBpY29uOiAn8J+OpycsXG4gICAgYnVsbGV0Q29sb3I6ICcjYTg1NWY3JyxcbiAgICBidWxsZXRUeXBlOiAnd2F2ZScsXG4gICAgbGV2ZWxzOiBbXG4gICAgICB7XG4gICAgICAgIGxldmVsOiAwLFxuICAgICAgICBuYW1lOiAn0J3QsNGH0LjQvdCw0Y7RidC40Lkg0JTQuNC00LbQtdC5JyxcbiAgICAgICAgY29zdDogMzAwLFxuICAgICAgICBkYW1hZ2U6IDUsXG4gICAgICAgIGZpcmVSYXRlOiAwLjQ1LCAvLyDQkdGL0LvQviAwLjhzXG4gICAgICAgIHJhbmdlOiAxMjAsXG4gICAgICAgIHNwZWNpYWw6ICfQkNGD0YDQsDogKzI1JSDRg9GA0L7QvdCwINCx0LDRiNC90Y/QvCDRgNGP0LTQvtC8JyxcbiAgICAgICAgZGVzY3JpcHRpb246ICfQodC+0LfQtNCw0LXRgiDQt9Cy0YPQutC+0LLRi9C1INCy0L7Qu9C90Ysg0Lgg0YPRgdC40LvQuNCy0LDQtdGCINGB0L7RgdC10LTQvdC40LUg0LHQsNGI0L3QuCcsXG4gICAgICB9LFxuICAgICAge1xuICAgICAgICBsZXZlbDogMSxcbiAgICAgICAgbmFtZTogJ9Ca0LvRg9Cx0L3Ri9C5INCR0LjRgtC80LXQudC60LXRgCcsXG4gICAgICAgIGNvc3Q6IDYwMCxcbiAgICAgICAgZGFtYWdlOiAxMixcbiAgICAgICAgZmlyZVJhdGU6IDAuNCxcbiAgICAgICAgcmFuZ2U6IDE1MCxcbiAgICAgICAgc3BlY2lhbDogJ9CQ0YPRgNCwOiArMzUlINGD0YDQvtC90LAg0LggKzI1JSDRgdC60L7RgNC+0YHRgtC4INCw0YLQsNC60LgnLFxuICAgICAgICBkZXNjcmlwdGlvbjogJ9Cc0L7RidC90YvQuSDQsdC40YIg0YPRgdC60L7RgNGP0LXRgiDRgdC+0Y7Qt9C90LjQutC+0LIg0LLQtNCy0L7QtScsXG4gICAgICB9LFxuICAgICAge1xuICAgICAgICBsZXZlbDogMixcbiAgICAgICAgbmFtZTogJ9CX0LLQtdC30LTQsCBFRE0g0KTQtdGB0YLQuNCy0LDQu9GPJyxcbiAgICAgICAgY29zdDogMTMwMCxcbiAgICAgICAgZGFtYWdlOiAyOCxcbiAgICAgICAgZmlyZVJhdGU6IDAuMzUsXG4gICAgICAgIHJhbmdlOiAxODAsXG4gICAgICAgIHNwZWNpYWw6ICfQkNGD0YDQsDogKzUwJSDRg9GA0L7QvdCwINC4ICszMCUg0LTQsNC70YzQvdC+0YHRgtC4JyxcbiAgICAgICAgZGVzY3JpcHRpb246ICfQodCy0LXRgtC+0LzRg9C30YvQutCwINC4INGB0LjQvdGF0YDQvtC90LjQt9C40YDQvtCy0LDQvdC90YvQtSDQt9Cw0LvQv9GLJyxcbiAgICAgIH0sXG4gICAgICB7XG4gICAgICAgIGxldmVsOiAzLFxuICAgICAgICBuYW1lOiAn0JvQtdCz0LXQvdC00LDRgNC90YvQuSDQoNC+0LHQu9C+0LrRgSBESicsXG4gICAgICAgIGNvc3Q6IDI4MDAsXG4gICAgICAgIGRhbWFnZTogNjAsXG4gICAgICAgIGZpcmVSYXRlOiAwLjI4LFxuICAgICAgICByYW5nZTogMjIwLFxuICAgICAgICBzcGVjaWFsOiAn0JzQtdCz0LAt0LHQsNGBOiDQsdCw0YjQvdC4INGB0YLRgNC10LvRj9GO0YIg0L3QsCA3MCUg0LHRi9GB0YLRgNC10LUhJyxcbiAgICAgICAgZGVzY3JpcHRpb246ICfQo9C70YzRgtC40LzQsNGC0LjQstC90YvQuSDRg9GB0LjQu9C40YLQtdC70Ywg0LLRgdC10Lkg0LrQvtC80LDQvdC00Ysg0LIg0LrQvtC+0L/QtScsXG4gICAgICB9LFxuICAgIF0sXG4gIH0sXG4gIHtcbiAgICBpZDogJ2Jhbmtlcl9jYXQnLFxuICAgIG5hbWU6ICfQmtC+0YIt0JHQsNC90LrQuNGAJyxcbiAgICB0YWdsaW5lOiAn0KTQuNC90LDQvdGB0L7QstGL0Lkg0LzQsNCz0L3QsNGCLCDQv9GA0LjQvdC+0YHRj9GJ0LjQuSDQt9C+0LvQvtGC0L4g0LrQsNC20LTRg9GOINCy0L7Qu9C90YMnLFxuICAgIGJhc2VDb3N0OiAyMjAsXG4gICAgdHlwZTogJ2Vjb25vbXknLFxuICAgIGljb246ICfwn5KwJyxcbiAgICBidWxsZXRDb2xvcjogJyMxMGI5ODEnLFxuICAgIGJ1bGxldFR5cGU6ICdjb2luJyxcbiAgICBsZXZlbHM6IFtcbiAgICAgIHtcbiAgICAgICAgbGV2ZWw6IDAsXG4gICAgICAgIG5hbWU6ICfQodCy0LjQvdGM0Y8t0JrQvtC/0LjQu9C60LAnLFxuICAgICAgICBjb3N0OiAyMjAsXG4gICAgICAgIGRhbWFnZTogMCxcbiAgICAgICAgZmlyZVJhdGU6IDIuMCxcbiAgICAgICAgcmFuZ2U6IDcwLFxuICAgICAgICBzcGVjaWFsOiAnKyQxMjAg0LIg0LrQvtC90YbQtSDQutCw0LbQtNC+0Lkg0LLQvtC70L3RiycsXG4gICAgICAgIGRlc2NyaXB0aW9uOiAn0J/RgNC40L3QvtGB0LjRgiDRg9Cy0LXQu9C40YfQtdC90L3Ri9C5INC/0LDRgdGB0LjQstC90YvQuSDQtNC+0YXQvtC0INCyINC00L7Qu9C70LDRgNCw0YUnLFxuICAgICAgfSxcbiAgICAgIHtcbiAgICAgICAgbGV2ZWw6IDEsXG4gICAgICAgIG5hbWU6ICfQl9C+0LvQvtGC0L7QuSDQkdCw0L3QutC+0LzQsNGCJyxcbiAgICAgICAgY29zdDogNDUwLFxuICAgICAgICBkYW1hZ2U6IDAsXG4gICAgICAgIGZpcmVSYXRlOiAyLjAsXG4gICAgICAgIHJhbmdlOiA4MCxcbiAgICAgICAgc3BlY2lhbDogJyskMzAwINCyINC60L7QvdGG0LUg0LrQsNC20LTQvtC5INCy0L7Qu9C90YsnLFxuICAgICAgICBkZXNjcmlwdGlvbjogJ9Cj0YLRgNC+0LXQvdC90YvQuSDQtNC10L3QtdC20L3Ri9C5INC/0L7RgtC+0LonLFxuICAgICAgfSxcbiAgICAgIHtcbiAgICAgICAgbGV2ZWw6IDIsXG4gICAgICAgIG5hbWU6ICfQmtGA0LjQv9GC0L4t0KTQtdGA0LzQsCDQkdC70L7QutGB0LgnLFxuICAgICAgICBjb3N0OiAxMDAwLFxuICAgICAgICBkYW1hZ2U6IDAsXG4gICAgICAgIGZpcmVSYXRlOiAyLjAsXG4gICAgICAgIHJhbmdlOiA5MCxcbiAgICAgICAgc3BlY2lhbDogJyskNzUwINCyINC60L7QvdGG0LUg0LLQvtC70L3RiyArIDUg0LDQu9C80LDQt9C+0LIg0LfQsCDQv9C+0LHQtdC00YMnLFxuICAgICAgICBkZXNjcmlwdGlvbjogJ9Cc0LDQudC90LjRgiDQstCw0LvRjtGC0YMg0L/RgNGP0LzQviDQvdCwINC/0L7Qu9C1INCx0L7RjycsXG4gICAgICB9LFxuICAgICAge1xuICAgICAgICBsZXZlbDogMyxcbiAgICAgICAgbmFtZTogJ9Cj0L7Qu9C7LdCh0YLRgNC40YIg0JrQvtGA0L/QvtGA0LDRhtC40Y8nLFxuICAgICAgICBjb3N0OiAyMjAwLFxuICAgICAgICBkYW1hZ2U6IDAsXG4gICAgICAgIGZpcmVSYXRlOiAyLjAsXG4gICAgICAgIHJhbmdlOiAxMDAsXG4gICAgICAgIHNwZWNpYWw6ICcrJDE2MDAg0LIg0LrQvtC90YbQtSDQstC+0LvQvdGLICsg0LrQtdGI0LHRjdC6IDIwJSDQvdCwINC/0L7QutGD0L/QutC4INCx0LDRiNC10L0nLFxuICAgICAgICBkZXNjcmlwdGlvbjogJ9Ck0LjQvdCw0L3RgdC+0LLQsNGPINC80LXQs9CwLdC40LzQv9C10YDQuNGPINC00LvRjyDQu9C10LPQutC+0Lkg0L/QvtCx0LXQtNGLJyxcbiAgICAgIH0sXG4gICAgXSxcbiAgfSxcbiAge1xuICAgIGlkOiAnZmxhbWV0aHJvd2VyX25vb2InLFxuICAgIG5hbWU6ICfQntCz0L3QtdC80LXRgtGH0LjQuiDQkdC70L7QutGBJyxcbiAgICB0YWdsaW5lOiAn0J3QtdC/0YDQtdGA0YvQstC90YvQuSDQv9C+0YLQvtC6INGA0LDRgdC60LDQu9C10L3QvdC+0LPQviDQv9C70LDQvNC10L3QuCcsXG4gICAgYmFzZUNvc3Q6IDI4MCxcbiAgICB0eXBlOiAnc3BsYXNoJyxcbiAgICBpY29uOiAn8J+UpScsXG4gICAgYnVsbGV0Q29sb3I6ICcjZjk3MzE2JyxcbiAgICBidWxsZXRUeXBlOiAnZmlyZScsXG4gICAgbGV2ZWxzOiBbXG4gICAgICB7XG4gICAgICAgIGxldmVsOiAwLFxuICAgICAgICBuYW1lOiAn0J3QvtCy0LjRh9C+0Lot0J/QuNGA0L7RgtC10YXQvdC40LonLFxuICAgICAgICBjb3N0OiAyODAsXG4gICAgICAgIGRhbWFnZTogNyxcbiAgICAgICAgZmlyZVJhdGU6IDAuMTUsIC8vINCR0LXRiNC10L3QsNGPINC/0YPQu9C10LzQtdGC0L3QsNGPINGB0LrQvtGA0L7RgdGC0Ywg0L/QvtGC0L7QutCwINC+0LPQvdGPIVxuICAgICAgICByYW5nZTogODAsXG4gICAgICAgIGRlc2NyaXB0aW9uOiAn0KHRgtGA0YPRjyDQvtCz0L3Rjywg0LjRgdC/0LXQv9C10LvRj9GO0YnQsNGPINCz0YDRg9C/0L/RiyDQstGA0LDQs9C+0LIg0L3QsCDQv9C10YDQtdC00L7QstC+0LknLFxuICAgICAgfSxcbiAgICAgIHtcbiAgICAgICAgbGV2ZWw6IDEsXG4gICAgICAgIG5hbWU6ICfQntCz0L3QtdC80LXRgtGH0LjQuiDQktC10YLQtdGA0LDQvScsXG4gICAgICAgIGNvc3Q6IDQ4MCxcbiAgICAgICAgZGFtYWdlOiAxNSxcbiAgICAgICAgZmlyZVJhdGU6IDAuMTIsXG4gICAgICAgIHJhbmdlOiA5NSxcbiAgICAgICAgZGVzY3JpcHRpb246ICfQqNC40YDQvtC60LjQuSDQutC+0L3Rg9GBINC/0LvQsNC80LXQvdC4INC/0L7QstGL0YjQtdC90L3QvtC5INGC0LXQvNC/0LXRgNCw0YLRg9GA0YsnLFxuICAgICAgfSxcbiAgICAgIHtcbiAgICAgICAgbGV2ZWw6IDIsXG4gICAgICAgIG5hbWU6ICfQndCw0L/QsNC70LzQvtCy0YvQuSDQqNGC0YPRgNC80L7QstC40LonLFxuICAgICAgICBjb3N0OiAxMTAwLFxuICAgICAgICBkYW1hZ2U6IDM0LFxuICAgICAgICBmaXJlUmF0ZTogMC4xMCxcbiAgICAgICAgcmFuZ2U6IDExNSxcbiAgICAgICAgc3BlY2lhbDogJ9Cd0LDQv9Cw0LvQvDog0LPQvtGA0LXQvdC40LUg0LLRgNCw0LPQvtCyINC/0YDQvtC00L7Qu9C20LDQtdGC0YHRjyAyINGB0LXQutGD0L3QtNGLJyxcbiAgICAgICAgZGVzY3JpcHRpb246ICfQl9Cw0LvQuNCy0LDQtdGCINC00L7RgNC+0LPRgyDQttC40LTQutC40Lwg0L7Qs9C90LXQvCcsXG4gICAgICB9LFxuICAgICAge1xuICAgICAgICBsZXZlbDogMyxcbiAgICAgICAgbmFtZTogJ9CY0L3RhNC10YDQvdC+LdCi0LjRgtCw0L0nLFxuICAgICAgICBjb3N0OiAyNDAwLFxuICAgICAgICBkYW1hZ2U6IDc4LFxuICAgICAgICBmaXJlUmF0ZTogMC4wOCxcbiAgICAgICAgcmFuZ2U6IDEzNSxcbiAgICAgICAgc3BlY2lhbDogJ9Cb0LDQstC+0LLRi9C5INCy0LfRgNGL0LIgKyDRgNCw0YHQv9C70LDQstC70LXQvdC40LUg0LHRgNC+0L3QuCDQsdC+0YHRgdC+0LInLFxuICAgICAgICBkZXNjcmlwdGlvbjogJ9Cj0LvRjNGC0LjQvNCw0YLQuNCy0L3QvtC1INC+0YfQuNGJ0LXQvdC40LUg0L/QvtC70Y8g0LHQvtGPINC+0LPQvdC10L3QvdGL0Lwg0YjRgtC+0YDQvNC+0LwnLFxuICAgICAgfSxcbiAgICBdLFxuICB9LFxuICB7XG4gICAgaWQ6ICdtZWNoYV9jYXQnLFxuICAgIG5hbWU6ICfQnNC10YXQsC3QmtC+0YIg0JrQldCa0KEnLFxuICAgIHRhZ2xpbmU6ICfQoNC+0LHQvtGC0LjQt9C40YDQvtCy0LDQvdC90YvQuSDQutC+0YIg0YEg0YDQsNC60LXRgtC90YvQvNC4INGD0YHRgtCw0L3QvtCy0LrQsNC80LgnLFxuICAgIGJhc2VDb3N0OiAzNTAsXG4gICAgdHlwZTogJ3NwbGFzaCcsXG4gICAgaWNvbjogJ/CfpJYnLFxuICAgIGJ1bGxldENvbG9yOiAnI2UxMWQ0OCcsXG4gICAgYnVsbGV0VHlwZTogJ3JvY2tldCcsXG4gICAgbGV2ZWxzOiBbXG4gICAgICB7XG4gICAgICAgIGxldmVsOiAwLFxuICAgICAgICBuYW1lOiAn0J/RgNC+0YLQvtGC0LjQvyDQnNC10YXQsC3Qm9Cw0L/RiycsXG4gICAgICAgIGNvc3Q6IDM1MCxcbiAgICAgICAgZGFtYWdlOiA2NSxcbiAgICAgICAgZmlyZVJhdGU6IDEuMCxcbiAgICAgICAgcmFuZ2U6IDE1NSxcbiAgICAgICAgc3BlY2lhbDogJ9Cg0LDQutC10YLQvdGL0Lkg0YHQv9C70LXRiC3Rg9C00LDRgCDQv9C+INC/0LvQvtGJ0LDQtNC4ICjRgNCw0LTQuNGD0YEgNTBweCknLFxuICAgICAgICBkZXNjcmlwdGlvbjogJ9CX0LDQv9GD0YHQutCw0LXRgiDRgtGP0LbQtdC70YvQtSDRgNCw0LrQtdGC0Ysg0LIg0YHQutC+0L/Qu9C10L3QuNGPINCy0YDQsNCz0L7QsicsXG4gICAgICB9LFxuICAgICAge1xuICAgICAgICBsZXZlbDogMSxcbiAgICAgICAgbmFtZTogJ9CR0L7QtdCy0L7QuSDQlNGA0L7QvS3QmtC+0YInLFxuICAgICAgICBjb3N0OiA2NTAsXG4gICAgICAgIGRhbWFnZTogMTQwLFxuICAgICAgICBmaXJlUmF0ZTogMC45LFxuICAgICAgICByYW5nZTogMTg1LFxuICAgICAgICBkZXNjcmlwdGlvbjogJ9Cj0LLQtdC70LjRh9C10L3QvdCw0Y8g0YHQutC+0YDQvtGB0YLRjCDQv9C+0LvQtdGC0LAg0YHQvdCw0YDRj9C00L7QsiDQuCDQv9C70L7RidCw0LTRjCDQstC30YDRi9Cy0LAnLFxuICAgICAgfSxcbiAgICAgIHtcbiAgICAgICAgbGV2ZWw6IDIsXG4gICAgICAgIG5hbWU6ICfQntGB0LDQtNC90YvQuSDQoNC+0LHQvi3Qn9Cw0L3RgtC10YDQsCcsXG4gICAgICAgIGNvc3Q6IDE0MDAsXG4gICAgICAgIGRhbWFnZTogMzEwLFxuICAgICAgICBmaXJlUmF0ZTogMC43OCxcbiAgICAgICAgcmFuZ2U6IDIyNSxcbiAgICAgICAgc3BlY2lhbDogJ9CU0LLQvtC50L3QsNGPINCx0L7QtdCz0L7Qu9C+0LLQutCwINC/0L4g0LHQvtGB0YHQsNC8JyxcbiAgICAgICAgZGVzY3JpcHRpb246ICfQmtGA0YPRiNC40YIg0YnQuNGC0Ysg0LHRgNC+0L3QuNGA0L7QstCw0L3QvdGL0YUg0L/RgNC+0YLQuNCy0L3QuNC60L7QsicsXG4gICAgICB9LFxuICAgICAge1xuICAgICAgICBsZXZlbDogMyxcbiAgICAgICAgbmFtZTogJ9Ci0LjRgtCw0L0g0JrQldCa0KEtMzAwMCcsXG4gICAgICAgIGNvc3Q6IDMxMDAsXG4gICAgICAgIGRhbWFnZTogNzUwLFxuICAgICAgICBmaXJlUmF0ZTogMC42NSxcbiAgICAgICAgcmFuZ2U6IDI3NSxcbiAgICAgICAgc3BlY2lhbDogJ9Ca0LDRgdGB0LXRgtC90YvQuSDQt9Cw0LvQvzogNCDQvNC40LrRgNC+LdGA0LDQutC10YLRiyDQt9CwINCy0YvRgdGC0YDQtdC7IScsXG4gICAgICAgIGRlc2NyaXB0aW9uOiAn0JDQsdGB0L7Qu9GO0YLQvdCw0Y8g0L7Qs9C90LXQstCw0Y8g0LzQvtGJ0Ywg0YHQtdC60YDQtdGC0L3QvtC5INC70LDQsdC+0YDQsNGC0L7RgNC40LgnLFxuICAgICAgfSxcbiAgICBdLFxuICB9LFxuICB7XG4gICAgaWQ6ICd0ZXNsYV93aXphcmQnLFxuICAgIG5hbWU6ICfQotC10YHQu9CwLdCc0LDQsyDQoNC+0LHQu9C+0LrRgdCwJyxcbiAgICB0YWdsaW5lOiAn0KbQtdC/0L3Ri9C1INGN0LvQtdC60YLRgNC40YfQtdGB0LrQuNC1INGA0LDQt9GA0Y/QtNGLINC4INGB0YLQsNC9JyxcbiAgICBiYXNlQ29zdDogMzIwLFxuICAgIHR5cGU6ICdkYW1hZ2UnLFxuICAgIGljb246ICfimqEnLFxuICAgIGJ1bGxldENvbG9yOiAnI2E4NTVmNycsXG4gICAgYnVsbGV0VHlwZTogJ2xpZ2h0bmluZycsXG4gICAgbGV2ZWxzOiBbXG4gICAgICB7XG4gICAgICAgIGxldmVsOiAwLFxuICAgICAgICBuYW1lOiAn0KPRh9C10L3QuNC6INCt0LvQtdC60YLRgNC40YfQtdGB0YLQstCwJyxcbiAgICAgICAgY29zdDogMzIwLFxuICAgICAgICBkYW1hZ2U6IDI4LFxuICAgICAgICBmaXJlUmF0ZTogMC41OCxcbiAgICAgICAgcmFuZ2U6IDEzNSxcbiAgICAgICAgc3BlY2lhbDogJ9Cm0LXQv9C90LDRjyDQtNGD0LPQsDog0LHRjNC10YIg0YHRgNCw0LfRgyDQv9C+IDMg0YbQtdC70Y/QvCDRgNGP0LTQvtC8JyxcbiAgICAgICAgZGVzY3JpcHRpb246ICfQk9C10L3QtdGA0LjRgNGD0LXRgiDQtNGD0LPQvtCy0L7QuSDRgNCw0LfRgNGP0LQg0YLQvtC60LAg0LzQtdC20LTRgyDQstGA0LDQs9Cw0LzQuCcsXG4gICAgICB9LFxuICAgICAge1xuICAgICAgICBsZXZlbDogMSxcbiAgICAgICAgbmFtZTogJ9Co0L7QutC+0LLRi9C5INCc0LDQs9C40YHRgtGAJyxcbiAgICAgICAgY29zdDogNjAwLFxuICAgICAgICBkYW1hZ2U6IDYwLFxuICAgICAgICBmaXJlUmF0ZTogMC40OCxcbiAgICAgICAgcmFuZ2U6IDE2MCxcbiAgICAgICAgc3BlY2lhbDogJ9Cm0LXQv9C90LDRjyDQtNGD0LPQsDog0LHRjNC10YIg0L/QviA0INGG0LXQu9GP0LwnLFxuICAgICAgICBkZXNjcmlwdGlvbjogJ9CS0YvRgdC+0LrQvtCy0L7Qu9GM0YLQvdGL0LUg0LjQvNC/0YPQu9GM0YHRiyDQv9GA0L7QsdC40LLQsNGO0YIg0YLQvtC70L/RgycsXG4gICAgICB9LFxuICAgICAge1xuICAgICAgICBsZXZlbDogMixcbiAgICAgICAgbmFtZTogJ9CQ0YDRhdC40LzQsNCzINCT0YDQvtC30YsnLFxuICAgICAgICBjb3N0OiAxMjUwLFxuICAgICAgICBkYW1hZ2U6IDEzNSxcbiAgICAgICAgZmlyZVJhdGU6IDAuNDIsXG4gICAgICAgIHJhbmdlOiAxOTAsXG4gICAgICAgIHNwZWNpYWw6ICfQptC10L/QvdCw0Y8g0LTRg9Cz0LA6IDYg0YbQtdC70LXQuSArINC80LjQutGA0L4t0L7Qs9C70YPRiNC10L3QuNC1JyxcbiAgICAgICAgZGVzY3JpcHRpb246ICfQoNCw0LfRgNGP0LTRiyDQv9Cw0YDQsNC70LjQt9GD0Y7RgiDQsdGL0YHRgtGA0YvRhSDQv9GA0L7RgtC40LLQvdC40LrQvtCyJyxcbiAgICAgIH0sXG4gICAgICB7XG4gICAgICAgIGxldmVsOiAzLFxuICAgICAgICBuYW1lOiAn0J/QvtCy0LXQu9C40YLQtdC70Ywg0KLQtdGB0LvQsC3QkdGD0YDQuCcsXG4gICAgICAgIGNvc3Q6IDI4MDAsXG4gICAgICAgIGRhbWFnZTogMzIwLFxuICAgICAgICBmaXJlUmF0ZTogMC4zNSxcbiAgICAgICAgcmFuZ2U6IDIzNSxcbiAgICAgICAgc3BlY2lhbDogJ9Co0LDRgNC+0LLQsNGPINC80L7Qu9C90LjRjzog0LHRjNC10YIg0LTQviA4INGG0LXQu9C10Lkg0YHQviDRgdGC0LDQvdC+0LwgMC410YEnLFxuICAgICAgICBkZXNjcmlwdGlvbjogJ9Cd0LXQv9GA0LXRgNGL0LLQvdCw0Y8g0LHRg9GA0Y8g0L/Qu9Cw0LfQvNGLINC/0LDRgNCw0LvQuNC30YPQtdGCINC70Y7QsdGL0LUg0LLQvtC70L3RiycsXG4gICAgICB9LFxuICAgIF0sXG4gIH0sXG4gIHtcbiAgICBpZDogJ25pbmphX2NhdCcsXG4gICAgbmFtZTogJ9Ca0L7Rgi3QqNC40L3QvtCx0LgnLFxuICAgIHRhZ2xpbmU6ICfQodC80LXRgNGC0L7QvdC+0YHQvdGL0LUg0YHRjtGA0LjQutC10L3RiyDQuCDQutGA0LjRgtC40YfQtdGB0LrQuNC1INGD0LTQsNGA0YsnLFxuICAgIGJhc2VDb3N0OiAyNDAsXG4gICAgdHlwZTogJ2RhbWFnZScsXG4gICAgaWNvbjogJ/CfpbcnLFxuICAgIGJ1bGxldENvbG9yOiAnIzEwYjk4MScsXG4gICAgYnVsbGV0VHlwZTogJ3NodXJpa2VuJyxcbiAgICBsZXZlbHM6IFtcbiAgICAgIHtcbiAgICAgICAgbGV2ZWw6IDAsXG4gICAgICAgIG5hbWU6ICfQo9GH0LXQvdC40Log0JTQvtC00LfRkScsXG4gICAgICAgIGNvc3Q6IDI0MCxcbiAgICAgICAgZGFtYWdlOiAxOCxcbiAgICAgICAgZmlyZVJhdGU6IDAuMzgsXG4gICAgICAgIHJhbmdlOiAxMjUsXG4gICAgICAgIHNwZWNpYWw6ICfQqNCw0L3RgSDQutGA0LjRgtCwIDM1JSAoeDEuNSDRg9GA0L7QvdCwKScsXG4gICAgICAgIGRlc2NyaXB0aW9uOiAn0JHRi9GB0YLRgNGL0LUg0LHRgNC+0YHQutC4INGB0YLQsNC70YzQvdGL0YUg0LfQstC10LfQtNC+0YfQtdC6JyxcbiAgICAgIH0sXG4gICAgICB7XG4gICAgICAgIGxldmVsOiAxLFxuICAgICAgICBuYW1lOiAn0KLQtdC90LXQstC+0Lkg0JrQvtGCJyxcbiAgICAgICAgY29zdDogNDYwLFxuICAgICAgICBkYW1hZ2U6IDQwLFxuICAgICAgICBmaXJlUmF0ZTogMC4zMixcbiAgICAgICAgcmFuZ2U6IDE0NSxcbiAgICAgICAgc3BlY2lhbDogJ9Co0LDQvdGBINC60YDQuNGC0LAgNDUlICh4MS44INGD0YDQvtC90LApJyxcbiAgICAgICAgZGVzY3JpcHRpb246ICfQntGC0YDQsNC20LDQtdGCINGB0Y7RgNC40LrQtdC90Ysg0YEg0YPQtNCy0L7QtdC90L3QvtC5INGB0LjQu9C+0LknLFxuICAgICAgfSxcbiAgICAgIHtcbiAgICAgICAgbGV2ZWw6IDIsXG4gICAgICAgIG5hbWU6ICfQnNCw0YHRgtC10YAg0J3QuNC90LTQt9GO0YbRgycsXG4gICAgICAgIGNvc3Q6IDEwNTAsXG4gICAgICAgIGRhbWFnZTogOTAsXG4gICAgICAgIGZpcmVSYXRlOiAwLjI4LFxuICAgICAgICByYW5nZTogMTcwLFxuICAgICAgICBzcGVjaWFsOiAn0KjQsNC90YEg0LrRgNC40YLQsCA1NSUgKHgyLjAg0YPRgNC+0L3QsCkgKyDQv9GA0L7QsdC40LLQsNC10YIg0YHQutGA0YvRgtC90L7RgdGC0YwnLFxuICAgICAgICBkZXNjcmlwdGlvbjogJ9Ch0LLQtdGA0YXQt9Cy0YPQutC+0LLRi9C1INCx0YDQvtGB0LrQuCDRgdC60LLQvtC30Ywg0LHRgNC+0L3RjicsXG4gICAgICB9LFxuICAgICAge1xuICAgICAgICBsZXZlbDogMyxcbiAgICAgICAgbmFtZTogJ9Cb0LXQs9C10L3QtNCw0YDQvdGL0Lkg0JPRgNCw0L3QtNC80LDRgdGC0LXRgCcsXG4gICAgICAgIGNvc3Q6IDIzMDAsXG4gICAgICAgIGRhbWFnZTogMjAwLFxuICAgICAgICBmaXJlUmF0ZTogMC4yMCxcbiAgICAgICAgcmFuZ2U6IDIwNSxcbiAgICAgICAgc3BlY2lhbDogJ9CS0LXQtdGAINGB0Y7RgNC40LrQtdC90L7Qsjog0LHRgNC+0YHQsNC10YIgMyDQt9Cy0LXQt9C00L7Rh9C60Lgg0LfQsCDRgNCw0LchJyxcbiAgICAgICAgZGVzY3JpcHRpb246ICfQnNC+0LvQvdC40LXQvdC+0YHQvdGL0Lkg0LLQuNGF0YDRjCDQvtGB0YLRgNGL0YUg0LrQu9C40L3QutC+0LInLFxuICAgICAgfSxcbiAgICBdLFxuICB9LFxuICB7XG4gICAgaWQ6ICdmcmVlemVfcGVuZ3VpbicsXG4gICAgbmFtZTogJ9Cb0LXQtNGP0L3QvtC5INCf0LjQvdCz0LLQuNC9JyxcbiAgICB0YWdsaW5lOiAn0JzQsNCz0LjRh9C10YHQutC40Lkg0YXQvtC70L7QtCDQuCDQstC10YfQvdCw0Y8g0LzQtdGA0LfQu9C+0YLQsCcsXG4gICAgYmFzZUNvc3Q6IDI3MCxcbiAgICB0eXBlOiAnc2xvdycsXG4gICAgaWNvbjogJ/CfkKcnLFxuICAgIGJ1bGxldENvbG9yOiAnIzA2YjZkNCcsXG4gICAgYnVsbGV0VHlwZTogJ2Zyb3N0JyxcbiAgICBsZXZlbHM6IFtcbiAgICAgIHtcbiAgICAgICAgbGV2ZWw6IDAsXG4gICAgICAgIG5hbWU6ICfQn9C40L3Qs9Cy0LjQvS3QodC60LDRg9GCJyxcbiAgICAgICAgY29zdDogMjcwLFxuICAgICAgICBkYW1hZ2U6IDEyLFxuICAgICAgICBmaXJlUmF0ZTogMC42NSxcbiAgICAgICAgcmFuZ2U6IDExNSxcbiAgICAgICAgc3BlY2lhbDogJ9CX0LDQvNC10LTQu9C10L3QuNC1IC0zNSUg0L3QsCAyLjUg0YHQtdC6JyxcbiAgICAgICAgZGVzY3JpcHRpb246ICfQodGC0YDQtdC70Y/QtdGCINGB0L3QtdC20LrQsNC80LgsINGB0LrQvtCy0YvQstCw0Y7RidC40LzQuCDQstGA0LDQs9C+0LInLFxuICAgICAgfSxcbiAgICAgIHtcbiAgICAgICAgbGV2ZWw6IDEsXG4gICAgICAgIG5hbWU6ICfQn9C+0LvRj9GA0L3Ri9C5INCg0LXQudC90LTQttC10YAnLFxuICAgICAgICBjb3N0OiA1MjAsXG4gICAgICAgIGRhbWFnZTogMjgsXG4gICAgICAgIGZpcmVSYXRlOiAwLjU1LFxuICAgICAgICByYW5nZTogMTM1LFxuICAgICAgICBzcGVjaWFsOiAn0JfQsNC80LXQtNC70LXQvdC40LUgLTUwJSDQvdCwIDMuMCDRgdC10LonLFxuICAgICAgICBkZXNjcmlwdGlvbjogJ9Cb0LXQtNGP0L3Ri9C1INC+0YHQutC+0LvQutC4INGA0LDRgdGB0LXQutCw0Y7RgiDQs9GA0YPQv9C/0YsnLFxuICAgICAgfSxcbiAgICAgIHtcbiAgICAgICAgbGV2ZWw6IDIsXG4gICAgICAgIG5hbWU6ICfQqNC10YDQuNGEINCQ0L3RgtCw0YDQutGC0LjQutC4JyxcbiAgICAgICAgY29zdDogMTE1MCxcbiAgICAgICAgZGFtYWdlOiA2NSxcbiAgICAgICAgZmlyZVJhdGU6IDAuNDgsXG4gICAgICAgIHJhbmdlOiAxNjUsXG4gICAgICAgIHNwZWNpYWw6ICfQm9C10LTRj9C90L7QuSDRiNGC0L7RgNC8OiDQt9Cw0LzQtdC00LvQtdC90LjQtSAtNjAlINC/0L4g0L/Qu9C+0YnQsNC00LgnLFxuICAgICAgICBkZXNjcmlwdGlvbjogJ9Ce0LrRg9GC0YvQstCw0LXRgiDQstGA0LDQs9C+0LIg0YHQuNCx0LjRgNGB0LrQvtC5INC80LXRgtC10LvRjNGOJyxcbiAgICAgIH0sXG4gICAgICB7XG4gICAgICAgIGxldmVsOiAzLFxuICAgICAgICBuYW1lOiAn0J/QvtCy0LXQu9C40YLQtdC70Ywg0JHQu9C40LfQt9Cw0YDQtNCwJyxcbiAgICAgICAgY29zdDogMjUwMCxcbiAgICAgICAgZGFtYWdlOiAxNTUsXG4gICAgICAgIGZpcmVSYXRlOiAwLjM4LFxuICAgICAgICByYW5nZTogMTk1LFxuICAgICAgICBzcGVjaWFsOiAn0JDQsdGB0L7Qu9GO0YLQvdGL0Lkg0L3QvtC70Yw6INC30LDQvNC+0YDQvtC30LrQsCDQvdCwINC80LXRgdGC0LUg0L3QsCAx0YEgKyDQt9Cw0LzQtdC00LvQtdC90LjQtSA3MCUnLFxuICAgICAgICBkZXNjcmlwdGlvbjogJ9Cf0YDQtdCy0YDQsNGJ0LDQtdGCINC/0L7Qu9C1INCx0L7RjyDQsiDQvdC10L/RgNC+0YXQvtC00LjQvNGL0Lkg0LvQtdC00L3QuNC6JyxcbiAgICAgIH0sXG4gICAgXSxcbiAgfSxcbl07XG5cbmV4cG9ydCBjb25zdCBTS0lOU19EQVRBOiBTa2luW10gPSBbXG4gIHtcbiAgICBpZDogJ2NhdF90aHVnX2xpZmUnLFxuICAgIHRvd2VySWQ6ICdjYXQnLFxuICAgIG5hbWU6ICdUaHVnIExpZmUgUGl4ZWwgKNCe0YDQuNCz0LjQvdCw0LspJyxcbiAgICByYXJpdHk6ICdMZWdlbmRhcnknLFxuICAgIGNvc3RDb2luczogMCwgLy8gRGVmYXVsdCBmcmVlIHN0YXJ0ZXJcbiAgICBjb3N0R2VtczogMCxcbiAgICBpbWFnZTogQ0FUX0lNQUdFX1VSTCxcbiAgICBkZXNjcmlwdGlvbjogJ9Cb0LXQs9C10L3QtNCw0YDQvdGL0Lkg0LrRgNGD0YLQvtC5INC60L7RgiDQsiA4LdCx0LjRgtC90YvRhSDRgdC+0LvQvdGG0LXQt9Cw0YnQuNGC0L3Ri9GFINC+0YfQutCw0YUnLFxuICAgIGJhZGdlQ29sb3I6ICcjMzhiZGY4JyxcbiAgfSxcbiAge1xuICAgIGlkOiAnY2F0X2N5YmVycHVuaycsXG4gICAgdG93ZXJJZDogJ2NhdCcsXG4gICAgbmFtZTogJ9Ca0LjQsdC10YDQv9Cw0L3QuiDQndC10L7QvScsXG4gICAgcmFyaXR5OiAnRXBpYycsXG4gICAgY29zdENvaW5zOiAxNTAwLFxuICAgIGNvc3RHZW1zOiA3NSxcbiAgICBkZXNjcmlwdGlvbjogJ9Cd0LXQvtC90L7QstGL0LUg0LLQuNC30L7RgNGLLCDRhdGA0L7QvNC40YDQvtCy0LDQvdC90YvQtSDQutC+0LPRgtC4INC4INGE0LjQvtC70LXRgtC+0LLRi9C1INC70LDQt9C10YDRiycsXG4gICAgYmFkZ2VDb2xvcjogJyNjMDg0ZmMnLFxuICB9LFxuICB7XG4gICAgaWQ6ICdjYXRfZ29sZGVuX2tpbmcnLFxuICAgIHRvd2VySWQ6ICdjYXQnLFxuICAgIG5hbWU6ICfQl9C+0LvQvtGC0L7QuSDQmtC+0YDQvtC70Ywg0JzQtdC80L7QsicsXG4gICAgcmFyaXR5OiAnTXl0aGljJyxcbiAgICBjb3N0Q29pbnM6IDUwMDAsXG4gICAgY29zdEdlbXM6IDI1MCxcbiAgICBkZXNjcmlwdGlvbjogJ9Ca0L7RgNC+0L3QsCDQuNC3INGH0LjRgdGC0LXQudGI0LXQs9C+INC30L7Qu9C+0YLQsCDQuCDQutGA0LjRgdGC0LDQu9C70L7QsiDQoNC+0LHQu9C+0LrRgdCwJyxcbiAgICBiYWRnZUNvbG9yOiAnI2ZhY2MxNScsXG4gIH0sXG4gIHtcbiAgICBpZDogJ2NhdF9zcGFjZV9zdWl0JyxcbiAgICB0b3dlcklkOiAnY2F0JyxcbiAgICBuYW1lOiAn0JDRgdGC0YDQvi3QmtC+0YIgMzAwMCcsXG4gICAgcmFyaXR5OiAnUmFyZScsXG4gICAgY29zdENvaW5zOiA4MDAsXG4gICAgY29zdEdlbXM6IDQwLFxuICAgIGRlc2NyaXB0aW9uOiAn0JPQtdGA0LzQtdGC0LjRh9C90YvQuSDRiNC70LXQvCDQtNC70Y8g0LrQvtGB0LzQuNGH0LXRgdC60LjRhSDQstC+0LvQvSDQt9Cw0YnQuNGC0YsnLFxuICAgIGJhZGdlQ29sb3I6ICcjNjBhNWZhJyxcbiAgfSxcbiAge1xuICAgIGlkOiAnbm9vYl9nb2xkZW5fa25pZ2h0JyxcbiAgICB0b3dlcklkOiAnbm9vYl9rbmlnaHQnLFxuICAgIG5hbWU6ICfQl9C+0LvQvtGC0L7QuSDQoNGL0YbQsNGA0Ywg0JTQvtC80LjQvdGD0YEnLFxuICAgIHJhcml0eTogJ0xlZ2VuZGFyeScsXG4gICAgY29zdENvaW5zOiAzMDAwLFxuICAgIGNvc3RHZW1zOiAxNTAsXG4gICAgZGVzY3JpcHRpb246ICfQmNC90LrRgNGD0YHRgtC40YDQvtCy0LDQvdC90YvQuSDRiNC70LXQvCDQlNC+0LzQuNC90YPRgSDQuCDQv9C70LDQvNC10L3QvdGL0Lkg0LzQvtC70L7RgicsXG4gICAgYmFkZ2VDb2xvcjogJyNmNTllMGInLFxuICB9LFxuICB7XG4gICAgaWQ6ICdkal9uZW9uX3BhcnR5JyxcbiAgICB0b3dlcklkOiAnZGpfYmxveCcsXG4gICAgbmFtZTogJ0hvbG8tREog0JLQuNC90LjQuycsXG4gICAgcmFyaXR5OiAnRXBpYycsXG4gICAgY29zdENvaW5zOiAyMDAwLFxuICAgIGNvc3RHZW1zOiA5MCxcbiAgICBkZXNjcmlwdGlvbjogJ9CT0L7Qu9C+0LPRgNCw0YTQuNGH0LXRgdC60LjQtSDQv9C70LDRgdGC0LjQvdC60Lgg0Lgg0YHQstC10YLQvtC80YPQt9GL0LrQsCcsXG4gICAgYmFkZ2VDb2xvcjogJyNlYzQ4OTknLFxuICB9LFxuXTtcblxuZXhwb3J0IGNvbnN0IEFDSElFVkVNRU5UU19EQVRBOiBBY2hpZXZlbWVudFtdID0gW1xuICB7XG4gICAgaWQ6ICdmaXJzdF9jYXQnLFxuICAgIHRpdGxlOiAn0J/QtdGA0LLQsNGPINC70LDQv9C60LAnLFxuICAgIGRlc2NyaXB0aW9uOiAn0KDQsNC30LzQtdGB0YLQuNGC0LUg0L3QsNGH0LDQu9GM0L3Rg9GOINCx0LDRiNC90Y4gXCLQmtC+0YJcIicsXG4gICAgaWNvbjogJ/CfkL4nLFxuICAgIHJld2FyZENvaW5zOiAyMDAsXG4gICAgcmV3YXJkR2VtczogMTAsXG4gICAgcHJvZ3Jlc3M6IDAsXG4gICAgbWF4UHJvZ3Jlc3M6IDEsXG4gICAgY2xhaW1lZDogZmFsc2UsXG4gIH0sXG4gIHtcbiAgICBpZDogJ2NhdF9sZXZlbF8xJyxcbiAgICB0aXRsZTogJ9Cf0LXRgNCy0LDRjyDRgdGC0YPQv9C10L3RjCcsXG4gICAgZGVzY3JpcHRpb246ICfQo9C70YPRh9GI0LjRgtC1INCa0L7RgtCwINC00L4gMS3Qs9C+INGD0YDQvtCy0L3RjyAoJDMwMCwgNyDRg9GA0L7QvdCwL9GB0LXQuiknLFxuICAgIGljb246ICfimqEnLFxuICAgIHJld2FyZENvaW5zOiAzMDAsXG4gICAgcmV3YXJkR2VtczogMTUsXG4gICAgcHJvZ3Jlc3M6IDAsXG4gICAgbWF4UHJvZ3Jlc3M6IDEsXG4gICAgY2xhaW1lZDogZmFsc2UsXG4gIH0sXG4gIHtcbiAgICBpZDogJ2NhdF9tYXhfc2xvdycsXG4gICAgdGl0bGU6ICfQm9C10LTRj9C90L7QuSBUaHVnIExpZmUnLFxuICAgIGRlc2NyaXB0aW9uOiAn0J/RgNC+0LrQsNGH0LDQudGC0LUg0JrQvtGC0LAg0LTQviAzLdCz0L4g0YPRgNC+0LLQvdGPINGBINGN0YTRhNC10LrRgtC+0Lwg0LfQsNC80LXQtNC70LXQvdC40Y8gKDUwINGD0YDQvtC90LAsIDMw0LwpJyxcbiAgICBpY29uOiAn4p2E77iPJyxcbiAgICByZXdhcmRDb2luczogMTAwMCxcbiAgICByZXdhcmRHZW1zOiA1MCxcbiAgICBwcm9ncmVzczogMCxcbiAgICBtYXhQcm9ncmVzczogMSxcbiAgICBjbGFpbWVkOiBmYWxzZSxcbiAgfSxcbiAge1xuICAgIGlkOiAnd2F2ZXNfMTUnLFxuICAgIHRpdGxlOiAn0JfQsNGJ0LjRgtC90LjQuiDQkdCw0LfRiycsXG4gICAgZGVzY3JpcHRpb246ICfQn9GA0L7QudC00LjRgtC1IDE1INCy0L7Qu9C9INC90LAg0LvRjtCx0L7QuSDRgdC70L7QttC90L7RgdGC0LgnLFxuICAgIGljb246ICfwn5uh77iPJyxcbiAgICByZXdhcmRDb2luczogNTAwLFxuICAgIHJld2FyZEdlbXM6IDI1LFxuICAgIHByb2dyZXNzOiAwLFxuICAgIG1heFByb2dyZXNzOiAxNSxcbiAgICBjbGFpbWVkOiBmYWxzZSxcbiAgfSxcbiAge1xuICAgIGlkOiAnYm9zc19zbGF5ZXInLFxuICAgIHRpdGxlOiAn0JPRgNC+0LfQsCDQkdC+0YHRgdC+0LInLFxuICAgIGRlc2NyaXB0aW9uOiAn0KPQvdC40YfRgtC+0LbRjNGC0LUgNSDQs9C70LDQstC90YvRhSDQsdC+0YHRgdC+0LInLFxuICAgIGljb246ICfwn5GRJyxcbiAgICByZXdhcmRDb2luczogODAwLFxuICAgIHJld2FyZEdlbXM6IDQwLFxuICAgIHByb2dyZXNzOiAwLFxuICAgIG1heFByb2dyZXNzOiA1LFxuICAgIGNsYWltZWQ6IGZhbHNlLFxuICB9LFxuICB7XG4gICAgaWQ6ICdjbGFuX2pvaW4nLFxuICAgIHRpdGxlOiAn0KHQuNC70LAg0JrQu9Cw0L3QsCcsXG4gICAgZGVzY3JpcHRpb246ICfQktGB0YLRg9C/0LjRgtC1INCyINC60LvQsNC9INC40LvQuCDRgdC+0LfQtNCw0LnRgtC1INGB0LLQvtC5JyxcbiAgICBpY29uOiAn8J+PsCcsXG4gICAgcmV3YXJkQ29pbnM6IDQwMCxcbiAgICByZXdhcmRHZW1zOiAyMCxcbiAgICBwcm9ncmVzczogMCxcbiAgICBtYXhQcm9ncmVzczogMSxcbiAgICBjbGFpbWVkOiBmYWxzZSxcbiAgfSxcbiAge1xuICAgIGlkOiAnY29vcF92aWN0b3J5JyxcbiAgICB0aXRsZTogJ9Cf0LvQtdGH0L7QvCDQuiDQv9C70LXRh9GDJyxcbiAgICBkZXNjcmlwdGlvbjogJ9Ce0LTQtdGA0LbQuNGC0LUg0L/QvtCx0LXQtNGDINCyINC60L7QvtC/0LXRgNCw0YLQuNCy0L3QvtC8INGA0LXQttC40LzQtSDRgSDQtNGA0YPQs9C+0LwnLFxuICAgIGljb246ICfwn6SdJyxcbiAgICByZXdhcmRDb2luczogMTIwMCxcbiAgICByZXdhcmRHZW1zOiA2MCxcbiAgICBwcm9ncmVzczogMCxcbiAgICBtYXhQcm9ncmVzczogMSxcbiAgICBjbGFpbWVkOiBmYWxzZSxcbiAgfSxcbiAge1xuICAgIGlkOiAnc2tpbl9jb2xsZWN0b3InLFxuICAgIHRpdGxlOiAn0JzQvtC00L3Ri9C5INCc0L7QtNC90LjQuicsXG4gICAgZGVzY3JpcHRpb246ICfQoNCw0LfQsdC70L7QutC40YDRg9C50YLQtSAzINGA0LDQt9C90YvRhSDRgdC60LjQvdCwINCyINC80LDQs9Cw0LfQuNC90LUnLFxuICAgIGljb246ICfinKgnLFxuICAgIHJld2FyZENvaW5zOiAxNTAwLFxuICAgIHJld2FyZEdlbXM6IDc1LFxuICAgIHByb2dyZXNzOiAxLFxuICAgIG1heFByb2dyZXNzOiAzLFxuICAgIGNsYWltZWQ6IGZhbHNlLFxuICB9LFxuXTtcblxuZXhwb3J0IGNvbnN0IElOSVRJQUxfQ0xBTlM6IENsYW5bXSA9IFtcbiAge1xuICAgIGlkOiAnY2F0X2NhcnRlbCcsXG4gICAgbmFtZTogJ9Ca0L7RiNCw0YfQuNC5INCa0LDRgNGC0LXQu9GMJyxcbiAgICB0YWc6ICdDQVRaJyxcbiAgICBiYWRnZTogJ/CfkLHwn5GRJyxcbiAgICBkZXNjcmlwdGlvbjogJ9Ci0L7Qvy0xINC60LvQsNC9INC70Y7QsdC40YLQtdC70LXQuSDQutC+0YLQvtCyINCyINC+0YfQutCw0YUhINCU0LXQu9C40LzRgdGPINGC0LDQutGC0LjQutCw0LzQuCDQuCDQsdGM0LXQvCDQvNC40YDQvtCy0YvQtSDRgNC10LrQvtGA0LTRiy4nLFxuICAgIGxldmVsOiA3LFxuICAgIHhwOiAyODQwLFxuICAgIG1lbWJlcnNDb3VudDogMjksXG4gICAgbWF4TWVtYmVyczogMzAsXG4gICAgbGVhZGVyTmFtZTogJ1RodWdDYXRfU3VwcmVtZScsXG4gICAgcmF0aW5nU2NvcmU6IDk0MjAwLFxuICAgIHBlcmtzOiB7XG4gICAgICBib251c0dvbGRQZXJjZW50OiAxMixcbiAgICAgIGJvbnVzRGFtYWdlUGVyY2VudDogOCxcbiAgICB9LFxuICAgIHdlZWtseVF1ZXN0OiB7XG4gICAgICB0aXRsZTogJ9Cj0L3QuNGH0YLQvtC20LjRgtGMIDEwMDAg0LLRgNCw0LPQvtCyINCa0L7RgtC+0LwgMy3Qs9C+INGD0YDQvtCy0L3RjycsXG4gICAgICBwcm9ncmVzczogNzQyLFxuICAgICAgZ29hbDogMTAwMCxcbiAgICAgIHJld2FyZEdlbXM6IDIwMCxcbiAgICB9LFxuICB9LFxuICB7XG4gICAgaWQ6ICdibG94X2d1YXJkaWFucycsXG4gICAgbmFtZTogJ9Ch0YLRgNCw0LbQuCDQoNC+0LHQu9C+0LrRgdCwJyxcbiAgICB0YWc6ICdCTE9YJyxcbiAgICBiYWRnZTogJ/Cfm6HvuI/impTvuI8nLFxuICAgIGRlc2NyaXB0aW9uOiAn0KXQsNGA0LTQutC+0YDQvdGL0LUg0LLQtdGC0LXRgNCw0L3RiyBUb3dlciBEZWZlbnNlLiDQn9C+0LzQvtCz0LDQtdC8INC90L7QstC40YfQutCw0Lwg0L/RgNC+0YXQvtC00LjRgtGMINGB0LvQvtC20L3QtdC50YjQuNC1INC60LDRgNGC0YsuJyxcbiAgICBsZXZlbDogNixcbiAgICB4cDogMTk1MCxcbiAgICBtZW1iZXJzQ291bnQ6IDI0LFxuICAgIG1heE1lbWJlcnM6IDMwLFxuICAgIGxlYWRlck5hbWU6ICdWaXBlclhfUHJvJyxcbiAgICByYXRpbmdTY29yZTogNzg1MDAsXG4gICAgcGVya3M6IHtcbiAgICAgIGJvbnVzR29sZFBlcmNlbnQ6IDEwLFxuICAgICAgYm9udXNEYW1hZ2VQZXJjZW50OiA2LFxuICAgIH0sXG4gICAgd2Vla2x5UXVlc3Q6IHtcbiAgICAgIHRpdGxlOiAn0J/RgNC+0LnRgtC4IDUwINCy0L7Qu9C9INC90LAg0KXQsNGA0LTQutC+0YDQtScsXG4gICAgICBwcm9ncmVzczogMzgsXG4gICAgICBnb2FsOiA1MCxcbiAgICAgIHJld2FyZEdlbXM6IDE4MCxcbiAgICB9LFxuICB9LFxuICB7XG4gICAgaWQ6ICdjeWJlcl9zeW5kaWNhdGUnLFxuICAgIG5hbWU6ICfQmtC40LHQtdGAINCh0LjQvdC00LjQutCw0YInLFxuICAgIHRhZzogJ0NZQkVSJyxcbiAgICBiYWRnZTogJ/CfpJbimqEnLFxuICAgIGRlc2NyaXB0aW9uOiAn0KLQtdGF0L3Qvi3Qs9C10L3QuNC4INGBINC+0L/RgtC40YfQtdGB0LrQuNC80Lgg0LvQsNC30LXRgNCw0LzQuCDQuCDRgNC+0LHQvtGC0LDQvNC4LicsXG4gICAgbGV2ZWw6IDUsXG4gICAgeHA6IDE0MjAsXG4gICAgbWVtYmVyc0NvdW50OiAxOCxcbiAgICBtYXhNZW1iZXJzOiAyNSxcbiAgICBsZWFkZXJOYW1lOiAnTmVvbkJ5dGUnLFxuICAgIHJhdGluZ1Njb3JlOiA1NjMwMCxcbiAgICBwZXJrczoge1xuICAgICAgYm9udXNHb2xkUGVyY2VudDogOCxcbiAgICAgIGJvbnVzRGFtYWdlUGVyY2VudDogNSxcbiAgICB9LFxuICAgIHdlZWtseVF1ZXN0OiB7XG4gICAgICB0aXRsZTogJ9Cd0LDQvdC10YHRgtC4IDUwLDAwMCDRg9GA0L7QvdCwINCx0L7RgdGB0LDQvCcsXG4gICAgICBwcm9ncmVzczogMzIxMDAsXG4gICAgICBnb2FsOiA1MDAwMCxcbiAgICAgIHJld2FyZEdlbXM6IDE1MCxcbiAgICB9LFxuICB9LFxuXTtcblxuZXhwb3J0IGNvbnN0IFdFRUtMWV9DSEFMTEVOR0VfREFUQTogV2Vla2x5Q2hhbGxlbmdlID0ge1xuICBpZDogJ2NhdF9hcG9jYWx5cHNlX3dlZWsnLFxuICB0aXRsZTogJ9Ca0L7RiNCw0YfQuNC5INCi0YDQuNGD0LzRhDog0KLQvtC70YzQutC+INCa0L7RgtGLIScsXG4gIHRoZW1lOiAn0J7RgdC+0LHQvtC1INCY0YHQv9GL0YLQsNC90LjQtSDQndC10LTQtdC70LgnLFxuICBkZXNjcmlwdGlvbjogJ9Cd0LAg0L/QvtC70LUg0LHQvtGPINGA0LDQt9GA0LXRiNC10L3QviDRgdGC0LDQstC40YLRjCDQotCe0JvQrNCa0J4g0LrQvtGI0LDRh9GM0Lgg0LHQsNGI0L3QuCEg0JLRgdC1INC60L7RgtGLINC/0L7Qu9GD0YfQsNGO0YIgKzI1JSDQtNCw0LvRjNC90L7RgdGC0LgsINCwINCy0YDQsNCz0Lgg0LTQstC40LPQsNGO0YLRgdGPINC90LAgMjAlINCx0YvRgdGC0YDQtdC1LicsXG4gIG1vZGlmaWVyczogW1xuICAgICfQotC+0LvRjNC60L4g0LHQsNGI0L3QuCBcItCa0L7RglwiINC4IFwi0JrQvtGCLdCR0LDQvdC60LjRgFwiJyxcbiAgICAn0JLRgNCw0LPQuCDQvdCwIDIwJSDQsdGL0YHRgtGA0LXQtScsXG4gICAgJ9Ca0L7RgiAzLdCz0L4g0YPRgNC+0LLQvdGPINC30LDQvNC10LTQu9GP0LXRgiDQvdCwIDU1JSDQstC80LXRgdGC0L4gNDAlJyxcbiAgICAnKzUwJSDQt9C+0LvQvtGC0LAg0LfQsCDQutCw0LbQtNC+0LPQviDRg9Cx0LjRgtC+0LPQviDQsdC+0YHRgdCwJyxcbiAgXSxcbiAgcmVzdHJpY3RlZFRvd2VyczogWydjYXQnLCAnYmFua2VyX2NhdCddLFxuICByZXdhcmRDb2luczogMzUwMCxcbiAgcmV3YXJkR2VtczogMTUwLFxuICB0cm9waHlOYW1lOiAn0JfQvtC70L7RgtC+0Lkg0JrRg9Cx0L7QuiDQnNC10LzQvdC+0LPQviDQmtC+0YLQsCcsXG4gIHRhcmdldFdhdmU6IDI1LFxuICBlbmRzSW5EYXlzOiA0LFxufTtcblxuZXhwb3J0IGNvbnN0IElOSVRJQUxfTk9USUZJQ0FUSU9OUzogSW5HYW1lTm90aWZpY2F0aW9uW10gPSBbXG4gIHtcbiAgICBpZDogJ25vdGlmXzEnLFxuICAgIHRpdGxlOiAn8J+OiSDQntCx0L3QvtCy0LvQtdC90LjQtTog0JrQvtGCINCyINC+0YfQutCw0YUg0L/RgNC40LHRi9C7IScsXG4gICAgbWVzc2FnZTogJ9CS0YHRgtGA0LXRh9Cw0LnRgtC1INC70LXQs9C10L3QtNCw0YDQvdC+0LPQviDRgdGC0LDRgNGC0L7QstC+0LPQviDQs9C10YDQvtGPINGBINC/0YDQvtCz0YDQtdGB0YHQuNCy0L3QvtC5INC/0YDQvtC60LDRh9C60L7QuSDRg9GA0L7QvdCwINC4INC30LDQvNC10LTQu9C10L3QuNGPIScsXG4gICAgdHlwZTogJ3Byb21vJyxcbiAgICB0aW1lc3RhbXA6ICfQodC10LPQvtC00L3RjywgMTA6MDAnLFxuICAgIHJlYWQ6IGZhbHNlLFxuICAgIGJhZGdlOiAnTkVXJyxcbiAgfSxcbiAge1xuICAgIGlkOiAnbm90aWZfMicsXG4gICAgdGl0bGU6ICfwn5KOINClMiDQmtC10YjQsdGN0Log0L3QsCDQtNC+0L3QsNGCLdC60YDQuNGB0YLQsNC70LvRiycsXG4gICAgbWVzc2FnZTogJ9Cf0L7Qu9GD0YfQsNC50YLQtSAxMCUg0LLQvtC30LLRgNCw0YLQsCDQsiDQsdC+0L3Rg9GB0L3Ri9GFINC80L7QvdC10YLQsNGFINC30LAg0LrQsNC20LTRg9GOINC/0L7QutGD0L/QutGDINGH0LXRgNC10Lcg0KHQkdCfINC40LvQuCDQutCw0YDRgtGLIScsXG4gICAgdHlwZTogJ3Byb21vJyxcbiAgICB0aW1lc3RhbXA6ICfQktGH0LXRgNCwLCAxODozMCcsXG4gICAgcmVhZDogZmFsc2UsXG4gICAgYmFkZ2U6ICdIT1QnLFxuICB9LFxuICB7XG4gICAgaWQ6ICdub3RpZl8zJyxcbiAgICB0aXRsZTogJ/CfpJ0g0JrQvtC+0L/QtdGA0LDRgtC40LLQvdGL0Lkg0YDQtdC20LjQvCDQs9C+0YLQvtCyINC6INCx0L7RjicsXG4gICAgbWVzc2FnZTogJ9Ch0L7Qt9C00LDQudGC0LUg0LvQvtCx0LHQuCDQuCDQt9C+0LLQuNGC0LUg0LTRgNGD0LfQtdC5INC40LvQuCDQuNCz0YDQsNC50YLQtSDRgSDQsNCy0YLQvtC80LDRgtC40YfQtdGB0LrQuNC8INC/0L7QtNCx0L7RgNC+0Lwg0L3QsNC/0LDRgNC90LjQutC+0LIuJyxcbiAgICB0eXBlOiAnc3lzdGVtJyxcbiAgICB0aW1lc3RhbXA6ICcyINC00L3RjyDQvdCw0LfQsNC0JyxcbiAgICByZWFkOiB0cnVlLFxuICB9LFxuXTtcblxuZXhwb3J0IGNvbnN0IElOSVRJQUxfREFJTFlfUkVXQVJEUyA9IFtcbiAgeyBkYXk6IDEsIGNvaW5zOiAyNTAsIGdlbXM6IDEwLCBsYWJlbDogJ9CU0LXQvdGMIDEnLCBpY29uOiAn8J+qmScgfSxcbiAgeyBkYXk6IDIsIGNvaW5zOiA1MDAsIGdlbXM6IDIwLCBsYWJlbDogJ9CU0LXQvdGMIDInLCBpY29uOiAn8J+SjicgfSxcbiAgeyBkYXk6IDMsIGNvaW5zOiA4MDAsIGdlbXM6IDM1LCBsYWJlbDogJ9CU0LXQvdGMIDMnLCBpY29uOiAn8J+SsCcgfSxcbiAgeyBkYXk6IDQsIGNvaW5zOiAxMjAwLCBnZW1zOiA1MCwgbGFiZWw6ICfQlNC10L3RjCA0JywgaWNvbjogJ+KaoScgfSxcbiAgeyBkYXk6IDUsIGNvaW5zOiAxODAwLCBnZW1zOiA3NSwgbGFiZWw6ICfQlNC10L3RjCA1JywgaWNvbjogJ/CfjoEnIH0sXG4gIHsgZGF5OiA2LCBjb2luczogMjUwMCwgZ2VtczogMTAwLCBsYWJlbDogJ9CU0LXQvdGMIDYnLCBpY29uOiAn8J+PhicgfSxcbiAgeyBkYXk6IDcsIGNvaW5zOiA1MDAwLCBnZW1zOiAyMDAsIHNwZWNpYWxTa2luOiAnY2F0X2N5YmVycHVuaycsIGxhYmVsOiAn0JTQtdC90YwgNyAo0KHRg9C/0LXRgC3Qv9GA0LjQtyknLCBpY29uOiAn8J+RkScgfSxcbl07XG4iXX0=