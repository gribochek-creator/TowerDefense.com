const JSZip = __vite__cjsImport0_jszip;import __vite__cjsImport0_jszip from "/node_modules/.vite/deps/jszip.js?v=cf727c30";
import { CAT_IMAGE_URL } from "/src/data/constants.ts";
// Bundled text file contents for full source export
export async function downloadNetlifyProjectZip(onProgress) {
	const zip = new JSZip();
	onProgress?.("Подготовка файлов конфигурации Netlify...");
	// Netlify config
	zip.file("netlify.toml", `[build]
  command = "npm run build"
  publish = "dist"

[[redirects]]
  from = "/*"
  to = "/index.html"
  status = 200
`);
	// Public folder
	const publicFolder = zip.folder("public");
	publicFolder?.file("_redirects", "/*    /index.html   200\n");
	// Try fetching the Cat Image Asset and bundle it into the zip
	try {
		onProgress?.("Упаковка ассетов и изображения кота...");
		const response = await fetch(CAT_IMAGE_URL);
		if (response.ok) {
			const blob = await response.blob();
			const assetsFolder = zip.folder("public/assets/aistudio");
			assetsFolder?.file("5dcbe384-37cd-4f73-b297-5b25fdabce95_9dc95acb.jpg", blob);
		}
	} catch {}
	onProgress?.("Сборка исходного кода React и компонентов...");
	// README for Netlify deployer
	zip.file("README_NETLIFY.md", `# Roblox Tower Defense: Cat Hero Edition
Специальная сборка для развертывания на **Netlify**.

## Быстрый деплой на Netlify (2 варианта):

### Вариант 1: Через Netlify Drop (за 30 секунд без консоли)
1. Выполните локально команду \`npm install && npm run build\`.
2. Откройте в браузере [https://app.netlify.com/drop](https://app.netlify.com/drop).
3. Перетащите получившуюся папку \`dist\` в окно браузера.
4. Игра мгновенно запустится онлайн!

### Вариант 2: Через GitHub / Netlify Git Import
1. Загрузите файлы этого архива в ваш GitHub репозиторий.
2. В Netlify нажмите **"Add new site"** -> **"Import an existing project"** -> выберите репозиторий.
3. Команда сборки (\`npm run build\`) и папка (\`dist\`) уже автоматически настроены в файле \`netlify.toml\`!
4. Нажмите **"Deploy site"**!
`);
	// Root configuration files
	zip.file("package.json", JSON.stringify({
		name: "roblox-tower-defense-cat",
		private: true,
		version: "1.0.0",
		type: "module",
		scripts: {
			dev: "vite",
			build: "vite build",
			preview: "vite preview"
		},
		dependencies: {
			"canvas-confetti": "^1.9.4",
			"jszip": "^3.10.1",
			"lucide-react": "^0.546.0",
			"motion": "^12.23.24",
			"react": "^19.0.0",
			"react-dom": "^19.0.0"
		},
		devDependencies: {
			"@tailwindcss/vite": "^4.3.3",
			"@types/canvas-confetti": "^1.9.0",
			"@types/jszip": "^3.4.1",
			"@types/node": "^22.14.0",
			"@types/react": "^19.0.0",
			"@types/react-dom": "^19.0.0",
			"@vitejs/plugin-react": "^6.1.1",
			"tailwindcss": "^4.3.3",
			"typescript": "^7.0.2",
			"vite": "^8.3.0"
		}
	}, null, 2));
	zip.file("vite.config.ts", `import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import path from 'path';
import { defineConfig } from 'vite';

export default defineConfig({
  plugins: [react(), tailwindcss()],
  resolve: {
    alias: {
      '@': path.resolve(__dirname, '.'),
    },
  },
});
`);
	zip.file("tsconfig.json", `{
  "compilerOptions": {
    "target": "ES2022",
    "module": "ESNext",
    "lib": ["ES2022", "DOM", "DOM.Iterable"],
    "skipLibCheck": true,
    "moduleResolution": "bundler",
    "isolatedModules": true,
    "moduleDetection": "force",
    "jsx": "react-jsx",
    "paths": {
      "@/*": ["./*"]
    },
    "noEmit": true
  },
  "exclude": ["dist", "node_modules"]
}
`);
	zip.file("index.html", `<!doctype html>
<html lang="ru">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Roblox Tower Defense: Cat Hero Edition</title>
    <meta name="description" content="Эпический Roblox Tower Defense с легендарным котом в очках, прокачкой, скинами, коопом, кланами и еженедельными испытаниями." />
    <link rel="icon" type="image/jpeg" href="/assets/aistudio/5dcbe384-37cd-4f73-b297-5b25fdabce95_9dc95acb.jpg" />
  </head>
  <body class="bg-slate-950 text-slate-100 antialiased overflow-x-hidden">
    <div id="root"></div>
    <script type="module" src="/src/main.tsx"><\/script>
  </body>
</html>
`);
	// Fetch or pack active source files dynamically from Vite
	onProgress?.("Упаковка скриптов, стилей и логики башен...");
	const sourcePaths = [
		"/src/main.tsx",
		"/src/index.css",
		"/src/App.tsx",
		"/src/types/game.ts",
		"/src/data/constants.ts",
		"/src/utils/sound.ts",
		"/src/utils/storage.ts",
		"/src/utils/exportProject.ts",
		"/src/components/Navbar.tsx",
		"/src/components/GameCanvas.tsx",
		"/src/components/TowerDock.tsx",
		"/src/components/TowerControls.tsx",
		"/src/components/DailyRewardsModal.tsx",
		"/src/components/ShopModal.tsx",
		"/src/components/ClansModal.tsx",
		"/src/components/WeeklyChallengesModal.tsx",
		"/src/components/CoopLobbyModal.tsx",
		"/src/components/LeaderboardModal.tsx",
		"/src/components/AchievementsModal.tsx",
		"/src/components/ProfileModal.tsx",
		"/src/components/NotificationsModal.tsx",
		"/src/components/GameOverModal.tsx",
		"/src/components/SecretHintModal.tsx",
		"/src/components/SecretUnlockedModal.tsx",
		"/src/components/NetlifyDownloadModal.tsx"
	];
	for (const p of sourcePaths) {
		try {
			const res = await fetch(p);
			if (res.ok) {
				const text = await res.text();
				const zipPath = p.startsWith("/") ? p.substring(1) : p;
				zip.file(zipPath, text);
			}
		} catch {}
	}
	onProgress?.("Генерация ZIP архива для скачивания...");
	const content = await zip.generateAsync({
		type: "blob",
		compression: "DEFLATE",
		compressionOptions: { level: 6 }
	});
	// Trigger file download
	const downloadUrl = URL.createObjectURL(content);
	const a = document.createElement("a");
	a.href = downloadUrl;
	a.download = "roblox-tower-defense-cat-netlify.zip";
	document.body.appendChild(a);
	a.click();
	document.body.removeChild(a);
	setTimeout(() => URL.revokeObjectURL(downloadUrl), 4e3);
	onProgress?.("Готово! Архив загружен.");
}

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxXQUFXO0FBQ2xCLFNBQVMscUJBQXFCOztBQUc5QixPQUFPLGVBQWUsMEJBQTBCLFlBQW9DO0NBQ2xGLE1BQU0sTUFBTSxJQUFJLE1BQU07Q0FFdEIsYUFBYSwyQ0FBMkM7O0NBR3hELElBQUksS0FDRixnQkFDQTs7Ozs7Ozs7Q0FTRjs7Q0FHQSxNQUFNLGVBQWUsSUFBSSxPQUFPLFFBQVE7Q0FDeEMsY0FBYyxLQUFLLGNBQWMsMkJBQTJCOztDQUc1RCxJQUFJO0VBQ0YsYUFBYSx3Q0FBd0M7RUFDckQsTUFBTSxXQUFXLE1BQU0sTUFBTSxhQUFhO0VBQzFDLElBQUksU0FBUyxJQUFJO0dBQ2YsTUFBTSxPQUFPLE1BQU0sU0FBUyxLQUFLO0dBQ2pDLE1BQU0sZUFBZSxJQUFJLE9BQU8sd0JBQXdCO0dBQ3hELGNBQWMsS0FBSyxxREFBcUQsSUFBSTtFQUM5RTtDQUNGLFFBQVEsQ0FFUjtDQUVBLGFBQWEsOENBQThDOztDQUczRCxJQUFJLEtBQ0YscUJBQ0E7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FpQkY7O0NBR0EsSUFBSSxLQUNGLGdCQUNBLEtBQUssVUFDSDtFQUNFLE1BQU07RUFDTixTQUFTO0VBQ1QsU0FBUztFQUNULE1BQU07RUFDTixTQUFTO0dBQ1AsS0FBSztHQUNMLE9BQU87R0FDUCxTQUFTO0VBQ1g7RUFDQSxjQUFjO0dBQ1osbUJBQW1CO0dBQ25CLFNBQVM7R0FDVCxnQkFBZ0I7R0FDaEIsVUFBVTtHQUNWLFNBQVM7R0FDVCxhQUFhO0VBQ2Y7RUFDQSxpQkFBaUI7R0FDZixxQkFBcUI7R0FDckIsMEJBQTBCO0dBQzFCLGdCQUFnQjtHQUNoQixlQUFlO0dBQ2YsZ0JBQWdCO0dBQ2hCLG9CQUFvQjtHQUNwQix3QkFBd0I7R0FDeEIsZUFBZTtHQUNmLGNBQWM7R0FDZCxRQUFRO0VBQ1Y7Q0FDRixHQUNBLE1BQ0EsQ0FDRixDQUNGO0NBRUEsSUFBSSxLQUNGLGtCQUNBOzs7Ozs7Ozs7Ozs7O0NBY0Y7Q0FFQSxJQUFJLEtBQ0YsaUJBQ0E7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBa0JGO0NBRUEsSUFBSSxLQUNGLGNBQ0E7Ozs7Ozs7Ozs7Ozs7O0NBZUY7O0NBR0EsYUFBYSw2Q0FBNkM7Q0FFMUQsTUFBTSxjQUFjO0VBQ2xCO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0NBQ0Y7Q0FFQSxLQUFLLE1BQU0sS0FBSyxhQUFhO0VBQzNCLElBQUk7R0FDRixNQUFNLE1BQU0sTUFBTSxNQUFNLENBQUM7R0FDekIsSUFBSSxJQUFJLElBQUk7SUFDVixNQUFNLE9BQU8sTUFBTSxJQUFJLEtBQUs7SUFDNUIsTUFBTSxVQUFVLEVBQUUsV0FBVyxHQUFHLElBQUksRUFBRSxVQUFVLENBQUMsSUFBSTtJQUNyRCxJQUFJLEtBQUssU0FBUyxJQUFJO0dBQ3hCO0VBQ0YsUUFBUSxDQUVSO0NBQ0Y7Q0FFQSxhQUFhLHdDQUF3QztDQUVyRCxNQUFNLFVBQVUsTUFBTSxJQUFJLGNBQWM7RUFDdEMsTUFBTTtFQUNOLGFBQWE7RUFDYixvQkFBb0IsRUFBRSxPQUFPLEVBQUU7Q0FDakMsQ0FBQzs7Q0FHRCxNQUFNLGNBQWMsSUFBSSxnQkFBZ0IsT0FBTztDQUMvQyxNQUFNLElBQUksU0FBUyxjQUFjLEdBQUc7Q0FDcEMsRUFBRSxPQUFPO0NBQ1QsRUFBRSxXQUFXO0NBQ2IsU0FBUyxLQUFLLFlBQVksQ0FBQztDQUMzQixFQUFFLE1BQU07Q0FDUixTQUFTLEtBQUssWUFBWSxDQUFDO0NBQzNCLGlCQUFpQixJQUFJLGdCQUFnQixXQUFXLEdBQUcsR0FBSTtDQUV2RCxhQUFhLHlCQUF5QjtBQUN4QyIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJleHBvcnRQcm9qZWN0LnRzIl0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBKU1ppcCBmcm9tICdqc3ppcCc7XG5pbXBvcnQgeyBDQVRfSU1BR0VfVVJMIH0gZnJvbSAnLi4vZGF0YS9jb25zdGFudHMnO1xuXG4vLyBCdW5kbGVkIHRleHQgZmlsZSBjb250ZW50cyBmb3IgZnVsbCBzb3VyY2UgZXhwb3J0XG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZG93bmxvYWROZXRsaWZ5UHJvamVjdFppcChvblByb2dyZXNzPzogKG1zZzogc3RyaW5nKSA9PiB2b2lkKSB7XG4gIGNvbnN0IHppcCA9IG5ldyBKU1ppcCgpO1xuXG4gIG9uUHJvZ3Jlc3M/Lign0J/QvtC00LPQvtGC0L7QstC60LAg0YTQsNC50LvQvtCyINC60L7QvdGE0LjQs9GD0YDQsNGG0LjQuCBOZXRsaWZ5Li4uJyk7XG5cbiAgLy8gTmV0bGlmeSBjb25maWdcbiAgemlwLmZpbGUoXG4gICAgJ25ldGxpZnkudG9tbCcsXG4gICAgYFtidWlsZF1cbiAgY29tbWFuZCA9IFwibnBtIHJ1biBidWlsZFwiXG4gIHB1Ymxpc2ggPSBcImRpc3RcIlxuXG5bW3JlZGlyZWN0c11dXG4gIGZyb20gPSBcIi8qXCJcbiAgdG8gPSBcIi9pbmRleC5odG1sXCJcbiAgc3RhdHVzID0gMjAwXG5gXG4gICk7XG5cbiAgLy8gUHVibGljIGZvbGRlclxuICBjb25zdCBwdWJsaWNGb2xkZXIgPSB6aXAuZm9sZGVyKCdwdWJsaWMnKTtcbiAgcHVibGljRm9sZGVyPy5maWxlKCdfcmVkaXJlY3RzJywgJy8qICAgIC9pbmRleC5odG1sICAgMjAwXFxuJyk7XG5cbiAgLy8gVHJ5IGZldGNoaW5nIHRoZSBDYXQgSW1hZ2UgQXNzZXQgYW5kIGJ1bmRsZSBpdCBpbnRvIHRoZSB6aXBcbiAgdHJ5IHtcbiAgICBvblByb2dyZXNzPy4oJ9Cj0L/QsNC60L7QstC60LAg0LDRgdGB0LXRgtC+0LIg0Lgg0LjQt9C+0LHRgNCw0LbQtdC90LjRjyDQutC+0YLQsC4uLicpO1xuICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgZmV0Y2goQ0FUX0lNQUdFX1VSTCk7XG4gICAgaWYgKHJlc3BvbnNlLm9rKSB7XG4gICAgICBjb25zdCBibG9iID0gYXdhaXQgcmVzcG9uc2UuYmxvYigpO1xuICAgICAgY29uc3QgYXNzZXRzRm9sZGVyID0gemlwLmZvbGRlcigncHVibGljL2Fzc2V0cy9haXN0dWRpbycpO1xuICAgICAgYXNzZXRzRm9sZGVyPy5maWxlKCc1ZGNiZTM4NC0zN2NkLTRmNzMtYjI5Ny01YjI1ZmRhYmNlOTVfOWRjOTVhY2IuanBnJywgYmxvYik7XG4gICAgfVxuICB9IGNhdGNoIHtcbiAgICAvLyBJZiBvZmZsaW5lLCBjb250aW51ZSB3aXRob3V0IGJyZWFraW5nXG4gIH1cblxuICBvblByb2dyZXNzPy4oJ9Ch0LHQvtGA0LrQsCDQuNGB0YXQvtC00L3QvtCz0L4g0LrQvtC00LAgUmVhY3Qg0Lgg0LrQvtC80L/QvtC90LXQvdGC0L7Qsi4uLicpO1xuXG4gIC8vIFJFQURNRSBmb3IgTmV0bGlmeSBkZXBsb3llclxuICB6aXAuZmlsZShcbiAgICAnUkVBRE1FX05FVExJRlkubWQnLFxuICAgIGAjIFJvYmxveCBUb3dlciBEZWZlbnNlOiBDYXQgSGVybyBFZGl0aW9uXG7QodC/0LXRhtC40LDQu9GM0L3QsNGPINGB0LHQvtGA0LrQsCDQtNC70Y8g0YDQsNC30LLQtdGA0YLRi9Cy0LDQvdC40Y8g0L3QsCAqKk5ldGxpZnkqKi5cblxuIyMg0JHRi9GB0YLRgNGL0Lkg0LTQtdC/0LvQvtC5INC90LAgTmV0bGlmeSAoMiDQstCw0YDQuNCw0L3RgtCwKTpcblxuIyMjINCS0LDRgNC40LDQvdGCIDE6INCn0LXRgNC10LcgTmV0bGlmeSBEcm9wICjQt9CwIDMwINGB0LXQutGD0L3QtCDQsdC10Lcg0LrQvtC90YHQvtC70LgpXG4xLiDQktGL0L/QvtC70L3QuNGC0LUg0LvQvtC60LDQu9GM0L3QviDQutC+0LzQsNC90LTRgyBcXGBucG0gaW5zdGFsbCAmJiBucG0gcnVuIGJ1aWxkXFxgLlxuMi4g0J7RgtC60YDQvtC50YLQtSDQsiDQsdGA0LDRg9C30LXRgNC1IFtodHRwczovL2FwcC5uZXRsaWZ5LmNvbS9kcm9wXShodHRwczovL2FwcC5uZXRsaWZ5LmNvbS9kcm9wKS5cbjMuINCf0LXRgNC10YLQsNGJ0LjRgtC1INC/0L7Qu9GD0YfQuNCy0YjRg9GO0YHRjyDQv9Cw0L/QutGDIFxcYGRpc3RcXGAg0LIg0L7QutC90L4g0LHRgNCw0YPQt9C10YDQsC5cbjQuINCY0LPRgNCwINC80LPQvdC+0LLQtdC90L3QviDQt9Cw0L/Rg9GB0YLQuNGC0YHRjyDQvtC90LvQsNC50L0hXG5cbiMjIyDQktCw0YDQuNCw0L3RgiAyOiDQp9C10YDQtdC3IEdpdEh1YiAvIE5ldGxpZnkgR2l0IEltcG9ydFxuMS4g0JfQsNCz0YDRg9C30LjRgtC1INGE0LDQudC70Ysg0Y3RgtC+0LPQviDQsNGA0YXQuNCy0LAg0LIg0LLQsNGIIEdpdEh1YiDRgNC10L/QvtC30LjRgtC+0YDQuNC5LlxuMi4g0JIgTmV0bGlmeSDQvdCw0LbQvNC40YLQtSAqKlwiQWRkIG5ldyBzaXRlXCIqKiAtPiAqKlwiSW1wb3J0IGFuIGV4aXN0aW5nIHByb2plY3RcIioqIC0+INCy0YvQsdC10YDQuNGC0LUg0YDQtdC/0L7Qt9C40YLQvtGA0LjQuS5cbjMuINCa0L7QvNCw0L3QtNCwINGB0LHQvtGA0LrQuCAoXFxgbnBtIHJ1biBidWlsZFxcYCkg0Lgg0L/QsNC/0LrQsCAoXFxgZGlzdFxcYCkg0YPQttC1INCw0LLRgtC+0LzQsNGC0LjRh9C10YHQutC4INC90LDRgdGC0YDQvtC10L3RiyDQsiDRhNCw0LnQu9C1IFxcYG5ldGxpZnkudG9tbFxcYCFcbjQuINCd0LDQttC80LjRgtC1ICoqXCJEZXBsb3kgc2l0ZVwiKiohXG5gXG4gICk7XG5cbiAgLy8gUm9vdCBjb25maWd1cmF0aW9uIGZpbGVzXG4gIHppcC5maWxlKFxuICAgICdwYWNrYWdlLmpzb24nLFxuICAgIEpTT04uc3RyaW5naWZ5KFxuICAgICAge1xuICAgICAgICBuYW1lOiBcInJvYmxveC10b3dlci1kZWZlbnNlLWNhdFwiLFxuICAgICAgICBwcml2YXRlOiB0cnVlLFxuICAgICAgICB2ZXJzaW9uOiBcIjEuMC4wXCIsXG4gICAgICAgIHR5cGU6IFwibW9kdWxlXCIsXG4gICAgICAgIHNjcmlwdHM6IHtcbiAgICAgICAgICBkZXY6IFwidml0ZVwiLFxuICAgICAgICAgIGJ1aWxkOiBcInZpdGUgYnVpbGRcIixcbiAgICAgICAgICBwcmV2aWV3OiBcInZpdGUgcHJldmlld1wiXG4gICAgICAgIH0sXG4gICAgICAgIGRlcGVuZGVuY2llczoge1xuICAgICAgICAgIFwiY2FudmFzLWNvbmZldHRpXCI6IFwiXjEuOS40XCIsXG4gICAgICAgICAgXCJqc3ppcFwiOiBcIl4zLjEwLjFcIixcbiAgICAgICAgICBcImx1Y2lkZS1yZWFjdFwiOiBcIl4wLjU0Ni4wXCIsXG4gICAgICAgICAgXCJtb3Rpb25cIjogXCJeMTIuMjMuMjRcIixcbiAgICAgICAgICBcInJlYWN0XCI6IFwiXjE5LjAuMFwiLFxuICAgICAgICAgIFwicmVhY3QtZG9tXCI6IFwiXjE5LjAuMFwiXG4gICAgICAgIH0sXG4gICAgICAgIGRldkRlcGVuZGVuY2llczoge1xuICAgICAgICAgIFwiQHRhaWx3aW5kY3NzL3ZpdGVcIjogXCJeNC4zLjNcIixcbiAgICAgICAgICBcIkB0eXBlcy9jYW52YXMtY29uZmV0dGlcIjogXCJeMS45LjBcIixcbiAgICAgICAgICBcIkB0eXBlcy9qc3ppcFwiOiBcIl4zLjQuMVwiLFxuICAgICAgICAgIFwiQHR5cGVzL25vZGVcIjogXCJeMjIuMTQuMFwiLFxuICAgICAgICAgIFwiQHR5cGVzL3JlYWN0XCI6IFwiXjE5LjAuMFwiLFxuICAgICAgICAgIFwiQHR5cGVzL3JlYWN0LWRvbVwiOiBcIl4xOS4wLjBcIixcbiAgICAgICAgICBcIkB2aXRlanMvcGx1Z2luLXJlYWN0XCI6IFwiXjYuMS4xXCIsXG4gICAgICAgICAgXCJ0YWlsd2luZGNzc1wiOiBcIl40LjMuM1wiLFxuICAgICAgICAgIFwidHlwZXNjcmlwdFwiOiBcIl43LjAuMlwiLFxuICAgICAgICAgIFwidml0ZVwiOiBcIl44LjMuMFwiXG4gICAgICAgIH1cbiAgICAgIH0sXG4gICAgICBudWxsLFxuICAgICAgMlxuICAgIClcbiAgKTtcblxuICB6aXAuZmlsZShcbiAgICAndml0ZS5jb25maWcudHMnLFxuICAgIGBpbXBvcnQgdGFpbHdpbmRjc3MgZnJvbSAnQHRhaWx3aW5kY3NzL3ZpdGUnO1xuaW1wb3J0IHJlYWN0IGZyb20gJ0B2aXRlanMvcGx1Z2luLXJlYWN0JztcbmltcG9ydCBwYXRoIGZyb20gJ3BhdGgnO1xuaW1wb3J0IHsgZGVmaW5lQ29uZmlnIH0gZnJvbSAndml0ZSc7XG5cbmV4cG9ydCBkZWZhdWx0IGRlZmluZUNvbmZpZyh7XG4gIHBsdWdpbnM6IFtyZWFjdCgpLCB0YWlsd2luZGNzcygpXSxcbiAgcmVzb2x2ZToge1xuICAgIGFsaWFzOiB7XG4gICAgICAnQCc6IHBhdGgucmVzb2x2ZShfX2Rpcm5hbWUsICcuJyksXG4gICAgfSxcbiAgfSxcbn0pO1xuYFxuICApO1xuXG4gIHppcC5maWxlKFxuICAgICd0c2NvbmZpZy5qc29uJyxcbiAgICBge1xuICBcImNvbXBpbGVyT3B0aW9uc1wiOiB7XG4gICAgXCJ0YXJnZXRcIjogXCJFUzIwMjJcIixcbiAgICBcIm1vZHVsZVwiOiBcIkVTTmV4dFwiLFxuICAgIFwibGliXCI6IFtcIkVTMjAyMlwiLCBcIkRPTVwiLCBcIkRPTS5JdGVyYWJsZVwiXSxcbiAgICBcInNraXBMaWJDaGVja1wiOiB0cnVlLFxuICAgIFwibW9kdWxlUmVzb2x1dGlvblwiOiBcImJ1bmRsZXJcIixcbiAgICBcImlzb2xhdGVkTW9kdWxlc1wiOiB0cnVlLFxuICAgIFwibW9kdWxlRGV0ZWN0aW9uXCI6IFwiZm9yY2VcIixcbiAgICBcImpzeFwiOiBcInJlYWN0LWpzeFwiLFxuICAgIFwicGF0aHNcIjoge1xuICAgICAgXCJALypcIjogW1wiLi8qXCJdXG4gICAgfSxcbiAgICBcIm5vRW1pdFwiOiB0cnVlXG4gIH0sXG4gIFwiZXhjbHVkZVwiOiBbXCJkaXN0XCIsIFwibm9kZV9tb2R1bGVzXCJdXG59XG5gXG4gICk7XG5cbiAgemlwLmZpbGUoXG4gICAgJ2luZGV4Lmh0bWwnLFxuICAgIGA8IWRvY3R5cGUgaHRtbD5cbjxodG1sIGxhbmc9XCJydVwiPlxuICA8aGVhZD5cbiAgICA8bWV0YSBjaGFyc2V0PVwiVVRGLThcIiAvPlxuICAgIDxtZXRhIG5hbWU9XCJ2aWV3cG9ydFwiIGNvbnRlbnQ9XCJ3aWR0aD1kZXZpY2Utd2lkdGgsIGluaXRpYWwtc2NhbGU9MS4wXCIgLz5cbiAgICA8dGl0bGU+Um9ibG94IFRvd2VyIERlZmVuc2U6IENhdCBIZXJvIEVkaXRpb248L3RpdGxlPlxuICAgIDxtZXRhIG5hbWU9XCJkZXNjcmlwdGlvblwiIGNvbnRlbnQ9XCLQrdC/0LjRh9C10YHQutC40LkgUm9ibG94IFRvd2VyIERlZmVuc2Ug0YEg0LvQtdCz0LXQvdC00LDRgNC90YvQvCDQutC+0YLQvtC8INCyINC+0YfQutCw0YUsINC/0YDQvtC60LDRh9C60L7QuSwg0YHQutC40L3QsNC80LgsINC60L7QvtC/0L7QvCwg0LrQu9Cw0L3QsNC80Lgg0Lgg0LXQttC10L3QtdC00LXQu9GM0L3Ri9C80Lgg0LjRgdC/0YvRgtCw0L3QuNGP0LzQuC5cIiAvPlxuICAgIDxsaW5rIHJlbD1cImljb25cIiB0eXBlPVwiaW1hZ2UvanBlZ1wiIGhyZWY9XCIvYXNzZXRzL2Fpc3R1ZGlvLzVkY2JlMzg0LTM3Y2QtNGY3My1iMjk3LTViMjVmZGFiY2U5NV85ZGM5NWFjYi5qcGdcIiAvPlxuICA8L2hlYWQ+XG4gIDxib2R5IGNsYXNzPVwiYmctc2xhdGUtOTUwIHRleHQtc2xhdGUtMTAwIGFudGlhbGlhc2VkIG92ZXJmbG93LXgtaGlkZGVuXCI+XG4gICAgPGRpdiBpZD1cInJvb3RcIj48L2Rpdj5cbiAgICA8c2NyaXB0IHR5cGU9XCJtb2R1bGVcIiBzcmM9XCIvc3JjL21haW4udHN4XCI+PC9zY3JpcHQ+XG4gIDwvYm9keT5cbjwvaHRtbD5cbmBcbiAgKTtcblxuICAvLyBGZXRjaCBvciBwYWNrIGFjdGl2ZSBzb3VyY2UgZmlsZXMgZHluYW1pY2FsbHkgZnJvbSBWaXRlXG4gIG9uUHJvZ3Jlc3M/Lign0KPQv9Cw0LrQvtCy0LrQsCDRgdC60YDQuNC/0YLQvtCyLCDRgdGC0LjQu9C10Lkg0Lgg0LvQvtCz0LjQutC4INCx0LDRiNC10L0uLi4nKTtcblxuICBjb25zdCBzb3VyY2VQYXRocyA9IFtcbiAgICAnL3NyYy9tYWluLnRzeCcsXG4gICAgJy9zcmMvaW5kZXguY3NzJyxcbiAgICAnL3NyYy9BcHAudHN4JyxcbiAgICAnL3NyYy90eXBlcy9nYW1lLnRzJyxcbiAgICAnL3NyYy9kYXRhL2NvbnN0YW50cy50cycsXG4gICAgJy9zcmMvdXRpbHMvc291bmQudHMnLFxuICAgICcvc3JjL3V0aWxzL3N0b3JhZ2UudHMnLFxuICAgICcvc3JjL3V0aWxzL2V4cG9ydFByb2plY3QudHMnLFxuICAgICcvc3JjL2NvbXBvbmVudHMvTmF2YmFyLnRzeCcsXG4gICAgJy9zcmMvY29tcG9uZW50cy9HYW1lQ2FudmFzLnRzeCcsXG4gICAgJy9zcmMvY29tcG9uZW50cy9Ub3dlckRvY2sudHN4JyxcbiAgICAnL3NyYy9jb21wb25lbnRzL1Rvd2VyQ29udHJvbHMudHN4JyxcbiAgICAnL3NyYy9jb21wb25lbnRzL0RhaWx5UmV3YXJkc01vZGFsLnRzeCcsXG4gICAgJy9zcmMvY29tcG9uZW50cy9TaG9wTW9kYWwudHN4JyxcbiAgICAnL3NyYy9jb21wb25lbnRzL0NsYW5zTW9kYWwudHN4JyxcbiAgICAnL3NyYy9jb21wb25lbnRzL1dlZWtseUNoYWxsZW5nZXNNb2RhbC50c3gnLFxuICAgICcvc3JjL2NvbXBvbmVudHMvQ29vcExvYmJ5TW9kYWwudHN4JyxcbiAgICAnL3NyYy9jb21wb25lbnRzL0xlYWRlcmJvYXJkTW9kYWwudHN4JyxcbiAgICAnL3NyYy9jb21wb25lbnRzL0FjaGlldmVtZW50c01vZGFsLnRzeCcsXG4gICAgJy9zcmMvY29tcG9uZW50cy9Qcm9maWxlTW9kYWwudHN4JyxcbiAgICAnL3NyYy9jb21wb25lbnRzL05vdGlmaWNhdGlvbnNNb2RhbC50c3gnLFxuICAgICcvc3JjL2NvbXBvbmVudHMvR2FtZU92ZXJNb2RhbC50c3gnLFxuICAgICcvc3JjL2NvbXBvbmVudHMvU2VjcmV0SGludE1vZGFsLnRzeCcsXG4gICAgJy9zcmMvY29tcG9uZW50cy9TZWNyZXRVbmxvY2tlZE1vZGFsLnRzeCcsXG4gICAgJy9zcmMvY29tcG9uZW50cy9OZXRsaWZ5RG93bmxvYWRNb2RhbC50c3gnLFxuICBdO1xuXG4gIGZvciAoY29uc3QgcCBvZiBzb3VyY2VQYXRocykge1xuICAgIHRyeSB7XG4gICAgICBjb25zdCByZXMgPSBhd2FpdCBmZXRjaChwKTtcbiAgICAgIGlmIChyZXMub2spIHtcbiAgICAgICAgY29uc3QgdGV4dCA9IGF3YWl0IHJlcy50ZXh0KCk7XG4gICAgICAgIGNvbnN0IHppcFBhdGggPSBwLnN0YXJ0c1dpdGgoJy8nKSA/IHAuc3Vic3RyaW5nKDEpIDogcDtcbiAgICAgICAgemlwLmZpbGUoemlwUGF0aCwgdGV4dCk7XG4gICAgICB9XG4gICAgfSBjYXRjaCB7XG4gICAgICAvLyBDb250aW51ZSBwYWNraW5nXG4gICAgfVxuICB9XG5cbiAgb25Qcm9ncmVzcz8uKCfQk9C10L3QtdGA0LDRhtC40Y8gWklQINCw0YDRhdC40LLQsCDQtNC70Y8g0YHQutCw0YfQuNCy0LDQvdC40Y8uLi4nKTtcblxuICBjb25zdCBjb250ZW50ID0gYXdhaXQgemlwLmdlbmVyYXRlQXN5bmMoe1xuICAgIHR5cGU6ICdibG9iJyxcbiAgICBjb21wcmVzc2lvbjogJ0RFRkxBVEUnLFxuICAgIGNvbXByZXNzaW9uT3B0aW9uczogeyBsZXZlbDogNiB9LFxuICB9KTtcblxuICAvLyBUcmlnZ2VyIGZpbGUgZG93bmxvYWRcbiAgY29uc3QgZG93bmxvYWRVcmwgPSBVUkwuY3JlYXRlT2JqZWN0VVJMKGNvbnRlbnQpO1xuICBjb25zdCBhID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnYScpO1xuICBhLmhyZWYgPSBkb3dubG9hZFVybDtcbiAgYS5kb3dubG9hZCA9ICdyb2Jsb3gtdG93ZXItZGVmZW5zZS1jYXQtbmV0bGlmeS56aXAnO1xuICBkb2N1bWVudC5ib2R5LmFwcGVuZENoaWxkKGEpO1xuICBhLmNsaWNrKCk7XG4gIGRvY3VtZW50LmJvZHkucmVtb3ZlQ2hpbGQoYSk7XG4gIHNldFRpbWVvdXQoKCkgPT4gVVJMLnJldm9rZU9iamVjdFVSTChkb3dubG9hZFVybCksIDQwMDApO1xuXG4gIG9uUHJvZ3Jlc3M/Lign0JPQvtGC0L7QstC+ISDQkNGA0YXQuNCyINC30LDQs9GA0YPQttC10L0uJyk7XG59XG4iXX0=