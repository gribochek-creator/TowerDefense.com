# Roblox Tower Defense: Cat Hero Edition
Специальная сборка для развертывания на **Netlify**.

## Быстрый деплой на Netlify (2 варианта):

### Вариант 1: Через Netlify Drop (за 30 секунд без консоли)
1. Выполните локально команду `npm install && npm run build`.
2. Откройте в браузере [https://app.netlify.com/drop](https://app.netlify.com/drop).
3. Перетащите получившуюся папку `dist` в окно браузера.
4. Игра мгновенно запустится онлайн!

### Вариант 2: Через GitHub / Netlify Git Import
1. Загрузите файлы этого архива в ваш GitHub репозиторий.
2. В Netlify нажмите **"Add new site"** -> **"Import an existing project"** -> выберите репозиторий.
3. Команда сборки (`npm run build`) и папка (`dist`) уже автоматически настроены в файле `netlify.toml`!
4. Нажмите **"Deploy site"**!
